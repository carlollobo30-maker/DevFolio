<?php
/**
 * Faculty Dashboard
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/review-helpers.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'faculty') {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$pendingCount = dfPendingCount($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-image: url('../assets/img/background.jpg');
            background-position: center center;
            background-repeat: no-repeat;
            background-size: cover;
            background-attachment: fixed;
            color: #0f172a;
        }
        .content-shell {
            background: rgba(255, 255, 255, 0.22);
            backdrop-filter: none;
            min-height: calc(100vh - 88px);
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
            box-shadow: 0 8px 18px rgba(11, 35, 77, 0.18);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 260px;
        }
        .ccdi-mark {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #ffffff;
            border: 4px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(11,35,77,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(2.1rem, 2vw, 3rem);
            font-weight: 900;
            letter-spacing: 0.01em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.8rem 1.2rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1.05rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: linear-gradient(180deg, #f8c75e 0%, #f2ae1c 100%);
            color: #121826;
            box-shadow: 0 6px 18px rgba(242, 174, 28, 0.35);
        }
        .nav-link.red {
            background: linear-gradient(180deg, #ff5a5a 0%, #e53935 100%);
            color: #fff;
            border: none;
            box-shadow: 0 6px 18px rgba(229, 57, 53, 0.35);
        }
        .nav-link.red:hover {
            background: linear-gradient(180deg, #f25050 0%, #d62e2e 100%);
            color: #fff;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;
            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
            .ccdi-wordmark {
                font-size: 1.9rem;
            }
        }
        .page-bg-video {
            position: fixed;
            top: 50%;
            left: 50%;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: -1;
            transform: translate(-50%, -50%);
            object-fit: cover;
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <!-- Navigation -->
        <nav class="ccdi-header text-white p-5 shadow-lg">
            <div class="max-w-6xl mx-auto flex justify-between items-center gap-4 flex-wrap">
                <div class="ccdi-logo-wrap">
                    <div class="ccdi-mark">
                        <img src="../assets/img/ccdi_2.jpg" alt="CCDI logo">
                    </div>
                    <div class="ccdi-wordmark">DEVFOLIO</div>
                </div>

                <div class="ccdi-nav">
                    <a href="dashboard.php" class="nav-link active">Dashboard</a>
                    <a href="review-queue.php" class="nav-link">Review Pending Projects<?php if ($pendingCount > 0): ?> <span class="ml-2 bg-red-600 text-white text-xs font-black rounded-full px-2 py-0.5"><?php echo $pendingCount; ?></span><?php endif; ?></a>
                    <a href="student-list.php" class="nav-link">Student Directory</a>
                    <form method="POST" action="dashboard.php" class="inline">
                        <button type="submit" name="logout" value="1" class="nav-link red border-0 cursor-pointer">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="content-shell">
            <div class="max-w-6xl mx-auto px-4 py-8">
                <!-- Welcome Section -->
                <div class="bg-white/90 rounded-2xl border border-slate-200 shadow-sm p-8 mb-8">
                    <h2 class="text-3xl font-black text-slate-800 mb-3">Faculty Review & Accreditation Portal</h2>
                    <p class="text-lg text-slate-700 font-medium">Logged in as: <span class="text-slate-900 font-bold">Prof. E. Ramos, MSIT</span> (Capstone Coordinator)</p>
                </div>

                <!-- Statistics -->
                <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-slate-500 text-sm">Total Defended</p>
                                <h3 class="text-3xl font-bold text-slate-900">128</h3>
                            </div>
                            <i class="fa-solid fa-award text-4xl text-blue-500 opacity-20"></i>
                        </div>
                    </div>
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-slate-500 text-sm">Showcased</p>
                                <h3 class="text-3xl font-bold text-emerald-600">120 <span class="text-lg font-semibold text-slate-600">(94%)</span></h3>
                            </div>
                            <i class="fa-solid fa-chart-pie text-4xl text-emerald-500 opacity-20"></i>
                        </div>
                    </div>
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-slate-500 text-sm">Pending Review</p>
                                <h3 class="text-3xl font-bold text-amber-600"><?php echo $pendingCount; ?></h3>
                            </div>
                            <i class="fa-solid fa-hourglass text-4xl text-amber-500 opacity-20"></i>
                        </div>
                    </div>
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <p class="text-slate-500 text-sm">Employer Inquiries</p>
                                <h3 class="text-3xl font-bold text-purple-600">45</h3>
                            </div>
                            <i class="fa-solid fa-briefcase text-4xl text-purple-500 opacity-20"></i>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mb-8">
                    <h3 class="text-2xl font-black text-slate-900 mb-5">Quick Actions</h3>
                    <div class="flex flex-wrap gap-3">
                        <a href="review-queue.php" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-6 py-3 rounded-lg transition shadow-sm text-lg">
                            <i class="fa-solid fa-list-check mr-2"></i>Review Pending Projects
                        </a>
                        <button class="bg-blue-500 hover:bg-blue-600 text-white font-bold px-6 py-3 rounded-lg transition shadow-sm text-lg">
                            <i class="fa-solid fa-file-pdf mr-2"></i>Export Accreditation Report
                        </button>
                        <a href="student-list.php" class="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold px-6 py-3 rounded-lg transition shadow-sm text-lg">
                            <i class="fa-solid fa-users mr-2"></i>View All Students
                        </a>
                    </div>
                </div>

                <!-- Program Distribution -->
                <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                    <h3 class="text-2xl font-black text-slate-900 mb-5">Project Distribution by Program</h3>
                    <div class="space-y-5">
                        <div>
                            <div class="flex justify-between text-sm font-semibold mb-2">
                                <span class="text-slate-800 font-bold">BSCS (Computer Science)</span>
                                <span class="text-slate-700">58 Projects (45%)</span>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-3">
                                <div class="bg-amber-500 h-3 rounded-full" style="width: 45%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between text-sm font-semibold mb-2">
                                <span class="text-slate-800 font-bold">BSIT (Information Technology)</span>
                                <span class="text-slate-700">52 Projects (41%)</span>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-3">
                                <div class="bg-blue-600 h-3 rounded-full" style="width: 41%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between text-sm font-semibold mb-2">
                                <span class="text-slate-800 font-bold">BSIS (Information Systems)</span>
                                <span class="text-slate-700">20 Projects (15%)</span>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-3">
                                <div class="bg-sky-500 h-3 rounded-full" style="width: 15%"></div>
                            </div>
                        </div>
                        <div>
                            <div class="flex justify-between text-sm font-semibold mb-2">
                                <span class="text-slate-800 font-bold">ACT (Multimedia & Creative)</span>
                                <span class="text-slate-700">18 Projects (14%)</span>
                            </div>
                            <div class="w-full bg-slate-200 rounded-full h-3">
                                <div class="bg-emerald-500 h-3 rounded-full" style="width: 14%"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
