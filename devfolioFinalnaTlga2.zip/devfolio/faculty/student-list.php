<?php
/**
 * Faculty - Student Directory
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/review-helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}
$pendingCount = dfPendingCount($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Directory - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f3f6fb;
            color: #0f172a;
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 240px;
        }
        .ccdi-mark {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0f2d5c;
            border: 3px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(255,255,255,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(1.8rem, 2vw, 2.7rem);
            font-weight: 900;
            letter-spacing: 0.04em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.72rem 1.05rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: #f5a623;
            color: #101827;
            box-shadow: 0 6px 18px rgba(245, 166, 35, 0.35);
        }
        .nav-link.red {
            background: #e53935;
            color: #fff;
            border: none;
        }
        .nav-link.red:hover {
            background: #d92e2e;
            color: #fff;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;
            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <nav class="ccdi-header text-white p-5 shadow-lg">
            <div class="max-w-6xl mx-auto flex justify-between items-center gap-4 flex-wrap">
                <div class="ccdi-logo-wrap">
                    <div class="ccdi-mark">
                        <img src="../assets/img/ccdi_2.jpg" alt="CCDI logo">
                    </div>
                    <div class="ccdi-wordmark">DEVFOLIO</div>
                </div>

                <div class="ccdi-nav">
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                    <a href="review-queue.php" class="nav-link">Review Pending Projects<?php if ($pendingCount > 0): ?> <span class="ml-2 bg-red-600 text-white text-xs font-black rounded-full px-2 py-0.5"><?php echo $pendingCount; ?></span><?php endif; ?></a>
                    <a href="student-list.php" class="nav-link active">Student Directory</a>
                    <form method="POST" action="student-list.php" class="inline">
                        <button type="submit" name="logout" value="1" class="nav-link red border-0 cursor-pointer">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <!-- Main Content -->
        <div class="max-w-6xl mx-auto px-4 py-8">
            <h2 class="text-3xl font-bold text-slate-900 mb-6">CCDI Student Directory</h2>

            <!-- Filters -->
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mb-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Program</label>
                        <select class="w-full px-4 py-2 rounded-lg border border-slate-300">
                            <option>All Programs</option>
                            <option>BSCS</option>
                            <option>BSIT</option>
                            <option>ACT</option>
                            <option>BSIS</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Year Level</label>
                        <select class="w-full px-4 py-2 rounded-lg border border-slate-300">
                            <option>All Levels</option>
                            <option>1st Year</option>
                            <option>2nd Year</option>
                            <option>3rd Year</option>
                            <option>4th Year</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-sm font-bold text-slate-700 mb-2">Search</label>
                        <input type="text" placeholder="Search student name or ID..." class="w-full px-4 py-2 rounded-lg border border-slate-300">
                    </div>
                </div>
            </div>

            <!-- Student Grid -->
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Student Card -->
                <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition">
                    <div class="bg-gradient-to-r from-ccdi-navy to-slate-900 h-24"></div>
                    <div class="px-6 py-4 text-center -mt-12 relative">
                        <img src="https://placehold.co/80x80/0f2a4a/ffffff?text=Student" alt="Avatar" class="w-20 h-20 rounded-full mx-auto mb-3 border-4 border-white shadow-md">
                        <h3 class="text-lg font-bold text-slate-900">Jhon Mar Garcra</h3>
                        <p class="text-sm text-slate-600">BSCS • 3rd Year</p>
                        <p class="text-xs text-amber-600 font-semibold mt-1">2021-CCDI-0482</p>
                        <div class="mt-4 pt-4 border-t border-slate-100">
                            <button class="w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 rounded-lg text-sm transition">
                                <i class="fa-solid fa-folder mr-2"></i>View Portfolio
                            </button>
                        </div>
                    </div>
                </div>
                </div>
               </div>
            </div>
        </div>
    </div>
</body>
</html>
