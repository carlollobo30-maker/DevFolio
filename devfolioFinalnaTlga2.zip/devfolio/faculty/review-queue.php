<?php
/**
 * Faculty: Review Pending Projects
 * DEVFOLIO CCDI Sorsogon
 *
 * Students "Request Approval" -> status 'pending' -> shown here.
 * Faculty can view the details, then approve, or reject with a written reason
 * (the reason is sent to the project owner's notifications).
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/review-helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'faculty') {
    header('Location: ../login.php');
    exit;
}

function rqEsc($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

function rqTags($json): array {
    $arr = json_decode((string) $json, true);
    if (!is_array($arr)) return [];
    return array_values(array_filter(array_map(function ($t) { return trim((string) $t); }, $arr), 'strlen'));
}

function rqSafeLink(?string $url): string {
    $url = trim((string) $url);
    return preg_match('#^https?://#i', $url) ? $url : '';
}

function rqSize(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024) . ' KB';
    return $bytes . ' B';
}

/** The full project details a reviewer needs to make a decision. */
function rqDetailHtml(array $p, array $files): string {
    $tags = rqTags($p['tech_stack'] ?? null);
    $links = [];
    foreach ([$p['demo_link'] ?? '', $p['repository_link'] ?? ''] as $raw) {
        $safe = rqSafeLink($raw);
        if ($safe !== '' && !in_array($safe, $links, true)) $links[] = $safe;
    }
    $image = dfAssetUrl($p['banner_image_url'] ?? '');
    $owner = trim(($p['first_name'] ?? '') . ' ' . ($p['last_name'] ?? ''));
    ob_start(); ?>
    <?php if ($image !== ''): ?>
        <img src="<?php echo rqEsc($image); ?>" alt="<?php echo rqEsc('Cover photo of ' . $p['title']); ?>" class="w-full max-h-64 object-cover rounded-xl mb-5 bg-slate-100" onerror="this.remove()">
    <?php endif; ?>
    <div class="flex flex-wrap items-center gap-2 mb-2">
        <span class="bg-slate-100 text-slate-700 px-2 py-1 rounded text-xs font-bold"><?php echo rqEsc($p['category'] ?: 'Uncategorized'); ?></span>
        <span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold"><?php echo rqEsc($p['student_program'] ?? $p['program'] ?? ''); ?></span>
    </div>
    <h3 id="reviewTitle" class="text-2xl font-black text-slate-900 mb-1"><?php echo rqEsc($p['title']); ?></h3>
    <p class="text-sm text-slate-500 mb-5">
        <i class="fa-solid fa-user-graduate mr-1"></i><?php echo rqEsc($owner !== '' ? $owner : 'Unknown student'); ?>
        <?php if (!empty($p['student_no'])): ?> · <?php echo rqEsc($p['student_no']); ?><?php endif; ?>
        · Submitted <?php echo rqEsc(date('M j, Y g:i A', strtotime((string) $p['created_at']))); ?>
    </p>

    <h4 class="text-xs font-bold uppercase tracking-wide text-slate-500 mb-1">Description</h4>
    <p class="text-slate-800 leading-relaxed mb-5 break-words"><?php echo nl2br(rqEsc($p['description'] ?: $p['abstract'])); ?></p>

    <?php if ($tags): ?>
        <h4 class="text-xs font-bold uppercase tracking-wide text-slate-500 mb-2">Technologies</h4>
        <div class="flex flex-wrap gap-2 mb-5">
            <?php foreach ($tags as $t): ?><span class="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-full text-xs font-semibold"><?php echo rqEsc($t); ?></span><?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if ($links): ?>
        <h4 class="text-xs font-bold uppercase tracking-wide text-slate-500 mb-2">Project link</h4>
        <div class="flex flex-col gap-1 mb-5">
            <?php foreach ($links as $l): ?>
                <a href="<?php echo rqEsc($l); ?>" target="_blank" rel="noopener noreferrer" class="text-blue-700 hover:underline text-sm break-all"><i class="fa-solid fa-arrow-up-right-from-square mr-1"></i><?php echo rqEsc($l); ?></a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($files)): ?>
        <h4 class="text-xs font-bold uppercase tracking-wide text-slate-500 mb-2">Attached files</h4>
        <div class="space-y-2 mb-2">
            <?php foreach ($files as $f): ?>
                <a href="<?php echo rqEsc(dfAssetUrl($f['file_path'])); ?>" download="<?php echo rqEsc($f['file_name']); ?>" class="flex items-center gap-3 border border-slate-200 rounded-lg px-3 py-2 hover:bg-slate-50">
                    <i class="fa-solid fa-file text-slate-400"></i>
                    <span class="text-sm font-semibold text-slate-800 truncate"><?php echo rqEsc($f['file_name']); ?></span>
                    <span class="text-xs text-slate-500 ml-auto whitespace-nowrap"><?php echo rqEsc(rqSize((int) $f['file_size'])); ?></span>
                </a>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}

// ---------------------------------------------------------------
// JSON actions
// ---------------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];
    $pid = (int) ($_POST['project_id'] ?? 0);

    if ($action === 'get_project') {
        $st = $pdo->prepare(
            "SELECT p.*, s.student_id AS student_no, s.program AS student_program, u.first_name, u.last_name
             FROM projects p
             INNER JOIN students s ON s.id = p.student_id
             INNER JOIN users u ON u.id = s.user_id
             WHERE p.id = ? LIMIT 1"
        );
        $st->execute([$pid]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            echo json_encode(['success' => false, 'message' => 'Project not found.']);
            exit;
        }
        $fs = $pdo->prepare('SELECT * FROM project_files WHERE project_id = ? ORDER BY id ASC');
        $fs->execute([$pid]);
        echo json_encode([
            'success' => true,
            'status' => $row['status'],
            'html' => rqDetailHtml($row, $fs->fetchAll(PDO::FETCH_ASSOC)),
        ]);
        exit;
    }

    if ($action === 'approve' || $action === 'reject') {
        $result = dfReviewProject($pdo, $pid, (int) $_SESSION['user_id'], $action, (string) ($_POST['reason'] ?? ''));
        echo json_encode($result);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Unknown action.']);
    exit;
}

// ---------------------------------------------------------------
// Page data
// ---------------------------------------------------------------
$pending = $pdo->query(
    "SELECT p.id, p.title, p.category, p.created_at, s.student_id AS student_no, s.program AS student_program, u.first_name, u.last_name
     FROM projects p
     INNER JOIN students s ON s.id = p.student_id
     INNER JOIN users u ON u.id = s.user_id
     WHERE p.status = 'pending'
     ORDER BY p.created_at ASC, p.id ASC"
)->fetchAll(PDO::FETCH_ASSOC);

$recent = $pdo->query(
    "SELECT p.id, p.title, p.status, p.rejection_reason, p.reviewed_at, u.first_name, u.last_name
     FROM projects p
     INNER JOIN students s ON s.id = p.student_id
     INNER JOIN users u ON u.id = s.user_id
     WHERE p.status IN ('approved', 'rejected') AND p.reviewed_at IS NOT NULL
     ORDER BY p.reviewed_at DESC LIMIT 8"
)->fetchAll(PDO::FETCH_ASSOC);

$pendingCount = count($pending);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Review Pending Projects - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: #f3f6fb;
            color: #0f172a;
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 240px;
        }
        .ccdi-mark {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0f2d5c;
            border: 3px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(255,255,255,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(1.8rem, 2vw, 2.7rem);
            font-weight: 900;
            letter-spacing: 0.04em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.72rem 1.05rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: #f5a623;
            color: #101827;
            box-shadow: 0 6px 18px rgba(245, 166, 35, 0.35);
        }
        .nav-link.red {
            background: #e53935;
            color: #fff;
            border: none;
        }
        .nav-link.red:hover {
            background: #d92e2e;
            color: #fff;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;
            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <nav class="ccdi-header text-white p-5 shadow-lg">
            <div class="max-w-6xl mx-auto flex justify-between items-center gap-4 flex-wrap">
                <div class="ccdi-logo-wrap">
                    <div class="ccdi-mark">
                        <img src="../assets/img/ccdi_2.jpg" alt="CCDI logo">
                    </div>
                    <div class="ccdi-wordmark">DEVFOLIO</div>
                </div>

                <div class="ccdi-nav">
                    <a href="dashboard.php" class="nav-link">Dashboard</a>
                    <a href="review-queue.php" class="nav-link active">Review Pending Projects<?php if ($pendingCount > 0): ?> <span class="ml-2 bg-red-600 text-white text-xs font-black rounded-full px-2 py-0.5"><?php echo $pendingCount; ?></span><?php endif; ?></a>
                    <a href="student-list.php" class="nav-link">Student Directory</a>
                    <form method="POST" action="review-queue.php" class="inline">
                        <button type="submit" name="logout" value="1" class="nav-link red border-0 cursor-pointer">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="max-w-6xl mx-auto px-4 py-8">
            <div class="flex flex-wrap items-center justify-between gap-3 mb-8">
                <h2 class="text-3xl font-bold text-slate-900">Review Pending Projects</h2>
                <span class="text-sm font-bold bg-amber-100 text-amber-800 px-3 py-1.5 rounded-full"><?php echo $pendingCount; ?> awaiting review</span>
            </div>

            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <?php if ($pendingCount === 0): ?>
                    <div class="p-12 text-center text-slate-500">
                        <i class="fa-solid fa-circle-check text-4xl text-emerald-400 mb-3"></i>
                        <p class="font-bold text-slate-800">You're all caught up</p>
                        <p class="text-sm mt-1">Projects that students request approval for will appear here.</p>
                    </div>
                <?php else: ?>
                <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="bg-slate-50 border-b border-slate-200">
                        <tr>
                            <th class="px-6 py-4 text-left font-bold text-slate-700">Project Title</th>
                            <th class="px-6 py-4 text-left font-bold text-slate-700">Student</th>
                            <th class="px-6 py-4 text-left font-bold text-slate-700">Program</th>
                            <th class="px-6 py-4 text-left font-bold text-slate-700">Category</th>
                            <th class="px-6 py-4 text-left font-bold text-slate-700">Submitted</th>
                            <th class="px-6 py-4 text-center font-bold text-slate-700">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($pending as $row): ?>
                        <tr class="border-b border-slate-100 hover:bg-slate-50">
                            <td class="px-6 py-4 font-bold text-slate-900"><?php echo rqEsc($row['title']); ?></td>
                            <td class="px-6 py-4 text-slate-600"><?php echo rqEsc(trim($row['first_name'] . ' ' . $row['last_name'])); ?></td>
                            <td class="px-6 py-4"><span class="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs font-bold"><?php echo rqEsc($row['student_program']); ?></span></td>
                            <td class="px-6 py-4"><span class="bg-slate-100 text-slate-700 px-2 py-1 rounded text-xs font-bold"><?php echo rqEsc($row['category'] ?: 'Uncategorized'); ?></span></td>
                            <td class="px-6 py-4 text-slate-500 whitespace-nowrap"><?php echo rqEsc(date('M j, Y', strtotime((string) $row['created_at']))); ?></td>
                            <td class="px-6 py-4 text-center">
                                <button type="button" class="view-project bg-blue-600 hover:bg-blue-700 text-white px-3 py-1.5 rounded text-xs font-bold transition whitespace-nowrap" data-id="<?php echo (int) $row['id']; ?>">
                                    <i class="fa-solid fa-eye mr-1"></i>View Details
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                </div>
                <?php endif; ?>
            </div>

            <?php if (!empty($recent)): ?>
            <h3 class="text-xl font-bold text-slate-900 mt-10 mb-3">Recently reviewed</h3>
            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm divide-y divide-slate-100">
                <?php foreach ($recent as $r): $ok = $r['status'] === 'approved'; ?>
                    <div class="px-6 py-3 flex flex-wrap items-start gap-3">
                        <span class="<?php echo $ok ? 'bg-emerald-100 text-emerald-800' : 'bg-red-100 text-red-800'; ?> text-xs font-bold px-2 py-1 rounded"><?php echo $ok ? 'Approved' : 'Rejected'; ?></span>
                        <div class="min-w-0 flex-1">
                            <p class="font-semibold text-slate-900"><?php echo rqEsc($r['title']); ?> <span class="font-normal text-slate-500">· <?php echo rqEsc(trim($r['first_name'] . ' ' . $r['last_name'])); ?></span></p>
                            <?php if (!$ok && !empty($r['rejection_reason'])): ?><p class="text-xs text-slate-500 mt-0.5 break-words">Reason: <?php echo rqEsc(mb_strimwidth((string) $r['rejection_reason'], 0, 140, '…')); ?></p><?php endif; ?>
                        </div>
                        <span class="text-xs text-slate-400 whitespace-nowrap"><?php echo rqEsc(date('M j, g:i A', strtotime((string) $r['reviewed_at']))); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Review dialog -->
    <div id="reviewModal" class="hidden fixed inset-0 bg-slate-900/60 z-50 flex items-start justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-2xl w-full max-w-2xl shadow-2xl border border-slate-200 my-6" role="dialog" aria-modal="true" aria-labelledby="reviewTitle">
            <div class="flex justify-between items-center px-6 pt-5">
                <span class="text-xs font-bold uppercase tracking-wide text-slate-400">Project review</span>
                <button type="button" id="closeReview" class="text-slate-500 hover:text-slate-700 text-2xl leading-none" aria-label="Close">&times;</button>
            </div>
            <div id="reviewBody" class="px-6 py-4"></div>

            <div class="border-t border-slate-200 px-6 py-4 bg-slate-50 rounded-b-2xl">
                <div id="decisionBar" class="flex flex-wrap gap-3">
                    <button type="button" id="approveBtn" class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2.5 rounded-lg text-sm font-bold transition">
                        <i class="fa-solid fa-circle-check mr-1"></i>Approve
                    </button>
                    <button type="button" id="rejectBtn" class="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-lg text-sm font-bold transition">
                        <i class="fa-solid fa-circle-xmark mr-1"></i>Reject
                    </button>
                </div>

                <div id="rejectPanel" class="hidden">
                    <label for="rejectReason" class="block text-sm font-bold text-slate-800 mb-1">Reason for rejection <span class="text-red-600">*</span></label>
                    <p class="text-xs text-slate-500 mb-2">This message is sent to the student so they know what to fix.</p>
                    <textarea id="rejectReason" rows="4" maxlength="1000" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-red-500 text-sm" placeholder="e.g. The description is too short and the demo link does not open. Please add more detail and resubmit."></textarea>
                    <div class="flex flex-wrap items-center gap-3 mt-3">
                        <button type="button" id="sendReject" class="bg-red-600 hover:bg-red-700 text-white px-5 py-2.5 rounded-lg text-sm font-bold transition">Send rejection</button>
                        <button type="button" id="cancelReject" class="bg-slate-200 hover:bg-slate-300 text-slate-700 px-5 py-2.5 rounded-lg text-sm font-bold transition">Back</button>
                        <span id="reasonCount" class="text-xs text-slate-400 ml-auto">0 / 1000</span>
                    </div>
                </div>

                <p id="alreadyReviewed" class="hidden text-sm text-slate-600 font-semibold">This project has already been reviewed.</p>
            </div>
        </div>
    </div>

    <script>
    (function () {
        var modal = document.getElementById('reviewModal');
        var body = document.getElementById('reviewBody');
        var bar = document.getElementById('decisionBar');
        var panel = document.getElementById('rejectPanel');
        var reason = document.getElementById('rejectReason');
        var already = document.getElementById('alreadyReviewed');
        var currentId = 0;

        function toast(message, ok) {
            var t = document.createElement('div');
            t.className = (ok ? 'bg-emerald-600' : 'bg-red-600') + ' text-white text-sm font-semibold px-4 py-3 rounded-xl shadow-xl fixed bottom-5 right-5 z-[60] max-w-sm';
            t.textContent = message;
            document.body.appendChild(t);
            setTimeout(function () { t.remove(); }, 3500);
        }

        function post(data) {
            return fetch('review-queue.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams(data).toString()
            }).then(function (r) { return r.json(); });
        }

        function showDecisionBar() {
            panel.classList.add('hidden');
            bar.classList.remove('hidden');
            reason.value = '';
            document.getElementById('reasonCount').textContent = '0 / 1000';
        }

        function closeModal() {
            modal.classList.add('hidden');
            document.body.style.overflow = '';
            body.innerHTML = '';
            currentId = 0;
        }

        function setBusy(busy) {
            ['approveBtn', 'rejectBtn', 'sendReject', 'cancelReject'].forEach(function (id) {
                document.getElementById(id).disabled = busy;
                document.getElementById(id).classList.toggle('opacity-60', busy);
            });
        }

        document.querySelectorAll('.view-project').forEach(function (btn) {
            btn.addEventListener('click', function () {
                currentId = btn.dataset.id;
                body.innerHTML = '<p class="text-slate-500 py-10 text-center">Loading project…</p>';
                showDecisionBar();
                already.classList.add('hidden');
                modal.classList.remove('hidden');
                document.body.style.overflow = 'hidden';
                post({ action: 'get_project', project_id: currentId }).then(function (d) {
                    if (!d.success) { toast(d.message || 'Unable to open project.', false); closeModal(); return; }
                    body.innerHTML = d.html;
                    var pendingNow = d.status === 'pending';
                    bar.classList.toggle('hidden', !pendingNow);
                    already.classList.toggle('hidden', pendingNow);
                }).catch(function () { toast('Unable to open project.', false); closeModal(); });
            });
        });

        document.getElementById('closeReview').addEventListener('click', closeModal);
        modal.addEventListener('mousedown', function (e) { if (e.target === modal) closeModal(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !modal.classList.contains('hidden')) closeModal(); });

        document.getElementById('rejectBtn').addEventListener('click', function () {
            bar.classList.add('hidden');
            panel.classList.remove('hidden');
            reason.focus();
        });
        document.getElementById('cancelReject').addEventListener('click', showDecisionBar);
        reason.addEventListener('input', function () {
            document.getElementById('reasonCount').textContent = reason.value.length + ' / 1000';
        });

        function finish(d) {
            if (d.success) {
                toast(d.message, true);
                closeModal();
                setTimeout(function () { window.location.reload(); }, 900);
            } else {
                toast(d.message || 'Something went wrong.', false);
                setBusy(false);
            }
        }

        document.getElementById('approveBtn').addEventListener('click', function () {
            setBusy(true);
            post({ action: 'approve', project_id: currentId }).then(finish).catch(function () { toast('Something went wrong.', false); setBusy(false); });
        });

        document.getElementById('sendReject').addEventListener('click', function () {
            if (reason.value.trim() === '') {
                toast('Please type the reason for rejecting this project.', false);
                reason.focus();
                return;
            }
            setBusy(true);
            post({ action: 'reject', project_id: currentId, reason: reason.value.trim() }).then(finish).catch(function () { toast('Something went wrong.', false); setBusy(false); });
        });
    })();
    </script>
</body>
</html>
