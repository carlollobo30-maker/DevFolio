<?php
/**
 * Student Dashboard
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$userStmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$userStmt->execute([$_SESSION['user_id']]);
$user = $userStmt->fetch(PDO::FETCH_ASSOC);

$studentStmt = $pdo->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
$studentStmt->execute([$_SESSION['user_id']]);
$student = $studentStmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $_SESSION['user_id'], 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([
        $_SESSION['user_id'],
        $newStudentId,
        'BSCS',
        '3rd'
    ]);
    $student = $pdo->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
    $student->execute([$_SESSION['user_id']]);
    $student = $student->fetch(PDO::FETCH_ASSOC);
}

$programMap = [
    'BSCS' => 'Bachelor of Science in Computer Science',
    'BSIT' => 'Bachelor of Science in Information Technology',
    'BSACT' => 'Bachelor of Science in Associate in Computer Technology',
    'BSIS' => 'Bachelor of Science in Information System'
];

$fullName = trim((string) ($user['first_name'] ?? '') . ' ' . (string) ($user['last_name'] ?? ''));
if ($fullName === '') {
    $fullName = 'Student User';
}

$program = $student['program'] ?? 'BSCS';
$yearLevel = $student['year_level'] ?? '3rd';
$studentId = $student['student_id'] ?? 'N/A';
$degreeName = $programMap[$program] ?? ucfirst((string) $program);
$yearLabel = $yearLevel;
if (!preg_match('/(st|nd|rd|th)$/', $yearLabel)) {
    $yearLabel .= ' Year';
}

// ---------------------------------------------------------------
// Daily inspiring message (changes once per day, Asia/Manila time)
// Edit / add lines here. Order = rotation order.
// ---------------------------------------------------------------
$dailyMessages = [
    'Got a new Project? Showcase them by clicking here!',
    'Built something this week? Share it with the whole campus by clicking here!',
    'Every great developer started with one small project. Post yours by clicking here!',
    'Your code deserves an audience. Showcase your latest work by clicking here!',
    'Finished a capstone or an app? Let CCDI see it by clicking here!',
    'Someone might be inspired by what you built. Share it by clicking here!',
    'Proud of a project? Show it off by clicking here!',
    'Great ideas grow when they are shared. Showcase yours by clicking here!',
    'Got a project hiding in your folders? Bring it to light by clicking here!',
    'Progress counts, even for unfinished work. Share it by clicking here!',
    'Your next project could inspire a classmate. Post it by clicking here!',
    'Made something you are proud of? Showcase it by clicking here!',
    'Turn your hard work into a portfolio piece by clicking here!',
    'Show CCDI what you can build. Upload your project by clicking here!'
];
$dailyMessage = $dailyMessages[((int) date('z')) % count($dailyMessages)];

// ---------------------------------------------------------------
// Presentation helpers
// ---------------------------------------------------------------
function dfTimeAgo(?string $datetime): string {
    if (!$datetime) return '';
    $ts = strtotime($datetime);
    if (!$ts) return '';
    $diff = time() - $ts;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ' min ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hr ago';
    if ($diff < 604800) return floor($diff / 86400) . ' day' . (floor($diff / 86400) > 1 ? 's' : '') . ' ago';
    return date('M j, Y', $ts);
}

function dfSafeLink(?string $url): string {
    $url = trim((string) $url);
    return preg_match('#^https?://#i', $url) ? $url : '';
}

/** Label + icon for the single project link (repo hosts get the GitHub icon). */
function dfLinkMeta(string $url): array {
    $host = strtolower((string) parse_url($url, PHP_URL_HOST));
    foreach (['github.com', 'gitlab.com', 'bitbucket.org'] as $repoHost) {
        if ($host === $repoHost || substr($host, -strlen('.' . $repoHost)) === '.' . $repoHost) return ['Repository', 'github'];
    }
    return ['View project', 'external'];
}

function dfFormatSize(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024) . ' KB';
    return $bytes . ' B';
}

function dfEsc($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

function dfTags($json): array {
    if (!$json) return [];
    $arr = json_decode((string) $json, true);
    if (!is_array($arr)) return [];
    $out = [];
    foreach ($arr as $t) {
        $t = trim((string) $t);
        if ($t !== '') $out[] = $t;
    }
    return array_slice($out, 0, 8);
}

function dfTint(?string $category): string {
    $map = ['Web App' => 'web', 'Mobile App' => 'mobile', 'Capstone' => 'capstone', 'Multimedia' => 'media'];
    return 'df-tint-' . ($map[(string) $category] ?? 'default');
}

/** Project photo if there is a real one, otherwise a tinted title tile. */
function dfPreviewInner(array $p): string {
    $image = dfAssetUrl($p['banner_image_url'] ?? '');
    if ($image !== '' && stripos($image, 'placehold.co') !== false) $image = '';
    $html = '<div class="df-tile"><small>' . dfEsc($p['category'] ?? 'Project') . '</small><b>' . dfEsc($p['title'] ?? 'Untitled') . '</b></div>';
    if ($image !== '') {
        $html .= '<img src="' . dfEsc($image) . '" alt="' . dfEsc('Preview of ' . ($p['title'] ?? 'project')) . '" loading="lazy" onerror="this.remove()">';
    }
    return $html;
}

function dfAvatarHtml(array $p): string {
    $initials = dfInitials($p['first_name'] ?? '', $p['last_name'] ?? '');
    $avatar = dfAssetUrl($p['avatar_url'] ?? '');
    $img = $avatar !== '' ? '<img src="' . dfEsc($avatar) . '" alt="" onerror="this.remove()">' : '';
    return '<span class="df-av"><span>' . dfEsc($initials) . '</span>' . $img . '</span>';
}

function dfLikeButton(array $p): string {
    $liked = !empty($p['liked']);
    $count = (int) ($p['like_count'] ?? 0);
    return '<button type="button" class="df-like" data-like="' . (int) $p['id'] . '" aria-pressed="' . ($liked ? 'true' : 'false') . '" aria-label="' . dfEsc('Appreciate ' . ($p['title'] ?? 'this project')) . '">'
        . dfIcon('heart', 18) . '<span>' . ($count > 0 ? $count : '') . '</span></button>';
}

function dfOwnerName(array $p): string {
    $n = trim((string) ($p['first_name'] ?? '') . ' ' . (string) ($p['last_name'] ?? ''));
    return $n !== '' ? $n : 'Unknown User';
}

function dfRenderCard(array $p): string {
    $tags = dfTags($p['tech_stack'] ?? null);
    $desc = trim((string) ($p['description'] ?? ''));
    if ($desc === '') $desc = trim((string) ($p['abstract'] ?? ''));
    $title = $p['title'] ?? 'Untitled Project';
    ob_start(); ?>
    <article class="df-card">
        <button type="button" class="df-preview <?php echo dfEsc(dfTint($p['category'] ?? '')); ?>" data-open="<?php echo (int) $p['id']; ?>" aria-label="<?php echo dfEsc('View details for ' . $title); ?>">
            <?php echo dfPreviewInner($p); ?>
        </button>
        <div class="df-card-body">
            <?php if (!empty($p['category'])): ?><div class="df-cat"><?php echo dfEsc($p['category']); ?></div><?php endif; ?>
            <h3 class="df-card-title"><button type="button" data-open="<?php echo (int) $p['id']; ?>"><?php echo dfEsc($title); ?></button></h3>
            <?php if ($desc !== ''): ?><p class="df-desc"><?php echo dfEsc($desc); ?></p><?php endif; ?>
            <?php if ($tags): ?>
                <ul class="df-tags" aria-label="Technologies"><?php foreach ($tags as $t): ?><li><?php echo dfEsc($t); ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
            <div class="df-card-foot">
                <div class="df-creator">
                    <?php echo dfAvatarHtml($p); ?>
                    <span class="df-creator-text">
                        <span class="df-creator-name"><?php echo dfEsc(dfOwnerName($p)); ?></span>
                        <span class="df-creator-meta"><?php echo dfEsc(dfTimeAgo($p['created_at'] ?? null)); ?></span>
                    </span>
                </div>
                <?php echo dfLikeButton($p); ?>
            </div>
        </div>
    </article>
    <?php
    return ob_get_clean();
}

function dfRenderDetail(array $p, array $files): string {
    $tags = dfTags($p['tech_stack'] ?? null);
    $desc = trim((string) ($p['description'] ?? ''));
    if ($desc === '') $desc = trim((string) ($p['abstract'] ?? ''));
    $links = [];
    foreach ([$p['demo_link'] ?? '', $p['repository_link'] ?? ''] as $rawLink) {
        $safe = dfSafeLink($rawLink);
        if ($safe !== '' && !in_array($safe, $links, true)) $links[] = $safe;
    }
    ob_start(); ?>
    <div class="df-detail-hero <?php echo dfEsc(dfTint($p['category'] ?? '')); ?>"><?php echo dfPreviewInner($p); ?></div>
    <div class="df-detail-body">
        <?php if (!empty($p['category'])): ?><div class="df-cat"><?php echo dfEsc($p['category']); ?></div><?php endif; ?>
        <h2 id="detailTitle"><?php echo dfEsc($p['title'] ?? 'Untitled Project'); ?></h2>
        <div class="df-detail-meta">
            <div class="df-creator">
                <?php echo dfAvatarHtml($p); ?>
                <span class="df-creator-text">
                    <span class="df-creator-name"><?php echo dfEsc(dfOwnerName($p)); ?></span>
                    <span class="df-creator-meta"><?php echo dfEsc(trim(($p['student_program'] ?? '') . ' · ' . dfTimeAgo($p['created_at'] ?? null), ' ·')); ?></span>
                </span>
            </div>
            <?php echo dfLikeButton($p); ?>
        </div>
        <?php if ($desc !== ''): ?><p class="df-detail-text"><?php echo dfEsc($desc); ?></p><?php endif; ?>
        <?php if ($tags): ?><ul class="df-tags" aria-label="Technologies"><?php foreach ($tags as $t): ?><li><?php echo dfEsc($t); ?></li><?php endforeach; ?></ul><?php endif; ?>
        <?php if ($links): ?>
            <div class="df-linkrow">
                <?php foreach ($links as $linkUrl): $meta = dfLinkMeta($linkUrl); ?>
                    <a class="df-link" href="<?php echo dfEsc($linkUrl); ?>" target="_blank" rel="noopener noreferrer"><?php echo dfIcon($meta[1], 16); ?> <?php echo dfEsc($meta[0]); ?></a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        <?php if (!empty($files)): ?>
            <h3 class="df-files-title">Attached files</h3>
            <div class="df-files">
                <?php foreach ($files as $f): ?>
                    <a class="df-file" href="<?php echo dfEsc(dfAssetUrl($f['file_path'])); ?>" download="<?php echo dfEsc($f['file_name']); ?>">
                        <?php echo dfIcon('file', 20); ?>
                        <span class="df-file-text"><b><?php echo dfEsc($f['file_name']); ?></b><span><?php echo dfEsc(dfFormatSize((int) $f['file_size'])); ?></span></span>
                        <?php echo dfIcon('download', 16); ?>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
    return ob_get_clean();
}

/** Shared SELECT for feed + detail (adds appreciation counts for the current user). */
function dfProjectSelectSql(): string {
    return "SELECT p.*, s.program AS student_program, u.id AS owner_user_id, u.first_name, u.last_name, u.avatar_url,
                   (SELECT COUNT(*) FROM project_likes l WHERE l.project_id = p.id) AS like_count,
                   (SELECT COUNT(*) FROM project_likes l2 WHERE l2.project_id = p.id AND l2.user_id = :me) AS liked
            FROM projects p
            INNER JOIN students s ON s.id = p.student_id
            INNER JOIN users u ON u.id = s.user_id";
}

function dfFilesFor(PDO $pdo, array $ids): array {
    $out = [];
    if (empty($ids)) return $out;
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT * FROM project_files WHERE project_id IN ($in) ORDER BY id ASC");
    $st->execute(array_values($ids));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) $out[(int) $f['project_id']][] = $f;
    return $out;
}

// ---------------------------------------------------------------
// Real data for the sidebar (nothing here is sample content)
// ---------------------------------------------------------------
$meId = (int) $_SESSION['user_id'];
$skillCount = (int) $pdo->query('SELECT COUNT(*) FROM skills WHERE student_id = ' . (int) $student['id'])->fetchColumn();
$projectCount = (int) $pdo->query('SELECT COUNT(*) FROM projects WHERE student_id = ' . (int) $student['id'])->fetchColumn();

$completionSteps = [
    ['done' => !empty($user['avatar_url']), 'label' => 'Add a profile photo', 'href' => 'profile.php'],
    ['done' => !empty($user['phone']), 'label' => 'Add your phone number', 'href' => 'profile.php'],
    ['done' => trim((string) ($student['bio'] ?? '')) !== '', 'label' => 'Write a short bio', 'href' => 'profile.php'],
    ['done' => $skillCount > 0, 'label' => 'Add your first skill', 'href' => 'manage-skills.php'],
    ['done' => $projectCount > 0, 'label' => 'Showcase your first project', 'href' => ''],
];
$completion = (int) round(count(array_filter($completionSteps, function ($s) { return $s['done']; })) / count($completionSteps) * 100);
$nextStep = null;
foreach ($completionSteps as $stepItem) { if (!$stepItem['done']) { $nextStep = $stepItem; break; } }

$popularSkills = $pdo->query('SELECT skill_name, COUNT(DISTINCT student_id) AS cnt FROM skills GROUP BY skill_name ORDER BY cnt DESC, skill_name ASC LIMIT 5')->fetchAll(PDO::FETCH_ASSOC);

$firstName = trim((string) ($user['first_name'] ?? '')) ?: 'there';
$userInitials = dfInitials($user['first_name'] ?? '', $user['last_name'] ?? '');
$userAvatar = dfAssetUrl($user['avatar_url'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'save_avatar_upload' || $action === 'save_avatar_capture') {
        $targetAvatar = '';

        if ($action === 'save_avatar_upload') {
            if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'message' => 'Please select an image to upload.']);
                exit;
            }

            $file = $_FILES['avatar'];
            $allowed = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
            if (!in_array($file['type'], $allowed, true)) {
                echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, and WEBP images are allowed.']);
                exit;
            }

            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $ext;
            $uploadDir = __DIR__ . '/../assets/uploads/avatars/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $destination = $uploadDir . $filename;
            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                echo json_encode(['success' => false, 'message' => 'Image upload failed.']);
                exit;
            }

            $targetAvatar = '../assets/uploads/avatars/' . $filename;
        }

        if ($action === 'save_avatar_capture') {
            $dataUrl = $_POST['avatar_data_url'] ?? '';
            if ($dataUrl === '' || stripos($dataUrl, 'data:image/') === false) {
                echo json_encode(['success' => false, 'message' => 'No captured image was provided.']);
                exit;
            }

            if (preg_match('/^data:image\/(png|jpg|jpeg|webp);base64,/', $dataUrl, $matches)) {
                $imageData = substr($dataUrl, strpos($dataUrl, ',') + 1);
                $decoded = base64_decode($imageData);
                if ($decoded === false) {
                    echo json_encode(['success' => false, 'message' => 'Captured image could not be processed.']);
                    exit;
                }

                $ext = strtolower($matches[1]);
                $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $ext;
                $uploadDir = __DIR__ . '/../assets/uploads/avatars/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $destination = $uploadDir . $filename;
                if (!file_put_contents($destination, $decoded)) {
                    echo json_encode(['success' => false, 'message' => 'Captured image could not be saved.']);
                    exit;
                }

                $targetAvatar = '../assets/uploads/avatars/' . $filename;
            } else {
                echo json_encode(['success' => false, 'message' => 'Unsupported captured image format.']);
                exit;
            }
        }

        $updateUser = $pdo->prepare('UPDATE users SET avatar_url = ?, updated_at = NOW() WHERE id = ?');
        $updateUser->execute([$targetAvatar, $_SESSION['user_id']]);

        $_SESSION['avatar_url'] = $targetAvatar;
        echo json_encode(['success' => true, 'message' => 'Profile photo saved successfully.', 'avatar_url' => $targetAvatar]);
        exit;
    }


    // ---------- Feed: search / sort / paginate ----------
    if ($action === 'get_feed') {
        $offset = max(0, (int) ($_POST['offset'] ?? 0));
        $limit = 6;
        $q = trim((string) ($_POST['q'] ?? ''));
        $sort = $_POST['sort'] ?? 'latest';

        $where = "WHERE p.status = 'approved'";
        $filter = [];
        if ($q !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $where .= " AND (p.title LIKE :q1 OR p.description LIKE :q2 OR p.category LIKE :q3
                        OR CONCAT(u.first_name, ' ', u.last_name) LIKE :q4 OR CAST(p.tech_stack AS CHAR) LIKE :q5)";
            $filter = [':q1' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like, ':q5' => $like];
        }

        $orderBy = 'p.created_at DESC, p.id DESC';
        if ($sort === 'oldest') $orderBy = 'p.created_at ASC, p.id ASC';
        if ($sort === 'appreciated') $orderBy = 'like_count DESC, p.created_at DESC, p.id DESC';

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM projects p INNER JOIN students s ON s.id = p.student_id INNER JOIN users u ON u.id = s.user_id $where");
        $countStmt->execute($filter);
        $total = (int) $countStmt->fetchColumn();

        $feedStmt = $pdo->prepare(dfProjectSelectSql() . " $where ORDER BY $orderBy LIMIT :lim OFFSET :off");
        foreach ($filter as $k => $v) $feedStmt->bindValue($k, $v);
        $feedStmt->bindValue(':me', $meId, PDO::PARAM_INT);
        $feedStmt->bindValue(':lim', $limit + 1, PDO::PARAM_INT);
        $feedStmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $feedStmt->execute();
        $rows = $feedStmt->fetchAll(PDO::FETCH_ASSOC);

        $hasMore = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);

        $html = '';
        foreach ($rows as $row) $html .= dfRenderCard($row);

        echo json_encode(['success' => true, 'html' => $html, 'count' => count($rows), 'total' => $total, 'has_more' => $hasMore, 'next_offset' => $offset + count($rows)]);
        exit;
    }

    // ---------- Project details ----------
    if ($action === 'get_project') {
        $pid = (int) ($_POST['project_id'] ?? 0);
        $st = $pdo->prepare(dfProjectSelectSql() . " WHERE p.id = :pid AND p.status = 'approved' LIMIT 1");
        $st->bindValue(':me', $meId, PDO::PARAM_INT);
        $st->bindValue(':pid', $pid, PDO::PARAM_INT);
        $st->execute();
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            echo json_encode(['success' => false, 'message' => 'This project is no longer available.']);
            exit;
        }
        $files = dfFilesFor($pdo, [(int) $row['id']]);
        echo json_encode(['success' => true, 'html' => dfRenderDetail($row, $files[(int) $row['id']] ?? [])]);
        exit;
    }

    // ---------- Appreciation (heart) toggle ----------
    if ($action === 'toggle_like') {
        $pid = (int) ($_POST['project_id'] ?? 0);
        $exists = $pdo->prepare("SELECT id FROM projects WHERE id = ? AND status = 'approved' LIMIT 1");
        $exists->execute([$pid]);
        if (!$exists->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Project not found.']);
            exit;
        }
        $has = $pdo->prepare('SELECT id FROM project_likes WHERE project_id = ? AND user_id = ? LIMIT 1');
        $has->execute([$pid, $meId]);
        if ($has->fetch()) {
            $pdo->prepare('DELETE FROM project_likes WHERE project_id = ? AND user_id = ?')->execute([$pid, $meId]);
            $liked = false;
        } else {
            $pdo->prepare('INSERT IGNORE INTO project_likes (project_id, user_id) VALUES (?, ?)')->execute([$pid, $meId]);
            $liked = true;
        }
        $cnt = $pdo->prepare('SELECT COUNT(*) FROM project_likes WHERE project_id = ?');
        $cnt->execute([$pid]);
        echo json_encode(['success' => true, 'liked' => $liked, 'count' => (int) $cnt->fetchColumn()]);
        exit;
    }

    // ---------- Add a project (photo, links, files) ----------
    if ($action === 'add_project') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? 'Web App');
        $categoryOther = trim(preg_replace('/\s+/', ' ', (string) ($_POST['category_other'] ?? '')));
        // One link field only (stored in demo_link; repository_link stays empty for new projects)
        $projectLink = trim($_POST['project_link'] ?? '');
        // Students can never publish directly: every new project waits for faculty approval.
        $status = 'pending';

        // Technologies: comma-separated, up to 8 tags
        $techTags = [];
        foreach (explode(',', (string) ($_POST['tech_stack'] ?? '')) as $rawTag) {
            $tag = trim(preg_replace('/\s+/', ' ', $rawTag));
            if ($tag === '') continue;
            $tag = mb_substr($tag, 0, 30);
            if (!in_array(mb_strtolower($tag), array_map('mb_strtolower', $techTags), true)) $techTags[] = $tag;
            if (count($techTags) >= 8) break;
        }
        $techJson = $techTags ? json_encode($techTags, JSON_UNESCAPED_UNICODE) : null;

        $allowedCategories = ['Web App', 'Mobile App', 'Capstone', 'Multimedia'];
        if ($category === 'Others, Specify') {
            if ($categoryOther === '') {
                echo json_encode(['success' => false, 'message' => 'Please specify the category of your project.']);
                exit;
            }
            if (mb_strlen($categoryOther) > 100) {
                echo json_encode(['success' => false, 'message' => 'Category is too long (max 100 characters).']);
                exit;
            }
            $category = $categoryOther;
        } elseif (!in_array($category, $allowedCategories, true)) {
            $category = 'Web App';
        }

        if ($title === '' || $description === '') {
            echo json_encode(['success' => false, 'message' => 'Title and description are required.']);
            exit;
        }
        if (mb_strlen($title) > 255) {
            echo json_encode(['success' => false, 'message' => 'Title is too long (max 255 characters).']);
            exit;
        }
        if ($projectLink !== '' && (!preg_match('#^https?://#i', $projectLink) || mb_strlen($projectLink) > 255)) {
            echo json_encode(['success' => false, 'message' => 'Project link must be a valid link starting with http:// or https://']);
            exit;
        }

        $maxBytes = 5 * 1024 * 1024; // 5 MB per file
        $bannerPath = null;

        // --- Photo ---
        if (isset($_FILES['photo']) && $_FILES['photo']['error'] !== UPLOAD_ERR_NO_FILE) {
            $photo = $_FILES['photo'];
            if ($photo['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'message' => 'Photo upload failed. Try a smaller image (max 5 MB).']);
                exit;
            }
            $ext = strtolower(pathinfo($photo['name'], PATHINFO_EXTENSION));
            if (!in_array($ext, ['jpg', 'jpeg', 'png', 'webp', 'gif'], true) || @getimagesize($photo['tmp_name']) === false) {
                echo json_encode(['success' => false, 'message' => 'Photo must be a JPG, PNG, WEBP, or GIF image.']);
                exit;
            }
            if ($photo['size'] > $maxBytes) {
                echo json_encode(['success' => false, 'message' => 'Photo is larger than 5 MB.']);
                exit;
            }
            $photoDir = __DIR__ . '/../assets/uploads/projects/';
            if (!is_dir($photoDir)) mkdir($photoDir, 0777, true);
            $photoName = 'project_' . $student['id'] . '_' . bin2hex(random_bytes(6)) . '.' . $ext;
            if (!move_uploaded_file($photo['tmp_name'], $photoDir . $photoName)) {
                echo json_encode(['success' => false, 'message' => 'Could not save the photo.']);
                exit;
            }
            $bannerPath = 'assets/uploads/projects/' . $photoName;
        }

        // --- Attached files (validated first, saved after the project row exists) ---
        $pendingFiles = [];
        if (isset($_FILES['files']) && is_array($_FILES['files']['name'])) {
            $allowedExt = ['pdf', 'doc', 'docx', 'ppt', 'pptx', 'xls', 'xlsx', 'zip', 'txt', 'png', 'jpg', 'jpeg'];
            $count = count($_FILES['files']['name']);
            for ($i = 0; $i < $count; $i++) {
                if ($_FILES['files']['error'][$i] === UPLOAD_ERR_NO_FILE) continue;
                $origName = basename((string) $_FILES['files']['name'][$i]);
                if ($_FILES['files']['error'][$i] !== UPLOAD_ERR_OK) {
                    echo json_encode(['success' => false, 'message' => "\"$origName\" could not be uploaded (max 5 MB per file)."]);
                    exit;
                }
                $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
                if (!in_array($ext, $allowedExt, true)) {
                    echo json_encode(['success' => false, 'message' => "\"$origName\" has a file type that is not allowed."]);
                    exit;
                }
                if ($_FILES['files']['size'][$i] > $maxBytes) {
                    echo json_encode(['success' => false, 'message' => "\"$origName\" is larger than 5 MB."]);
                    exit;
                }
                $pendingFiles[] = ['tmp' => $_FILES['files']['tmp_name'][$i], 'name' => $origName, 'ext' => $ext, 'size' => (int) $_FILES['files']['size'][$i]];
            }
            if (count($pendingFiles) > 5) {
                echo json_encode(['success' => false, 'message' => 'You can attach up to 5 files per project.']);
                exit;
            }
        }

        $insert = $pdo->prepare(
            'INSERT INTO projects (student_id, title, description, abstract, category, program, academic_year, course_code, status, banner_image_url, demo_link, repository_link, tech_stack, published_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $insert->execute([
            $student['id'],
            $title,
            $description,
            $description,
            $category,
            $student['program'] ?? 'BSCS',
            date('Y') . '-' . (date('Y') + 1),
            'CCDI-PROJ',
            $status,
            $bannerPath,
            $projectLink,
            '',
            $techJson,
            null
        ]);
        $newProjectId = (int) $pdo->lastInsertId();

        if (!empty($pendingFiles)) {
            $fileDir = __DIR__ . '/../assets/uploads/project_files/';
            if (!is_dir($fileDir)) mkdir($fileDir, 0777, true);
            $fileInsert = $pdo->prepare('INSERT INTO project_files (project_id, file_name, file_path, file_size) VALUES (?, ?, ?, ?)');
            foreach ($pendingFiles as $pf) {
                $stored = 'file_' . $newProjectId . '_' . bin2hex(random_bytes(6)) . '.' . $pf['ext'];
                if (move_uploaded_file($pf['tmp'], $fileDir . $stored)) {
                    $fileInsert->execute([$newProjectId, $pf['name'], 'assets/uploads/project_files/' . $stored, $pf['size']]);
                }
            }
        }

        echo json_encode(['success' => true, 'message' => 'Approval requested! A faculty member will review your project, and it will appear on the feed once approved.']);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    if (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css">
</head>
<body>
<?php $navActive = 'discover'; include __DIR__ . '/../includes/student-nav.php'; ?>

<main id="main" class="df-page">
    <!-- Intro -->
    <section class="df-intro" aria-labelledby="pageTitle">
        <div>
            <p class="df-eyebrow">The CCDI Creative Community</p>
            <h1 id="pageTitle" class="df-h1">Big ideas. Built by you.</h1>
            <button type="button" class="df-lede open-add-project"><?php echo htmlspecialchars($dailyMessage); ?></button>
        </div>
        <button type="button" id="addProjectBtn" class="df-btn df-btn-primary open-add-project"><?php echo dfIcon('plus', 18); ?> Add Project</button>
    </section>

    <div class="df-layout">
        <!-- Gallery -->
        <section aria-labelledby="galleryTitle">
            <div class="df-toolbar" role="search">
                <div class="df-search">
                    <?php echo dfIcon('search', 18); ?>
                    <label for="feedSearch" class="df-sr">Search projects</label>
                    <input id="feedSearch" class="df-input" type="search" placeholder="Search projects, technologies or creators" autocomplete="off">
                </div>
                <div>
                    <label for="feedSort" class="df-sr">Sort projects</label>
                    <select id="feedSort" class="df-select">
                        <option value="latest">Latest projects</option>
                        <option value="appreciated">Most appreciated</option>
                        <option value="oldest">Oldest first</option>
                    </select>
                </div>
            </div>

            <div class="df-section-head">
                <h2 id="galleryTitle">Community projects</h2>
                <span class="df-count" id="feedCount" aria-live="polite"></span>
            </div>

            <div id="feed" class="df-grid"></div>

            <div id="feedSkeleton" class="df-grid" hidden aria-hidden="true">
                <div class="df-skel"><i style="aspect-ratio:16/10"></i><i style="height:14px;width:30%;margin:18px 12px 10px"></i><i style="height:22px;width:60%;margin:0 12px 12px"></i><i style="height:12px;margin:0 12px 8px"></i><i style="height:12px;width:80%;margin:0 12px 18px"></i></div>
                <div class="df-skel"><i style="aspect-ratio:16/10"></i><i style="height:14px;width:30%;margin:18px 12px 10px"></i><i style="height:22px;width:60%;margin:0 12px 12px"></i><i style="height:12px;margin:0 12px 8px"></i><i style="height:12px;width:80%;margin:0 12px 18px"></i></div>
            </div>

            <div id="feedEnd" class="df-end" hidden>You're all caught up</div>
            <div id="feedSentinel" style="height:2px"></div>
        </section>

        <!-- Sidebar (all figures come from the database) -->
        <aside class="df-side" aria-label="Community">
            <section class="df-panel" aria-labelledby="welcomeTitle">
                <div class="df-welcome-head">
                    <span class="df-welcome-av"><span><?php echo htmlspecialchars($userInitials); ?></span><?php if ($userAvatar !== ''): ?><img src="<?php echo htmlspecialchars($userAvatar); ?>" alt="" onerror="this.remove()"><?php endif; ?></span>
                    <div>
                        <h2 id="welcomeTitle">Welcome back, <?php echo htmlspecialchars($firstName); ?></h2>
                        <p><?php echo htmlspecialchars($program); ?> · <?php echo htmlspecialchars($yearLabel); ?></p>
                    </div>
                </div>
                <div class="df-progress-row"><span id="pcLabel">Profile completeness</span><b><?php echo $completion; ?>%</b></div>
                <div class="df-bar" role="progressbar" aria-labelledby="pcLabel" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo $completion; ?>"><i style="width: <?php echo $completion; ?>%"></i></div>
                <p class="df-next">
                    <?php if ($nextStep === null): ?>
                        Your profile is complete.
                    <?php elseif ($nextStep['href'] === ''): ?>
                        Next: <button type="button" class="open-add-project"><?php echo htmlspecialchars($nextStep['label']); ?></button>
                    <?php else: ?>
                        Next: <a href="<?php echo htmlspecialchars($nextStep['href']); ?>"><?php echo htmlspecialchars($nextStep['label']); ?></a>
                    <?php endif; ?>
                </p>
            </section>

            <section class="df-panel is-tip" aria-labelledby="tipTitle">
                <span class="df-tip-icon"><?php echo dfIcon('sparkles', 20); ?></span>
                <h3 id="tipTitle">Make your work stand out</h3>
                <p>A great cover and a clear story make all the difference. Show the problem, your process, and what you built.</p>
            </section>

            <?php if (!empty($popularSkills)): ?>
            <section class="df-panel df-pop" aria-labelledby="popTitle">
                <h3 id="popTitle">Popular skills in the community</h3>
                <ul>
                    <?php foreach ($popularSkills as $sk): ?>
                        <li><?php echo htmlspecialchars($sk['skill_name']); ?><span><?php echo (int) $sk['cnt']; ?> <?php echo ((int) $sk['cnt']) === 1 ? 'student' : 'students'; ?></span></li>
                    <?php endforeach; ?>
                </ul>
            </section>
            <?php endif; ?>
        </aside>
    </div>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>

<button type="button" id="dfFab" class="df-btn df-btn-primary open-add-project" aria-label="Add Project" tabindex="-1"><?php echo dfIcon('plus', 18); ?> Add Project</button>
<div id="dfToastHost" role="status" aria-live="polite"></div>

<!-- Project details -->
<div id="detailModal" class="df-modal" hidden>
    <div class="df-dialog is-wide" role="dialog" aria-modal="true" aria-labelledby="detailTitle">
        <button type="button" class="df-x" data-close aria-label="Close project details"><?php echo dfIcon('close', 18); ?></button>
        <div id="detailBody"></div>
    </div>
</div>

<!-- Add project -->
<div id="addModal" class="df-modal" hidden>
    <div class="df-dialog" role="dialog" aria-modal="true" aria-labelledby="addTitle">
        <button type="button" class="df-x" data-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
        <div class="df-dialog-pad">
            <h2 id="addTitle">Showcase a project</h2>
            <form id="projectForm" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_project">
                <div class="df-field">
                    <label for="fTitle">Project title <span class="req" aria-hidden="true">*</span></label>
                    <input id="fTitle" name="title" type="text" required maxlength="255" class="df-light">
                </div>
                <div class="df-field">
                    <label for="fCategory">Category</label>
                    <select id="fCategory" name="category" class="df-light">
                        <option>Web App</option><option>Mobile App</option><option>Capstone</option><option>Multimedia</option><option>Others, Specify</option>
                    </select>
                    <input id="fCategoryOther" name="category_other" type="text" maxlength="100" class="df-light df-other" placeholder="Type your project's category" aria-label="Specify the category" hidden style="margin-top:8px">
                </div>
                <div class="df-field">
                    <label for="fDesc">Description <span class="req" aria-hidden="true">*</span></label>
                    <textarea id="fDesc" name="description" rows="4" required class="df-light" placeholder="What problem does it solve? How did you build it?"></textarea>
                </div>
                <div class="df-field">
                    <label for="fTech">Technologies</label>
                    <input id="fTech" name="tech_stack" type="text" class="df-light" placeholder="React, Tailwind, Firebase">
                    <small>Separate with commas (up to 8).</small>
                </div>
                <div class="df-field">
                    <label for="projectPhoto">Cover photo</label>
                    <input id="projectPhoto" name="photo" type="file" accept="image/jpeg,image/png,image/webp,image/gif">
                    <img id="photoPreview" class="df-photo-preview" alt="Selected cover photo preview">
                </div>
                <div class="df-field">
                    <label for="fLink">Project link</label>
                    <input id="fLink" name="project_link" type="url" class="df-light" placeholder="https://... (live demo or repository)">
                </div>
                <div class="df-field">
                    <label for="projectFiles">Files <span style="font-weight:500;color:#64748b">(optional, up to 5)</span></label>
                    <input id="projectFiles" name="files[]" type="file" multiple accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.zip,.txt,.png,.jpg,.jpeg">
                    <small>PDF, Word, PowerPoint, Excel, ZIP, TXT or images. Max 5 MB each.</small>
                </div>
                <p class="df-approval-note">Your project will be reviewed by a faculty member. It only appears on the feed once it is approved.</p>
                <div class="df-actions">
                    <button type="submit" id="submitProject" class="df-btn df-btn-primary">Request Approval</button>
                    <button type="button" class="df-btn df-btn-ghost" data-close>Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    // ---------- Toast ----------
    function toast(message, type) {
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        document.getElementById('dfToastHost').appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    function post(body) {
        return fetch(window.location.href, {
            method: 'POST',
            headers: body instanceof FormData ? undefined : { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body
        });
    }

    // ---------- Accessible modals ----------
    var openModal = null, lastFocus = null;
    var focusable = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

    function showModal(modal) {
        lastFocus = document.activeElement;
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        openModal = modal;
        var first = modal.querySelector('input:not([type=hidden]),textarea,.df-x');
        (first || modal.querySelector('.df-x')).focus();
    }
    function hideModal() {
        if (!openModal) return;
        openModal.hidden = true;
        openModal = null;
        document.body.style.overflow = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
    }
    document.addEventListener('keydown', function (e) {
        if (!openModal) return;
        if (e.key === 'Escape') { hideModal(); return; }
        if (e.key === 'Tab') {
            var items = Array.prototype.filter.call(openModal.querySelectorAll(focusable), function (n) { return n.offsetParent !== null; });
            if (!items.length) return;
            var first = items[0], last = items[items.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    });
    document.querySelectorAll('.df-modal').forEach(function (m) {
        m.addEventListener('mousedown', function (e) { if (e.target === m) hideModal(); });
        m.addEventListener('click', function (e) { if (e.target.closest('[data-close]')) hideModal(); });
    });

    // ---------- Add project ----------
    var addModal = document.getElementById('addModal');
    var form = document.getElementById('projectForm');
    var photoInput = document.getElementById('projectPhoto');
    var photoPreview = document.getElementById('photoPreview');

    document.querySelectorAll('.open-add-project').forEach(function (b) {
        b.addEventListener('click', function () { showModal(addModal); });
    });
    // "Others, Specify" reveals a text box right under the category list
    var catSelect = document.getElementById('fCategory'), catOther = document.getElementById('fCategoryOther');
    function syncCategory() {
        var other = catSelect.value === 'Others, Specify';
        catOther.hidden = !other;
        catOther.required = other;
        if (!other) catOther.value = '';
    }
    catSelect.addEventListener('change', function () { syncCategory(); if (!catOther.hidden) catOther.focus(); });
    syncCategory();

    photoInput.addEventListener('change', function () {
        var f = photoInput.files[0];
        if (!f) { photoPreview.style.display = 'none'; return; }
        photoPreview.src = URL.createObjectURL(f);
        photoPreview.style.display = 'block';
    });
    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        if (document.getElementById('projectFiles').files.length > 5) { toast('You can attach up to 5 files.', 'err'); return; }
        var btn = document.getElementById('submitProject');
        btn.disabled = true; btn.textContent = 'Sending...';
        try {
            var res = await post(new FormData(form));
            var text = await res.text(), data;
            try { data = JSON.parse(text); } catch (err) { throw new Error('The upload was too large for the server. Try smaller files.'); }
            if (data.success) {
                toast(data.message || 'Approval requested!', 'ok');
                form.reset(); photoPreview.style.display = 'none'; syncCategory();
                hideModal();
                searchEl.value = ''; sortEl.value = 'latest';
                window.scrollTo({ top: 0, behavior: 'smooth' });
                loadFeed(true);
            } else {
                toast(data.message || 'Unable to save project.', 'err');
            }
        } catch (err) {
            toast(err.message || 'Unable to save project.', 'err');
        } finally {
            btn.disabled = false; btn.textContent = 'Request Approval';
        }
    });

    // ---------- Floating Add Project (shows once the header button scrolls away) ----------
    var fab = document.getElementById('dfFab');
    new IntersectionObserver(function (entries) {
        var away = !entries[0].isIntersecting;
        fab.classList.toggle('show', away);
        fab.tabIndex = away ? 0 : -1;
    }, { rootMargin: '-72px 0px 0px 0px' }).observe(document.getElementById('addProjectBtn'));

    // ---------- Feed: search, sort, infinite scroll ----------
    var feedEl = document.getElementById('feed'), skel = document.getElementById('feedSkeleton');
    var endEl = document.getElementById('feedEnd'), countEl = document.getElementById('feedCount');
    var searchEl = document.getElementById('feedSearch'), sortEl = document.getElementById('feedSort');
    var state = { offset: 0, loading: false, done: false, token: 0 };

    function emptyState(q) {
        var wrap = document.createElement('div'); wrap.className = 'df-empty';
        var h = document.createElement('h3'), p = document.createElement('p');
        if (q) { h.textContent = 'No projects match your search'; p.textContent = 'Try a different title, technology or creator name.'; }
        else { h.textContent = 'No projects yet'; p.textContent = 'Be the first to showcase a project to the CCDI community.'; }
        wrap.appendChild(h); wrap.appendChild(p);
        if (!q) {
            var b = document.createElement('button'); b.type = 'button'; b.className = 'df-btn df-btn-primary';
            b.textContent = 'Add Project'; b.addEventListener('click', function () { showModal(addModal); });
            wrap.appendChild(b);
        }
        feedEl.appendChild(wrap);
    }

    async function loadFeed(reset) {
        if (reset) {
            state.token++; state.offset = 0; state.done = false; state.loading = false;
            feedEl.innerHTML = ''; endEl.hidden = true;
        }
        if (state.loading || state.done) return;
        state.loading = true;
        var token = state.token;
        skel.hidden = false;
        var q = searchEl.value.trim();
        try {
            var body = new URLSearchParams({ action: 'get_feed', offset: state.offset, q: q, sort: sortEl.value });
            var res = await post(body.toString());
            var data = await res.json();
            if (token !== state.token) return;
            if (!data.success) throw new Error('feed');
            feedEl.insertAdjacentHTML('beforeend', data.html);
            state.offset = data.next_offset;
            countEl.textContent = data.total + (data.total === 1 ? ' project' : ' projects');
            if (!data.has_more) {
                state.done = true;
                if (data.total === 0) emptyState(q); else endEl.hidden = false;
            }
        } catch (err) {
            if (token === state.token) toast('Unable to load projects. Please try again.', 'err');
        } finally {
            if (token === state.token) { state.loading = false; skel.hidden = true; }
        }
    }

    var debounce;
    searchEl.addEventListener('input', function () { clearTimeout(debounce); debounce = setTimeout(function () { loadFeed(true); }, 300); });
    sortEl.addEventListener('change', function () { loadFeed(true); });
    new IntersectionObserver(function (en) { if (en[0].isIntersecting) loadFeed(); }, { rootMargin: '600px 0px' })
        .observe(document.getElementById('feedSentinel'));

    // ---------- Open details / appreciate ----------
    var detailModal = document.getElementById('detailModal'), detailBody = document.getElementById('detailBody');

    document.addEventListener('click', async function (e) {
        var opener = e.target.closest('[data-open]');
        if (opener) {
            try {
                var res = await post(new URLSearchParams({ action: 'get_project', project_id: opener.dataset.open }).toString());
                var data = await res.json();
                if (!data.success) { toast(data.message || 'Unable to open project.', 'err'); return; }
                detailBody.innerHTML = data.html;
                showModal(detailModal);
            } catch (err) { toast('Unable to open project.', 'err'); }
            return;
        }
        var like = e.target.closest('[data-like]');
        if (like) {
            var id = like.dataset.like;
            try {
                var r = await post(new URLSearchParams({ action: 'toggle_like', project_id: id }).toString());
                var d = await r.json();
                if (!d.success) { toast(d.message || 'Could not update.', 'err'); return; }
                document.querySelectorAll('[data-like="' + id + '"]').forEach(function (b) {
                    b.setAttribute('aria-pressed', d.liked ? 'true' : 'false');
                    b.querySelector('span').textContent = d.count > 0 ? d.count : '';
                });
            } catch (err) { toast('Could not update.', 'err'); }
        }
    });

    loadFeed(true);
})();
</script>
</body>
</html>
