<?php
/**
 * Student Profile Settings
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$studentStmt = $pdo->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
$studentStmt->execute([$_SESSION['user_id']]);
$student = $studentStmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $_SESSION['user_id'], 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([
        $_SESSION['user_id'],
        $newStudentId,
        'BSCS',
        '3rd'
    ]);
    $student = $pdo->query('SELECT * FROM students WHERE user_id = ' . (int) $_SESSION['user_id'] . ' LIMIT 1')->fetch(PDO::FETCH_ASSOC);
}

$errors = [];
$successMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'save_profile') {
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');
        $bio = trim($_POST['bio'] ?? '');

        if ($firstName === '' || $lastName === '' || $email === '') {
            echo json_encode(['success' => false, 'message' => 'First name, last name, and email are required.']);
            exit;
        }

        $userCheck = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
        $userCheck->execute([$email, $_SESSION['user_id']]);
        if ($userCheck->fetch()) {
            echo json_encode(['success' => false, 'message' => 'This email is already used by another account.']);
            exit;
        }

        $baseAvatar = $_POST['avatar'] ?? $user['avatar_url'] ?? 'https://placehold.co/120x120/0f2a4a/ffffff?text=JM';

        $updateUser = $pdo->prepare('UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, avatar_url = ?, updated_at = NOW() WHERE id = ?');
        $updateUser->execute([$firstName, $lastName, $email, $phone, $baseAvatar, $_SESSION['user_id']]);

        $updateStudent = $pdo->prepare('UPDATE students SET bio = ? WHERE user_id = ?');
        $updateStudent->execute([$bio, $_SESSION['user_id']]);

        $_SESSION['first_name'] = $firstName;
        $_SESSION['last_name'] = $lastName;
        $_SESSION['email'] = $email;

        echo json_encode(['success' => true, 'message' => 'Profile saved successfully.']);
        exit;
    }

    if ($action === 'upload_avatar') {
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['success' => false, 'message' => 'Please choose an image.']);
            exit;
        }

        $file = $_FILES['avatar'];
        $allowed = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
        if (!in_array($file['type'], $allowed, true)) {
            echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, or WEBP images are allowed.']);
            exit;
        }

        $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . strtolower($extension);
        $uploadDir = __DIR__ . '/../assets/uploads/avatars/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $destination = $uploadDir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            echo json_encode(['success' => false, 'message' => 'Avatar upload failed.']);
            exit;
        }

        $avatarUrl = '../assets/uploads/avatars/' . $filename;
        $updateUser = $pdo->prepare('UPDATE users SET avatar_url = ?, updated_at = NOW() WHERE id = ?');
        $updateUser->execute([$avatarUrl, $_SESSION['user_id']]);

        echo json_encode(['success' => true, 'message' => 'Avatar updated successfully.', 'avatar_url' => $avatarUrl]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    if (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
}

$profileFirst = $user['first_name'] ?? 'Jhon';
$profileLast = $user['last_name'] ?? 'Arcos';
$profileEmail = $user['email'] ?? 'jhonmar@ccdi.edu.ph';
$profilePhone = $user['phone'] ?? '+639123456789';
$profileBio = $student['bio'] ?? 'Passionate full-stack developer with expertise in modern web technologies and mobile app development...';
$profileAvatar = $user['avatar_url'] ?? 'https://placehold.co/120x120/0f2a4a/ffffff?text=JM';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile Settings - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #edf2f7 0%, #f8fafc 42%, #e0f2fe 100%);
            color: #0f172a;
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 240px;
        }
        .ccdi-mark {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0f2d5c;
            border: 3px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(255,255,255,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(1.8rem, 2vw, 2.7rem);
            font-weight: 900;
            letter-spacing: 0.04em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.72rem 1.05rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: #f5a623;
            color: #101827;
            box-shadow: 0 6px 18px rgba(245, 166, 35, 0.35);
        }
        .nav-link.red {
            background: #e53935;
            color: #fff;
            border: none;
        }
        .nav-link.red:hover {
            background: #d92e2e;
            color: #fff;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;

            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <?php $navActive = 'profile'; include __DIR__ . '/../includes/student-nav.php'; ?>

        <div id="main" class="max-w-xl mx-auto px-4 py-8">
            <div class="bg-white rounded-2xl p-8 shadow-sm border border-slate-200">
                <h2 class="text-2xl font-bold text-slate-900 mb-6 text-center">Profile Settings</h2>

                <form id="profileForm" method="POST" class="space-y-6">
                    <div class="profile-photo-shell mb-8">
                        <h2 class="text-4xl font-bold text-slate-900 mb-5 text-center">Profile Photo</h2>

                        <div class="rounded-[28px] overflow-hidden shadow-sm border border-slate-200 bg-slate-300/90 w-full max-w-[520px] mx-auto">
                            <div class="flex items-center justify-center bg-neutral-100 px-4 py-5 min-h-[140px] relative">
                                <div class="absolute inset-0 opacity-30">
                                    <div class="absolute top-10 left-20 h-2 w-2 rounded-full bg-white"></div>
                                    <div class="absolute top-16 right-24 h-2 w-2 rounded-full bg-white"></div>
                                    <div class="absolute bottom-16 left-1/3 h-2 w-2 rounded-full bg-white"></div>
                                    <div class="absolute bottom-12 right-1/3 h-2 w-2 rounded-full bg-white"></div>
                                </div>

                                <div class="relative z-10 flex items-center justify-center w-full">
                                    <button type="button" id="avatarTrigger" class="relative flex-shrink-0 focus:outline-none">
                                        <div class="w-20 h-20 rounded-full border-4 border-white/90 bg-slate-200 overflow-hidden shadow-xl">
                                            <img id="profileAvatarLarge" src="<?php echo htmlspecialchars($profileAvatar); ?>" alt="Avatar" class="w-full h-full object-cover">
                                        </div>
                                        <span class="absolute -bottom-1 -right-1 flex items-center justify-center w-8 h-8 rounded-full bg-amber-400 text-slate-900 shadow-lg border-2 border-white">
                                            <i class="fa-solid fa-camera text-sm"></i>
                                        </span>
                                    </button>
                                </div>
                            </div>

                            <div id="photoActions" class="hidden">
                                <button type="button" id="capturePhotoBtn" class="w-full bg-gradient-to-r from-[#4f9afc] to-[#277ae6] text-white flex items-center justify-center gap-3 py-4 font-bold text-lg transition hover:brightness-105">
                                    <i class="fa-solid fa-camera"></i>
                                    <span>Capture Photo</span>
                                </button>
                                <button type="button" id="uploadPhotoBtn" class="w-full bg-gradient-to-r from-[#27b56f] to-[#1aa85e] text-white flex items-center justify-center gap-3 py-4 font-bold text-lg transition hover:brightness-105">
                                    <i class="fa-solid fa-upload"></i>
                                    <span>Upload Photo</span>
                                </button>
                            </div>

                            <input type="file" id="captureInput" accept="image/*" capture="user" class="hidden">
                            <input type="file" id="uploadInput" accept="image/*" class="hidden">
                        </div>
                    </div>

                    <div class="border-t border-slate-200 pt-6">
                        <h3 class="text-lg font-bold text-slate-900 mb-4 text-center">Basic Information</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-sm font-bold text-slate-700 mb-1">First Name</label>
                                <input id="firstName" type="text" value="<?php echo htmlspecialchars($profileFirst); ?>" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                            </div>
                            <div>
                                <label class="block text-sm font-bold text-slate-700 mb-1">Last Name</label>
                                <input id="lastName" type="text" value="<?php echo htmlspecialchars($profileLast); ?>" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                            </div>
                        </div>
                    </div>

                    <div class="border-t border-slate-200 pt-6">
                        <h3 class="text-lg font-bold text-slate-900 mb-4">Contact Information</h3>
                        <div class="space-y-4">
                            <div>
                                <label class="block text-sm font-bold text-slate-700 mb-1">Email</label>
                                <input id="email" type="email" value="<?php echo htmlspecialchars($profileEmail); ?>" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                            </div>
                            <div>
                                <label class="block text-sm font-bold text-slate-700 mb-1">Phone Number</label>
                                <input id="phone" type="tel" value="<?php echo htmlspecialchars($profilePhone); ?>" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                            </div>
                        </div>
                    </div>

                    <div class="border-t border-slate-200 pt-6">
                        <h3 class="text-lg font-bold text-slate-900 mb-4">Professional Bio</h3>
                        <textarea id="bio" rows="4" placeholder="Tell employers about yourself..." class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"><?php echo htmlspecialchars($profileBio); ?></textarea>
                    </div>

                    <div class="flex space-x-3 pt-6">
                        <button type="submit" class="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-3 rounded-lg transition">
                            <i class="fa-solid fa-floppy-disk mr-2"></i>Save Changes
                        </button>
                        <button type="button" id="cancelProfileBtn" class="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-3 rounded-lg transition">
                            <i class="fa-solid fa-xmark mr-2"></i>Cancel
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script>
        const defaultAvatar = '<?php echo addslashes($profileAvatar); ?>';
        const defaultProfile = {
            avatar: defaultAvatar,
            firstName: '<?php echo addslashes($profileFirst); ?>',
            lastName: '<?php echo addslashes($profileLast); ?>',
            email: '<?php echo addslashes($profileEmail); ?>',
            phone: '<?php echo addslashes($profilePhone); ?>',
            bio: '<?php echo addslashes($profileBio); ?>'
        };

        const profileForm = document.getElementById('profileForm');
        const captureInput = document.getElementById('captureInput');
        const uploadInput = document.getElementById('uploadInput');
        const profileAvatar = document.getElementById('profileAvatarLarge');
        const avatarTrigger = document.getElementById('avatarTrigger');
        const photoActions = document.getElementById('photoActions');

        function showToast(message, type = 'success') {
            const toast = document.createElement('div');
            const bg = type === 'success' ? 'bg-emerald-600' : 'bg-slate-800';
            toast.className = `${bg} text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl fixed bottom-5 right-5 z-50 transition-all duration-300`;
            toast.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-info'} text-amber-400 mr-2"></i>${message}`;
            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('opacity-0', 'translate-y-2'), 2000);
            setTimeout(() => toast.remove(), 2600);
        }

        function uploadSelectedAvatar(file) {
            if (!file) return;

            const formData = new FormData();
            formData.append('action', 'upload_avatar');
            formData.append('avatar', file);

            fetch(window.location.href, {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then((data) => {
                if (data.success) {
                    profileAvatar.src = data.avatar_url;
                    showToast(data.message || 'Avatar updated successfully.', 'success');
                } else {
                    showToast(data.message || 'Avatar upload failed.', 'error');
                }
            })
            .catch(() => {
                showToast('Avatar upload failed.', 'error');
            });
        }

        avatarTrigger.addEventListener('click', () => {
            photoActions.classList.toggle('hidden');
        });

        document.addEventListener('click', (event) => {
            if (!photoActions.contains(event.target) && !avatarTrigger.contains(event.target)) {
                photoActions.classList.add('hidden');
            }
        });

        document.getElementById('capturePhotoBtn').addEventListener('click', () => captureInput.click());
        document.getElementById('uploadPhotoBtn').addEventListener('click', () => uploadInput.click());

        captureInput.addEventListener('change', (event) => {
            uploadSelectedAvatar(event.target.files && event.target.files[0]);
            captureInput.value = '';
            photoActions.classList.add('hidden');
        });

        uploadInput.addEventListener('change', (event) => {
            uploadSelectedAvatar(event.target.files && event.target.files[0]);
            uploadInput.value = '';
            photoActions.classList.add('hidden');
        });

        const oldAvatarInput = document.getElementById('avatarInput');
        if (oldAvatarInput) {
            oldAvatarInput.remove();
        }

        document.getElementById('cancelProfileBtn').addEventListener('click', () => {
            document.getElementById('firstName').value = defaultProfile.firstName;
            document.getElementById('lastName').value = defaultProfile.lastName;
            document.getElementById('email').value = defaultProfile.email;
            document.getElementById('phone').value = defaultProfile.phone;
            document.getElementById('bio').value = defaultProfile.bio;
            profileAvatar.src = defaultProfile.avatar;
            captureInput.value = '';
            uploadInput.value = '';
            photoActions.classList.add('hidden');
            showToast('Changes cancelled.', 'info');
        });

        profileForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const payload = new URLSearchParams();
            payload.append('action', 'save_profile');
            payload.append('first_name', document.getElementById('firstName').value.trim());
            payload.append('last_name', document.getElementById('lastName').value.trim());
            payload.append('email', document.getElementById('email').value.trim());
            payload.append('phone', document.getElementById('phone').value.trim());
            payload.append('bio', document.getElementById('bio').value.trim());
            payload.append('avatar', profileAvatar.src);

            try {
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: payload.toString()
                });
                const data = await response.json();
                if (data.success) {
                    showToast(data.message || 'Profile saved successfully.', 'success');
                } else {
                    showToast(data.message || 'Unable to save profile.', 'error');
                }
            } catch (error) {
                console.error(error);
                showToast('Unable to save profile.', 'error');
            }
        });
    </script>
</body>
</html>
