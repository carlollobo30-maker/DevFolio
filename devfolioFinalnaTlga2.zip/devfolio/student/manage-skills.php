<?php
/**
 * Manage Skills & Certifications
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $_SESSION['user_id'], 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([
        $_SESSION['user_id'],
        $newStudentId,
        'BSCS',
        '3rd'
    ]);
    $student = ['id' => $pdo->lastInsertId()];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'get_data') {
        $skillsStmt = $pdo->prepare('SELECT skill_name FROM skills WHERE student_id = ? ORDER BY created_at DESC');
        $skillsStmt->execute([$student['id']]);
        $skills = array_map(fn($item) => $item['skill_name'], $skillsStmt->fetchAll(PDO::FETCH_ASSOC));

        $certsStmt = $pdo->prepare('SELECT certificate_name, issuing_organization, certificate_image_url FROM certificates WHERE student_id = ? ORDER BY created_at DESC');
        $certsStmt->execute([$student['id']]);
        $certificates = $certsStmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'skills' => $skills, 'certificates' => $certificates]);
        exit;
    }

    if ($action === 'add_skill') {
        $skill = trim($_POST['skill'] ?? '');
        if ($skill === '') {
            echo json_encode(['success' => false, 'message' => 'Skill name is required.']);
            exit;
        }

        $check = $pdo->prepare('SELECT id FROM skills WHERE student_id = ? AND skill_name = ? LIMIT 1');
        $check->execute([$student['id'], $skill]);
        if ($check->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Skill already exists.']);
            exit;
        }

        $insert = $pdo->prepare('INSERT INTO skills (student_id, skill_name, proficiency_level, verified) VALUES (?, ?, "intermediate", FALSE)');
        $insert->execute([$student['id'], $skill]);
        echo json_encode(['success' => true, 'message' => 'Skill added successfully.']);
        exit;
    }

    if ($action === 'delete_skill') {
        $skill = trim($_POST['skill'] ?? '');
        if ($skill === '') {
            echo json_encode(['success' => false, 'message' => 'Skill is required.']);
            exit;
        }
        $delete = $pdo->prepare('DELETE FROM skills WHERE student_id = ? AND skill_name = ?');
        $delete->execute([$student['id'], $skill]);
        echo json_encode(['success' => true, 'message' => 'Skill removed.']);
        exit;
    }

    if ($action === 'add_certificate') {
        $title = trim($_POST['title'] ?? '');
        $detail = trim($_POST['detail'] ?? '');

        if ($title === '' || $detail === '') {
            echo json_encode(['success' => false, 'message' => 'Certificate title and details are required.']);
            exit;
        }

        $imageUrl = null;
        if (isset($_FILES['certificate_image']) && $_FILES['certificate_image']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['certificate_image'];
            $allowed = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
            if (!in_array($file['type'], $allowed, true)) {
                echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, and WEBP images are allowed for certificates.']);
                exit;
            }

            $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $filename = 'certificate_' . $_SESSION['user_id'] . '_' . time() . '.' . $extension;
            $uploadDir = __DIR__ . '/../assets/uploads/certificates/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $destination = $uploadDir . $filename;
            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                echo json_encode(['success' => false, 'message' => 'Certificate image upload failed.']);
                exit;
            }

            $imageUrl = '../assets/uploads/certificates/' . $filename;
        }

        $insert = $pdo->prepare('INSERT INTO certificates (student_id, certificate_name, issuing_organization, certificate_image_url) VALUES (?, ?, ?, ?)');
        $insert->execute([$student['id'], $title, $detail, $imageUrl]);
        echo json_encode(['success' => true, 'message' => 'Certificate added successfully.']);
        exit;
    }

    if ($action === 'delete_certificate') {
        $title = trim($_POST['title'] ?? '');
        if ($title === '') {
            echo json_encode(['success' => false, 'message' => 'Certificate title is required.']);
            exit;
        }
        $delete = $pdo->prepare('DELETE FROM certificates WHERE student_id = ? AND certificate_name = ?');
        $delete->execute([$student['id'], $title]);
        echo json_encode(['success' => true, 'message' => 'Certificate removed.']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Skills & Certificates - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #edf2f7 0%, #f8fafc 42%, #e0f2fe 100%);
            color: #0f172a;
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 240px;
        }
        .ccdi-mark {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0f2d5c;
            border: 3px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(255,255,255,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(1.8rem, 2vw, 2.7rem);
            font-weight: 900;
            letter-spacing: 0.04em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.72rem 1.05rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: #f5a623;
            color: #101827;
            box-shadow: 0 6px 18px rgba(245, 166, 35, 0.35);
        }
        .nav-link.red {
            background: #e53935;
            color: #fff;
            border: none;
        }
        .nav-link.red:hover {
            background: #d92e2e;
            color: #fff;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;
            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <?php $navActive = 'skills'; include __DIR__ . '/../includes/student-nav.php'; ?>

        <div id="main" class="max-w-6xl mx-auto px-4 py-8">
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mb-8">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-slate-900">Technical Skills</h2>
                    <button type="button" id="addSkillBtn" class="bg-blue-500 hover:bg-blue-600 text-white font-bold px-4 py-2 rounded-lg text-sm transition">
                        <i class="fa-solid fa-plus mr-2"></i>Add Skill
                    </button>
                </div>
                <div id="skillList" class="flex flex-wrap gap-3"></div>
            </div>

            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <div class="flex justify-between items-center mb-6">
                    <h2 class="text-2xl font-bold text-slate-900">Certificates & Badges</h2>
                    <button type="button" id="addCertificateBtn" class="bg-green-500 hover:bg-green-600 text-white font-bold px-4 py-2 rounded-lg text-sm transition">
                        <i class="fa-solid fa-plus mr-2"></i>Add Certificate
                    </button>
                </div>
                <div id="certificateList" class="space-y-4"></div>
            </div>
        </div>
    </div>

    <div id="skillModal" class="hidden fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div class="flex justify-between items-center mb-4">
                <h3 id="skillModalTitle" class="text-xl font-bold text-slate-900">Add Skill</h3>
                <button type="button" id="closeSkillModal" class="text-slate-500 text-2xl">&times;</button>
            </div>
            <form id="skillForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Skill Name</label>
                    <input id="skillInput" type="text" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                <div class="flex gap-3">
                    <button type="submit" class="flex-1 bg-blue-500 hover:bg-blue-600 text-white font-bold py-3 rounded-lg transition">Save</button>
                    <button type="button" id="cancelSkillModal" class="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-3 rounded-lg transition">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <div id="certificateModal" class="hidden fixed inset-0 bg-slate-900/50 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl w-full max-w-md p-6 shadow-2xl">
            <div class="flex justify-between items-center mb-4">
                <h3 id="certificateModalTitle" class="text-xl font-bold text-slate-900">Add Certificate</h3>
                <button type="button" id="closeCertificateModal" class="text-slate-500 text-2xl">&times;</button>
            </div>
            <form id="certificateForm" class="space-y-4">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Certificate Title</label>
                    <input id="certificateTitle" type="text" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Issuer / Details</label>
                    <input id="certificateDetail" type="text" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Certificate Image</label>
                    <input id="certificateImage" type="file" accept="image/*" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-green-500">
                </div>
                <div class="flex gap-3">
                    <button type="submit" class="flex-1 bg-green-500 hover:bg-green-600 text-white font-bold py-3 rounded-lg transition">Save</button>
                    <button type="button" id="cancelCertificateModal" class="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-3 rounded-lg transition">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function showToast(message, type = 'success') {
            const toast = document.createElement('div');
            const bg = type === 'success' ? 'bg-emerald-600' : 'bg-slate-800';
            toast.className = `${bg} text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl fixed bottom-5 right-5 z-50 transition-all duration-300`;
            toast.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-info'} text-amber-400 mr-2"></i>${message}`;
            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('opacity-0', 'translate-y-2'), 2000);
            setTimeout(() => toast.remove(), 2600);
        }

        function renderSkills(skills) {
            const skillList = document.getElementById('skillList');
            if (!skills.length) {
                skillList.innerHTML = '<div class="text-slate-500">No skills added yet.</div>';
                return;
            }
            skillList.innerHTML = skills.map((skill, index) => `
                <span class="skill-item bg-slate-100 text-slate-700 text-sm font-semibold px-4 py-2 rounded-lg border border-slate-200">
                    <i class="fa-solid fa-xmark text-red-500 cursor-pointer mr-2 remove-skill" data-skill="${encodeURIComponent(skill)}"></i>${skill}
                </span>
            `).join('');
        }

        function renderCertificates(certificates) {
            const certificateList = document.getElementById('certificateList');
            if (!certificates.length) {
                certificateList.innerHTML = '<div class="text-slate-500">No certificates added yet.</div>';
                return;
            }
            certificateList.innerHTML = certificates.map((certificate, index) => `
                <div class="certificate-item border border-slate-200 rounded-lg p-4 flex justify-between items-start gap-4" data-index="${index}">
                    <div class="flex gap-4 items-start">
                        ${certificate.certificate_image_url ? `<img src="${certificate.certificate_image_url}" alt="${certificate.certificate_name}" class="w-24 h-24 rounded-xl object-cover border border-slate-200 bg-slate-50">` : '<div class="w-24 h-24 rounded-xl bg-slate-100 border border-slate-200 flex items-center justify-center text-slate-400"><i class="fa-solid fa-image text-2xl"></i></div>'}
                        <div>
                            <h3 class="font-bold text-slate-900">${certificate.certificate_name}</h3>
                            <p class="text-sm text-slate-600 mt-1">${certificate.issuing_organization}</p>
                        </div>
                    </div>
                    <button type="button" class="remove-certificate text-red-600 hover:text-red-700 font-bold" data-title="${encodeURIComponent(certificate.certificate_name)}">
                        <i class="fa-solid fa-trash"></i>
                    </button>
                </div>
            `).join('');
        }

        async function loadData() {
            try {
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: 'action=get_data'
                });
                const data = await response.json();
                if (data.success) {
                    renderSkills(data.skills || []);
                    renderCertificates(data.certificates || []);
                }
            } catch (error) {
                console.error(error);
                showToast('Unable to load skills.', 'error');
            }
        }

        document.getElementById('addSkillBtn').addEventListener('click', () => {
            document.getElementById('skillModalTitle').textContent = 'Add Skill';
            document.getElementById('skillForm').reset();
            document.getElementById('skillModal').classList.remove('hidden');
        });

        document.getElementById('closeSkillModal').addEventListener('click', () => document.getElementById('skillModal').classList.add('hidden'));
        document.getElementById('cancelSkillModal').addEventListener('click', () => document.getElementById('skillModal').classList.add('hidden'));

        document.getElementById('skillForm').addEventListener('submit', async (event) => {
            event.preventDefault();
            const skill = document.getElementById('skillInput').value.trim();
            if (!skill) return;

            const formData = new URLSearchParams();
            formData.append('action', 'add_skill');
            formData.append('skill', skill);

            try {
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: formData.toString()
                });
                const data = await response.json();
                if (data.success) {
                    showToast(data.message || 'Skill added successfully.', 'success');
                    document.getElementById('skillModal').classList.add('hidden');
                    document.getElementById('skillForm').reset();
                    loadData();
                } else {
                    showToast(data.message || 'Unable to save skill.', 'error');
                }
            } catch (error) {
                console.error(error);
                showToast('Unable to save skill.', 'error');
            }
        });

        document.getElementById('addCertificateBtn').addEventListener('click', () => {
            document.getElementById('certificateModalTitle').textContent = 'Add Certificate';
            document.getElementById('certificateForm').reset();
            document.getElementById('certificateModal').classList.remove('hidden');
        });

        document.getElementById('closeCertificateModal').addEventListener('click', () => document.getElementById('certificateModal').classList.add('hidden'));
        document.getElementById('cancelCertificateModal').addEventListener('click', () => document.getElementById('certificateModal').classList.add('hidden'));

        document.getElementById('certificateForm').addEventListener('submit', async (event) => {
            event.preventDefault();
            const title = document.getElementById('certificateTitle').value.trim();
            const detail = document.getElementById('certificateDetail').value.trim();
            const imageInput = document.getElementById('certificateImage');
            if (!title || !detail) return;

            const formData = new FormData();
            formData.append('action', 'add_certificate');
            formData.append('title', title);
            formData.append('detail', detail);
            if (imageInput.files && imageInput.files[0]) {
                formData.append('certificate_image', imageInput.files[0]);
            }

            try {
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    body: formData
                });
                const data = await response.json();
                if (data.success) {
                    showToast(data.message || 'Certificate added successfully.', 'success');
                    document.getElementById('certificateModal').classList.add('hidden');
                    document.getElementById('certificateForm').reset();
                    imageInput.value = '';
                    loadData();
                } else {
                    showToast(data.message || 'Unable to save certificate.', 'error');
                }
            } catch (error) {
                console.error(error);
                showToast('Unable to save certificate.', 'error');
            }
        });

        document.addEventListener('click', async (event) => {
            const removeSkill = event.target.closest('.remove-skill');
            if (removeSkill) {
                const skill = decodeURIComponent(removeSkill.dataset.skill || '');
                const formData = new URLSearchParams();
                formData.append('action', 'delete_skill');
                formData.append('skill', skill);
                try {
                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                        body: formData.toString()
                    });
                    const data = await response.json();
                    if (data.success) {
                        showToast(data.message || 'Skill removed.', 'success');
                        loadData();
                    }
                } catch (error) {
                    console.error(error);
                    showToast('Unable to remove skill.', 'error');
                }
            }

            const removeCertificate = event.target.closest('.remove-certificate');
            if (removeCertificate) {
                const title = decodeURIComponent(removeCertificate.dataset.title || '');
                const formData = new URLSearchParams();
                formData.append('action', 'delete_certificate');
                formData.append('title', title);
                try {
                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                        body: formData.toString()
                    });
                    const data = await response.json();
                    if (data.success) {
                        showToast(data.message || 'Certificate removed.', 'success');
                        loadData();
                    }
                } catch (error) {
                    console.error(error);
                    showToast('Unable to remove certificate.', 'error');
                }
            }
        });

        loadData();
    </script>
</body>
</html>
