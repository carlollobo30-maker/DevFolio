<?php
/**
 * Manage Projects - Student Portfolio
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
$stmt->execute([$_SESSION['user_id']]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $_SESSION['user_id'], 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([
        $_SESSION['user_id'],
        $newStudentId,
        'BSCS',
        '3rd'
    ]);
    $student = ['id' => $pdo->lastInsertId()];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'get_projects') {
        $projectStmt = $pdo->prepare('SELECT * FROM projects WHERE student_id = ? ORDER BY created_at DESC');
        $projectStmt->execute([$student['id']]);
        $projects = $projectStmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($projects as &$project) {
            $project['status_label'] = ucfirst(str_replace('_', ' ', $project['status']));
            $project['image'] = $project['banner_image_url'] ?: 'https://placehold.co/400x200/0f2a4a/f59e0b?text=Project';
        }
        unset($project);

        echo json_encode(['success' => true, 'projects' => $projects]);
        exit;
    }

    if ($action === 'save_project') {
        $projectId = isset($_POST['project_id']) && $_POST['project_id'] !== '' ? (int) $_POST['project_id'] : null;
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? 'Web App');
        $categoryOther = trim(preg_replace('/\s+/', ' ', (string) ($_POST['category_other'] ?? '')));
        $image = trim($_POST['image'] ?? '');

        if ($title === '' || $description === '') {
            echo json_encode(['success' => false, 'message' => 'Title and description are required.']);
            exit;
        }

        if ($category === 'Others, Specify') {
            if ($categoryOther === '') {
                echo json_encode(['success' => false, 'message' => 'Please specify the category of your project.']);
                exit;
            }
            if (mb_strlen($categoryOther) > 100) {
                echo json_encode(['success' => false, 'message' => 'Category is too long (max 100 characters).']);
                exit;
            }
            $category = $categoryOther;
        } elseif (!in_array($category, ['Web App', 'Mobile App', 'Capstone', 'Multimedia'], true)) {
            $category = 'Web App';
        }

        // Students cannot publish directly: new projects and every edit go to faculty review.
        $normalizedStatus = 'pending';

        if ($projectId) {
            $stmt = $pdo->prepare("UPDATE projects SET title = ?, description = ?, category = ?, status = ?, rejection_reason = NULL, reviewed_by = NULL, reviewed_at = NULL, published_at = NULL, banner_image_url = ?, updated_at = NOW() WHERE id = ? AND student_id = ?");
            $stmt->execute([$title, $description, $category, $normalizedStatus, $image ?: null, $projectId, $student['id']]);
            $response = ['success' => true, 'message' => 'Changes saved and sent to faculty for approval.'];
        } else {
            $stmt = $pdo->prepare('INSERT INTO projects (student_id, title, description, category, status, banner_image_url, abstract, academic_year, course_code, program, demo_link, repository_link) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
            $stmt->execute([
                $student['id'],
                $title,
                $description,
                $category,
                $normalizedStatus,
                $image ?: 'https://placehold.co/400x200/0f2a4a/f59e0b?text=Project',
                $description,
                date('Y') . '-' . (date('Y') + 1),
                'CCDI-PROJ',
                'BSCS',
                '',
                ''
            ]);
            $response = ['success' => true, 'message' => 'Approval requested! A faculty member will review your project.'];
        }

        echo json_encode($response);
        exit;
    }

    if ($action === 'delete_project') {
        $projectId = isset($_POST['project_id']) ? (int) $_POST['project_id'] : 0;
        $stmt = $pdo->prepare('DELETE FROM projects WHERE id = ? AND student_id = ?');
        $stmt->execute([$projectId, $student['id']]);
        echo json_encode(['success' => true, 'message' => 'Project deleted successfully.']);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Projects - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #edf2f7 0%, #f8fafc 42%, #e0f2fe 100%);
            color: #0f172a;
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 240px;
        }
        .ccdi-mark {
            width: 68px;
            height: 68px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #0f2d5c;
            border: 3px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(255,255,255,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(1.8rem, 2vw, 2.7rem);
            font-weight: 900;
            letter-spacing: 0.04em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.72rem 1.05rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: #f5a623;
            color: #101827;
            box-shadow: 0 6px 18px rgba(245, 166, 35, 0.35);
        }
        .nav-link.red {
            background: #e53935;
            color: #fff;
            border: none;
        }
        .nav-link.red:hover {
            background: #d92e2e;
            color: #fff;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;
            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <?php $navActive = 'projects'; include __DIR__ . '/../includes/student-nav.php'; ?>

        <div id="main" class="max-w-6xl mx-auto px-4 py-8">
            <div class="flex justify-between items-center mb-8">
                <h2 class="text-3xl font-bold text-slate-900">My Projects & Capstones</h2>
                <button type="button" id="addProjectBtn" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-6 py-2.5 rounded-lg transition">
                    <i class="fa-solid fa-plus mr-2"></i>Add New Project
                </button>
            </div>

            <div id="projectsGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"></div>

            <div id="addProjectCard" class="bg-white rounded-2xl border-2 border-dashed border-slate-300 shadow-sm flex items-center justify-center min-h-80 hover:border-amber-500 hover:bg-amber-50 transition cursor-pointer mt-6">
                <div class="text-center">
                    <i class="fa-solid fa-cloud-arrow-up text-4xl text-slate-400 mb-3"></i>
                    <p class="font-bold text-slate-900">Add New Project</p>
                    <p class="text-sm text-slate-500 mt-1">Upload capstone, app, or multimedia</p>
                </div>
            </div>
        </div>
    </div>

    <div id="projectModal" class="hidden fixed inset-0 bg-slate-900/60 z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-2xl w-full max-w-xl p-6 shadow-2xl border border-slate-200">
            <div class="flex justify-between items-center mb-5">
                <h3 id="projectModalTitle" class="text-2xl font-bold text-slate-900">Add New Project</h3>
                <button type="button" id="closeProjectModal" class="text-slate-500 hover:text-slate-700 text-2xl">&times;</button>
            </div>

            <form id="projectForm" class="space-y-4">
                <input type="hidden" id="projectId">
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Project Title</label>
                    <input id="projectTitle" type="text" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Category</label>
                    <select id="projectCategory" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                        <option value="Web App">Web App</option>
                        <option value="Mobile App">Mobile App</option>
                        <option value="Capstone">Capstone</option>
                        <option value="Multimedia">Multimedia</option>
                        <option value="Others, Specify">Others, Specify</option>
                    </select>
                    <input id="projectCategoryOther" type="text" maxlength="100" placeholder="Type your project's category" aria-label="Specify the category" class="hidden mt-2 w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Project Image URL</label>
                    <input id="projectImage" type="url" value="https://placehold.co/400x200/0f2a4a/f59e0b?text=Project" class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500">
                </div>
                <div>
                    <label class="block text-sm font-bold text-slate-700 mb-1">Description</label>
                    <textarea id="projectDescription" rows="4" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-amber-500"></textarea>
                </div>
                <p id="approvalNote" class="text-xs text-blue-900 bg-blue-50 border border-blue-200 rounded-lg px-3 py-2">Your project will be reviewed by a faculty member. It only appears on the feed once it is approved.</p>

                <div class="flex gap-3 pt-2">
                    <button type="submit" class="flex-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-3 rounded-lg transition">Request Approval</button>
                    <button type="button" id="cancelProjectModal" class="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold py-3 rounded-lg transition">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        const projectModal = document.getElementById('projectModal');
        const projectForm = document.getElementById('projectForm');
        const projectIdInput = document.getElementById('projectId');
        const projectModalTitle = document.getElementById('projectModalTitle');

        function showToast(message, type = 'success') {
            const toast = document.createElement('div');
            const bg = type === 'success' ? 'bg-emerald-600' : 'bg-slate-800';
            toast.className = `${bg} text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl fixed bottom-5 right-5 z-50 transition-all duration-300`;
            toast.innerHTML = `<i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-info'} text-amber-400 mr-2"></i>${message}`;
            document.body.appendChild(toast);
            setTimeout(() => toast.classList.add('opacity-0', 'translate-y-2'), 2000);
            setTimeout(() => toast.remove(), 2600);
        }

        function esc(value) {
            return String(value ?? '').replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
        }

        const STANDARD_CATEGORIES = ['Web App', 'Mobile App', 'Capstone', 'Multimedia'];
        const projectCategory = document.getElementById('projectCategory');
        const projectCategoryOther = document.getElementById('projectCategoryOther');

        function syncCategory() {
            const other = projectCategory.value === 'Others, Specify';
            projectCategoryOther.classList.toggle('hidden', !other);
            projectCategoryOther.required = other;
            if (!other) projectCategoryOther.value = '';
        }
        projectCategory.addEventListener('change', () => { syncCategory(); if (!projectCategoryOther.classList.contains('hidden')) projectCategoryOther.focus(); });

        function statusBadge(status) {
            if (status === 'approved') return { cls: 'bg-emerald-100 text-emerald-800', icon: 'fa-circle-check', text: 'Approved' };
            if (status === 'rejected') return { cls: 'bg-red-100 text-red-800', icon: 'fa-circle-xmark', text: 'Rejected' };
            return { cls: 'bg-amber-100 text-amber-800', icon: 'fa-clock', text: 'Pending approval' };
        }

        function renderProjects(projects) {
            const grid = document.getElementById('projectsGrid');
            if (!projects.length) {
                grid.innerHTML = `
                    <div class="col-span-full bg-white rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500">
                        No projects yet. Add your first project.
                    </div>
                `;
                return;
            }

            grid.innerHTML = projects.map(project => {
                const badge = statusBadge(project.status);
                const image = project.banner_image_url || project.image || 'https://placehold.co/400x200/0f2a4a/f59e0b?text=Project';
                const rejectedBox = project.status === 'rejected' && project.rejection_reason ? `
                            <div class="mb-3 rounded-lg border border-red-200 bg-red-50 p-3">
                                <p class="text-xs font-bold text-red-800 mb-1"><i class="fa-solid fa-comment-dots mr-1"></i>Reason from faculty</p>
                                <p class="text-sm text-red-900 whitespace-pre-line break-words">${esc(project.rejection_reason)}</p>
                                <p class="text-xs text-red-700 mt-2">Edit your project and click Request Approval to resubmit.</p>
                            </div>` : '';
                return `
                    <div class="bg-white rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition overflow-hidden">
                        <img src="${esc(image)}" alt="${esc(project.title)}" class="w-full h-40 object-cover">
                        <div class="p-5">
                            <div class="flex justify-between items-start gap-2 mb-2">
                                <h3 class="font-bold text-slate-900">${esc(project.title)}</h3>
                                <span class="${badge.cls} text-xs font-bold px-2 py-0.5 rounded whitespace-nowrap">
                                    <i class="fa-solid ${badge.icon}"></i> ${badge.text}
                                </span>
                            </div>
                            <p class="text-sm text-slate-600 mb-3">${esc(project.description)}</p>
                            ${rejectedBox}
                            <div class="flex space-x-2">
                                <button type="button" class="edit-project flex-1 text-xs font-bold bg-blue-100 text-blue-700 px-3 py-2 rounded hover:bg-blue-200 transition" data-id="${project.id}">
                                    <i class="fa-solid fa-pencil mr-1"></i>Edit
                                </button>
                                <button type="button" class="delete-project flex-1 text-xs font-bold bg-red-100 text-red-700 px-3 py-2 rounded hover:bg-red-200 transition" data-id="${project.id}">
                                    <i class="fa-solid fa-trash mr-1"></i>Delete
                                </button>
                            </div>
                        </div>
                    </div>
                `;
            }).join('');
        }

        async function loadProjects() {
            try {
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: 'action=get_projects'
                });
                const data = await response.json();
                if (data.success) {
                    renderProjects(data.projects || []);
                }
            } catch (error) {
                console.error(error);
                showToast('Unable to load projects.', 'error');
            }
        }

        function openProjectModal(mode = 'create', project = null) {
            projectModalTitle.textContent = mode === 'create' ? 'Add New Project' : 'Edit Project';
            projectForm.reset();
            projectIdInput.value = '';
            document.getElementById('projectCategory').value = 'Web App';
            document.getElementById('projectImage').value = 'https://placehold.co/400x200/0f2a4a/f59e0b?text=Project';

            if (mode === 'edit' && project) {
                projectIdInput.value = project.id;
                document.getElementById('projectTitle').value = project.title;
                const cat = project.category || 'Web App';
                if (STANDARD_CATEGORIES.includes(cat)) {
                    document.getElementById('projectCategory').value = cat;
                } else {
                    document.getElementById('projectCategory').value = 'Others, Specify';
                    projectCategoryOther.value = cat;
                }
                document.getElementById('projectDescription').value = project.description;
                document.getElementById('projectImage').value = project.banner_image_url || project.image || 'https://placehold.co/400x200/0f2a4a/f59e0b?text=Project';
            }

            syncCategory();
            if (mode === 'edit' && project && project.status === 'approved') {
                document.getElementById('approvalNote').textContent = 'This project is approved. Saving changes sends it back to faculty for approval, and it is hidden from the feed until then.';
            } else {
                document.getElementById('approvalNote').textContent = 'Your project will be reviewed by a faculty member. It only appears on the feed once it is approved.';
            }
            projectModal.classList.remove('hidden');
        }

        function closeProjectModal() {
            projectModal.classList.add('hidden');
            projectForm.reset();
        }

        document.getElementById('addProjectBtn').addEventListener('click', () => openProjectModal('create'));
        document.getElementById('addProjectCard').addEventListener('click', () => openProjectModal('create'));
        document.getElementById('closeProjectModal').addEventListener('click', closeProjectModal);
        document.getElementById('cancelProjectModal').addEventListener('click', closeProjectModal);

        document.addEventListener('click', async (event) => {
            const editBtn = event.target.closest('.edit-project');
            if (editBtn) {
                const projectId = Number(editBtn.dataset.id);
                const projectList = Array.from(document.querySelectorAll('.edit-project')).map(item => Number(item.dataset.id));
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: 'action=get_projects'
                });
                const data = await response.json();
                const project = (data.projects || []).find(item => Number(item.id) === projectId);
                if (project) openProjectModal('edit', project);
                return;
            }

            const deleteBtn = event.target.closest('.delete-project');
            if (deleteBtn) {
                const projectId = Number(deleteBtn.dataset.id);
                const confirmed = confirm('Delete this project?');
                if (!confirmed) return;
                try {
                    const response = await fetch(window.location.href, {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                        body: `action=delete_project&project_id=${projectId}`
                    });
                    const data = await response.json();
                    if (data.success) {
                        showToast(data.message || 'Project deleted successfully.', 'success');
                        loadProjects();
                    }
                } catch (error) {
                    console.error(error);
                    showToast('Unable to delete project.', 'error');
                }
            }
        });

        projectForm.addEventListener('submit', async (event) => {
            event.preventDefault();
            const payload = new URLSearchParams();
            payload.append('action', projectIdInput.value ? 'save_project' : 'save_project');
            payload.append('project_id', projectIdInput.value || '');
            payload.append('title', document.getElementById('projectTitle').value.trim());
            payload.append('category', document.getElementById('projectCategory').value);
            payload.append('description', document.getElementById('projectDescription').value.trim());
            payload.append('category_other', projectCategoryOther.value.trim());
            payload.append('image', document.getElementById('projectImage').value.trim());

            try {
                const response = await fetch(window.location.href, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: payload.toString()
                });
                const data = await response.json();
                if (data.success) {
                    showToast(data.message || 'Project saved successfully.', 'success');
                    closeProjectModal();
                    loadProjects();
                } else {
                    showToast(data.message || 'Unable to save project.', 'error');
                }
            } catch (error) {
                console.error(error);
                showToast('Unable to save project.', 'error');
            }
        });

        loadProjects();
    </script>
</body>
</html>
