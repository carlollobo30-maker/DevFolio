# Project Approval Workflow

Students can no longer publish projects directly. Flow:

1. **Student** clicks **Request Approval** (Discover page or My Projects) -> project saved with `status = 'pending'`.
2. **Faculty** sees it under **Review Pending Projects** (`faculty/review-queue.php`, with a live count badge),
   opens **View Details**, then **Approve** or **Reject**.
3. **Approve** -> `status = 'approved'`, appears on the student feed. Owner gets a notification.
4. **Reject** -> faculty must type a reason. `status = 'rejected'`, the reason is stored in
   `projects.rejection_reason`, sent to the owner's notification bell, and shown on their project card in My Projects.
5. Student can edit a rejected project and click **Request Approval** again (clears the reason, back to pending).

## Other form changes
- Only one **Project link** box (saved in `projects.demo_link`; `repository_link` is left empty for new projects).
- Category list has **Others, Specify** with a text box beneath it; the typed text is saved as the category.

## Files
- `includes/review-helpers.php`  shared approve/reject logic + `dfNotify()` (used by faculty and admin)
- `includes/db_connect.php`      auto-adds `rejection_reason`, `reviewed_by`, `reviewed_at` to existing databases
- `student/notifications.php`    marks notifications read when the bell is opened
- `faculty/review-queue.php`     rewritten with real data
- `admin/dashboard.php`          Review Projects tab uses the same logic (reason required to reject)

## Rules worth knowing
- The feed, project details and appreciation (heart) only work for `approved` projects.
- Editing an approved project sends it back to `pending` (hidden until re-approved).
- Any faculty account can review any pending project (there is no per-adviser assignment yet).
