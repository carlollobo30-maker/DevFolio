-- DEVFOLIO Database Schema
-- CCDI Sorsogon Student Showcase Platform
-- MySQL 5.7+

-- Create Database
CREATE DATABASE IF NOT EXISTS ccdi_devfolio;
USE ccdi_devfolio;

-- ============================================
-- USERS TABLE (Students, Faculty, Admins)
-- ============================================
CREATE TABLE users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    role ENUM('student', 'faculty', 'admin') NOT NULL,
    phone VARCHAR(20),
    avatar_url VARCHAR(255),
    is_verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX (email),
    INDEX (role)
);

-- ============================================
-- STUDENTS TABLE
-- ============================================
CREATE TABLE students (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    student_id VARCHAR(20) UNIQUE NOT NULL,
    program VARCHAR(50) NOT NULL,
    year_level VARCHAR(10),
    gpa DECIMAL(3, 2),
    adviser_id INT,
    enrollment_status ENUM('active', 'inactive', 'graduated') DEFAULT 'active',
    bio TEXT,
    portfolio_link VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (adviser_id) REFERENCES users(id),
    INDEX (student_id),
    INDEX (program)
);

-- ============================================
-- FACULTY TABLE
-- ============================================
CREATE TABLE faculty (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    employee_id VARCHAR(20) UNIQUE,
    department VARCHAR(100),
    specialization VARCHAR(255),
    qualifications TEXT,
    is_capstone_adviser BOOLEAN DEFAULT FALSE,
    is_evaluator BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ============================================
-- PROJECTS TABLE
-- ============================================
CREATE TABLE projects (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT,
    abstract TEXT,
    category VARCHAR(100),
    program VARCHAR(50),
    academic_year VARCHAR(20),
    course_code VARCHAR(50),
    status ENUM('draft', 'pending', 'approved', 'rejected', 'revision_needed') DEFAULT 'draft',
    banner_image_url VARCHAR(255),
    demo_link VARCHAR(255),
    repository_link VARCHAR(255),
    tech_stack JSON,
    rejection_reason TEXT NULL,          -- why a faculty member rejected it (shown to the owner)
    reviewed_by INT NULL,                -- users.id of the reviewer
    reviewed_at TIMESTAMP NULL DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    published_at TIMESTAMP NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    INDEX (status),
    INDEX (category),
    INDEX (program),
    INDEX (academic_year)
);

-- ============================================
-- PROJECT FILES TABLE (attachments shown in the feed)
-- ============================================
CREATE TABLE project_files (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX (project_id)
);

-- ============================================
-- PROJECT LIKES TABLE (appreciation on the feed)
-- ============================================
CREATE TABLE project_likes (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    user_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE KEY (project_id, user_id)
);

-- ============================================
-- PROJECT TEAM MEMBERS TABLE
-- ============================================
CREATE TABLE project_team_members (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    student_id INT NOT NULL,
    role VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE KEY (project_id, student_id)
);

-- ============================================
-- PROJECT ADVISERS TABLE
-- ============================================
CREATE TABLE project_advisers (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    faculty_id INT NOT NULL,
    role VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (faculty_id) REFERENCES faculty(id) ON DELETE CASCADE
);

-- ============================================
-- PROJECT EVALUATIONS TABLE
-- ============================================
CREATE TABLE project_evaluations (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    evaluator_id INT NOT NULL,
    score INT,
    comments TEXT,
    recommendation ENUM('approve', 'revision', 'reject') NOT NULL,
    evaluation_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (evaluator_id) REFERENCES faculty(id) ON DELETE CASCADE
);

-- ============================================
-- SKILLS TABLE
-- ============================================
CREATE TABLE skills (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    skill_name VARCHAR(100) NOT NULL,
    proficiency_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE KEY (student_id, skill_name)
);

-- ============================================
-- CERTIFICATES TABLE
-- ============================================
CREATE TABLE certificates (
    id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    certificate_name VARCHAR(255) NOT NULL,
    issuing_organization VARCHAR(255),
    issue_date DATE,
    expiry_date DATE,
    credential_url VARCHAR(255),
    certificate_image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ============================================
-- EMPLOYER INQUIRIES TABLE
-- ============================================
CREATE TABLE employer_inquiries (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    employer_name VARCHAR(255),
    employer_email VARCHAR(100),
    employer_company VARCHAR(255),
    message TEXT,
    interest_type ENUM('hire', 'partner', 'inquiry', 'other') DEFAULT 'inquiry',
    status ENUM('new', 'read', 'responded', 'archived') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX (status)
);

-- ============================================
-- PROJECT VIEWS/ANALYTICS TABLE
-- ============================================
CREATE TABLE project_views (
    id INT PRIMARY KEY AUTO_INCREMENT,
    project_id INT NOT NULL,
    viewer_ip VARCHAR(45),
    viewer_type ENUM('student', 'faculty', 'employer', 'public') DEFAULT 'public',
    viewed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    INDEX (project_id),
    INDEX (viewed_at)
);

-- ============================================
-- NOTIFICATIONS TABLE
-- ============================================
CREATE TABLE notifications (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    notification_type VARCHAR(100),
    title VARCHAR(255),
    message TEXT,
    related_project_id INT,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (related_project_id) REFERENCES projects(id) ON DELETE SET NULL,
    INDEX (user_id, is_read)
);

-- ============================================
-- AUDIT LOG TABLE
-- ============================================
CREATE TABLE audit_logs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    action VARCHAR(255),
    entity_type VARCHAR(100),
    entity_id INT,
    old_values JSON,
    new_values JSON,
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX (created_at),
    INDEX (user_id)
);

-- ============================================
-- SAMPLE INSERT STATEMENTS
-- ============================================

-- Sample Admin User
INSERT INTO users (email, password_hash, first_name, last_name, role, is_verified) 
VALUES ('admin@ccdi.edu.ph', SHA2('Admin12345', 256), 'Admin', 'User', 'admin', TRUE);

-- Sample Faculty User
INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_verified) 
VALUES ('eramos@ccdi.edu.ph', SHA2('Faculty12345', 256), 'Elena', 'Ramos', 'faculty', '+639123456789', TRUE);

-- Sample Student User
INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_verified) 
VALUES ('jhonmar@ccdi.edu.ph', SHA2('Student12345', 256), 'Jhon', 'Arcos', 'student', '+639987654321', TRUE);

-- ============================================
-- INDEXES FOR PERFORMANCE
-- ============================================
CREATE INDEX idx_projects_student_status ON projects(student_id, status);
CREATE INDEX idx_projects_academic_year ON projects(academic_year);
CREATE INDEX idx_notifications_user_date ON notifications(user_id, created_at);
CREATE INDEX idx_views_project_date ON project_views(project_id, viewed_at);
