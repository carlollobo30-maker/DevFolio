<?php
/**
 * Shared project-review logic (used by faculty/review-queue.php and admin/dashboard.php).
 *
 * Workflow:  student "Request Approval"  ->  status = pending
 *            reviewer approves           ->  status = approved (shows on the feed)
 *            reviewer rejects + reason   ->  status = rejected (owner is notified with the reason)
 */

if (!function_exists('dfNotify')) {
    /** Drop a message in a user's notification inbox. */
    function dfNotify(PDO $pdo, int $userId, string $type, string $title, string $message, ?int $projectId = null): void {
        $st = $pdo->prepare(
            'INSERT INTO notifications (user_id, notification_type, title, message, related_project_id) VALUES (?, ?, ?, ?, ?)'
        );
        $st->execute([$userId, $type, mb_substr($title, 0, 255), $message, $projectId]);
    }
}

if (!function_exists('dfReviewProject')) {
    /**
     * Approve or reject a pending project.
     *
     * @param string $decision 'approve' | 'reject'
     * @return array{success:bool,message:string}
     */
    function dfReviewProject(PDO $pdo, int $projectId, int $reviewerUserId, string $decision, string $reason = ''): array {
        $reason = trim($reason);

        if ($decision === 'reject') {
            if ($reason === '') {
                return ['success' => false, 'message' => 'Please type the reason for rejecting this project.'];
            }
            if (mb_strlen($reason) > 1000) {
                return ['success' => false, 'message' => 'The reason is too long (max 1000 characters).'];
            }
        } elseif ($decision !== 'approve') {
            return ['success' => false, 'message' => 'Unknown decision.'];
        }

        // Find the project and its owner (only projects that are actually waiting for review).
        $find = $pdo->prepare(
            "SELECT p.id, p.title, p.status, u.id AS owner_user_id
             FROM projects p
             INNER JOIN students s ON s.id = p.student_id
             INNER JOIN users u ON u.id = s.user_id
             WHERE p.id = ? LIMIT 1"
        );
        $find->execute([$projectId]);
        $project = $find->fetch(PDO::FETCH_ASSOC);

        if (!$project) {
            return ['success' => false, 'message' => 'Project not found.'];
        }
        if ($project['status'] !== 'pending') {
            return ['success' => false, 'message' => 'This project has already been reviewed.'];
        }

        if ($decision === 'approve') {
            $upd = $pdo->prepare(
                "UPDATE projects
                 SET status = 'approved', rejection_reason = NULL, reviewed_by = ?, reviewed_at = NOW(), published_at = NOW()
                 WHERE id = ? AND status = 'pending'"
            );
            $upd->execute([$reviewerUserId, $projectId]);
        } else {
            $upd = $pdo->prepare(
                "UPDATE projects
                 SET status = 'rejected', rejection_reason = ?, reviewed_by = ?, reviewed_at = NOW(), published_at = NULL
                 WHERE id = ? AND status = 'pending'"
            );
            $upd->execute([$reason, $reviewerUserId, $projectId]);
        }

        // Someone else may have reviewed it a split second earlier.
        if ($upd->rowCount() === 0) {
            return ['success' => false, 'message' => 'This project has already been reviewed.'];
        }

        if ($decision === 'approve') {
            dfNotify(
                $pdo, (int) $project['owner_user_id'], 'project_approved',
                'Project approved: ' . $project['title'],
                'Your project "' . $project['title'] . '" was approved and is now visible on the feed.',
                (int) $project['id']
            );
            return ['success' => true, 'message' => 'Project approved. It is now visible on the feed.'];
        }

        dfNotify(
            $pdo, (int) $project['owner_user_id'], 'project_rejected',
            'Project rejected: ' . $project['title'],
            $reason,
            (int) $project['id']
        );
        return ['success' => true, 'message' => 'Project rejected. The reason was sent to the student.'];
    }
}

if (!function_exists('dfPendingCount')) {
    function dfPendingCount(PDO $pdo): int {
        return (int) $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'pending'")->fetchColumn();
    }
}
