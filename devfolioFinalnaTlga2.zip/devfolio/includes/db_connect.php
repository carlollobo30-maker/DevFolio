<?php
// db_connect.php - Database Connection for DEVFOLIO (CCDI Sorsogon)
$host = 'localhost';
$username = 'root';
$password = ''; // Palitan kung may password ang iyong local MySQL (e.g., XAMPP/WAMP usually walang password)
$database = 'ccdi_devfolio';

function ensureDevfolioDatabase(PDO $driver, string $database): void {
    $driver->exec("CREATE DATABASE IF NOT EXISTS `{$database}` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    $driver->exec("USE `{$database}`");

    $tables = [
        "CREATE TABLE IF NOT EXISTS users (
            id INT PRIMARY KEY AUTO_INCREMENT,
            email VARCHAR(100) UNIQUE NOT NULL,
            password_hash VARCHAR(255) NOT NULL,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            role ENUM('student', 'faculty', 'admin') NOT NULL,
            phone VARCHAR(20),
            avatar_url VARCHAR(255),
            is_verified BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            INDEX (email),
            INDEX (role)
        )",
        "CREATE TABLE IF NOT EXISTS students (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL UNIQUE,
            student_id VARCHAR(20) UNIQUE NOT NULL,
            program VARCHAR(50) NOT NULL,
            year_level VARCHAR(10),
            gpa DECIMAL(3, 2),
            adviser_id INT,
            enrollment_status ENUM('active', 'inactive', 'graduated') DEFAULT 'active',
            bio TEXT,
            portfolio_link VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (adviser_id) REFERENCES users(id),
            INDEX (student_id),
            INDEX (program)
        )",
        "CREATE TABLE IF NOT EXISTS faculty (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL UNIQUE,
            employee_id VARCHAR(20) UNIQUE,
            department VARCHAR(100),
            specialization VARCHAR(255),
            qualifications TEXT,
            is_capstone_adviser BOOLEAN DEFAULT FALSE,
            is_evaluator BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )",
        "CREATE TABLE IF NOT EXISTS projects (
            id INT PRIMARY KEY AUTO_INCREMENT,
            student_id INT NOT NULL,
            title VARCHAR(255) NOT NULL,
            description TEXT,
            abstract TEXT,
            category VARCHAR(100),
            program VARCHAR(50),
            academic_year VARCHAR(20),
            course_code VARCHAR(50),
            status ENUM('draft', 'pending', 'approved', 'rejected', 'revision_needed') DEFAULT 'draft',
            banner_image_url VARCHAR(255),
            demo_link VARCHAR(255),
            repository_link VARCHAR(255),
            tech_stack JSON,
            rejection_reason TEXT NULL,
            reviewed_by INT NULL,
            reviewed_at TIMESTAMP NULL DEFAULT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            published_at TIMESTAMP NULL,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            INDEX (status),
            INDEX (category),
            INDEX (program),
            INDEX (academic_year)
        )",
        "CREATE TABLE IF NOT EXISTS project_files (
            id INT PRIMARY KEY AUTO_INCREMENT,
            project_id INT NOT NULL,
            file_name VARCHAR(255) NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            file_size INT DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
            INDEX (project_id)
        )",
        "CREATE TABLE IF NOT EXISTS project_likes (
            id INT PRIMARY KEY AUTO_INCREMENT,
            project_id INT NOT NULL,
            user_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE KEY (project_id, user_id)
        )",
        "CREATE TABLE IF NOT EXISTS skills (
            id INT PRIMARY KEY AUTO_INCREMENT,
            student_id INT NOT NULL,
            skill_name VARCHAR(100) NOT NULL,
            proficiency_level ENUM('beginner', 'intermediate', 'advanced', 'expert') DEFAULT 'intermediate',
            verified BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            UNIQUE KEY (student_id, skill_name)
        )",
        "CREATE TABLE IF NOT EXISTS certificates (
            id INT PRIMARY KEY AUTO_INCREMENT,
            student_id INT NOT NULL,
            certificate_name VARCHAR(255) NOT NULL,
            issuing_organization VARCHAR(255),
            issue_date DATE,
            expiry_date DATE,
            credential_url VARCHAR(255),
            certificate_image_url VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
        )",
        "CREATE TABLE IF NOT EXISTS notifications (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            notification_type VARCHAR(100),
            title VARCHAR(255),
            message TEXT,
            related_project_id INT,
            is_read BOOLEAN DEFAULT FALSE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (related_project_id) REFERENCES projects(id) ON DELETE SET NULL,
            INDEX (user_id, is_read)
        )"
    ];

    foreach ($tables as $sql) {
        $driver->exec($sql);
    }

    // Approval workflow columns (adds them to databases created before this feature)
    $approvalColumns = [
        'rejection_reason' => 'ALTER TABLE projects ADD COLUMN rejection_reason TEXT NULL',
        'reviewed_by'      => 'ALTER TABLE projects ADD COLUMN reviewed_by INT NULL',
        'reviewed_at'      => 'ALTER TABLE projects ADD COLUMN reviewed_at TIMESTAMP NULL DEFAULT NULL',
    ];
    $colCheck = $driver->prepare(
        'SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = \'projects\' AND COLUMN_NAME = ?'
    );
    foreach ($approvalColumns as $column => $alterSql) {
        $colCheck->execute([$column]);
        if ((int) $colCheck->fetchColumn() === 0) {
            $driver->exec($alterSql);
        }
    }

    $seedUsers = [
        [
            'email' => 'admin@ccdi.edu.ph',
            'password' => 'Admin12345',
            'first' => 'Admin',
            'last' => 'User',
            'role' => 'admin'
        ],
        [
            'email' => 'eramos@ccdi.edu.ph',
            'password' => 'Faculty12345',
            'first' => 'Elena',
            'last' => 'Ramos',
            'role' => 'faculty'
        ],
        [
            'email' => 'jhonmar@ccdi.edu.ph',
            'password' => 'Student12345',
            'first' => 'Jhon',
            'last' => 'Arcos',
            'role' => 'student'
        ]
    ];

    foreach ($seedUsers as $user) {
        $check = $driver->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $check->execute([$user['email']]);
        if (!$check->fetch()) {
            $insert = $driver->prepare(
                'INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_verified) VALUES (?, SHA2(?, 256), ?, ?, ?, NULL, TRUE)'
            );
            $insert->execute([$user['email'], $user['password'], $user['first'], $user['last'], $user['role']]);
        }
    }
}

try {
    $rootConnection = new PDO("mysql:host={$host};charset=utf8mb4", $username, $password);
    $rootConnection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $rootConnection->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    ensureDevfolioDatabase($rootConnection, $database);

    $pdo = new PDO("mysql:host={$host};dbname={$database};charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

    $studentCheck = $pdo->query("SELECT 1 FROM students LIMIT 1");
    if ($studentCheck === false) {
        // no-op; schema ensures table exists
    }
} catch (PDOException $e) {
    die("Database Connection Failed: " . $e->getMessage());
}
?>