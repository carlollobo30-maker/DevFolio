# DEVFOLIO - CCDI Sorsogon Student Showcase Platform

A comprehensive web application for the Computer Communication Development Institute (CCDI) Sorsogon to manage, evaluate, and showcase student capstone projects and creative outputs.

## 📁 Project Structure

```
devfolio/
│
├── 📁 assets/                          # Static files (Images, CSS, Icons)
│   ├── img/                            # Image resources
│   │   ├── ccdi-logo.png
│   │   ├── hero-bg.jpg
│   │   └── default-avatar.png
│   └── css/
│       ├── tailwind.css                # Tailwind CSS output (if needed)
│       └── custom.css                  # CCDI Theme & Custom Styles (Navy & Gold)
│
├── 📁 js/                              # JavaScript Modules
│   ├── main.js                         # Core functions (Navigation, Modal, Notifications)
│   ├── public-showcase.js              # Public showcase filtering & rendering
│   ├── student-dash.js                 # Student portfolio management
│   ├── faculty-dash.js                 # Faculty evaluation & approvals
│   └── repository.js                   # Project repository filtering
│
├── 📁 includes/                        # Reusable PHP Components
│   ├── header.php                      # Navigation & Meta tags
│   ├── footer.php                      # Modals & Scripts
│   └── db_connect.php                  # Database connection (MySQL)
│
├── 📄 index.php                        # Main Landing & Public Showcase
├── 📄 login.php                        # Unified Login (Student/Faculty/Admin)
├── 📄 register.php                     # Student Registration Page
│
├── 📁 student/                         # Student Portal Module
│   ├── dashboard.php                   # Student dashboard overview
│   ├── manage-projects.php             # CRUD: Create, View, Edit, Delete projects
│   ├── manage-skills.php               # Manage skills & certificates
│   └── profile.php                     # Student profile settings
│
├── 📁 faculty/                         # Faculty & Admin Portal Module
│   ├── dashboard.php                   # Faculty main dashboard
│   ├── reports.php                # Project reports from students (moderation)
│   └── student-list.php                # Directory of all student portfolios
│
└── 📁 database/                        # Database Scripts
    └── schema.sql                      # MySQL database schema with all tables
```

## 🎨 Features

### Public Showcase (Landing Page)
- **Project Discovery**: Browse all approved student projects
- **Category Filtering**: Filter by Capstone, Web App, Mobile App, 3D & Multimedia
- **Search Functionality**: Search by project title, technology stack, or author
- **Featured Projects**: Highlighted top-performing capstones
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile

### Student Portal
- **Dashboard Overview**: View project submissions status & employer views
- **Project Management**: Upload, edit, and manage capstone projects
- **Skills & Certifications**: Add technical skills and academic badges
- **Profile Settings**: Customize portfolio information
- **Portfolio Sharing**: Generate shareable links for employers
- **Project Status Tracking**: Monitor approval status in real-time

### Faculty Dashboard
- **Review Queue**: Approve/Reject pending project submissions
- **Accreditation Reports**: Export documentation for CHED evaluation
- **Student Directory**: Browse all student portfolios
- **Program Analytics**: Visualize project distribution across programs
- **Employer Inquiry Management**: Track industry interest in students

## 🛠️ Technology Stack

### Frontend
- **Tailwind CSS**: Utility-first CSS framework
- **Font Awesome 6**: Icon library
- **Google Fonts**: Plus Jakarta Sans typography
- **Vanilla JavaScript**: No dependencies, lightweight interactions

### Backend
- **PHP 7.4+**: Server-side logic & data processing
- **MySQL 5.7+**: Relational database for persistent storage

### Theme Colors (CCDI Branding)
- **Navy**: `#0A192F` - Primary color
- **Gold**: `#F59E0B` - Accent color
- **Light**: `#F8FAFC` - Background

## 📊 Database Structure

The application includes a comprehensive MySQL schema with tables for:
- **Users**: Students, Faculty, Administrators
- **Students**: Profile, academic info, skills, certificates
- **Faculty**: Department, qualifications, adviser status
- **Projects**: Capstones, web apps, multimedia outputs
- **Evaluations**: Faculty review and scoring
- **Project Views**: Analytics for employer engagement
- **Employer Inquiries**: Hiring & partnership requests
- **Notifications**: System alerts and updates
- **Audit Logs**: Activity tracking and compliance

## 🚀 Getting Started

### Prerequisites
- PHP 7.4 or higher
- MySQL 5.7 or higher
- Web server (Apache/Nginx)
- Modern web browser

### Installation

1. **Clone/Extract the project**
   ```bash
   cd devfolio
   ```

2. **Create MySQL Database**
   ```bash
   mysql -u root -p < database/schema.sql
   ```

3. **Configure Database Connection**
   - Edit `includes/db_connect.php`
   - Update host, username, password, database name

4. **Start Web Server**
   ```bash
   php -S localhost:8000
   ```

5. **Access the Application**
   - Open browser: `http://localhost:8000`
   - Demo Login: `demo@ccdi.edu.ph` / `Demo12345`

## 📝 File Descriptions

### index.php
Main landing page with:
- Public project showcase grid
- Category and search filtering
- Student portal access
- Faculty dashboard link
- Project repository

### login.php
Unified authentication for:
- Student accounts
- Faculty members
- Administrators
- Remember me functionality
- Password recovery link

### register.php
Student registration with:
- Personal information
- Academic details (Student ID, Program, Year Level)
- Account creation
- Password validation

### student/dashboard.php
Student portal featuring:
- Portfolio overview
- Project statistics
- Quick action buttons
- Recent projects list

### student/manage-projects.php
Project management interface:
- Upload new projects
- Edit project details
- Delete submissions
- View project status

### student/manage-skills.php
Skills and certifications:
- Add technical skills
- Add professional certificates
- Remove skills/badges
- Proficiency levels

### student/profile.php
Profile management:
- Update personal information
- Change avatar/profile picture
- Edit bio and contact details
- Save profile changes

### faculty/dashboard.php
Faculty overview:
- Project statistics
- Program distribution charts
- Quick action buttons
- Pending review count

### faculty/reports.php
Project reports (moderation) interface:
- List of pending submissions
- Project details preview
- Approve/Reject functionality
- Feedback comments

### faculty/student-list.php
Student directory:
- Filter by program and year
- Search students
- View student portfolios
- Quick access to profiles

### js/main.js
Core functionality:
- View navigation (switchView)
- Modal operations (openProjectModal, closeModal)
- Toast notifications
- Utility functions (copyToClipboard)

### js/public-showcase.js
Showcase features:
- renderShowcaseProjects()
- filterCategory()
- filterShowcaseProjects()
- Sample project data store

### js/student-dash.js
Student functions:
- renderStudentProjects()
- handleProjectSubmit()
- copyStudentShareLink()
- copyShareablePortfolioLink()

### js/faculty-dash.js
Faculty features:
- renderFacultyTable()
- approveProject()
- rejectProject()
- requestRevision()
- requestEmployerContact()

### js/repository.js
Repository functions:
- renderRepository()
- filterRepository()
- getRepositoryStats()

### includes/db_connect.php
Database connection configuration:
- MySQL connection settings
- Error handling
- Character encoding setup

### database/schema.sql
Complete database schema:
- User management tables
- Student and faculty profiles
- Project storage
- Evaluations and analytics
- Audit logging

## 🎯 Key Features

### For Students
✅ Upload and showcase projects  
✅ Manage portfolio information  
✅ Track project approval status  
✅ Share portfolio links  
✅ View employer interest  
✅ Add skills and certifications  

### For Faculty
✅ Review pending submissions  
✅ Approve/Reject projects  
✅ Monitor student portfolios  
✅ View project analytics  
✅ Generate accreditation reports  
✅ Track employer inquiries  

### For Employers/Partners
✅ Browse approved projects  
✅ Filter by category and technology  
✅ View student profiles  
✅ Send hiring inquiries  
✅ Contact students directly  

## 🔐 Security Features

- User authentication system
- Role-based access control (Student/Faculty/Admin)
- Password hashing (SHA-256)
- Input validation
- Session management
- Audit logging for compliance

## 📱 Responsive Design

- Mobile-first approach
- Tablet optimization
- Desktop full-featured view
- Touch-friendly interfaces
- Fast loading times

## 🌐 Browser Support

- Chrome (Latest)
- Firefox (Latest)
- Safari (Latest)
- Edge (Latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

## 📞 Support & Contact

For technical issues or feature requests:
- Contact: CCDI Sorsogon IT Department
- Email: support@ccdi.edu.ph

## 📄 License

© 2025 CCDI Sorsogon. All rights reserved.

---

**Version**: 1.0.0  
**Last Updated**: October 2026  
**Status**: Production Ready
