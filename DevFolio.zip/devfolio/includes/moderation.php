<?php
/**
 * DEVFOLIO moderation: project reports, warnings, removals and bans.
 * Shared by the student, faculty and admin pages. Only functions and constants here.
 */

const DF_REPORT_REASONS = [
    'sexual_harassment' => 'Sexual harassment',
    'harassment'        => 'Harassment or bullying',
    'hate'              => 'Hate speech or discrimination',
    'violence'          => 'Violence or threats',
    'sexual_content'    => 'Nudity or sexual content',
    'plagiarism'        => 'Plagiarism or copied work',
    'spam'              => 'Spam or scam',
];

const DF_BAN_DURATIONS = [1 => '1 day', 3 => '3 days', 7 => '7 days', 14 => '14 days', 30 => '30 days', 90 => '90 days'];

if (!function_exists('dfNotify')) {
    /** Drop a message in a user's notification inbox. */
    function dfNotify(PDO $pdo, int $userId, string $type, string $title, string $message, ?int $projectId = null): void {
        $st = $pdo->prepare(
            'INSERT INTO notifications (user_id, notification_type, title, message, related_project_id) VALUES (?, ?, ?, ?, ?)'
        );
        $st->execute([$userId, $type, mb_substr($title, 0, 255), $message, $projectId]);
    }
}

function dfActiveBan(PDO $pdo, int $userId): ?array {
    $st = $pdo->prepare(
        "SELECT * FROM user_sanctions
         WHERE user_id = ? AND type = 'ban' AND lifted_at IS NULL AND (permanent = 1 OR expires_at > NOW())
         ORDER BY permanent DESC, expires_at DESC, id DESC LIMIT 1"
    );
    $st->execute([$userId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

function dfBanMessage(array $ban): string {
    $when = !empty($ban['permanent'])
        ? 'permanently banned'
        : 'banned until ' . date('F j, Y g:i A', strtotime((string) $ban['expires_at']));
    $msg = 'Your account is ' . $when . '.';
    if (!empty($ban['reason'])) $msg .= ' Reason: ' . $ban['reason'];
    return $msg . ' Please contact a faculty member if you think this is a mistake.';
}

function dfOpenReportCount(PDO $pdo): int {
    return (int) $pdo->query("SELECT COUNT(*) FROM project_reports WHERE status = 'open'")->fetchColumn();
}

function dfFetchReports(PDO $pdo, string $scope): array {
    $where = $scope === 'open' ? "r.status = 'open'" : "r.status <> 'open'";
    $order = $scope === 'open' ? 'r.created_at ASC, r.id ASC' : 'r.handled_at DESC, r.id DESC LIMIT 15';
    return $pdo->query(
        "SELECT r.*, p.status AS project_status, p.description, p.category, p.tech_stack, p.banner_image_url, p.demo_link, p.repository_link,
                ou.first_name AS owner_first, ou.last_name AS owner_last, ou.email AS owner_email,
                ru.first_name AS reporter_first, ru.last_name AS reporter_last,
                hu.first_name AS handler_first, hu.last_name AS handler_last,
                (SELECT COUNT(*) FROM user_sanctions w WHERE w.user_id = r.reported_user_id AND w.type = 'warning') AS owner_warnings,
                (SELECT COUNT(*) FROM project_reports r2 WHERE r2.reported_user_id = r.reported_user_id) AS owner_reports_total
         FROM project_reports r
         LEFT JOIN projects p ON p.id = r.project_id
         LEFT JOIN users ou ON ou.id = r.reported_user_id
         LEFT JOIN users ru ON ru.id = r.reporter_user_id
         LEFT JOIN users hu ON hu.id = r.handled_by
         WHERE $where ORDER BY $order"
    )->fetchAll(PDO::FETCH_ASSOC);
}

function dfActiveBans(PDO $pdo): array {
    return $pdo->query(
        "SELECT s.*, u.first_name, u.last_name, u.email
         FROM user_sanctions s INNER JOIN users u ON u.id = s.user_id
         WHERE s.type = 'ban' AND s.lifted_at IS NULL AND (s.permanent = 1 OR s.expires_at > NOW())
         ORDER BY s.created_at DESC"
    )->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * Decide on an open report.
 * $action: dismiss | remove | warn | ban
 * Ban: pass $banDays (1..365) or $permanent = true. $alsoRemove also removes the reported project.
 *
 * @return array{success:bool,message:string}
 */
function dfResolveReport(PDO $pdo, int $reportId, int $modId, string $action, string $note, ?int $banDays = null, bool $permanent = false, bool $alsoRemove = false): array {
    $note = trim($note);
    if (!in_array($action, ['dismiss', 'remove', 'warn', 'ban'], true)) {
        return ['success' => false, 'message' => 'Please choose what to do with this report.'];
    }
    if ($action !== 'dismiss' && mb_strlen($note) < 3) {
        return ['success' => false, 'message' => 'Please type the reason. It is sent to the project owner.'];
    }
    if (mb_strlen($note) > 1000) {
        return ['success' => false, 'message' => 'The message is too long (max 1000 characters).'];
    }
    if ($action === 'ban' && !$permanent && ($banDays === null || $banDays < 1 || $banDays > 365)) {
        return ['success' => false, 'message' => 'Choose how long the ban lasts, or make it permanent.'];
    }

    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT * FROM project_reports WHERE id = ? FOR UPDATE');
        $st->execute([$reportId]);
        $report = $st->fetch(PDO::FETCH_ASSOC);
        if (!$report) { $pdo->rollBack(); return ['success' => false, 'message' => 'Report not found.']; }
        if ($report['status'] !== 'open') { $pdo->rollBack(); return ['success' => false, 'message' => 'This report was already handled.']; }

        $ownerId = (int) ($report['reported_user_id'] ?? 0);
        $projectId = (int) ($report['project_id'] ?? 0);
        $title = (string) $report['project_title'];
        if (in_array($action, ['warn', 'ban'], true) && $ownerId === 0) {
            $pdo->rollBack();
            return ['success' => false, 'message' => 'The reported user no longer exists.'];
        }

        $removeProject = function () use ($pdo, $projectId, $ownerId, $title, $note) {
            if ($projectId === 0) return;
            $u = $pdo->prepare("UPDATE projects SET status = 'removed', published_at = NULL WHERE id = ? AND status <> 'removed'");
            $u->execute([$projectId]);
            if ($u->rowCount() > 0 && $ownerId > 0) {
                dfNotify($pdo, $ownerId, 'project_removed', 'Your project was removed: ' . $title, $note, $projectId);
            }
        };

        $message = '';
        $cascade = false;

        if ($action === 'remove') {
            $removeProject();
            $cascade = true;
            $message = 'Project removed. The owner was notified.';
        } elseif ($action === 'warn') {
            $pdo->prepare("INSERT INTO user_sanctions (user_id, type, reason, report_id, issued_by) VALUES (?, 'warning', ?, ?, ?)")
                ->execute([$ownerId, $note, $reportId, $modId]);
            dfNotify($pdo, $ownerId, 'moderation_warning', 'Warning from moderators', $note, $projectId ?: null);
            $message = 'Warning sent to the user.';
        } elseif ($action === 'ban') {
            if ($permanent) {
                $pdo->prepare("INSERT INTO user_sanctions (user_id, type, reason, report_id, issued_by, permanent) VALUES (?, 'ban', ?, ?, ?, 1)")
                    ->execute([$ownerId, $note, $reportId, $modId]);
                $length = 'permanently';
            } else {
                $pdo->prepare("INSERT INTO user_sanctions (user_id, type, reason, report_id, issued_by, permanent, expires_at) VALUES (?, 'ban', ?, ?, ?, 0, DATE_ADD(NOW(), INTERVAL ? DAY))")
                    ->execute([$ownerId, $note, $reportId, $modId, (int) $banDays]);
                $length = 'for ' . (int) $banDays . ' day' . ((int) $banDays === 1 ? '' : 's');
            }
            dfNotify($pdo, $ownerId, 'moderation_ban', 'Your account was banned ' . $length, $note, $projectId ?: null);
            if ($alsoRemove) { $removeProject(); $cascade = true; }
            $message = 'User banned ' . $length . '.' . ($alsoRemove ? ' The project was removed too.' : '');
        } else {
            $message = 'Report dismissed.';
        }

        $final = $action === 'dismiss' ? 'dismissed' : 'resolved';
        $pdo->prepare('UPDATE project_reports SET status = ?, action_taken = ?, resolution_note = ?, handled_by = ?, handled_at = NOW() WHERE id = ?')
            ->execute([$final, $action === 'ban' && $alsoRemove ? 'ban' : $action, $note !== '' ? $note : null, $modId, $reportId]);

        if ($cascade && $projectId > 0) {
            $pdo->prepare("UPDATE project_reports SET status = 'resolved', action_taken = 'remove', resolution_note = ?, handled_by = ?, handled_at = NOW()
                           WHERE project_id = ? AND status = 'open' AND id <> ?")
                ->execute(['Closed together with report #' . $reportId, $modId, $projectId, $reportId]);
        }

        $pdo->commit();
        return ['success' => true, 'message' => $message];
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return ['success' => false, 'message' => 'Something went wrong while saving the decision.'];
    }
}

function dfLiftBan(PDO $pdo, int $sanctionId, int $modId): array {
    $st = $pdo->prepare("SELECT * FROM user_sanctions WHERE id = ? AND type = 'ban' AND lifted_at IS NULL LIMIT 1");
    $st->execute([$sanctionId]);
    $ban = $st->fetch(PDO::FETCH_ASSOC);
    if (!$ban) return ['success' => false, 'message' => 'That ban is no longer active.'];
    $pdo->prepare('UPDATE user_sanctions SET lifted_at = NOW(), lifted_by = ? WHERE id = ?')->execute([$modId, $sanctionId]);
    dfNotify($pdo, (int) $ban['user_id'], 'moderation_ban_lifted', 'Your ban was lifted', 'A moderator lifted your ban. You can use DEVFOLIO again. Please follow the community guidelines.');
    return ['success' => true, 'message' => 'Ban lifted. The user can sign in again.'];
}
