<?php
/**
 * "My Projects" tab of the student's own profile.
 * Lists every project the student uploaded, with Edit and Delete.
 * Needs ui-helpers.php, project-helpers.php and project-form.php loaded.
 */

require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';
require_once __DIR__ . '/project-form.php';

/**
 * Photos of a project in order. A project that only has an old single cover gets it
 * saved as its first photo row, so the edit form can show and manage it.
 *
 * @return array<int,array{id:int,url:string}>
 */
function dfMyProjectPhotos(PDO $pdo, int $projectId, ?string $banner): array {
    if (!dfPhotosReady($pdo)) return [];
    $st = $pdo->prepare('SELECT id, file_path FROM project_photos WHERE project_id = ? ORDER BY sort_order ASC, id ASC');
    $st->execute([$projectId]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows && dfIsRealPhoto($banner)) {
        $pdo->prepare('INSERT INTO project_photos (project_id, file_path, sort_order) VALUES (?, ?, 0)')->execute([$projectId, $banner]);
        $st->execute([$projectId]);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    }
    $out = [];
    foreach ($rows as $r) $out[] = ['id' => (int) $r['id'], 'url' => dfAssetUrl($r['file_path'])];
    return $out;
}

/** Everything the owner's list and edit form need, newest first. */
function dfFetchMyProjects(PDO $pdo, int $userId): array {
    $st = $pdo->prepare(
        "SELECT p.*,
                (SELECT COUNT(*) FROM project_likes l WHERE l.project_id = p.id) AS like_count,
                (SELECT COUNT(*) FROM project_comments c WHERE c.project_id = p.id) AS comment_count,
                COALESCE((SELECT r.resolution_note FROM project_reports r
                          WHERE r.project_id = p.id AND r.action_taken IN ('remove', 'ban') AND r.resolution_note IS NOT NULL
                          ORDER BY r.handled_at DESC, r.id DESC LIMIT 1), p.rejection_reason) AS moderation_note
         FROM projects p
         INNER JOIN students s ON s.id = p.student_id
         WHERE s.user_id = ?
         ORDER BY p.created_at DESC, p.id DESC"
    );
    try {
        $st->execute([$userId]);
    } catch (Throwable $e) {
        // older database without comments/likes tables: fall back to a plain list
        $st = $pdo->prepare('SELECT p.*, 0 AS like_count, 0 AS comment_count, p.rejection_reason AS moderation_note FROM projects p INNER JOIN students s ON s.id = p.student_id WHERE s.user_id = ? ORDER BY p.created_at DESC, p.id DESC');
        $st->execute([$userId]);
    }
    return $st->fetchAll(PDO::FETCH_ASSOC);
}

/** The tab panel content for the owner's profile. */
function dfRenderMyProjectsPanel(PDO $pdo, int $userId): string {
    $projects = dfFetchMyProjects($pdo, $userId);
    $data = [];
    $e = 'dfEsc';

    ob_start(); ?>
    <section class="upx-card mp" aria-labelledby="mpHeading">
        <div class="pf-card-head">
            <h2 class="upx-h" id="mpHeading">My Projects</h2>
            <span class="upx-muted" id="mpCount"><?php echo count($projects); ?> <?php echo count($projects) === 1 ? 'project' : 'projects'; ?></span>
        </div>

        <?php if (!$projects): ?>
            <div class="mp-empty">
                <p><b>You have not uploaded a project yet.</b></p>
                <p>Post one from the Discover page and it will show up here, where you can edit or delete it.</p>
                <a class="df-btn df-btn-primary" href="dashboard.php"><?php echo dfIcon('plus', 16); ?> Go to Discover</a>
            </div>
        <?php else: ?>
            <div class="mp-list">
            <?php foreach ($projects as $p):
                $pid = (int) $p['id'];
                $removed = $p['status'] === 'removed';
                $isDraft = $p['status'] === 'draft';
                $photos = dfMyProjectPhotos($pdo, $pid, $p['banner_image_url'] ?? '');
                $thumb = $photos ? $photos[0]['url'] : '';
                $tags = dfTags($p['tech_stack'] ?? null);
                $desc = trim((string) ($p['description'] ?? ''));
                if ($desc === '') $desc = trim((string) ($p['abstract'] ?? ''));
                $cat = (string) ($p['category'] ?? '');
                $inList = in_array($cat, DF_PROJECT_CATEGORIES, true);
                $data[$pid] = [
                    'id'          => $pid,
                    'title'       => (string) $p['title'],
                    'category'    => $inList ? $cat : ($cat === '' ? 'Web App' : 'Others, Specify'),
                    'categoryOther' => $inList ? '' : $cat,
                    'description' => $desc,
                    'tech'        => implode(', ', $tags),
                    'link'        => dfSafeLink($p['demo_link'] ?? ''),
                    'photos'      => $photos,
                    'removed'     => $removed,
                ];
                $url = 'project.php?id=' . $pid;
                $likes = (int) $p['like_count'];
                $comments = (int) $p['comment_count'];
            ?>
                <article class="mp-row<?php echo $removed ? ' is-removed' : ''; ?>" data-project-row="<?php echo $pid; ?>">
                    <a class="mp-thumb <?php echo $e(dfTint($cat)); ?>" href="<?php echo $e($url); ?>" tabindex="-1" aria-hidden="true">
                        <span class="mp-thumb-letter"><?php echo $e(mb_strtoupper(mb_substr((string) $p['title'], 0, 1))); ?></span>
                        <?php if ($thumb !== ''): ?><img src="<?php echo $e($thumb); ?>" alt="" loading="lazy" onerror="this.remove()"><?php endif; ?>
                    </a>
                    <div class="mp-main">
                        <div class="mp-top">
                            <h3 class="mp-title"><a href="<?php echo $e($url); ?>"><?php echo $e($p['title']); ?></a></h3>
                            <?php if ($removed): ?>
                                <span class="mp-badge is-removed">Removed by moderator</span>
                            <?php elseif ($isDraft): ?>
                                <span class="mp-badge">Draft</span>
                            <?php else: ?>
                                <span class="mp-badge is-live">Published</span>
                            <?php endif; ?>
                        </div>
                        <p class="mp-meta">
                            <?php if ($cat !== ''): ?><span><?php echo $e($cat); ?></span><?php endif; ?>
                            <span>Posted <?php echo $e(dfTimeAgo($p['created_at'] ?? null)); ?></span>
                            <span><?php echo dfIcon('heart', 13); ?> <?php echo $likes; ?></span>
                            <span><?php echo dfIcon('comment', 13); ?> <?php echo $comments; ?></span>
                        </p>
                        <?php if ($desc !== ''): ?><p class="mp-desc"><?php echo $e($desc); ?></p><?php endif; ?>
                        <?php if ($removed): ?>
                            <div class="mp-note" role="note">
                                <b>Message from moderators</b>
                                <p><?php echo nl2br($e($p['moderation_note'] ?: 'This project was removed after a report. Check your notifications for details.')); ?></p>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div class="mp-actions">
                        <a class="df-btn df-btn-ghost" href="<?php echo $e($url); ?>"><?php echo dfIcon('external', 15); ?> View</a>
                        <?php if (!$removed): ?>
                            <button type="button" class="df-btn df-btn-ghost" data-proj-edit="<?php echo $pid; ?>"><?php echo dfIcon('compose', 15); ?> Edit</button>
                        <?php endif; ?>
                        <button type="button" class="df-btn mp-delete" data-proj-delete="<?php echo $pid; ?>" data-title="<?php echo $e($p['title']); ?>"><?php echo dfIcon('trash', 15); ?> Delete</button>
                    </div>
                </article>
            <?php endforeach; ?>
            </div>
            <script type="application/json" id="mpData"><?php echo json_encode($data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?></script>
        <?php endif; ?>
    </section>
    <?php
    return ob_get_clean();
}

/** The Edit and Delete dialogs (white dialogs, same look as "Showcase a project"). */
function dfRenderMyProjectsDialogs(): string {
    ob_start(); ?>
    <div id="mpEditModal" class="df-modal" hidden>
        <div class="df-dialog is-wide" role="dialog" aria-modal="true" aria-labelledby="mpEditTitle">
            <button type="button" class="df-x" data-mp-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
            <div class="df-dialog-pad">
                <h2 id="mpEditTitle">Edit project</h2>
                <form id="mpEditForm" enctype="multipart/form-data">
                    <input type="hidden" name="action" value="update_project">
                    <input type="hidden" name="project_id" id="mpId" value="">
                    <div class="df-field">
                        <label for="mpTitle">Project title <span class="req" aria-hidden="true">*</span></label>
                        <input id="mpTitle" name="title" type="text" required maxlength="255" class="df-light">
                    </div>
                    <div class="df-field">
                        <label for="mpCategory">Category</label>
                        <select id="mpCategory" name="category" class="df-light">
                            <?php foreach (DF_PROJECT_CATEGORIES as $c): ?><option><?php echo dfEsc($c); ?></option><?php endforeach; ?>
                            <option>Others, Specify</option>
                        </select>
                        <input id="mpCategoryOther" name="category_other" type="text" maxlength="100" class="df-light df-other" placeholder="Type your project's category" aria-label="Specify the category" hidden style="margin-top:8px">
                    </div>
                    <div class="df-field">
                        <label for="mpDesc">Description <span class="req" aria-hidden="true">*</span></label>
                        <textarea id="mpDesc" name="description" rows="5" required class="df-light"></textarea>
                    </div>
                    <div class="df-field">
                        <label for="mpTech">Technologies</label>
                        <input id="mpTech" name="tech_stack" type="text" class="df-light" placeholder="React, Tailwind, Firebase">
                        <small>Separate with commas (up to 8).</small>
                    </div>
                    <div class="df-field">
                        <?php echo dfPhotoPickerHtml(); ?>
                    </div>
                    <div class="df-field">
                        <label for="mpLink">Project link</label>
                        <input id="mpLink" name="project_link" type="url" class="df-light" placeholder="https://... (live demo or repository)">
                        <small>Your README and team are edited on the project page.</small>
                    </div>
                    <div class="df-actions">
                        <button type="submit" id="mpSave" class="df-btn df-btn-primary">Save changes</button>
                        <button type="button" class="df-btn df-btn-ghost" data-mp-close>Cancel</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <div id="mpDeleteModal" class="df-modal" hidden>
        <div class="df-dialog" role="alertdialog" aria-modal="true" aria-labelledby="mpDelTitle" aria-describedby="mpDelText">
            <button type="button" class="df-x" data-mp-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
            <div class="df-dialog-pad">
                <h2 id="mpDelTitle" class="df-report-h"><?php echo dfIcon('trash', 22); ?> Delete this project?</h2>
                <p class="df-report-sub" id="mpDelName" style="margin-top:-6px"></p>
                <p id="mpDelText" class="mp-del-text">This permanently deletes the project with its photos, comments, hearts and README. This cannot be undone.</p>
                <div class="df-actions">
                    <button type="button" id="mpDelConfirm" class="df-btn df-btn-danger">Delete project</button>
                    <button type="button" class="df-btn df-btn-ghost" data-mp-close>Cancel</button>
                </div>
            </div>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
