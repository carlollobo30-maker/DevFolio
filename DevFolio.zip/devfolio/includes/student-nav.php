<?php
/**
 * Shared top navigation for student pages (DEVFOLIO redesign).
 * Expects: $pdo and an active student session.
 * Optional: $navActive = 'discover' | 'myprofile' | 'profile'
 */
require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/badges.php';

$navActive = $navActive ?? 'discover';

$navUserStmt = $pdo->prepare('SELECT first_name, last_name, email, avatar_url FROM users WHERE id = ? LIMIT 1');
$navUserStmt->execute([$_SESSION['user_id']]);
$navUser = $navUserStmt->fetch(PDO::FETCH_ASSOC) ?: [];

$navName = trim((string) ($navUser['first_name'] ?? '') . ' ' . (string) ($navUser['last_name'] ?? ''));
if ($navName === '') $navName = 'Student';
$navInitials = dfInitials($navUser['first_name'] ?? '', $navUser['last_name'] ?? '');
$navAvatar = dfAssetUrl($navUser['avatar_url'] ?? '');

// Streak + badges (before the inbox query so a new-badge notice shows up straight away)
$navUid = (int) $_SESSION['user_id'];
$navStreak = dfTouchStreak($pdo, $navUid);
dfRunBadgeCheck($pdo, $navUid, 'student');
$navNewBadges = dfPopNewBadges();

// Inbox: notices from moderators (warnings, removed projects, bans)
$navNotifStmt = $pdo->prepare('SELECT id, notification_type, title, message, related_project_id, is_read, created_at FROM notifications WHERE user_id = ? ORDER BY created_at DESC, id DESC LIMIT 8');
$navNotifStmt->execute([$_SESSION['user_id']]);
$navNotifs = $navNotifStmt->fetchAll(PDO::FETCH_ASSOC);
$navUnread = 0;
foreach ($navNotifs as $n) { if (empty($n['is_read'])) $navUnread++; }
$navUnreadTotal = (int) $pdo->query('SELECT COUNT(*) FROM notifications WHERE is_read = FALSE AND user_id = ' . (int) $_SESSION['user_id'])->fetchColumn();

$navTabs = [
    'discover' => ['dashboard.php', 'Discover'],
    'myprofile' => ['my-profile.php', 'Profile'],
];
?>
<a class="df-skip" href="#main">Skip to content</a>
<header class="df-nav">
    <div class="df-nav-inner">
        <a class="df-brand" href="dashboard.php" aria-label="DevFolio home">
            <span class="df-brand-mark"><?php echo dfIcon('code', 20); ?></span>
            <span class="df-brand-name">devfolio</span>
        </a>

        <nav class="df-tabs" aria-label="Primary">
            <?php foreach ($navTabs as $key => $tab): ?>
                <a href="<?php echo htmlspecialchars($tab[0]); ?>" class="df-tab"<?php echo $navActive === $key ? ' aria-current="page"' : ''; ?>><?php echo htmlspecialchars($tab[1]); ?></a>
            <?php endforeach; ?>
        </nav>

        <?php echo dfStreakChip($navStreak); ?>

        <details class="df-user df-notif" id="dfNotifMenu">
            <summary class="df-bell-btn" aria-label="Notifications<?php echo $navUnreadTotal > 0 ? ', ' . $navUnreadTotal . ' unread' : ''; ?>">
                <?php echo dfIcon('bell', 18); ?>
                <?php if ($navUnreadTotal > 0): ?><b class="df-bell-badge"><?php echo $navUnreadTotal > 9 ? '9+' : $navUnreadTotal; ?></b><?php endif; ?>
            </summary>
            <div class="df-menu df-notif-menu">
                <div class="df-menu-head"><strong>Notifications</strong></div>
                <?php if (empty($navNotifs)): ?>
                    <p class="df-notif-empty">No messages yet. Comments on your projects, new projects from students you follow, and notices from moderators will show up here.</p>
                <?php else: ?>
                    <ul class="df-notif-list">
                        <?php foreach ($navNotifs as $n): $rejected = in_array($n['notification_type'], ['project_removed', 'moderation_warning', 'moderation_ban', 'project_rejected'], true); ?>
                            <li class="df-notif-item<?php echo empty($n['is_read']) ? ' is-unread' : ''; ?><?php echo $rejected ? ' is-rejected' : ''; ?>">
                                <strong><?php echo htmlspecialchars((string) $n['title']); ?></strong>
                                <?php if ($rejected): ?><span class="df-notif-label">Message from moderators</span><?php endif; ?>
                                <p><?php echo nl2br(htmlspecialchars((string) $n['message'])); ?></p>
                                <small><?php echo htmlspecialchars(date('M j, Y g:i A', strtotime((string) $n['created_at']))); ?><?php if ($rejected && !empty($n['related_project_id'])): ?> · <a href="project.php?id=<?php echo (int) $n['related_project_id']; ?>">View project</a><?php elseif ($rejected): ?><?php elseif ($n['notification_type'] === 'project_comment' && !empty($n['related_project_id'])): ?> · <a href="project.php?id=<?php echo (int) $n['related_project_id']; ?>#comments">View</a><?php elseif (in_array($n['notification_type'], ['new_project', 'project_shared', 'project_tag'], true) && !empty($n['related_project_id'])): ?> · <a href="project.php?id=<?php echo (int) $n['related_project_id']; ?>">View project</a><?php endif; ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </details>

        <details class="df-user" id="dfUserMenu">
            <summary class="df-avatar-btn<?php echo $navActive === 'profile' ? ' is-current' : ''; ?>" aria-label="Account menu for <?php echo htmlspecialchars($navName); ?>">
                <?php if ($navAvatar !== ''): ?>
                    <img src="<?php echo htmlspecialchars($navAvatar); ?>" alt="" onerror="this.remove()">
                <?php endif; ?>
                <span><?php echo htmlspecialchars($navInitials); ?></span>
            </summary>
            <div class="df-menu">
                <div class="df-menu-head">
                    <strong><?php echo htmlspecialchars($navName); ?></strong>
                    <span><?php echo htmlspecialchars((string) ($navUser['email'] ?? '')); ?></span>
                    <?php echo dfRoleBadge('student'); ?>
                </div>
                <a class="df-menu-item" href="badges.php"><?php echo dfIcon('award', 16); ?> Badges &amp; streak</a>
                <a class="df-menu-item" href="profile.php"><?php echo dfIcon('user', 16); ?> Account settings</a>
                <form method="POST" action="dashboard.php">
                    <button type="submit" name="logout" value="1" class="df-menu-item"><?php echo dfIcon('logout', 16); ?> Log out</button>
                </form>
            </div>
        </details>
    </div>
</header>
<script>
    (function () {
        ['dfUserMenu', 'dfNotifMenu'].forEach(function (id) {
            var menu = document.getElementById(id);
            if (!menu) return;
            document.addEventListener('click', function (e) { if (menu.open && !menu.contains(e.target)) menu.open = false; });
            menu.addEventListener('keydown', function (e) {
                if (e.key === 'Escape' && menu.open) { menu.open = false; menu.querySelector('summary').focus(); }
            });
        });
        // Opening the inbox marks everything as read
        var notif = document.getElementById('dfNotifMenu');
        if (notif) {
            notif.addEventListener('toggle', function () {
                var badge = notif.querySelector('.df-bell-badge');
                if (!notif.open || !badge) return;
                fetch('notifications.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                    body: 'action=mark_read'
                }).then(function () { badge.remove(); });
            });
        }
    })();
</script>
<?php if (!empty($navNewBadges)): ?>
<script>
    // "Badge unlocked" toasts
    (function () {
        var items = <?php echo json_encode(array_map(static function ($d) { return ['name' => $d['name'], 'tier' => dfTiers()[$d['tier']]['label']]; }, $navNewBadges), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
        items.slice(0, 4).forEach(function (it, i) {
            setTimeout(function () {
                var el = document.createElement('div');
                el.className = 'df-toast ok';
                el.style.top = (80 + i * 64) + 'px';
                el.textContent = 'Badge unlocked: ' + it.name + ' (' + it.tier + ')';
                document.body.appendChild(el);
                setTimeout(function () { el.style.opacity = '0'; }, 4800);
                setTimeout(function () { el.remove(); }, 5300);
            }, 500 + i * 400);
        });
    })();
</script>
<?php endif; ?>
