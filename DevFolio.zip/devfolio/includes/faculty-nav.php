<?php
/**
 * Shared top navigation for faculty pages (same look as the student header).
 * Expects: $pdo and an active faculty session.
 * Optional: $facActive = 'discover' | 'reports' | 'students'
 *
 * Also prepares $navUser (used by social-ui.php) and $openCount (used by the sidebar).
 */
require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/badges.php';

$facActive = $facActive ?? 'discover';

$navUserStmt = $pdo->prepare('SELECT first_name, last_name, email, avatar_url FROM users WHERE id = ? LIMIT 1');
$navUserStmt->execute([$_SESSION['user_id']]);
$navUser = $navUserStmt->fetch(PDO::FETCH_ASSOC) ?: [];

$navName = trim((string) ($navUser['first_name'] ?? '') . ' ' . (string) ($navUser['last_name'] ?? ''));
if ($navName === '') $navName = 'Faculty';
$navInitials = dfInitials($navUser['first_name'] ?? '', $navUser['last_name'] ?? '');
$navAvatar = dfAssetUrl($navUser['avatar_url'] ?? '');

// Streak + badges
$navUid = (int) $_SESSION['user_id'];
$navStreak = dfTouchStreak($pdo, $navUid);
dfRunBadgeCheck($pdo, $navUid, 'faculty');
$navNewBadges = dfPopNewBadges();

$openCount = dfOpenReportCount($pdo);
?>
<a class="df-skip" href="#main">Skip to content</a>
<header class="df-nav">
    <div class="df-nav-inner">
        <a class="df-brand" href="dashboard.php" aria-label="DevFolio home">
            <span class="df-brand-mark"><?php echo dfIcon('code', 20); ?></span>
            <span class="df-brand-name">devfolio</span>
        </a>

        <nav class="df-tabs df-tabs-right" aria-label="Primary">
            <a href="dashboard.php" class="df-tab"<?php echo $facActive === 'discover' ? ' aria-current="page"' : ''; ?>>Home</a>
            <a href="reports.php" class="df-tab"<?php echo $facActive === 'reports' ? ' aria-current="page"' : ''; ?>>Project Reports<?php if ($openCount > 0): ?><b class="fac-badge" aria-label="<?php echo (int) $openCount; ?> open"><?php echo (int) $openCount; ?></b><?php endif; ?></a>
            <a href="student-list.php" class="df-tab"<?php echo $facActive === 'students' ? ' aria-current="page"' : ''; ?>>Student Directory</a>
        </nav>

        <?php echo dfStreakChip($navStreak); ?>

        <details class="df-user" id="dfUserMenu">
            <summary class="df-avatar-btn" aria-label="Account menu for <?php echo htmlspecialchars($navName); ?>">
                <?php if ($navAvatar !== ''): ?>
                    <img src="<?php echo htmlspecialchars($navAvatar); ?>" alt="" onerror="this.remove()">
                <?php endif; ?>
                <span><?php echo htmlspecialchars($navInitials); ?></span>
            </summary>
            <div class="df-menu">
                <div class="df-menu-head">
                    <strong><?php echo htmlspecialchars($navName); ?></strong>
                    <span><?php echo htmlspecialchars((string) ($navUser['email'] ?? '')); ?></span>
                    <?php echo dfRoleBadge('faculty'); ?>
                </div>
                <a class="df-menu-item" href="badges.php"><?php echo dfIcon('award', 16); ?> Badges &amp; streak</a>
                <form method="POST" action="dashboard.php">
                    <button type="submit" name="logout" value="1" class="df-menu-item"><?php echo dfIcon('logout', 16); ?> Log out</button>
                </form>
            </div>
        </details>
    </div>
</header>
<script>
    (function () {
        var menu = document.getElementById('dfUserMenu');
        if (!menu) return;
        document.addEventListener('click', function (e) { if (menu.open && !menu.contains(e.target)) menu.open = false; });
        menu.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && menu.open) { menu.open = false; menu.querySelector('summary').focus(); }
        });
    })();
</script>
<?php if (!empty($navNewBadges)): ?>
<script>
    // "Badge unlocked" toasts
    (function () {
        var items = <?php echo json_encode(array_map(static function ($d) { return ['name' => $d['name'], 'tier' => dfTiers()[$d['tier']]['label']]; }, $navNewBadges), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
        items.slice(0, 4).forEach(function (it, i) {
            setTimeout(function () {
                var el = document.createElement('div');
                el.className = 'df-toast ok';
                el.style.top = (80 + i * 64) + 'px';
                el.textContent = 'Badge unlocked: ' + it.name + ' (' + it.tier + ')';
                document.body.appendChild(el);
                setTimeout(function () { el.style.opacity = '0'; }, 4800);
                setTimeout(function () { el.remove(); }, 5300);
            }, 500 + i * 400);
        });
    })();
</script>
<?php endif; ?>
