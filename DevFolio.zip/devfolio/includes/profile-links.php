<?php
/**
 * Working profiles & links (LinkedIn, GitHub, personal portfolio, Behance, ...).
 *
 * Edited on Account settings (student/profile.php, saved through student/profile-actions.php).
 * Shown on the profile header (student/my-profile.php + student/user.php), on the About tab,
 * and at the top right of every project the member posted (student/project.php).
 *
 * The old single students.portfolio_link is still honoured: it shows as a "Portfolio" link
 * until the member removes it, so nothing that was saved before this feature disappears.
 *
 * Needs ui-helpers.php and project-helpers.php (dfIcon, dfEsc, dfSafeLink) loaded by the page.
 */

const DF_LINK_LIMIT = 8;
const DF_LINK_URL_MAX = 255;
const DF_LINK_LABEL_MAX = 40;

/** Link types the member can pick: key => [label, icon]. */
function dfLinkTypes(): array {
    return [
        'linkedin'  => ['LinkedIn', 'linkedin'],
        'github'    => ['GitHub', 'github'],
        'gitlab'    => ['GitLab', 'gitlab'],
        'portfolio' => ['Portfolio', 'briefcase'],
        'behance'   => ['Behance', 'palette'],
        'dribbble'  => ['Dribbble', 'dribbble'],
        'website'   => ['Website', 'globe'],
        'other'     => ['Link', 'link'],
    ];
}

/** Creates profile_links if it is missing (once per session). */
function dfLinksReady(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    if (!empty($_SESSION['df_links_table'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS profile_links (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            kind VARCHAR(20) NOT NULL DEFAULT 'other',
            label VARCHAR(" . DF_LINK_LABEL_MAX . ") NULL,
            url VARCHAR(" . DF_LINK_URL_MAX . ") NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            INDEX idx_profile_links_user (user_id, sort_order),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $_SESSION['df_links_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return $ready = false;
    }
}

/**
 * Cleans what the member typed into a safe absolute http(s) URL.
 * "linkedin.com/in/jhon" becomes "https://linkedin.com/in/jhon". Returns '' when it is not a real web link.
 */
function dfNormalizeLinkUrl(string $raw): string {
    $url = trim($raw);
    if ($url === '') return '';
    if (!preg_match('#^[a-z][a-z0-9+.-]*://#i', $url)) $url = 'https://' . ltrim($url, '/');
    if (!preg_match('#^https?://#i', $url)) return '';
    if (mb_strlen($url) > DF_LINK_URL_MAX) return '';
    if (filter_var($url, FILTER_VALIDATE_URL) === false) return '';
    $host = (string) parse_url($url, PHP_URL_HOST);
    if ($host === '' || strpos($host, '.') === false) return '';
    return $url;
}

/** Guesses the link type from its address (used when the member leaves the type on "Detect"). */
function dfDetectLinkKind(string $url): string {
    $host = strtolower((string) parse_url($url, PHP_URL_HOST));
    $host = preg_replace('/^www\./', '', $host);
    $map = [
        'linkedin.com' => 'linkedin', 'lnkd.in' => 'linkedin',
        'github.com' => 'github', 'github.io' => 'portfolio',
        'gitlab.com' => 'gitlab',
        'behance.net' => 'behance',
        'dribbble.com' => 'dribbble',
    ];
    foreach ($map as $domain => $kind) {
        if ($host === $domain || substr($host, -strlen('.' . $domain)) === '.' . $domain) return $kind;
    }
    return 'website';
}

/** Display shape of one stored link: id, kind, label, url, host, icon, legacy. */
function dfLinkView(array $row): array {
    $types = dfLinkTypes();
    $kind = isset($types[$row['kind'] ?? '']) ? (string) $row['kind'] : 'other';
    $url = (string) $row['url'];
    $host = preg_replace('/^www\./', '', (string) parse_url($url, PHP_URL_HOST));
    $label = trim((string) ($row['label'] ?? ''));
    if ($label === '') $label = $kind === 'other' ? ($host !== '' ? $host : 'Link') : $types[$kind][0];
    $path = rtrim((string) parse_url($url, PHP_URL_PATH), '/');
    return [
        'id'     => (int) ($row['id'] ?? 0),
        'kind'   => $kind,
        'label'  => $label,
        'url'    => $url,
        'host'   => $host,
        'short'  => $host . ($path !== '' ? $path : ''),
        'icon'   => $types[$kind][1],
        'legacy' => !empty($row['legacy']),
    ];
}

/**
 * Every link of a member, in the order they added them.
 * $legacyUrl: the old students.portfolio_link if the caller already has it (null = look it up).
 */
function dfFetchLinks(PDO $pdo, int $userId, ?string $legacyUrl = null): array {
    if ($userId <= 0) return [];
    $out = [];
    $seen = [];

    if (dfLinksReady($pdo)) {
        try {
            $st = $pdo->prepare('SELECT id, kind, label, url FROM profile_links WHERE user_id = ? ORDER BY sort_order ASC, id ASC LIMIT ' . DF_LINK_LIMIT);
            $st->execute([$userId]);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $safe = dfSafeLink($row['url'] ?? '');
                if ($safe === '' || isset($seen[strtolower($safe)])) continue;
                $seen[strtolower($safe)] = true;
                $row['url'] = $safe;
                $out[] = dfLinkView($row);
            }
        } catch (Throwable $e) {
            // links are optional; the profile still loads
        }
    }

    if ($legacyUrl === null) {
        try {
            $ls = $pdo->prepare('SELECT portfolio_link FROM students WHERE user_id = ? LIMIT 1');
            $ls->execute([$userId]);
            $legacyUrl = (string) $ls->fetchColumn();
        } catch (Throwable $e) {
            $legacyUrl = '';
        }
    }
    $legacy = dfSafeLink($legacyUrl);
    if ($legacy !== '' && !isset($seen[strtolower($legacy)])) {
        array_unshift($out, dfLinkView(['id' => 0, 'kind' => 'portfolio', 'label' => '', 'url' => $legacy, 'legacy' => true]));
    }
    return $out;
}

/** Number of links stored in profile_links (the old portfolio link does not count toward the limit). */
function dfLinkCount(PDO $pdo, int $userId): int {
    if (!dfLinksReady($pdo)) return 0;
    $st = $pdo->prepare('SELECT COUNT(*) FROM profile_links WHERE user_id = ?');
    $st->execute([$userId]);
    return (int) $st->fetchColumn();
}

/** <a> attributes shared by every outgoing profile link. */
function dfLinkAttrs(array $l, string $class): string {
    return 'class="' . dfEsc($class) . ' is-' . dfEsc($l['kind']) . '" href="' . dfEsc($l['url']) . '" target="_blank" rel="noopener noreferrer nofollow"'
        . ' title="' . dfEsc($l['label'] . ' - ' . $l['short']) . '"';
}

/**
 * Pills with icon + name.
 *   $variant 'profile' - light profile header (student/my-profile.php, student/user.php)
 *   $variant 'project' - dark project page header, top right (student/project.php)
 */
function dfRenderLinkPills(array $links, string $variant = 'profile', string $ariaLabel = 'Working profiles and links'): string {
    if (!$links) return '';
    $base = $variant === 'project' ? 'pjx-olink' : 'pf-olink';
    $html = '<ul class="' . ($variant === 'project' ? 'pjx-olinks' : 'pf-olinks') . '" aria-label="' . dfEsc($ariaLabel) . '">';
    foreach ($links as $l) {
        $html .= '<li><a ' . dfLinkAttrs($l, $base) . '>' . dfIcon($l['icon'], 15) . '<span>' . dfEsc($l['label']) . '</span></a></li>';
    }
    return $html . '</ul>';
}

/** Full rows (icon, name, address) for the About tab. */
function dfRenderLinkRows(array $links): string {
    if (!$links) return '';
    $html = '<ul class="pf-linkrows" aria-label="Working profiles and links">';
    foreach ($links as $l) {
        $html .= '<li><a ' . dfLinkAttrs($l, 'pf-linkrow') . '>'
            . '<span class="pf-linkrow-ico" aria-hidden="true">' . dfIcon($l['icon'], 18) . '</span>'
            . '<span class="pf-linkrow-text"><b>' . dfEsc($l['label']) . '</b><small>' . dfEsc($l['short']) . '</small></span>'
            . dfIcon('external', 14) . '</a></li>';
    }
    return $html . '</ul>';
}

/** Editable list on Account settings: every row has a remove button. */
function dfRenderLinkManager(array $links): string {
    if (!$links) return '<p class="upx-muted">No links yet. Add your LinkedIn, GitHub or personal portfolio below.</p>';
    $html = '<ul class="mp-links" aria-label="Your links">';
    foreach ($links as $l) {
        $delKey = $l['legacy'] ? 'legacy' : (string) $l['id'];
        $html .= '<li class="mp-link">'
            . '<span class="mp-link-ico is-' . dfEsc($l['kind']) . '" aria-hidden="true">' . dfIcon($l['icon'], 18) . '</span>'
            . '<span class="mp-link-text"><b>' . dfEsc($l['label']) . '</b>'
            . '<a href="' . dfEsc($l['url']) . '" target="_blank" rel="noopener noreferrer nofollow">' . dfEsc($l['short']) . '</a></span>'
            . '<button type="button" class="df-chip-x mp-link-x" data-link-delete="' . dfEsc($delKey) . '" aria-label="' . dfEsc('Remove link ' . $l['label']) . '">' . dfIcon('close', 14) . '</button>'
            . '</li>';
    }
    return $html . '</ul>';
}

/** Fresh HTML + count for the Account settings list (page load and after every change). */
function dfLinkLists(PDO $pdo, int $userId): array {
    $links = dfFetchLinks($pdo, $userId);
    return [
        'links_html' => dfRenderLinkManager($links),
        'link_count' => count($links),
    ];
}

/**
 * Links of many members at once (one query for links + one for old portfolio links),
 * e.g. everyone tagged on a team project. Returns [userId => links].
 */
function dfLinksForUsers(PDO $pdo, array $userIds): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $userIds))));
    $out = [];
    if (!$ids) return $out;
    foreach ($ids as $id) $out[$id] = [];
    $in = implode(',', array_fill(0, count($ids), '?'));
    $seen = [];

    try {
        $ls = $pdo->prepare("SELECT user_id, portfolio_link FROM students WHERE user_id IN ($in)");
        $ls->execute($ids);
        foreach ($ls->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $safe = dfSafeLink($r['portfolio_link'] ?? '');
            if ($safe === '') continue;
            $uid = (int) $r['user_id'];
            $seen[$uid][strtolower($safe)] = true;
            $out[$uid][] = dfLinkView(['id' => 0, 'kind' => 'portfolio', 'label' => '', 'url' => $safe, 'legacy' => true]);
        }
    } catch (Throwable $e) {
        // optional
    }

    if (dfLinksReady($pdo)) {
        try {
            $st = $pdo->prepare("SELECT id, user_id, kind, label, url FROM profile_links WHERE user_id IN ($in) ORDER BY user_id, sort_order ASC, id ASC");
            $st->execute($ids);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $row) {
                $uid = (int) $row['user_id'];
                $safe = dfSafeLink($row['url'] ?? '');
                if ($safe === '' || isset($seen[$uid][strtolower($safe)])) continue;
                if (count($out[$uid]) >= DF_LINK_LIMIT) continue;
                $seen[$uid][strtolower($safe)] = true;
                $row['url'] = $safe;
                $out[$uid][] = dfLinkView($row);
            }
        } catch (Throwable $e) {
            // optional
        }
    }
    return $out;
}

/**
 * Small round icon buttons (LinkedIn, GitHub, portfolio...) of one member,
 * used for tagged collaborators on the project page. The first $max show; "+N" opens their profile.
 */
function dfRenderLinkIcons(array $links, int $userId, string $name, int $max = 4): string {
    if (!$links) return '';
    $html = '<ul class="df-olinks-mini" aria-label="' . dfEsc('Work links of ' . $name) . '">';
    foreach (array_slice($links, 0, $max) as $l) {
        $html .= '<li><a class="df-olink-mini is-' . dfEsc($l['kind']) . '" href="' . dfEsc($l['url']) . '" target="_blank" rel="noopener noreferrer nofollow"'
            . ' title="' . dfEsc($l['label'] . ' - ' . $l['short']) . '" aria-label="' . dfEsc($name . ' on ' . $l['label'] . ' (opens in a new tab)') . '">'
            . dfIcon($l['icon'], 15) . '</a></li>';
    }
    $extra = count($links) - $max;
    if ($extra > 0 && $userId > 0) {
        $html .= '<li><a class="df-olink-mini is-more" href="user.php?id=' . $userId . '" title="' . dfEsc('See all links of ' . $name) . '" aria-label="' . dfEsc($extra . ' more links on the profile of ' . $name) . '">+' . $extra . '</a></li>';
    }
    return $html . '</ul>';
}
