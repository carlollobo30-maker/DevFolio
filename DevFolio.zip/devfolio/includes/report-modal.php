<?php
/**
 * "Report this project" dialog (student pages).
 * Any element with data-report="<project id>" (and optional data-title) opens it.
 * Needs #dfToastHost on the page and ui-helpers.php loaded.
 */
require_once __DIR__ . '/moderation.php';
?>
<div id="reportModal" class="df-modal" hidden>
    <div class="df-dialog" role="dialog" aria-modal="true" aria-labelledby="reportTitle">
        <button type="button" class="df-x" data-report-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
        <div class="df-dialog-pad">
            <h2 id="reportTitle" class="df-report-h"><?php echo dfIcon('flag', 22); ?> Report this project</h2>
            <p id="reportProject" class="df-report-sub"></p>
            <form id="reportForm">
                <input type="hidden" name="project_id" id="reportProjectId" value="">
                <fieldset class="df-reasons">
                    <legend>Why are you reporting it?</legend>
                    <?php foreach (DF_REPORT_REASONS as $key => $label): ?>
                        <label class="df-reason"><input type="radio" name="reason" value="<?php echo dfEsc($key); ?>"> <span><?php echo dfEsc($label); ?></span></label>
                    <?php endforeach; ?>
                    <label class="df-reason"><input type="radio" name="reason" value="other"> <span>Others, Specify</span></label>
                </fieldset>
                <div class="df-field" id="reportOtherWrap" hidden>
                    <label for="reportOther">Tell us what the problem is <span class="req" aria-hidden="true">*</span></label>
                    <input id="reportOther" name="reason_other" type="text" maxlength="120" class="df-light" placeholder="Type the reason">
                </div>
                <div class="df-field">
                    <label for="reportDetails">Extra details <span style="font-weight:500;color:#64748b">(optional)</span></label>
                    <textarea id="reportDetails" name="details" rows="3" maxlength="500" class="df-light" placeholder="Anything that helps a moderator understand."></textarea>
                </div>
                <p class="df-report-note">Reports go to faculty and admin. The project owner is not told who reported them.</p>
                <div class="df-actions">
                    <button type="submit" id="reportSubmit" class="df-btn df-btn-danger">Submit report</button>
                    <button type="button" class="df-btn df-btn-ghost" data-report-close>Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>
<script>
(function () {
    var modal = document.getElementById('reportModal');
    var form = document.getElementById('reportForm');
    var otherWrap = document.getElementById('reportOtherWrap');
    var otherInput = document.getElementById('reportOther');
    var lastFocus = null;
    var focusable = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled])';

    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3800);
        setTimeout(function () { el.remove(); }, 4300);
    }
    function open(id, title) {
        lastFocus = document.activeElement;
        form.reset();
        otherWrap.hidden = true; otherInput.required = false;
        document.getElementById('reportProjectId').value = id;
        document.getElementById('reportProject').textContent = title || '';
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        form.querySelector('input[name=reason]').focus();
    }
    function close() {
        modal.hidden = true;
        document.body.style.overflow = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
    }
    document.addEventListener('click', function (e) {
        var opener = e.target.closest('[data-report]');
        if (opener) { e.preventDefault(); open(opener.dataset.report, opener.dataset.title); return; }
        if (e.target.closest('[data-report-close]')) close();
    });
    modal.addEventListener('mousedown', function (e) { if (e.target === modal) close(); });
    document.addEventListener('keydown', function (e) {
        if (modal.hidden) return;
        if (e.key === 'Escape') { e.stopPropagation(); close(); return; }
        if (e.key === 'Tab') {
            var items = Array.prototype.filter.call(modal.querySelectorAll(focusable), function (n) { return n.offsetParent !== null; });
            if (!items.length) return;
            var first = items[0], last = items[items.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    }, true);

    form.addEventListener('change', function () {
        var other = (form.querySelector('input[name=reason]:checked') || {}).value === 'other';
        otherWrap.hidden = !other;
        otherInput.required = other;
        if (other) otherInput.focus();
    });

    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        if (!form.querySelector('input[name=reason]:checked')) { toast('Please choose a reason.', 'err'); return; }
        var btn = document.getElementById('reportSubmit');
        btn.disabled = true; btn.textContent = 'Sending...';
        try {
            var res = await fetch('report-project.php', { method: 'POST', body: new FormData(form) });
            var data = await res.json();
            toast(data.message || (data.success ? 'Report sent.' : 'Could not send the report.'), data.success ? 'ok' : 'err');
            if (data.success) close();
        } catch (err) {
            toast('Could not send the report. Please try again.', 'err');
        } finally {
            btn.disabled = false; btn.textContent = 'Submit report';
        }
    });
})();
</script>
