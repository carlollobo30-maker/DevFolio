<?php
/**
 * Shared project presentation helpers (cards, previews, links, files).
 * Used by student/dashboard.php (feed) and student/project.php (full project page).
 */

function dfTimeAgo(?string $datetime): string {
    if (!$datetime) return '';
    $ts = strtotime($datetime);
    if (!$ts) return '';
    $diff = time() - $ts;
    if ($diff < 60) return 'Just now';
    if ($diff < 3600) return floor($diff / 60) . ' min ago';
    if ($diff < 86400) return floor($diff / 3600) . ' hr ago';
    if ($diff < 604800) return floor($diff / 86400) . ' day' . (floor($diff / 86400) > 1 ? 's' : '') . ' ago';
    return date('M j, Y', $ts);
}

function dfSafeLink(?string $url): string {
    $url = trim((string) $url);
    return preg_match('#^https?://#i', $url) ? $url : '';
}

/** Label + icon for the single project link (repo hosts get the GitHub icon). */
function dfLinkMeta(string $url): array {
    $host = strtolower((string) parse_url($url, PHP_URL_HOST));
    foreach (['github.com', 'gitlab.com', 'bitbucket.org'] as $repoHost) {
        if ($host === $repoHost || substr($host, -strlen('.' . $repoHost)) === '.' . $repoHost) return ['Repository', 'github'];
    }
    return ['View project', 'external'];
}

/**
 * The project's own link (live demo or repository) as a clickable chip for feed / profile posts.
 * Uses the first safe link of demo_link, repository_link. Empty when the project has none.
 */
function dfProjectLinkChip(array $p): string {
    $url = '';
    foreach ([$p['demo_link'] ?? '', $p['repository_link'] ?? ''] as $raw) {
        $url = dfSafeLink($raw);
        if ($url !== '') break;
    }
    if ($url === '') return '';
    [$kind, $icon] = dfLinkMeta($url);
    $label = $kind === 'Repository' ? 'Repository' : 'Project link';
    $host = preg_replace('/^www\./i', '', (string) parse_url($url, PHP_URL_HOST));
    $path = rtrim((string) parse_url($url, PHP_URL_PATH), '/');
    $short = $host . $path;
    if (mb_strlen($short) > 48) $short = mb_substr($short, 0, 45) . '…';
    return '<a class="df-pjlink" href="' . dfEsc($url) . '" target="_blank" rel="noopener noreferrer nofollow"'
        . ' title="' . dfEsc($url) . '" aria-label="' . dfEsc('Open ' . strtolower($label) . ': ' . $url . ' (opens in a new tab)') . '">'
        . '<span class="df-pjlink-ico" aria-hidden="true">' . dfIcon($icon === 'github' ? 'github' : 'link', 15) . '</span>'
        . '<span class="df-pjlink-text"><b>' . dfEsc($label) . '</b><span>' . dfEsc($short) . '</span></span>'
        . dfIcon('external', 14) . '</a>';
}

function dfFormatSize(int $bytes): string {
    if ($bytes >= 1048576) return round($bytes / 1048576, 1) . ' MB';
    if ($bytes >= 1024) return round($bytes / 1024) . ' KB';
    return $bytes . ' B';
}

function dfEsc($v): string { return htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8'); }

function dfTags($json): array {
    if (!$json) return [];
    $arr = json_decode((string) $json, true);
    if (!is_array($arr)) return [];
    $out = [];
    foreach ($arr as $t) {
        $t = trim((string) $t);
        if ($t !== '') $out[] = $t;
    }
    return array_slice($out, 0, 8);
}

function dfTint(?string $category): string {
    $map = ['Web App' => 'web', 'Mobile App' => 'mobile', 'Capstone' => 'capstone', 'Multimedia' => 'media', 'Animation' => 'animation'];
    return 'df-tint-' . ($map[(string) $category] ?? 'default');
}

/* ===================================================================
 * Project photos (several per project)
 *
 * project_photos holds every photo in display order (sort_order 0 = cover).
 * projects.banner_image_url always mirrors the cover, so cards, profiles and
 * everything written before this feature keep working unchanged.
 * Projects that only have an old banner (no rows yet) are treated as having one photo.
 * =================================================================== */

/** Creates project_photos if it is missing (once per session). */
function dfPhotosReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_photos_table'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS project_photos (
            id INT PRIMARY KEY AUTO_INCREMENT,
            project_id INT NOT NULL,
            file_path VARCHAR(255) NOT NULL,
            sort_order INT NOT NULL DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
            INDEX idx_project_photos (project_id, sort_order)
        )");
        $_SESSION['df_photos_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

/** True for a real uploaded image path (placeholder images do not count). */
function dfIsRealPhoto(?string $path): bool {
    $path = trim((string) $path);
    return $path !== '' && stripos($path, 'placehold.co') === false;
}

/**
 * Photos for several projects at once.
 *
 * @param  array<int,array> $projects rows that contain id and banner_image_url
 * @return array<int,array<int,array{id:int,path:string}>> project id => photos in display order (id 0 = legacy banner)
 */
function dfPhotosFor(PDO $pdo, array $projects): array {
    $out = [];
    $ids = [];
    foreach ($projects as $p) $ids[] = (int) $p['id'];
    if (!$ids) return $out;

    if (dfPhotosReady($pdo)) {
        try {
            $in = implode(',', array_fill(0, count($ids), '?'));
            $st = $pdo->prepare("SELECT id, project_id, file_path FROM project_photos WHERE project_id IN ($in) ORDER BY sort_order ASC, id ASC");
            $st->execute($ids);
            foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                $out[(int) $r['project_id']][] = ['id' => (int) $r['id'], 'path' => (string) $r['file_path']];
            }
        } catch (Throwable $e) {
            $out = [];
        }
    }
    foreach ($projects as $p) {
        $pid = (int) $p['id'];
        if (empty($out[$pid]) && dfIsRealPhoto($p['banner_image_url'] ?? '')) {
            $out[$pid] = [['id' => 0, 'path' => (string) $p['banner_image_url']]];
        }
    }
    return $out;
}

/** Turns old single-cover projects (no photo rows yet) into one-photo projects, so each photo has an id. Never throws. */
function dfMigrateLegacyPhotos(PDO $pdo, array $projects): void {
    if (!$projects || !dfPhotosReady($pdo)) return;
    try {
        $ids = array_map(static function ($p) { return (int) $p['id']; }, $projects);
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $pdo->prepare("SELECT DISTINCT project_id FROM project_photos WHERE project_id IN ($in)");
        $st->execute($ids);
        $has = array_flip(array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN)));
        $ins = $pdo->prepare('INSERT INTO project_photos (project_id, file_path, sort_order) VALUES (?, ?, 0)');
        foreach ($projects as $p) {
            if (!isset($has[(int) $p['id']]) && dfIsRealPhoto($p['banner_image_url'] ?? '')) {
                $ins->execute([(int) $p['id'], (string) $p['banner_image_url']]);
            }
        }
    } catch (Throwable $e) {
        // the editor falls back to the old single cover
    }
}

/** Adds 'photo_count' to feed rows (one query for the whole page). Never throws. */
function dfAttachPhotoCounts(PDO $pdo, array &$rows): void {
    foreach ($rows as &$r) $r['photo_count'] = dfIsRealPhoto($r['banner_image_url'] ?? '') ? 1 : 0;
    unset($r);
    if (!$rows || !dfPhotosReady($pdo)) return;
    try {
        $ids = array_map(static function ($r) { return (int) $r['id']; }, $rows);
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $pdo->prepare("SELECT project_id, COUNT(*) AS n FROM project_photos WHERE project_id IN ($in) GROUP BY project_id");
        $st->execute($ids);
        $counts = [];
        foreach ($st->fetchAll(PDO::FETCH_KEY_PAIR) as $pid => $n) $counts[(int) $pid] = (int) $n;
        foreach ($rows as &$r) if (isset($counts[(int) $r['id']])) $r['photo_count'] = $counts[(int) $r['id']];
        unset($r);
    } catch (Throwable $e) {
        // the little "+N photos" chip is optional
    }
}

/** Project photo if there is a real one, otherwise a tinted title tile. */
function dfPreviewInner(array $p): string {
    $image = dfAssetUrl($p['banner_image_url'] ?? '');
    if ($image !== '' && stripos($image, 'placehold.co') !== false) $image = '';
    $html = '<div class="df-tile"><small>' . dfEsc($p['category'] ?? 'Project') . '</small><b>' . dfEsc($p['title'] ?? 'Untitled') . '</b></div>';
    if ($image !== '') {
        $html .= '<img src="' . dfEsc($image) . '" alt="' . dfEsc('Preview of ' . ($p['title'] ?? 'project')) . '" loading="lazy" onerror="this.remove()">';
    }
    if ((int) ($p['photo_count'] ?? 0) > 1) {
        $html .= '<span class="df-photo-count" title="' . (int) $p['photo_count'] . ' photos">' . dfIcon('image', 14) . (int) $p['photo_count'] . '</span>';
    }
    return $html;
}

function dfAvatarHtml(array $p): string {
    $initials = dfInitials($p['first_name'] ?? '', $p['last_name'] ?? '');
    $avatar = dfAssetUrl($p['avatar_url'] ?? '');
    $img = $avatar !== '' ? '<img src="' . dfEsc($avatar) . '" alt="" onerror="this.remove()">' : '';
    return '<span class="df-av"><span>' . dfEsc($initials) . '</span>' . $img . '</span>';
}

function dfLikeButton(array $p): string {
    $liked = !empty($p['liked']);
    $count = (int) ($p['like_count'] ?? 0);
    return '<button type="button" class="df-like" data-like="' . (int) $p['id'] . '" aria-pressed="' . ($liked ? 'true' : 'false') . '" aria-label="' . dfEsc('Appreciate ' . ($p['title'] ?? 'this project')) . '">'
        . dfIcon('heart', 18) . '<span>' . ($count > 0 ? $count : '') . '</span></button>';
}

function dfOwnerName(array $p): string {
    $n = trim((string) ($p['first_name'] ?? '') . ' ' . (string) ($p['last_name'] ?? ''));
    return $n !== '' ? $n : 'Unknown User';
}

/** Shared SELECT for feed + detail (adds appreciation counts for the current user). */
function dfProjectSelectSql(): string {
    return "SELECT p.*, s.program AS student_program, u.id AS owner_user_id, u.first_name, u.last_name, u.avatar_url,
                   (SELECT COUNT(*) FROM project_likes l WHERE l.project_id = p.id) AS like_count,
                   (SELECT COUNT(*) FROM project_likes l2 WHERE l2.project_id = p.id AND l2.user_id = :me) AS liked,
                   (SELECT COUNT(*) FROM project_comments c WHERE c.project_id = p.id AND c.status = 'visible') AS comment_count,
                   (SELECT COUNT(DISTINCT sh.user_id) FROM project_shares sh WHERE sh.project_id = p.id) AS share_count
            FROM projects p
            INNER JOIN students s ON s.id = p.student_id
            INNER JOIN users u ON u.id = s.user_id";
}

function dfFilesFor(PDO $pdo, array $ids): array {
    $out = [];
    if (empty($ids)) return $out;
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT * FROM project_files WHERE project_id IN ($in) ORDER BY id ASC");
    $st->execute(array_values($ids));
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $f) $out[(int) $f['project_id']][] = $f;
    return $out;
}

/** Small red flag + "Report" (hidden on the signed-in user's own projects). */
function dfReportButton(array $p): string {
    if ((int) ($p['owner_user_id'] ?? 0) === (int) ($_SESSION['user_id'] ?? 0)) return '';
    if (in_array($_SESSION['role'] ?? '', ['faculty', 'admin'], true)) return ''; // moderators review reports, they don't file them
    return '<button type="button" class="df-report" data-report="' . (int) $p['id'] . '" data-title="' . dfEsc($p['title'] ?? '') . '" aria-label="' . dfEsc('Report ' . ($p['title'] ?? 'this project')) . '">'
        . dfIcon('flag', 15) . '<span>Report</span></button>';
}


/* ===================================================================
 * Comments + sharing
 * =================================================================== */

const DF_COMMENT_MAX = 500;
const DF_COMMENT_PAGE = 10;

/** Comment toggle (feed) / jump-to-comments (project page). Count is kept in sync by df-social.js. */
function dfCommentButton(array $p): string {
    $count = (int) ($p['comment_count'] ?? 0);
    $id = (int) $p['id'];
    return '<button type="button" class="df-act df-act-comment" data-comment-toggle="' . $id . '" aria-expanded="false" aria-controls="comments-' . $id . '" aria-label="' . dfEsc('Comments on ' . ($p['title'] ?? 'this project')) . '">'
        . dfIcon('comment', 18) . '<span data-comment-count="' . $id . '">' . ($count > 0 ? $count : '') . '</span></button>';
}

/** Share button: opens the share dialog (includes/social-ui.php). */
function dfShareButton(array $p): string {
    $count = (int) ($p['share_count'] ?? 0);
    $id = (int) $p['id'];
    return '<button type="button" class="df-act df-act-share" data-share="' . $id . '" data-owner="' . (int) ($p['owner_user_id'] ?? 0) . '" data-title="' . dfEsc($p['title'] ?? '') . '" aria-label="' . dfEsc('Share ' . ($p['title'] ?? 'this project')) . '">'
        . dfIcon('share', 18) . '<span data-share-count="' . $id . '">' . ($count > 0 ? $count : '') . '</span></button>';
}

/**
 * One page of visible comments for a project, oldest first inside the page.
 * $beforeId = only comments older than this id ("View earlier comments").
 *
 * @return array{rows:array,has_more:bool}
 */
function dfFetchComments(PDO $pdo, int $projectId, int $beforeId = 0, int $limit = DF_COMMENT_PAGE): array {
    $sql = "SELECT c.id, c.user_id, c.body, c.created_at, u.first_name, u.last_name, u.avatar_url, u.role
            FROM project_comments c
            INNER JOIN users u ON u.id = c.user_id
            WHERE c.project_id = :pid AND c.status = 'visible'" . ($beforeId > 0 ? ' AND c.id < :before' : '') . "
            ORDER BY c.id DESC LIMIT :lim";
    $st = $pdo->prepare($sql);
    $st->bindValue(':pid', $projectId, PDO::PARAM_INT);
    if ($beforeId > 0) $st->bindValue(':before', $beforeId, PDO::PARAM_INT);
    $st->bindValue(':lim', $limit + 1, PDO::PARAM_INT);
    $st->execute();
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    $hasMore = count($rows) > $limit;
    $rows = array_reverse(array_slice($rows, 0, $limit));
    if (function_exists('dfAttachCommentBadges')) dfAttachCommentBadges($pdo, $rows);   // member-chosen badge (badges.php)
    return ['rows' => $rows, 'has_more' => $hasMore];
}

function dfCommentCount(PDO $pdo, int $projectId): int {
    $st = $pdo->prepare("SELECT COUNT(*) FROM project_comments WHERE project_id = ? AND status = 'visible'");
    $st->execute([$projectId]);
    return (int) $st->fetchColumn();
}

/** HTML for a single comment. The author and the project owner get a delete button. */
function dfRenderComment(array $c, int $meId, int $projectOwnerUserId): string {
    $canDelete = (int) $c['user_id'] === $meId || $projectOwnerUserId === $meId;
    $name = dfOwnerName($c);
    $mine = (int) $c['user_id'] === $meId;
    $isOwnerComment = (int) $c['user_id'] === $projectOwnerUserId;
    $html = '<li class="df-comment" data-comment="' . (int) $c['id'] . '">'
        . '<a class="df-profile-link" href="user.php?id=' . (int) $c['user_id'] . '" data-profile="' . (int) $c['user_id'] . '" aria-label="' . dfEsc('View profile of ' . $name) . '" tabindex="-1">' . dfAvatarHtml($c) . '</a>'
        . '<div class="df-comment-main">'
        . '<div class="df-comment-bubble">'
        . '<span class="df-comment-name"><a class="df-profile-link" href="user.php?id=' . (int) $c['user_id'] . '" data-profile="' . (int) $c['user_id'] . '">' . dfEsc($name) . '</a>'
        . (in_array($c['role'] ?? '', ['admin', 'faculty'], true) ? ' <span class="df-role df-role-' . $c['role'] . ' df-role-sm">' . ($c['role'] === 'admin' ? 'Admin' : 'Faculty') . '</span>' : '')
        . (!empty($c['comment_badge']) && function_exists('dfCommentBadgeChip') ? ' ' . dfCommentBadgeChip((string) $c['comment_badge']) : '')
        . ($isOwnerComment ? ' <em class="df-comment-badge">Creator</em>' : '') . '</span>'
        . '<p class="df-comment-body">' . dfEsc($c['body']) . '</p>'
        . '</div>'
        . '<div class="df-comment-meta"><time datetime="' . dfEsc($c['created_at']) . '">' . dfEsc(dfTimeAgo($c['created_at'])) . '</time>';
    if ($canDelete) {
        $html .= '<button type="button" class="df-comment-del" data-comment-delete="' . (int) $c['id'] . '" aria-label="' . dfEsc($mine ? 'Delete your comment' : 'Remove comment by ' . $name) . '">'
            . dfIcon('trash', 13) . ' ' . ($mine ? 'Delete' : 'Remove') . '</button>';
    }
    return $html . '</div></div></li>';
}

/** Cleans a submitted comment: normalises line breaks, trims, caps blank lines. */
function dfCleanComment(string $raw): string {
    $raw = str_replace(["\r\n", "\r"], "\n", $raw);
    $raw = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $raw) ?? '';
    $raw = preg_replace("/\n{3,}/", "\n\n", trim($raw)) ?? '';
    return $raw;
}


/* ===================================================================
 * Feed card (shared by student/dashboard.php and faculty/dashboard.php)
 * =================================================================== */
function dfRenderCard(array $p): string {
    $tags = dfTags($p['tech_stack'] ?? null);
    $desc = trim((string) ($p['description'] ?? ''));
    if ($desc === '') $desc = trim((string) ($p['abstract'] ?? ''));
    $title = $p['title'] ?? 'Untitled Project';
    $url = 'project.php?id=' . (int) $p['id'];
    $meta = dfTimeAgo($p['created_at'] ?? null);
    if (!empty($p['category'])) $meta .= ($meta !== '' ? ' · ' : '') . $p['category'];
    ob_start(); ?>
    <article class="df-card df-post">
        <!-- Profile logo (top left), name, time + category -->
        <header class="df-post-head">
            <a class="df-creator df-profile-link" href="user.php?id=<?php echo (int) $p['owner_user_id']; ?>" data-profile="<?php echo (int) $p['owner_user_id']; ?>" aria-label="<?php echo dfEsc('View profile of ' . dfOwnerName($p)); ?>">
                <?php echo dfAvatarHtml($p); ?>
                <span class="df-creator-text">
                    <span class="df-creator-name"><?php echo dfEsc(dfOwnerName($p)); ?></span>
                    <span class="df-creator-meta"><?php echo dfEsc($meta); ?></span>
                </span>
            </a>
            <?php echo dfReportButton($p); ?>
        </header>

        <?php if (!empty($p['collaborators'])): ?>
            <!-- Tagged collaborators: "with Maria Santos and 2 others" -->
            <div class="df-post-collab"><?php echo dfRenderCollabLine($p['collaborators'], $url); ?></div>
        <?php endif; ?>

        <!-- Caption (clamped, with "See more") -->
        <div class="df-post-text">
            <h3 class="df-post-title"><a href="<?php echo $url; ?>"><?php echo dfEsc($title); ?></a></h3>
            <?php if ($desc !== ''): ?>
                <p class="df-post-caption" data-caption><?php echo dfEsc($desc); ?></p>
                <button type="button" class="df-see-more" data-seemore aria-expanded="false" hidden>See more</button>
            <?php endif; ?>
            <?php if ($tags): ?>
                <ul class="df-tags" aria-label="Technologies"><?php foreach ($tags as $t): ?><li><?php echo dfEsc($t); ?></li><?php endforeach; ?></ul>
            <?php endif; ?>
            <?php echo dfProjectLinkChip($p); ?>
        </div>

        <!-- Photo below the caption: opens the project page, same as before -->
        <a class="df-preview df-post-photo <?php echo dfEsc(dfTint($p['category'] ?? '')); ?>" href="<?php echo $url; ?>" aria-label="<?php echo dfEsc('View details for ' . $title); ?>">
            <?php echo dfPreviewInner($p); ?>
        </a>

        <footer class="df-post-foot">
            <div class="df-foot-actions">
                <?php echo dfLikeButton($p); ?>
                <?php echo dfCommentButton($p); ?>
                <?php echo dfShareButton($p); ?>
            </div>
            <a class="df-post-open" href="<?php echo $url; ?>">View project</a>
        </footer>

        <!-- Comment thread (built on first open by js/df-social.js) -->
        <section class="df-comments" id="comments-<?php echo (int) $p['id']; ?>" data-comments="<?php echo (int) $p['id']; ?>" aria-label="Comments" hidden></section>
    </article>
    <?php
    return ob_get_clean();
}

// Tagged collaborators (team projects) - shared by every page that shows projects
require_once __DIR__ . '/project-collaborators.php';
