<?php
/**
 * Profile helpers: load a public profile and render the hover card.
 * Used by student/user.php (full profile page), student/profile-card.php (hover card JSON)
 * and the faculty wrappers of both.
 *
 * Privacy: email and student ID are only shown to faculty/admin viewers; phone is never shown.
 */
require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';
require_once __DIR__ . '/badges.php';
require_once __DIR__ . '/follow-helpers.php';
require_once __DIR__ . '/profile-edit-helpers.php';
require_once __DIR__ . '/profile-links.php';

/** "3rd" -> "3rd Year" (leaves anything else as typed). */
function dfYearLabel(?string $year): string {
    $year = trim((string) $year);
    if ($year === '') return '';
    return preg_match('/^\d+(st|nd|rd|th)$/i', $year) ? $year . ' Year' : $year;
}

/** URL of a user's profile page, relative to student/ or faculty/ (both have user.php). */
function dfProfileUrl(int $userId): string {
    return 'user.php?id=' . $userId;
}

/** Wraps already-escaped inner HTML in a link that also triggers the hover card. */
function dfProfileLink(int $userId, string $innerHtml, string $class = '', string $label = ''): string {
    if ($userId <= 0) return $innerHtml;
    return '<a class="df-profile-link' . ($class !== '' ? ' ' . dfEsc($class) : '') . '" href="' . dfEsc(dfProfileUrl($userId)) . '" data-profile="' . $userId . '"'
        . ($label !== '' ? ' aria-label="' . dfEsc($label) . '"' : '') . '>' . $innerHtml . '</a>';
}

/**
 * Loads a student or faculty profile. Returns null if the user does not exist
 * (admin accounts are not shown as public profiles).
 *
 * @return array|null
 */
function dfFetchProfile(PDO $pdo, int $userId, bool $withProjects = false): ?array {
    if ($userId <= 0) return null;

    $st = $pdo->prepare("SELECT id, first_name, last_name, email, role, avatar_url, created_at FROM users WHERE id = ? AND role IN ('student', 'faculty') LIMIT 1");
    $st->execute([$userId]);
    $u = $st->fetch(PDO::FETCH_ASSOC);
    if (!$u) return null;

    $u['id'] = (int) $u['id'];
    $u['program'] = '';
    $u['year_level'] = '';
    $u['bio'] = '';
    $u['portfolio_link'] = '';
    $u['student_code'] = '';
    $u['department'] = '';
    $u['specialization'] = '';
    $u['project_count'] = 0;
    $u['like_total'] = 0;
    $u['follower_count'] = dfFollowerCount($pdo, $userId);
    $u['following_count'] = dfFollowingCount($pdo, $userId);
    $u['skills'] = [];
    $u['certificates'] = [];
    $u['profession'] = '';
    $u['projects'] = [];
    $u['links'] = [];   // working profiles: LinkedIn, GitHub, portfolio... (see profile-links.php)
    $streak = dfStreakInfo($pdo, $userId);
    $u['streak'] = (int) $streak['current'];
    $u['streak_best'] = (int) $streak['longest'];
    $u['badges'] = dfEarnedBadges($pdo, $userId);                       // everything earned (used for counts)
    $u['badge_prefs'] = dfBadgePrefs($pdo, $userId);
    $u['badges_shown'] = dfProfileBadges($u['badges'], $u['badge_prefs']); // what the member chose to display

    if ($u['role'] === 'student') {
        $ss = $pdo->prepare('SELECT id, student_id, program, year_level, bio, portfolio_link' . (dfProfessionReady($pdo) ? ', profession' : '') . ' FROM students WHERE user_id = ? LIMIT 1');
        $ss->execute([$userId]);
        $s = $ss->fetch(PDO::FETCH_ASSOC);
        if ($s) {
            $sid = (int) $s['id'];
            $u['program'] = (string) ($s['program'] ?? '');
            $u['year_level'] = (string) ($s['year_level'] ?? '');
            $u['bio'] = trim((string) ($s['bio'] ?? ''));
            $u['portfolio_link'] = dfSafeLink($s['portfolio_link'] ?? '');
            $u['student_code'] = (string) ($s['student_id'] ?? '');
            $u['profession'] = trim((string) ($s['profession'] ?? ''));

            $pc = $pdo->prepare("SELECT COUNT(*) FROM projects WHERE student_id = ? AND status = 'approved'");
            $pc->execute([$sid]);
            $u['project_count'] = (int) $pc->fetchColumn();

            $lc = $pdo->prepare("SELECT COUNT(*) FROM project_likes l INNER JOIN projects p ON p.id = l.project_id WHERE p.student_id = ? AND p.status = 'approved'");
            $lc->execute([$sid]);
            $u['like_total'] = (int) $lc->fetchColumn();

            $u['skills'] = dfFetchSkillList($pdo, $sid);
            $u['certificates'] = dfFetchCertificates($pdo, $sid);
            $u['links'] = dfFetchLinks($pdo, $userId, (string) ($s['portfolio_link'] ?? ''));

            if ($withProjects) {
                $pj = $pdo->prepare("SELECT p.id, p.title, p.category, p.banner_image_url, p.tech_stack, p.created_at,
                                            (SELECT COUNT(*) FROM project_likes l WHERE l.project_id = p.id) AS like_count
                                     FROM projects p WHERE p.student_id = ? AND p.status = 'approved'
                                     ORDER BY p.created_at DESC, p.id DESC LIMIT 24");
                $pj->execute([$sid]);
                $u['projects'] = $pj->fetchAll(PDO::FETCH_ASSOC);
            }
        }
    } else {
        $fs = $pdo->prepare('SELECT department, specialization FROM faculty WHERE user_id = ? LIMIT 1');
        $fs->execute([$userId]);
        $f = $fs->fetch(PDO::FETCH_ASSOC);
        if ($f) {
            $u['department'] = trim((string) ($f['department'] ?? ''));
            $u['specialization'] = trim((string) ($f['specialization'] ?? ''));
        }
    }

    return $u;
}

/** "BSCS · 3rd Year" for students, department for faculty. */
function dfProfileSubtitle(array $pf): string {
    if ($pf['role'] === 'faculty') {
        return $pf['department'] !== '' ? $pf['department'] : 'Faculty · CCDI Sorsogon';
    }
    $bits = array_filter([$pf['program'], dfYearLabel($pf['year_level'])], static function ($v) { return $v !== ''; });
    return $bits ? implode(' · ', $bits) : 'Student · CCDI Sorsogon';
}

/** Small preview card shown when the pointer rests on a name or avatar. */
function dfRenderProfileCard(array $pf): string {
    $name = dfOwnerName($pf);
    $bio = $pf['bio'];
    if ($bio === '' && $pf['role'] === 'faculty') $bio = $pf['specialization'];
    $skills = array_slice($pf['skills'], 0, 4);
    $extraSkills = max(0, count($pf['skills']) - count($skills));
    $isStudent = $pf['role'] === 'student';

    ob_start(); ?>
    <div class="pcard-top">
        <?php echo dfAvatarHtml($pf); ?>
        <div class="pcard-id">
            <strong class="pcard-name"><?php echo dfEsc($name); ?></strong>
            <?php echo dfRoleBadge($pf['role']); ?>
            <span class="pcard-sub"><?php echo dfEsc(dfProfileSubtitle($pf)); ?></span>
        </div>
    </div>
    <?php if ($bio !== ''): ?><p class="pcard-bio"><?php echo dfEsc($bio); ?></p><?php endif; ?>
    <dl class="pcard-stats">
        <?php if ($isStudent): ?>
            <div><dt>Projects</dt><dd><?php echo (int) $pf['project_count']; ?></dd></div>
            <div><dt>Appreciations</dt><dd><?php echo (int) $pf['like_total']; ?></dd></div>
            <div><dt>Followers</dt><dd><?php echo (int) $pf['follower_count']; ?></dd></div>
        <?php endif; ?>
        <div><dt>Streak</dt><dd class="pcard-streak"><?php echo dfIcon('flame', 15); ?><?php echo (int) $pf['streak']; ?></dd></div>
        <?php if (!$isStudent): ?>
            <div><dt>Badges</dt><dd><?php echo count($pf['badges']); ?></dd></div>
        <?php endif; ?>
    </dl>
    <?php echo dfBadgeStrip($pf['badges_shown'], DF_BADGE_PROFILE_MAX); ?>
    <?php if ($isStudent && $skills): ?>
        <ul class="df-tags pcard-tags" aria-label="Top skills">
            <?php foreach ($skills as $s): ?><li><?php echo dfEsc($s['skill_name']); ?></li><?php endforeach; ?>
            <?php if ($extraSkills > 0): ?><li>+<?php echo $extraSkills; ?></li><?php endif; ?>
        </ul>
    <?php endif; ?>
    <a class="pcard-link" href="<?php echo dfEsc(dfProfileUrl($pf['id'])); ?>">View full profile</a>
    <?php
    return ob_get_clean();
}
