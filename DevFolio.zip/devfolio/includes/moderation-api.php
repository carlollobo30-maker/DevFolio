<?php
/**
 * Moderation endpoint (JSON) for faculty and admin accounts.
 * POST action=resolve_report  report_id, decision (dismiss|remove|warn|ban), reason, ban_duration (days|permanent), also_remove
 * POST action=lift_ban        sanction_id
 */
session_start();
require_once __DIR__ . '/db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['faculty', 'admin'], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Only faculty and admin accounts can do this.']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$modId = (int) $_SESSION['user_id'];
$action = $_POST['action'] ?? '';

if ($action === 'resolve_report') {
    $duration = (string) ($_POST['ban_duration'] ?? '');
    $permanent = $duration === 'permanent';
    $days = ctype_digit($duration) ? (int) $duration : null;
    echo json_encode(dfResolveReport(
        $pdo,
        (int) ($_POST['report_id'] ?? 0),
        $modId,
        (string) ($_POST['decision'] ?? ''),
        (string) ($_POST['reason'] ?? ''),
        $days,
        $permanent,
        !empty($_POST['also_remove'])
    ));
    exit;
}

if ($action === 'lift_ban') {
    echo json_encode(dfLiftBan($pdo, (int) ($_POST['sanction_id'] ?? 0), $modId));
    exit;
}

echo json_encode(['success' => false, 'message' => 'Unknown action.']);
