<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEVFOLIO | CCDI Sorsogon Student Showcase Platform</title>
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Font Awesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="../assets/css/custom.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        ccdi: {
                            navy: '#0A192F',
                            blue: '#0F2A4A',
                            gold: '#F59E0B',
                            goldDark: '#D97706',
                            goldLight: '#FEF3C7',
                            accent: '#1E3A8A',
                            bg: '#F8FAFC'
                        }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">

    <!-- HEADER & NAVIGATION -->
    <header class="bg-ccdi-navy text-white sticky top-0 z-40 shadow-lg border-b border-amber-500/30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <!-- Branding -->
                <div class="flex items-center space-x-3">
                    <div class="w-12 h-12 bg-gradient-to-tr from-amber-500 to-amber-300 rounded-xl flex items-center justify-center text-ccdi-navy font-black text-xl shadow-md border border-amber-200">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="font-extrabold text-xl tracking-tight text-white">DEV<span class="text-amber-400">FOLIO</span></span>
                            <span class="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">CCDI</span>
                        </div>
                        <p class="text-xs text-slate-300 font-medium">Computer Communication Development Institute - Sorsogon</p>
                    </div>
                </div>

                <!-- Navigation Tabs -->
                <nav class="hidden md:flex space-x-1 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700">
                    <button onclick="switchView('showcase')" id="nav-showcase" class="nav-btn active flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 text-white bg-ccdi-gold font-bold shadow-md">
                        <i class="fa-solid fa-globe"></i>
                        <span>Public Showcase</span>
                    </button>
                    <button onclick="switchView('student')" id="nav-student" class="nav-btn flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all duration-200">
                        <i class="fa-solid fa-user-graduate"></i>
                        <span>Student Portal</span>
                    </button>
                    <button onclick="switchView('faculty')" id="nav-faculty" class="nav-btn flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all duration-200">
                        <i class="fa-solid fa-user-shield"></i>
                        <span>Faculty Dashboard</span>
                    </button>
                    <button onclick="switchView('repository')" id="nav-repository" class="nav-btn flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all duration-200">
                        <i class="fa-solid fa-folder-tree"></i>
                        <span>Project Repository</span>
                    </button>
                </nav>

                <!-- User Profile Badge & Quick Action -->
                <div class="flex items-center space-x-3">
                    <button onclick="openUploadModal()" class="hidden sm:flex items-center space-x-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold px-4 py-2 rounded-lg text-sm shadow-md transition duration-150 transform active:scale-95">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                        <span>Submit Project</span>
                    </button>

                    <!-- Profile Menu Dropdown simulation -->
                    <div class="relative flex items-center space-x-2 bg-slate-800/90 pl-3 pr-2 py-1.5 rounded-xl border border-slate-700">
                        <div class="text-right hidden sm:block">
                            <p class="text-xs font-bold text-white leading-none" id="currentUserRoleName">Jhon Mar (BSCS 4)</p>
                            <p class="text-[10px] text-amber-400 font-medium leading-tight" id="currentUserRoleTag">Student Account</p>
                        </div>
                        <img src="https://placehold.co/100x100/0f2a4a/ffffff?text=JM" alt="User Avatar" class="w-8 h-8 rounded-lg ring-2 ring-amber-400">
                    </div>
                </div>
            </div>
            
            <!-- Mobile Navigation -->
            <div class="md:hidden flex overflow-x-auto space-x-2 py-2 border-t border-slate-700/60">
                <button onclick="switchView('showcase')" id="mob-nav-showcase" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold">Public Showcase</button>
                <button onclick="switchView('student')" id="mob-nav-student" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg text-slate-300 bg-slate-800">Student Portal</button>
                <button onclick="switchView('faculty')" id="mob-nav-faculty" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg text-slate-300 bg-slate-800">Faculty Panel</button>
                <button onclick="switchView('repository')" id="mob-nav-repository" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg text-slate-300 bg-slate-800">Repository</button>
            </div>
        </div>
    </header>

    <!-- Toast Notification Container -->
    <div id="toastContainer" class="fixed bottom-5 right-5 z-50 flex flex-col space-y-2 pointer-events-none"></div>
