<?php
/**
 * Feed filters: Tags (project categories) + release date.
 * Shared by student/dashboard.php and faculty/dashboard.php.
 *
 *   dfFeedTags()          the tag list (label + which projects.category values it matches)
 *   dfFeedFilterSql()     turns the posted filters into a safe " AND ..." fragment + bound params
 *   dfFeedToolbarExtras() the Tags button and Date select (goes between search and sort)
 *   dfFeedFilterPanels()  the tag chips and the Custom date range (goes under the toolbar)
 *
 * The browser side lives in js/df-feed-filters.js (window.DFFilters).
 */
require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';

/** slug => label + the categories it covers. categories = null means "everything else". */
function dfFeedTags(): array {
    return [
        'web'        => ['label' => 'Web based',  'categories' => ['Web App']],
        'mobile'     => ['label' => 'Mobile app', 'categories' => ['Mobile App']],
        'animation'  => ['label' => 'Animation',  'categories' => ['Animation']],
        'multimedia' => ['label' => 'Multimedia', 'categories' => ['Multimedia']],
        'capstone'   => ['label' => 'Capstone',   'categories' => ['Capstone']],
        'others'     => ['label' => 'Others',     'categories' => null],
    ];
}

/** How many approved projects each tag has (slug => count). Never throws. */
function dfFeedTagCounts(PDO $pdo): array {
    $counts = array_fill_keys(array_keys(dfFeedTags()), 0);
    try {
        $rows = $pdo->query("SELECT category, COUNT(*) AS n FROM projects WHERE status = 'approved' GROUP BY category")->fetchAll(PDO::FETCH_ASSOC);
        $byCat = [];
        foreach (dfFeedTags() as $slug => $t) {
            foreach ((array) $t['categories'] as $c) $byCat[strtolower($c)] = $slug;
        }
        foreach ($rows as $r) {
            $slug = $byCat[strtolower((string) $r['category'])] ?? 'others';
            $counts[$slug] += (int) $r['n'];
        }
    } catch (Throwable $e) {
        // counts are a nicety, the filter still works without them
    }
    return $counts;
}

/** Parses Y-m-d strictly (rejects 2026-02-31). Returns null when blank or invalid. */
function dfParseFilterDate($value): ?DateTime {
    $value = trim((string) $value);
    if ($value === '') return null;
    $d = DateTime::createFromFormat('!Y-m-d', $value, new DateTimeZone('Asia/Manila'));
    return ($d && $d->format('Y-m-d') === $value) ? $d : null;
}

/**
 * Builds the extra WHERE conditions for the feed.
 *   $in['tags']  comma separated tag slugs (a project matches ANY chosen tag)
 *   $in['date']  any | today | week | month | year | custom
 *   $in['from'], $in['to']  Y-m-d, used by "custom" (either one may be left empty)
 * Values are only ever bound as parameters. Returns '' or a string starting with " AND ".
 */
function dfFeedFilterSql(array $in, array &$params): string {
    $sql = '';

    // ---- Tags ----
    $defs = dfFeedTags();
    $slugs = array_unique(array_filter(array_map('trim', explode(',', (string) ($in['tags'] ?? ''))), static function ($s) use ($defs) {
        return isset($defs[$s]);
    }));
    if ($slugs) {
        $standard = [];
        foreach ($defs as $t) foreach ((array) $t['categories'] as $c) $standard[] = $c;

        $conds = [];
        $i = 0;
        foreach ($slugs as $slug) {
            if ($defs[$slug]['categories'] === null) {
                $ph = [];
                foreach ($standard as $c) { $k = ':tgs' . $i++; $params[$k] = $c; $ph[] = $k; }
                $conds[] = "(p.category IS NULL OR p.category = '' OR p.category NOT IN (" . implode(',', $ph) . '))';
            } else {
                foreach ($defs[$slug]['categories'] as $c) { $k = ':tg' . $i++; $params[$k] = $c; $conds[] = "p.category = $k"; }
            }
        }
        $sql .= ' AND (' . implode(' OR ', $conds) . ')';
    }

    // ---- Release date (published date, falling back to the date it was added) ----
    $mode = (string) ($in['date'] ?? 'any');
    $today = new DateTime('today', new DateTimeZone('Asia/Manila'));
    $from = null;
    $to = null;   // inclusive last day

    if ($mode === 'today') {
        $from = clone $today; $to = clone $today;
    } elseif ($mode === 'week') {                      // Monday to today
        $from = (clone $today)->modify('-' . ((int) $today->format('N') - 1) . ' days'); $to = clone $today;
    } elseif ($mode === 'month') {
        $from = new DateTime($today->format('Y-m-01'), new DateTimeZone('Asia/Manila')); $to = clone $today;
    } elseif ($mode === 'year') {
        $from = new DateTime($today->format('Y-01-01'), new DateTimeZone('Asia/Manila')); $to = clone $today;
    } elseif ($mode === 'custom') {
        $from = dfParseFilterDate($in['from'] ?? '');
        $to = dfParseFilterDate($in['to'] ?? '');
        if ($from && $to && $from > $to) { $tmp = $from; $from = $to; $to = $tmp; }
    }

    $when = 'COALESCE(p.published_at, p.created_at)';
    if ($from) { $sql .= " AND $when >= :dffrom"; $params[':dffrom'] = $from->format('Y-m-d') . ' 00:00:00'; }
    if ($to)   { $sql .= " AND $when < :dfto";    $params[':dfto'] = (clone $to)->modify('+1 day')->format('Y-m-d') . ' 00:00:00'; }

    return $sql;
}

/** Tags button + date select. Sits between the search box and the sort select. */
function dfFeedToolbarExtras(): string {
    return '<div>'
        . '<button type="button" id="tagBtn" class="df-select dftag-btn" aria-expanded="false" aria-controls="tagPanel">'
        . '<svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12.586 2.586A2 2 0 0 0 11.172 2H4a2 2 0 0 0-2 2v7.172a2 2 0 0 0 .586 1.414l8.704 8.704a2.426 2.426 0 0 0 3.42 0l6.58-6.58a2.426 2.426 0 0 0 0-3.42z"/><circle cx="7.5" cy="7.5" r=".5" fill="currentColor"/></svg>'
        . '<span>Tags</span><span id="tagBtnCount" class="dftag-count" hidden>0</span></button>'
        . '</div>'
        . '<div>'
        . '<label for="feedDate" class="df-sr">Filter by release date</label>'
        . '<select id="feedDate" class="df-select">'
        . '<option value="any">Any time</option><option value="today">Today</option><option value="week">This week</option>'
        . '<option value="month">This month</option><option value="year">This year</option><option value="custom">Custom</option>'
        . '</select></div>';
}

/** Tag chips + Custom date range. Sits right under the toolbar. */
function dfFeedFilterPanels(PDO $pdo): string {
    $counts = dfFeedTagCounts($pdo);
    $today = (new DateTime('today', new DateTimeZone('Asia/Manila')))->format('Y-m-d');

    $chips = '';
    foreach (dfFeedTags() as $slug => $t) {
        $chips .= '<li><button type="button" class="dftag-chip" data-tag="' . dfEsc($slug) . '" aria-pressed="false">'
            . dfEsc($t['label']) . ' <small>' . (int) $counts[$slug] . '</small></button></li>';
    }

    return '<div id="tagPanel" class="dftag-panel" hidden>'
        . '<div class="dftag-head"><h3>Browse by tag</h3><button type="button" id="tagClear" class="dftag-clear" hidden>Clear filters</button></div>'
        . '<ul class="dftag-row" aria-label="Project tags">' . $chips . '</ul>'
        . '<p class="dftag-hint">Pick one or more. Projects that match any chosen tag are shown.</p>'
        . '</div>'
        . '<div id="dateCustom" class="dftag-panel dftag-dates" data-today="' . dfEsc($today) . '" hidden>'
        . '<label for="dateFrom">From <input type="date" id="dateFrom" class="df-input" max="' . dfEsc($today) . '"></label>'
        . '<label for="dateTo">To <input type="date" id="dateTo" class="df-input" max="' . dfEsc($today) . '"></label>'
        . '<p class="dftag-hint">Choose the release dates to look at. Use the same day in both boxes to see a single date.</p>'
        . '</div>';
}
