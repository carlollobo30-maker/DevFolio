<?php
/**
 * Follow system: students follow other students and get a notification
 * whenever someone they follow publishes a new project.
 *
 * Used by student/follow-actions.php (JSON endpoint), student/user.php (public profile),
 * student/profile.php (own profile), includes/profile-helpers.php (counts + hover card),
 * and the two places a project is published (student/dashboard.php).
 *
 * Needs ui-helpers.php / project-helpers.php (dfIcon, dfEsc, dfOwnerName) and moderation.php (dfNotify)
 * to be loaded by the page; db_connect.php already loads moderation.php.
 */

/** Creates user_follows if it is missing (once per session). */
function dfFollowTableReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_follow_table'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_follows (
            follower_id INT NOT NULL,
            following_id INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (follower_id, following_id),
            INDEX idx_follows_following (following_id),
            FOREIGN KEY (follower_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (following_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $_SESSION['df_follow_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

/** How many people follow this user. Never throws. */
function dfFollowerCount(PDO $pdo, int $userId): int {
    if ($userId <= 0 || !dfFollowTableReady($pdo)) return 0;
    try {
        $st = $pdo->prepare('SELECT COUNT(*) FROM user_follows WHERE following_id = ?');
        $st->execute([$userId]);
        return (int) $st->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/** How many people this user follows. Never throws. */
function dfFollowingCount(PDO $pdo, int $userId): int {
    if ($userId <= 0 || !dfFollowTableReady($pdo)) return 0;
    try {
        $st = $pdo->prepare('SELECT COUNT(*) FROM user_follows WHERE follower_id = ?');
        $st->execute([$userId]);
        return (int) $st->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

function dfIsFollowing(PDO $pdo, int $followerId, int $targetId): bool {
    if ($followerId <= 0 || $targetId <= 0 || !dfFollowTableReady($pdo)) return false;
    try {
        $st = $pdo->prepare('SELECT 1 FROM user_follows WHERE follower_id = ? AND following_id = ? LIMIT 1');
        $st->execute([$followerId, $targetId]);
        return (bool) $st->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

/** True when this user is a student account (only students post projects, so only they can be followed). */
function dfCanBeFollowed(PDO $pdo, int $userId): bool {
    if ($userId <= 0) return false;
    $st = $pdo->prepare("SELECT 1 FROM users WHERE id = ? AND role = 'student' LIMIT 1");
    $st->execute([$userId]);
    return (bool) $st->fetchColumn();
}

/**
 * Follow someone. Returns true when a new follow was created (false if already following).
 * Tells the followed student, at most once a day per follower, so follow/unfollow loops cannot spam them.
 */
function dfFollowUser(PDO $pdo, int $followerId, int $targetId): bool {
    if (!dfFollowTableReady($pdo)) return false;
    $ins = $pdo->prepare('INSERT IGNORE INTO user_follows (follower_id, following_id) VALUES (?, ?)');
    $ins->execute([$followerId, $targetId]);
    if ($ins->rowCount() < 1) return false;

    try {
        $me = $pdo->prepare('SELECT first_name, last_name FROM users WHERE id = ? LIMIT 1');
        $me->execute([$followerId]);
        $who = $me->fetch(PDO::FETCH_ASSOC) ?: [];
        $message = dfOwnerName($who) . ' started following you.';

        $dup = $pdo->prepare("SELECT 1 FROM notifications WHERE user_id = ? AND notification_type = 'new_follower' AND message = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY) LIMIT 1");
        $dup->execute([$targetId, $message]);
        if (!$dup->fetchColumn()) {
            dfNotify($pdo, $targetId, 'new_follower', 'You have a new follower', $message);
        }
    } catch (Throwable $e) {
        // the follow itself already succeeded; the notice is a bonus
    }
    return true;
}

function dfUnfollowUser(PDO $pdo, int $followerId, int $targetId): void {
    if (!dfFollowTableReady($pdo)) return;
    $pdo->prepare('DELETE FROM user_follows WHERE follower_id = ? AND following_id = ?')->execute([$followerId, $targetId]);
}

/**
 * Notify every follower of $ownerUserId that a new project is on the feed.
 * One INSERT ... SELECT, so it stays fast with many followers. Never throws:
 * a notification problem must not make "Post project" fail.
 *
 * @return int number of followers notified
 */
function dfNotifyFollowersOfProject(PDO $pdo, int $ownerUserId, int $projectId, string $projectTitle): int {
    if ($ownerUserId <= 0 || $projectId <= 0 || !dfFollowTableReady($pdo)) return 0;
    try {
        $st = $pdo->prepare('SELECT first_name, last_name FROM users WHERE id = ? LIMIT 1');
        $st->execute([$ownerUserId]);
        $owner = $st->fetch(PDO::FETCH_ASSOC) ?: [];
        $name = dfOwnerName($owner);

        $ins = $pdo->prepare(
            "INSERT INTO notifications (user_id, notification_type, title, message, related_project_id)
             SELECT f.follower_id, 'new_project', ?, ?, ?
             FROM user_follows f
             INNER JOIN users u ON u.id = f.follower_id
             WHERE f.following_id = ?"
        );
        $ins->execute([
            mb_substr($name . ' posted a new project', 0, 255),
            $name . ' posted a new project: "' . $projectTitle . '"',
            $projectId,
            $ownerUserId,
        ]);
        return (int) $ins->rowCount();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * Follow / Following button. Only shown to students, on other students' profiles.
 * js/df-follow.js handles the click and keeps every [data-follower-count] in sync.
 */
function dfFollowButton(int $targetUserId, bool $following): string {
    return '<button type="button" class="df-btn df-follow' . ($following ? ' is-following df-btn-ghost' : ' df-btn-primary') . '" data-follow="' . $targetUserId . '" aria-pressed="' . ($following ? 'true' : 'false') . '">'
        . '<span class="df-follow-icon">' . dfIcon($following ? 'check' : 'plus', 16) . '</span>'
        . '<span class="df-follow-label">' . ($following ? 'Following' : 'Follow') . '</span></button>';
}
