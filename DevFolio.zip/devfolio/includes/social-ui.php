<?php
/**
 * Comment composer template + "Share this project" dialog (student pages).
 * Include once per page, after student-nav.php, together with js/df-social.js.
 *   - Any [data-share="<project id>"] button opens the share dialog.
 *   - Any [data-comments="<project id>"] container becomes a comment thread.
 * Needs #dfToastHost on the page and ui-helpers.php / project-helpers.php loaded.
 */
if (!defined('DF_SHARE_CAPTION_MAX')) {
    require_once __DIR__ . '/profile-timeline.php';
}
if (!isset($navUser) || !is_array($navUser)) {
    $socialUserStmt = $pdo->prepare('SELECT first_name, last_name, avatar_url FROM users WHERE id = ? LIMIT 1');
    $socialUserStmt->execute([$_SESSION['user_id']]);
    $navUser = $socialUserStmt->fetch(PDO::FETCH_ASSOC) ?: [];
}
?>
<template id="dfComposerTpl">
    <form class="df-composer" autocomplete="off">
        <?php echo dfAvatarHtml($navUser); ?>
        <div class="df-composer-box">
            <textarea class="df-composer-input" rows="1" aria-label="Write a comment" maxlength="<?php echo (int) DF_COMMENT_MAX; ?>" placeholder="Write a comment..."></textarea>
            <div class="df-composer-row">
                <span class="df-composer-count" aria-hidden="true"></span>
                <button type="submit" class="df-composer-send" disabled><?php echo dfIcon('send', 15); ?> Post</button>
            </div>
        </div>
    </form>
</template>

<div id="shareModal" class="df-modal" data-me="<?php echo (int) ($_SESSION['user_id'] ?? 0); ?>" data-role="<?php echo htmlspecialchars((string) ($_SESSION['role'] ?? '')); ?>" hidden>
    <div class="df-dialog" role="dialog" aria-modal="true" aria-labelledby="shareTitle">
        <button type="button" class="df-x" data-share-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
        <div class="df-dialog-pad">
            <h2 id="shareTitle" class="df-share-h"><?php echo dfIcon('share', 22); ?> Share this project</h2>
            <p id="shareProject" class="df-share-sub"></p>

            <div id="shareProfileBox" class="df-share-profile" hidden>
                <h3 class="df-share-profile-h"><?php echo dfIcon('user', 16); ?> Share to your profile</h3>
                <p class="df-share-profile-p">Posts this on your profile with your name and photo. The original creator's photo and name stay on it, so credit always goes to them.</p>
                <label class="df-share-sr" for="shareCaption">Add a note (optional)</label>
                <textarea id="shareCaption" class="df-light" rows="2" maxlength="<?php echo (int) DF_SHARE_CAPTION_MAX; ?>" placeholder="Say something about this project (optional)"></textarea>
                <button type="button" id="shareToProfile" class="df-btn df-btn-primary"><?php echo dfIcon('send', 16); ?> <span>Share to profile</span></button>
            </div>

            <p class="df-share-or" id="shareOr" hidden><span>or share outside DEVFOLIO</span></p>

            <div class="df-share-link">
                <input id="shareUrl" type="text" readonly class="df-light" aria-label="Project link" value="">
                <button type="button" id="shareCopy" class="df-btn df-btn-primary"><?php echo dfIcon('link', 16); ?> <span>Copy link</span></button>
            </div>

            <div class="df-share-grid">
                <button type="button" id="shareNative" class="df-share-opt" hidden><?php echo dfIcon('share', 16); ?> Share via...</button>
                <button type="button" class="df-share-opt" data-share-channel="facebook">Facebook</button>
                <button type="button" class="df-share-opt" data-share-channel="x">X (Twitter)</button>
                <button type="button" class="df-share-opt" data-share-channel="email"><?php echo dfIcon('mail', 16); ?> Email</button>
            </div>

            <p class="df-share-note">Only signed-in CCDI students and faculty can open this link.</p>
        </div>
    </div>
</div>
