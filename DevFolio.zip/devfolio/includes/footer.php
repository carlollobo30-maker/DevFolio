    <!-- MODAL 1: PROJECT DETAILS MODAL -->
    <div id="projectModal" class="fixed inset-0 z-50 hidden bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-100 my-8 animate-fade-in">
            <!-- Modal Header -->
            <div class="relative bg-ccdi-navy text-white p-6 sm:p-8">
                <button onclick="closeModal('projectModal')" class="absolute top-4 right-4 w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                <div class="inline-block bg-amber-500 text-ccdi-navy text-xs font-bold px-3 py-1 rounded-full mb-3" id="modalCategory">Capstone System</div>
                <h2 class="text-2xl sm:text-3xl font-black text-white" id="modalTitle">Sorsogon Wander: AR-Assisted Tourism System</h2>
                <p class="text-xs text-amber-300 font-semibold mt-1" id="modalCourseCode">CS 412 - Final Capstone Project • AY 2025-2026</p>
            </div>

            <!-- Modal Content -->
            <div class="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
                <!-- Preview Image -->
                <div class="rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 max-h-72">
                    <img id="modalImage" src="" alt="Project Banner" class="w-full h-full object-cover">
                </div>

                <!-- Abstract -->
                <div>
                    <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Project Abstract & Overview</h4>
                    <p class="text-sm text-slate-700 leading-relaxed" id="modalAbstract">Detailed abstract content goes here...</p>
                </div>

                <!-- Tech Stack Tags -->
                <div>
                    <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Technologies Used</h4>
                    <div class="flex flex-wrap gap-2" id="modalTechStack">
                        <!-- Tech badges -->
                    </div>
                </div>

                <!-- Student Authors & Adviser Grid -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div>
                        <h4 class="text-xs font-bold text-slate-400 uppercase">Student Authors</h4>
                        <p class="text-xs font-bold text-slate-800 mt-1" id="modalAuthors">Jhon Mar, Maria Santos, Alex Perez</p>
                        <p class="text-[11px] text-slate-500">CCDI Sorsogon Senior Batch</p>
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-slate-400 uppercase">Faculty Panel Adviser</h4>
                        <p class="text-xs font-bold text-slate-800 mt-1" id="modalAdviser">Prof. E. Ramos, MSIT</p>
                        <p class="text-[11px] text-emerald-600 font-semibold"><i class="fa-solid fa-circle-check"></i> Defended & Approved</p>
                    </div>
                </div>

                <!-- Contact & Live Demo Actions -->
                <div class="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <a id="modalDemoLink" href="#" target="_blank" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm transition inline-flex items-center space-x-2">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span>Launch Live System Demo</span>
                    </a>
                    <button onclick="requestEmployerContact()" class="bg-ccdi-navy hover:bg-slate-800 text-white font-semibold px-5 py-2.5 rounded-xl text-sm transition inline-flex items-center space-x-2">
                        <i class="fa-solid fa-envelope"></i>
                        <span>Contact Student / Hire Request</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- MODAL 2: UPLOAD PROJECT MODAL (STUDENT FORM) -->
    <div id="uploadModal" class="fixed inset-0 z-50 hidden bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 my-8">
            <div class="bg-ccdi-navy text-white p-6 flex justify-between items-center border-b border-amber-500/30">
                <div>
                    <h3 class="text-xl font-bold text-white">Submit New CCDI Project</h3>
                    <p class="text-xs text-slate-300">Publish your capstone, app, or creative output to DEVFOLIO</p>
                </div>
                <button onclick="closeModal('uploadModal')" class="w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <form id="projectUploadForm" onsubmit="handleProjectSubmit(event)" class="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Project Title *</label>
                    <input type="text" id="formTitle" required placeholder="e.g. Sorsogon Coastal Threat Detection System" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Category *</label>
                        <select id="formCategory" required class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="Capstone System">Capstone System</option>
                            <option value="Web Application">Web Application</option>
                            <option value="Mobile App">Mobile App</option>
                            <option value="3D & Multimedia">3D & Multimedia</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Course / Subject Code *</label>
                        <input type="text" id="formCourseCode" required placeholder="e.g. CS 412 - Capstone 2" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Project Abstract / Summary *</label>
                    <textarea id="formAbstract" required rows="3" placeholder="Brief explanation of the project scope, problem solved, and technical features..." class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none"></textarea>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Tech Stack (Comma Separated) *</label>
                        <input type="text" id="formTechStack" required placeholder="e.g. React, PHP, MySQL, Tailwind" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Demo / Repository Link</label>
                        <input type="url" id="formDemoLink" placeholder="https://github.com/or-demo-link" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Project Banner / Preview Image URL</label>
                    <input type="url" id="formImage" placeholder="https://placehold.co/600x400/0f2a4a/ffffff?text=Project+Preview" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    <p class="text-[10px] text-slate-400 mt-0.5">Leave empty for a auto-generated CCDI preview placeholder.</p>
                </div>

                <div class="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                    <button type="button" onclick="closeModal('uploadModal')" class="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition">Cancel</button>
                    <button type="submit" class="px-5 py-2 text-xs font-bold text-ccdi-navy bg-amber-500 hover:bg-amber-600 rounded-xl shadow transition">Submit for Faculty Review</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>
