<?php
/**
 * Shared project form handling (the "Showcase a project" form on the feed).
 * Fields: title, category, description, technologies, photos, one project link and an
 * optional README.md. Only a Markdown (.md) file can be attached: it is read as text and
 * shown on the project page (never offered as a download), so the project stays with its owner.
 */

require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';

const DF_PROJECT_CATEGORIES = ['Web App', 'Mobile App', 'Animation', 'Capstone', 'Multimedia'];
const DF_PROJECT_MAX_BYTES = 5242880; // 5 MB per file
const DF_PROJECT_PHOTO_EXT = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

/**
 * Reads and validates the text fields.
 *
 * @return array{error?:string,title?:string,description?:string,category?:string,link?:string,tech?:?string}
 */
function dfReadProjectFields(array $post): array {
    $title = trim((string) ($post['title'] ?? ''));
    $description = trim((string) ($post['description'] ?? ''));
    $category = trim((string) ($post['category'] ?? 'Web App'));
    $categoryOther = trim((string) preg_replace('/\s+/', ' ', (string) ($post['category_other'] ?? '')));
    $link = trim((string) ($post['project_link'] ?? ''));

    if ($title === '' || $description === '') {
        return ['error' => 'Title and description are required.'];
    }
    if (mb_strlen($title) > 255) {
        return ['error' => 'Title is too long (max 255 characters).'];
    }

    if ($category === 'Others, Specify') {
        if ($categoryOther === '') return ['error' => 'Please specify the category of your project.'];
        if (mb_strlen($categoryOther) > 100) return ['error' => 'Category is too long (max 100 characters).'];
        $category = $categoryOther;
    } elseif (!in_array($category, DF_PROJECT_CATEGORIES, true)) {
        $category = 'Web App';
    }

    if ($link !== '' && (!preg_match('#^https?://#i', $link) || mb_strlen($link) > 255)) {
        return ['error' => 'Project link must be a valid link starting with http:// or https://'];
    }

    // Technologies: comma-separated, up to 8 tags
    $tags = [];
    foreach (explode(',', (string) ($post['tech_stack'] ?? '')) as $rawTag) {
        $tag = trim((string) preg_replace('/\s+/', ' ', $rawTag));
        if ($tag === '') continue;
        $tag = mb_substr($tag, 0, 30);
        if (!in_array(mb_strtolower($tag), array_map('mb_strtolower', $tags), true)) $tags[] = $tag;
        if (count($tags) >= 8) break;
    }

    return [
        'title'       => $title,
        'description' => $description,
        'category'    => $category,
        'link'        => $link,
        'tech'        => $tags ? json_encode($tags, JSON_UNESCAPED_UNICODE) : null,
    ];
}

/**
 * Validates the optional cover photo.
 *
 * @return array{0:?string,1:?array} [error message or null, photo info or null when none was chosen]
 */
function dfReadPhotoUpload(array $files): array {
    if (!isset($files['photo']) || $files['photo']['error'] === UPLOAD_ERR_NO_FILE) return [null, null];
    $photo = $files['photo'];
    if ($photo['error'] !== UPLOAD_ERR_OK) {
        return ['Photo upload failed. Try a smaller image (max 5 MB).', null];
    }
    $ext = strtolower(pathinfo((string) $photo['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, DF_PROJECT_PHOTO_EXT, true) || @getimagesize($photo['tmp_name']) === false) {
        return ['Photo must be a JPG, PNG, WEBP, or GIF image.', null];
    }
    if ($photo['size'] > DF_PROJECT_MAX_BYTES) {
        return ['Photo is larger than 5 MB.', null];
    }
    return [null, ['tmp' => $photo['tmp_name'], 'ext' => $ext]];
}

/** Saves a validated cover photo. Returns the stored relative path, or null on failure. */
function dfStoreProjectPhoto(array $photo, int $studentId): ?string {
    $dir = __DIR__ . '/../assets/uploads/projects/';
    if (!is_dir($dir)) mkdir($dir, 0777, true);
    $name = 'project_' . $studentId . '_' . bin2hex(random_bytes(6)) . '.' . $photo['ext'];
    if (!move_uploaded_file($photo['tmp'], $dir . $name)) return null;
    return 'assets/uploads/projects/' . $name;
}

/** Deletes a file we stored earlier. Only touches our own project upload folders. */
function dfDeleteUploadedFile(?string $relPath): void {
    $relPath = (string) $relPath;
    if (strpos($relPath, '..') !== false) return;
    if (strpos($relPath, 'assets/uploads/projects/') !== 0 && strpos($relPath, 'assets/uploads/project_files/') !== 0) return;
    $full = __DIR__ . '/../' . $relPath;
    if (is_file($full)) @unlink($full);
}


/* ===================================================================
 * Several photos per project
 * Form fields:  photos[]        new image files, in the order they were added
 *               photo_order     "e12,n0,e15" = existing photo 12, new file 0, existing photo 15 (first = cover)
 *               remove_photos[] ids of existing photos to delete (edit only)
 * =================================================================== */

const DF_PROJECT_MAX_PHOTOS = 10;

/**
 * Validates the optional new photos (the "photos[]" input; the old single "photo" input still works).
 *
 * @return array{0:?string,1:array} [error message or null, list of pending photos]
 */
function dfReadPhotoUploads(array $files): array {
    $pending = [];
    $list = [];
    if (isset($files['photos']) && is_array($files['photos']['name'])) {
        foreach ($files['photos']['name'] as $i => $name) {
            $list[] = ['name' => (string) $name, 'tmp' => $files['photos']['tmp_name'][$i], 'error' => $files['photos']['error'][$i], 'size' => (int) $files['photos']['size'][$i]];
        }
    } elseif (isset($files['photo']) && !is_array($files['photo']['name'])) {
        $list[] = ['name' => (string) $files['photo']['name'], 'tmp' => $files['photo']['tmp_name'], 'error' => $files['photo']['error'], 'size' => (int) $files['photo']['size']];
    }

    foreach ($list as $f) {
        if ($f['error'] === UPLOAD_ERR_NO_FILE) continue;
        $label = '"' . basename($f['name']) . '"';
        if ($f['error'] !== UPLOAD_ERR_OK) return [$label . ' could not be uploaded (max 5 MB per photo).', []];
        $ext = strtolower(pathinfo($f['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, DF_PROJECT_PHOTO_EXT, true) || @getimagesize($f['tmp']) === false) {
            return [$label . ' must be a JPG, PNG, WEBP, or GIF image.', []];
        }
        if ($f['size'] > DF_PROJECT_MAX_BYTES) return [$label . ' is larger than 5 MB.', []];
        $pending[] = ['tmp' => $f['tmp'], 'ext' => $ext];
    }
    if (count($pending) > DF_PROJECT_MAX_PHOTOS) {
        return ['A project can have up to ' . DF_PROJECT_MAX_PHOTOS . ' photos.', []];
    }
    return [null, $pending];
}

/**
 * Applies a project's photo changes in one go: removes, stores the new files, sets the order
 * and points projects.banner_image_url at the new cover. Nothing is written when the limit
 * would be exceeded. Returns an error message, or null on success.
 *
 * @param array $pending   result of dfReadPhotoUploads()
 * @param array $removeIds existing project_photos ids to delete
 * @param string $orderCsv the photo_order field
 */
function dfApplyProjectPhotos(PDO $pdo, int $projectId, int $studentId, array $pending, array $removeIds, string $orderCsv): ?string {
    if (!dfPhotosReady($pdo)) return 'Photos are unavailable right now. Please try again.';

    try {
        // A project that only has an old single cover becomes the first row, so nothing is lost.
        $cur = $pdo->prepare('SELECT banner_image_url FROM projects WHERE id = ? LIMIT 1');
        $cur->execute([$projectId]);
        $banner = (string) $cur->fetchColumn();

        $rowsStmt = $pdo->prepare('SELECT id, file_path FROM project_photos WHERE project_id = ? ORDER BY sort_order ASC, id ASC');
        $rowsStmt->execute([$projectId]);
        $rows = $rowsStmt->fetchAll(PDO::FETCH_ASSOC);
        if (!$rows && dfIsRealPhoto($banner)) {
            $pdo->prepare('INSERT INTO project_photos (project_id, file_path, sort_order) VALUES (?, ?, 0)')->execute([$projectId, $banner]);
            $rowsStmt->execute([$projectId]);
            $rows = $rowsStmt->fetchAll(PDO::FETCH_ASSOC);
        }

        $existing = [];
        foreach ($rows as $r) $existing[(int) $r['id']] = (string) $r['file_path'];

        $remove = [];
        foreach ($removeIds as $rid) if (isset($existing[(int) $rid])) $remove[(int) $rid] = $existing[(int) $rid];
        $kept = array_diff_key($existing, $remove);

        if (count($kept) + count($pending) > DF_PROJECT_MAX_PHOTOS) {
            return 'A project can have up to ' . DF_PROJECT_MAX_PHOTOS . ' photos. Remove some first.';
        }

        // Store the new files first (so a failure leaves the project untouched)
        $stored = [];
        foreach ($pending as $k => $photo) {
            $path = dfStoreProjectPhoto($photo, $studentId);
            if ($path === null) {
                foreach ($stored as $done) dfDeleteUploadedFile($done);
                return 'Could not save a photo. Please try again.';
            }
            $stored[$k] = $path;
        }

        // Final order: what the person arranged, then anything they did not mention
        $final = [];   // list of ['id'=>int|null, 'path'=>string]
        $seenE = [];
        $seenN = [];
        foreach (array_filter(explode(',', $orderCsv), 'strlen') as $tok) {
            $kind = $tok[0];
            $n = (int) substr($tok, 1);
            if ($kind === 'e' && isset($kept[$n]) && !isset($seenE[$n])) { $final[] = ['id' => $n, 'path' => $kept[$n]]; $seenE[$n] = true; }
            if ($kind === 'n' && isset($stored[$n]) && !isset($seenN[$n])) { $final[] = ['id' => null, 'path' => $stored[$n]]; $seenN[$n] = true; }
        }
        foreach ($kept as $id => $path) if (!isset($seenE[$id])) $final[] = ['id' => $id, 'path' => $path];
        foreach ($stored as $k => $path) if (!isset($seenN[$k])) $final[] = ['id' => null, 'path' => $path];

        $pdo->beginTransaction();
        if ($remove) {
            $del = $pdo->prepare('DELETE FROM project_photos WHERE id = ? AND project_id = ?');
            foreach (array_keys($remove) as $rid) $del->execute([$rid, $projectId]);
        }
        $upd = $pdo->prepare('UPDATE project_photos SET sort_order = ? WHERE id = ? AND project_id = ?');
        $ins = $pdo->prepare('INSERT INTO project_photos (project_id, file_path, sort_order) VALUES (?, ?, ?)');
        foreach ($final as $i => $item) {
            if ($item['id'] !== null) $upd->execute([$i, $item['id'], $projectId]);
            else $ins->execute([$projectId, $item['path'], $i]);
        }
        $cover = $final ? $final[0]['path'] : null;
        $pdo->prepare('UPDATE projects SET banner_image_url = ? WHERE id = ? AND student_id = ?')->execute([$cover, $projectId, $studentId]);
        $pdo->commit();

        // Files of removed photos are no longer used (the old single cover counts too)
        foreach ($remove as $path) dfDeleteUploadedFile($path);
        return null;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return 'Could not save the photos. Please try again.';
    }
}

/** Deletes the stored files of every photo of a project (used before the project row is deleted). */
function dfDeleteProjectPhotoFiles(PDO $pdo, int $projectId): void {
    try {
        $paths = [];
        if (dfPhotosReady($pdo)) {
            $st = $pdo->prepare('SELECT file_path FROM project_photos WHERE project_id = ?');
            $st->execute([$projectId]);
            $paths = $st->fetchAll(PDO::FETCH_COLUMN);
        }
        $b = $pdo->prepare('SELECT banner_image_url FROM projects WHERE id = ? LIMIT 1');
        $b->execute([$projectId]);
        $paths[] = (string) $b->fetchColumn();
        foreach (array_unique($paths) as $path) dfDeleteUploadedFile($path);
    } catch (Throwable $e) {
        // leftover files are harmless
    }
}

/** The photo picker markup, shared by the feed's "Showcase a project" dialog and My Projects. */
function dfPhotoPickerHtml(): string {
    return '<div class="dfpp" id="photoPicker" data-max="' . (int) DF_PROJECT_MAX_PHOTOS . '">'
        . '<span class="dfpp-title" id="photoPickerLabel">Photos <span class="dfpp-opt">(optional, up to ' . (int) DF_PROJECT_MAX_PHOTOS . ')</span></span>'
        . '<ul class="dfpp-grid" id="photoGrid" aria-labelledby="photoPickerLabel"></ul>'
        . '<input type="file" id="photoInput" accept="image/jpeg,image/png,image/webp,image/gif" multiple hidden>'
        . '<button type="button" class="dfpp-add" id="photoAdd">' . dfIcon('plus', 16) . ' <span>Add photos</span></button>'
        . '<p class="dfpp-msg" id="photoMsg" role="status" aria-live="polite"></p>'
        . '<small>JPG, PNG, WEBP or GIF, max 5 MB each. The first photo is the cover. Use the arrows to change the order.</small>'
        . '</div>';
}


/* ===================================================================
 * README.md (the only file a project can carry)
 *
 * Stored as text in project_readmes (one row per project) and rendered in the
 * browser by js/df-markdown.js. Nothing is written to disk, so there is no file
 * for anyone to download and re-use.
 * =================================================================== */

const DF_README_MAX_BYTES = 262144; // 256 KB of text

/** Creates project_readmes if it is missing (once per session). */
function dfReadmesReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_readmes_table'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS project_readmes (
            project_id INT PRIMARY KEY,
            body MEDIUMTEXT NOT NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )");
        $_SESSION['df_readmes_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

/**
 * Cleans README text: UTF-8 only, no BOM, no control characters, \n line endings.
 *
 * @return array{0:?string,1:string} [error message or null, cleaned text]
 */
function dfCleanReadmeText(string $raw): array {
    if (strlen($raw) > DF_README_MAX_BYTES + 3) return ['The README is too large (max 256 KB).', ''];
    if (strpos($raw, "\0") !== false) return ['A README must be a plain text .md file.', ''];
    if (strncmp($raw, "\xEF\xBB\xBF", 3) === 0) $raw = substr($raw, 3);
    if (!mb_check_encoding($raw, 'UTF-8')) return ['The README must be saved as UTF-8 text.', ''];
    $raw = str_replace(["\r\n", "\r"], "\n", $raw);
    $raw = preg_replace('/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/', '', $raw) ?? '';   // keeps tabs and new lines
    if (strlen($raw) > DF_README_MAX_BYTES) return ['The README is too large (max 256 KB).', ''];
    return [null, rtrim($raw)];
}

/**
 * Validates the optional README upload (the "readme" file input) and returns its text.
 *
 * @return array{0:?string,1:?string} [error message or null, text or null when none was chosen]
 */
function dfReadReadmeUpload(array $files): array {
    if (!isset($files['readme']) || is_array($files['readme']['name']) || $files['readme']['error'] === UPLOAD_ERR_NO_FILE) {
        return [null, null];
    }
    $f = $files['readme'];
    if ($f['error'] !== UPLOAD_ERR_OK) return ['The README could not be uploaded (max 256 KB).', null];
    if (!is_uploaded_file($f['tmp_name'])) return ['The README could not be uploaded.', null];
    if (strtolower(pathinfo((string) $f['name'], PATHINFO_EXTENSION)) !== 'md') {
        return ['Only a Markdown file (.md, like README.md) can be attached.', null];
    }
    if ($f['size'] > DF_README_MAX_BYTES) return ['The README is too large (max 256 KB).', null];
    $raw = @file_get_contents($f['tmp_name']);
    if ($raw === false) return ['The README could not be read. Please try again.', null];
    [$error, $text] = dfCleanReadmeText($raw);
    if ($error !== null) return [$error, null];
    return [null, $text === '' ? null : $text];
}

/**
 * Reads the README text typed (or loaded from a .md file) in the "Showcase a project" editor.
 * It goes through the same cleaning and 256 KB limit as an uploaded file.
 *
 * @return array{0:?string,1:?string} [error message or null, text or null when left empty]
 */
function dfReadReadmeText(array $post): array {
    if (!isset($post['readme_text']) || !is_string($post['readme_text'])) return [null, null];
    [$error, $text] = dfCleanReadmeText($post['readme_text']);
    if ($error !== null) return [$error, null];
    return [null, trim($text) === '' ? null : $text];
}

/** Saves a project's README. Empty text removes it. Returns false when it could not be saved. */
function dfSaveReadme(PDO $pdo, int $projectId, ?string $text): bool {
    if (!dfReadmesReady($pdo)) return false;
    try {
        if ($text === null || trim($text) === '') {
            $pdo->prepare('DELETE FROM project_readmes WHERE project_id = ?')->execute([$projectId]);
        } else {
            $pdo->prepare('INSERT INTO project_readmes (project_id, body) VALUES (?, ?) ON DUPLICATE KEY UPDATE body = VALUES(body)')
                ->execute([$projectId, $text]);
        }
        return true;
    } catch (Throwable $e) {
        return false;
    }
}

/** The README text of a project ('' when it has none). */
function dfLoadReadme(PDO $pdo, int $projectId): string {
    if (!dfReadmesReady($pdo)) return '';
    try {
        $st = $pdo->prepare('SELECT body FROM project_readmes WHERE project_id = ? LIMIT 1');
        $st->execute([$projectId]);
        return (string) ($st->fetchColumn() ?: '');
    } catch (Throwable $e) {
        return '';
    }
}
