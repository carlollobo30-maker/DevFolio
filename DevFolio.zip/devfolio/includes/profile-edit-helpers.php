<?php
/**
 * Profile customization helpers: profession, skills (shown as titles) and certificates.
 * Used by student/profile.php (Account settings, where the owner edits these),
 * student/profile-actions.php (saves them) and
 * student/user.php (the public profile that students and faculty see).
 *
 * Needs ui-helpers.php and project-helpers.php (dfIcon, dfEsc, dfAssetUrl) loaded by the page.
 */

/** Limits for the profile fields edited on Account settings. */
const DF_BIO_MAX = 600;
const DF_PROFESSION_MAX = 120;
const DF_SKILL_MAX_LEN = 50;
const DF_SKILL_LIMIT = 40;
const DF_CERT_LIMIT = 30;
const DF_CERT_TEXT_MAX = 150;

/** How many skills / certificates show before the "View more" button. */
const DF_PREVIEW_MAX = 3;
const DF_CERT_MAX_BYTES = 5 * 1024 * 1024;
const DF_CERT_DIR_URL = '../assets/uploads/certificates/';

/** Adds students.profession if this database does not have it yet (once per session). */
function dfProfessionReady(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    if (!empty($_SESSION['df_profession_col'])) return $ready = true;
    try {
        $chk = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'students' AND COLUMN_NAME = 'profession'");
        if ((int) $chk->fetchColumn() === 0) {
            $pdo->exec('ALTER TABLE students ADD COLUMN profession VARCHAR(120) NULL');
        }
        $_SESSION['df_profession_col'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return $ready = false;
    }
}

/** All skills of a student, strongest first. */
function dfFetchSkillList(PDO $pdo, int $studentId): array {
    $st = $pdo->prepare("SELECT id, skill_name, proficiency_level FROM skills WHERE student_id = ?
                         ORDER BY FIELD(proficiency_level, 'expert', 'advanced', 'intermediate', 'beginner'), skill_name ASC LIMIT 100");
    $st->execute([$studentId]);
    return $st->fetchAll(PDO::FETCH_ASSOC);
}

/** All certificates of a student, newest first. */
function dfFetchCertificates(PDO $pdo, int $studentId): array {
    $st = $pdo->prepare('SELECT id, certificate_name, issuing_organization, certificate_image_url, created_at
                         FROM certificates WHERE student_id = ? ORDER BY created_at DESC, id DESC LIMIT 100');
    $st->execute([$studentId]);
    return $st->fetchAll(PDO::FETCH_ASSOC);
}

/** The "View more (N)" / "Show less" button, wired by js/df-more.js. Empty when everything already fits. */
function dfMoreButton(int $total, string $noun): string {
    $extra = $total - DF_PREVIEW_MAX;
    if ($extra <= 0) return '';
    return '<button type="button" class="df-more" data-more-toggle aria-expanded="false" data-more-text="View more (' . $extra . ')">View more (' . $extra . ')</button>';
}

/**
 * Skills as title chips: name plus level. The first DF_PREVIEW_MAX show; the rest sit behind "View more".
 * $editable adds a remove button on every chip (owner only).
 */
function dfRenderSkillChips(array $skills, bool $editable = false): string {
    if (!$skills) return '';
    $html = '<div data-more-wrap><ul class="df-skill-titles" aria-label="Skills">';
    foreach (array_values($skills) as $i => $s) {
        $extra = $i >= DF_PREVIEW_MAX;
        $name = (string) $s['skill_name'];
        $html .= '<li class="df-skill-title"' . ($extra ? ' data-more-item hidden' : '') . '>'
            . '<span class="df-skill-name">' . dfEsc($name) . '</span>'
            . '<small>' . dfEsc(ucfirst((string) ($s['proficiency_level'] ?? 'intermediate'))) . '</small>';
        if ($editable) {
            $html .= '<button type="button" class="df-chip-x" data-skill-delete="' . (int) $s['id'] . '" aria-label="' . dfEsc('Remove skill ' . $name) . '">' . dfIcon('close', 14) . '</button>';
        }
        $html .= '</li>';
    }
    $html .= '</ul>' . dfMoreButton(count($skills), 'skills') . '</div>';
    return $html;
}

/**
 * Skills as simple rows (name on the left, level on the right) for the profile sidebar.
 * The first DF_PREVIEW_MAX show; the rest sit behind "View more".
 */
function dfRenderSkillRows(array $skills): string {
    if (!$skills) return '';
    $html = '<div data-more-wrap><ul class="pf-skill-rows" aria-label="Skills">';
    foreach (array_values($skills) as $i => $s) {
        $extra = $i >= DF_PREVIEW_MAX;
        $html .= '<li' . ($extra ? ' data-more-item hidden' : '') . '>'
            . '<span class="pf-skill-name">' . dfEsc((string) $s['skill_name']) . '</span>'
            . '<span class="pf-skill-level">' . dfEsc(ucfirst((string) ($s['proficiency_level'] ?? 'intermediate'))) . '</span></li>';
    }
    return $html . '</ul>' . dfMoreButton(count($skills), 'skills') . '</div>';
}

/** The "See certificate" button. js/df-cert-view.js opens the viewer from its data attributes. */
function dfCertViewButton(array $c): string {
    $name = (string) $c['certificate_name'];
    $img = dfAssetUrl($c['certificate_image_url'] ?? '');
    return '<button type="button" class="df-cert-see" data-cert-view'
        . ' data-cert-title="' . dfEsc($name) . '"'
        . ' data-cert-issuer="' . dfEsc((string) ($c['issuing_organization'] ?? '')) . '"'
        . ' data-cert-img="' . dfEsc($img) . '"'
        . ' aria-haspopup="dialog" aria-label="' . dfEsc('See certificate: ' . $name) . '">'
        . dfIcon('eye', 15) . '<span>See certificate</span></button>';
}

/**
 * Certificates. The first DF_PREVIEW_MAX show; the rest sit behind "View more".
 * Every certificate has a "See certificate" button that opens it in a viewer.
 *
 * $editable adds a remove button on every card (owner only, Account settings).
 * $compact  renders slim rows (icon, title, issuer, button) for the profile sidebar.
 */
function dfRenderCertificates(array $certs, bool $editable = false, bool $compact = false): string {
    if (!$certs) return '';
    $html = '<div data-more-wrap><div class="' . ($compact ? 'pf-certs' : 'df-certs') . '">';
    foreach (array_values($certs) as $i => $c) {
        $extra = $i >= DF_PREVIEW_MAX;
        $name = (string) $c['certificate_name'];
        $org = trim((string) ($c['issuing_organization'] ?? ''));
        $img = dfAssetUrl($c['certificate_image_url'] ?? '');

        if ($compact) {
            $year = !empty($c['created_at']) ? date('Y', strtotime((string) $c['created_at']) ?: time()) : '';
            $sub = trim($org . ($org !== '' && $year !== '' ? ' · ' : '') . $year);
            $html .= '<article class="pf-cert"' . ($extra ? ' data-more-item hidden' : '') . '>'
                . '<span class="pf-cert-ico" aria-hidden="true">' . dfIcon('award', 18) . '</span>'
                . '<div class="pf-cert-text"><h3>' . dfEsc($name) . '</h3>' . ($sub !== '' ? '<p>' . dfEsc($sub) . '</p>' : '') . '</div>'
                . dfCertViewButton($c) . '</article>';
            continue;
        }

        $html .= '<article class="df-cert"' . ($extra ? ' data-more-item hidden' : '') . '>';
        if ($img !== '') {
            $html .= '<button type="button" class="df-cert-img" data-cert-view data-cert-title="' . dfEsc($name) . '" data-cert-issuer="' . dfEsc($org) . '" data-cert-img="' . dfEsc($img) . '" aria-haspopup="dialog" aria-label="' . dfEsc('See certificate: ' . $name) . '">'
                . '<img src="' . dfEsc($img) . '" alt="' . dfEsc('Certificate: ' . $name) . '" loading="lazy" onerror="this.remove()"></button>';
        } else {
            $html .= '<div class="df-cert-img is-empty" aria-hidden="true">' . dfIcon('award', 34) . '</div>';
        }
        $html .= '<div class="df-cert-body"><h3>' . dfEsc($name) . '</h3>';
        if ($org !== '') {
            $html .= '<p>' . dfEsc($org) . '</p>';
        }
        $html .= '<div class="df-cert-actions">' . dfCertViewButton($c);
        if ($editable) {
            $html .= '<button type="button" class="df-cert-del" data-cert-delete="' . (int) $c['id'] . '" aria-label="' . dfEsc('Remove certificate ' . $name) . '">' . dfIcon('trash', 14) . ' Remove</button>';
        }
        $html .= '</div></div></article>';
    }
    $html .= '</div>' . dfMoreButton(count($certs), 'certificates') . '</div>';
    return $html;
}

/**
 * Validates and stores an uploaded certificate image.
 * The type is read from the file itself (not from what the browser claims).
 *
 * @return array{0:?string,1:?string} [error message or null, stored url or null]
 */
function dfStoreCertificateImage(array $file, int $userId): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return [null, null];
    if ($file['error'] !== UPLOAD_ERR_OK) return ['The certificate image could not be uploaded (max 5 MB).', null];
    if ((int) $file['size'] > DF_CERT_MAX_BYTES) return ['The certificate image is larger than 5 MB.', null];

    $info = @getimagesize($file['tmp_name']);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($types[$info[2]])) return ['Only JPG, PNG, and WEBP images are allowed for certificates.', null];

    $dir = __DIR__ . '/../assets/uploads/certificates/';
    if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) return ['Certificate image upload failed.', null];

    $name = 'certificate_' . $userId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $types[$info[2]];
    if (!move_uploaded_file($file['tmp_name'], $dir . $name)) return ['Certificate image upload failed.', null];
    return [null, DF_CERT_DIR_URL . $name];
}

/** Deletes a stored certificate image, but only if it really lives in the certificates folder. */
function dfDeleteCertificateImage(?string $url): void {
    $url = (string) $url;
    if (strpos($url, DF_CERT_DIR_URL) !== 0) return;
    $file = __DIR__ . '/../assets/uploads/certificates/' . basename($url);
    if (is_file($file)) @unlink($file);
}

/** Fresh HTML for the skills and certificates lists (used on page load and after every change). */
function dfProfileLists(PDO $pdo, int $sid): array {
    $skills = dfFetchSkillList($pdo, $sid);
    $certs = dfFetchCertificates($pdo, $sid);
    return [
        'skills_html' => $skills ? dfRenderSkillChips($skills, true) : '<p class="upx-muted">No skills yet. Add your first one below.</p>',
        'certs_html'  => $certs ? dfRenderCertificates($certs, true) : '<p class="upx-muted">No certificates yet. Add one to show it on your profile.</p>',
        'skill_count' => count($skills),
        'cert_count'  => count($certs),
    ];
}
