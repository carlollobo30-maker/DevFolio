<?php
/**
 * Roles, streaks and badges (DEVFOLIO CCDI Sorsogon).
 *
 *  Roles    Admin = gold, Faculty = red, Student = green          (dfRoleBadge)
 *  Streaks  consecutive days a signed-in user opens DevFolio      (dfTouchStreak / dfStreakInfo)
 *  Badges   earned automatically from real activity, 4 tiers      (dfBadgeCatalog / dfEvaluateBadges)
 *
 * Badges are defined here in code; the database only remembers WHO earned WHAT and WHEN
 * (user_badges). Nothing in this file can break a page: every database call is guarded, and
 * the three tables are created on first use if they do not exist yet.
 */
require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';   // dfEsc()

/* ===================================================================
 * Roles
 * =================================================================== */

/** Colored role pill. Admin = gold, Faculty = red, Student = green. */
function dfRoleBadge(string $role): string {
    $labels = ['admin' => 'Admin', 'faculty' => 'Faculty', 'student' => 'Student'];
    if (!isset($labels[$role])) return '';
    return '<span class="df-role df-role-' . $role . '">' . $labels[$role] . '</span>';
}

/* ===================================================================
 * Tiers + catalog
 * =================================================================== */

/** Difficulty tiers, easiest first. */
function dfTiers(): array {
    return [
        'easy'      => ['label' => 'Easy',      'tag' => 'Quick wins to get you started',   'points' => 10],
        'medium'    => ['label' => 'Medium',    'tag' => 'Takes steady effort',             'points' => 25],
        'hard'      => ['label' => 'Hard',      'tag' => 'For truly dedicated members',     'points' => 50],
        'legendary' => ['label' => 'Legendary', 'tag' => 'Reserved for the very best',      'points' => 100],
    ];
}

/** What each progress metric is called on the badges page. */
function dfMetricUnit(string $metric): string {
    $units = [
        'streak_best'    => 'days',
        'comments'       => 'comments',
        'likes_given'    => 'appreciations',
        'shares'         => 'projects shared',
        'projects'       => 'projects',
        'likes_received' => 'appreciations',
        'skills'         => 'skills',
        'profile'        => '',
        'reports'        => 'reports',
        'badges'         => 'badges',
    ];
    return $units[$metric] ?? '';
}

/**
 * Every badge. Fields: slug, name, desc, tier, icon, metric, goal, roles.
 * Metrics are computed in dfBadgeMetrics(); a badge is earned when metric >= goal.
 */
function dfBadgeCatalog(): array {
    static $catalog = null;
    if ($catalog !== null) return $catalog;

    $all = ['student', 'faculty'];
    $stu = ['student'];
    $fac = ['faculty'];
    $b = static function (string $slug, string $name, string $desc, string $tier, string $icon, string $metric, int $goal, array $roles) {
        return ['slug' => $slug, 'name' => $name, 'desc' => $desc, 'tier' => $tier, 'icon' => $icon, 'metric' => $metric, 'goal' => $goal, 'roles' => $roles];
    };

    $catalog = [
        // ---------- EASY ----------
        $b('welcome',       'Welcome Aboard',       'Sign in to DevFolio for the first time.',                   'easy', 'sparkles', 'streak_best',    1,  $all),
        $b('first-words',   'Conversation Starter', 'Comment on someone else\'s project.',                       'easy', 'comment',  'comments',       1,  $all),
        $b('appreciator',   'Appreciator',          'Appreciate 5 projects by other students.',                  'easy', 'heart',    'likes_given',    5,  $all),
        $b('streak-3',      'Warming Up',           'Keep a 3-day streak.',                                      'easy', 'flame',    'streak_best',    3,  $all),
        $b('first-project', 'First Showcase',       'Showcase your first project.',                              'easy', 'folder',   'projects',       1,  $stu),
        $b('picture',       'Picture Perfect',      'Add a bio and a profile photo.',                            'easy', 'user',     'profile',        1,  $stu),
        $b('skill-starter', 'Skill Starter',        'List 3 skills on your profile.',                            'easy', 'code',     'skills',         3,  $stu),
        $b('first-review',  'First Review',         'Handle your first project report.',                         'easy', 'shield',   'reports',        1,  $fac),

        // ---------- MEDIUM ----------
        $b('streak-7',      'Week Warrior',         'Keep a 7-day streak.',                                      'medium', 'flame',  'streak_best',    7,  $all),
        $b('voice',         'Community Voice',      'Leave 15 comments on other people\'s projects.',            'medium', 'comment','comments',       15, $all),
        $b('sharer',        'Spread the Word',      'Share 5 different projects.',                               'medium', 'share',  'shares',         5,  $all),
        $b('portfolio',     'Portfolio Builder',    'Have 3 projects on the showcase.',                          'medium', 'folder', 'projects',       3,  $stu),
        $b('well-rounded',  'Well-Rounded',         'List 8 skills on your profile.',                            'medium', 'star',   'skills',         8,  $stu),
        $b('crowd',         'Crowd Pleaser',        'Receive 10 appreciations from others.',                     'medium', 'heart',  'likes_received', 10, $stu),
        $b('guardian',      'Guardian',             'Handle 10 project reports.',                                'medium', 'shield', 'reports',        10, $fac),

        // ---------- HARD ----------
        $b('streak-30',     'Monthly Master',       'Keep a 30-day streak.',                                     'hard', 'flame',    'streak_best',    30, $all),
        $b('pillar',        'Community Pillar',     'Leave 50 comments on other people\'s projects.',            'hard', 'users',    'comments',       50, $all),
        $b('prolific',      'Prolific Creator',     'Have 6 projects on the showcase.',                          'hard', 'crown',    'projects',       6,  $stu),
        $b('fan-favorite',  'Fan Favorite',         'Receive 50 appreciations from others.',                     'hard', 'star',     'likes_received', 50, $stu),
        $b('polymath',      'Polymath',             'List 15 skills on your profile.',                           'hard', 'sparkles', 'skills',         15, $stu),
        $b('sentinel',      'Sentinel',             'Handle 40 project reports.',                                'hard', 'shield',   'reports',        40, $fac),

        // ---------- LEGENDARY ----------
        $b('streak-100',    'Unstoppable',          'Keep a 100-day streak.',                                    'legendary', 'zap',    'streak_best',    100, $all),
        $b('collector',     'Collector',            'Earn 12 other badges.',                                     'legendary', 'award',  'badges',         12,  $all),
        $b('campus-icon',   'Campus Icon',          'Receive 200 appreciations from others.',                    'legendary', 'crown',  'likes_received', 200, $stu),
        $b('hall-of-fame',  'Hall of Fame',         'Have 12 projects on the showcase.',                         'legendary', 'trophy', 'projects',       12,  $stu),
        $b('keeper',        'Keeper of the Peace',  'Handle 150 project reports.',                               'legendary', 'shield', 'reports',        150, $fac),
    ];
    return $catalog;
}

/** Badges a given role can earn, easiest tier first, then by goal. */
function dfBadgesFor(string $role): array {
    $order = array_flip(array_keys(dfTiers()));
    $list = array_values(array_filter(dfBadgeCatalog(), static function ($d) use ($role) {
        return in_array($role, $d['roles'], true);
    }));
    usort($list, static function ($a, $b) use ($order) {
        return [$order[$a['tier']], $a['goal']] <=> [$order[$b['tier']], $b['goal']];
    });
    return $list;
}

function dfBadgeBySlug(string $slug): ?array {
    foreach (dfBadgeCatalog() as $d) if ($d['slug'] === $slug) return $d;
    return null;
}

/* ===================================================================
 * Storage
 * =================================================================== */

/** Creates the three tables if they are missing (once per session). */
function dfBadgeTablesReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_badge_tables'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_streaks (
            user_id INT PRIMARY KEY,
            current_streak INT NOT NULL DEFAULT 0,
            longest_streak INT NOT NULL DEFAULT 0,
            last_active_date DATE NULL,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_activity_days (
            user_id INT NOT NULL,
            active_date DATE NOT NULL,
            PRIMARY KEY (user_id, active_date),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_badges (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            badge_slug VARCHAR(50) NOT NULL,
            earned_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_user_badge (user_id, badge_slug),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $_SESSION['df_badge_tables'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

/* ===================================================================
 * Streaks
 * =================================================================== */

function dfManilaDate(string $modify = ''): string {
    $d = new DateTime('now', new DateTimeZone('Asia/Manila'));
    if ($modify !== '') $d->modify($modify);
    return $d->format('Y-m-d');
}

/**
 * Records today's visit for a signed-in user and returns their streak.
 * Cheap: after the first call each day it does nothing for the rest of the session.
 */
function dfTouchStreak(PDO $pdo, int $userId): array {
    $today = dfManilaDate();
    if (!dfBadgeTablesReady($pdo)) return dfEmptyStreak();

    try {
        if (($_SESSION['df_streak_day'] ?? '') !== $today) {
            $yesterday = dfManilaDate('-1 day');
            $st = $pdo->prepare('SELECT current_streak, longest_streak, last_active_date FROM user_streaks WHERE user_id = ? LIMIT 1');
            $st->execute([$userId]);
            $row = $st->fetch(PDO::FETCH_ASSOC);

            if (!$row) {
                $pdo->prepare('INSERT IGNORE INTO user_streaks (user_id, current_streak, longest_streak, last_active_date) VALUES (?, 1, 1, ?)')->execute([$userId, $today]);
            } elseif ($row['last_active_date'] !== $today) {
                $cur = ($row['last_active_date'] === $yesterday) ? ((int) $row['current_streak'] + 1) : 1;
                $long = max((int) $row['longest_streak'], $cur);
                $pdo->prepare('UPDATE user_streaks SET current_streak = ?, longest_streak = ?, last_active_date = ? WHERE user_id = ?')->execute([$cur, $long, $today, $userId]);
            }
            $pdo->prepare('INSERT IGNORE INTO user_activity_days (user_id, active_date) VALUES (?, ?)')->execute([$userId, $today]);
            $_SESSION['df_streak_day'] = $today;
        }
        return dfStreakInfo($pdo, $userId);
    } catch (Throwable $e) {
        return dfEmptyStreak();
    }
}

function dfEmptyStreak(): array {
    return ['ok' => false, 'current' => 0, 'longest' => 0, 'last' => null, 'week' => []];
}

/**
 * A user's streak. "current" counts only if they were active today or yesterday;
 * otherwise the streak is broken and shows 0. $withWeek adds the last 7 days for the dots.
 */
function dfStreakInfo(PDO $pdo, int $userId, bool $withWeek = false): array {
    if (!dfBadgeTablesReady($pdo)) return dfEmptyStreak();
    try {
        $st = $pdo->prepare('SELECT current_streak, longest_streak, last_active_date FROM user_streaks WHERE user_id = ? LIMIT 1');
        $st->execute([$userId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);

        $today = dfManilaDate();
        $yesterday = dfManilaDate('-1 day');
        $last = $row['last_active_date'] ?? null;
        $current = ($row && ($last === $today || $last === $yesterday)) ? (int) $row['current_streak'] : 0;

        $info = ['ok' => true, 'current' => $current, 'longest' => (int) ($row['longest_streak'] ?? 0), 'last' => $last, 'week' => []];

        if ($withWeek) {
            $from = dfManilaDate('-6 days');
            $ds = $pdo->prepare('SELECT active_date FROM user_activity_days WHERE user_id = ? AND active_date >= ?');
            $ds->execute([$userId, $from]);
            $active = array_flip($ds->fetchAll(PDO::FETCH_COLUMN));
            for ($i = 6; $i >= 0; $i--) {
                $d = dfManilaDate('-' . $i . ' days');
                $info['week'][] = ['date' => $d, 'label' => date('D', strtotime($d)), 'active' => isset($active[$d]), 'today' => $i === 0];
            }
        }
        return $info;
    } catch (Throwable $e) {
        return dfEmptyStreak();
    }
}

/** Flame + day count, links to the badges page. Hidden when streaks are unavailable. */
function dfStreakChip(array $streak): string {
    if (empty($streak['ok'])) return '';
    $n = (int) $streak['current'];
    $label = $n === 1 ? '1 day streak' : $n . ' day streak';
    return '<a class="df-streak' . ($n > 0 ? ' is-lit' : '') . '" href="badges.php" title="' . $label . '" aria-label="' . $label . '. View badges and streak.">'
        . dfIcon('flame', 16) . '<span>' . $n . '</span></a>';
}

/* ===================================================================
 * Metrics, evaluation, awards
 * =================================================================== */

/** The numbers badges are measured against. Likes/comments on your own work do not count. */
function dfBadgeMetrics(PDO $pdo, int $userId, string $role, int $earnedCount = 0): array {
    $m = ['streak_best' => 0, 'comments' => 0, 'likes_given' => 0, 'shares' => 0, 'projects' => 0,
          'likes_received' => 0, 'skills' => 0, 'profile' => 0, 'reports' => 0, 'badges' => $earnedCount];
    try {
        $q = static function (string $sql, array $args) use ($pdo): int {
            $st = $pdo->prepare($sql);
            $st->execute($args);
            return (int) $st->fetchColumn();
        };

        $m['streak_best'] = $q('SELECT longest_streak FROM user_streaks WHERE user_id = ?', [$userId]);

        // Activity on OTHER people's projects (a project belongs to students.user_id)
        $m['comments'] = $q("SELECT COUNT(*) FROM project_comments c INNER JOIN projects p ON p.id = c.project_id INNER JOIN students s ON s.id = p.student_id
                             WHERE c.user_id = ? AND c.status = 'visible' AND s.user_id <> ?", [$userId, $userId]);
        $m['likes_given'] = $q('SELECT COUNT(*) FROM project_likes l INNER JOIN projects p ON p.id = l.project_id INNER JOIN students s ON s.id = p.student_id
                                WHERE l.user_id = ? AND s.user_id <> ?', [$userId, $userId]);
        $m['shares'] = $q('SELECT COUNT(DISTINCT project_id) FROM project_shares WHERE user_id = ?', [$userId]);

        if ($role === 'student') {
            $st = $pdo->prepare('SELECT s.id, s.bio, u.avatar_url FROM students s INNER JOIN users u ON u.id = s.user_id WHERE s.user_id = ? LIMIT 1');
            $st->execute([$userId]);
            $s = $st->fetch(PDO::FETCH_ASSOC);
            if ($s) {
                $sid = (int) $s['id'];
                $m['projects'] = $q("SELECT COUNT(*) FROM projects WHERE student_id = ? AND status = 'approved'", [$sid]);
                $m['likes_received'] = $q("SELECT COUNT(*) FROM project_likes l INNER JOIN projects p ON p.id = l.project_id
                                           WHERE p.student_id = ? AND p.status = 'approved' AND l.user_id <> ?", [$sid, $userId]);
                $m['skills'] = $q('SELECT COUNT(*) FROM skills WHERE student_id = ?', [$sid]);
                $avatar = trim((string) ($s['avatar_url'] ?? ''));
                $hasPhoto = $avatar !== '' && stripos($avatar, 'placehold.co') === false;
                $m['profile'] = (trim((string) ($s['bio'] ?? '')) !== '' && $hasPhoto) ? 1 : 0;
            }
        } elseif ($role === 'faculty') {
            $m['reports'] = $q("SELECT COUNT(*) FROM project_reports WHERE handled_by = ? AND status IN ('resolved', 'dismissed')", [$userId]);
        }
    } catch (Throwable $e) {
        // leave whatever was counted so far
    }
    return $m;
}

/** slug => earned_at for one user. */
function dfEarnedMap(PDO $pdo, int $userId): array {
    if (!dfBadgeTablesReady($pdo)) return [];
    try {
        $st = $pdo->prepare('SELECT badge_slug, earned_at FROM user_badges WHERE user_id = ?');
        $st->execute([$userId]);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[$r['badge_slug']] = $r['earned_at'];
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

/** Earned badge definitions (with earned_at), hardest tier first, newest first within a tier. */
function dfEarnedBadges(PDO $pdo, int $userId): array {
    $order = array_flip(array_reverse(array_keys(dfTiers())));
    $out = [];
    foreach (dfEarnedMap($pdo, $userId) as $slug => $at) {
        $d = dfBadgeBySlug($slug);
        if ($d) { $d['earned_at'] = $at; $out[] = $d; }
    }
    usort($out, static function ($a, $b) use ($order) {
        return [$order[$a['tier']], $b['earned_at']] <=> [$order[$b['tier']], $a['earned_at']];
    });
    return $out;
}

/**
 * Awards every badge the user now qualifies for. Returns the newly earned definitions.
 * Runs twice so "Collector" sees badges that were awarded in the first pass.
 */
function dfEvaluateBadges(PDO $pdo, int $userId, string $role): array {
    if (!in_array($role, ['student', 'faculty'], true) || !dfBadgeTablesReady($pdo)) return [];
    $newly = [];
    try {
        $earned = dfEarnedMap($pdo, $userId);
        for ($pass = 0; $pass < 2; $pass++) {
            $others = count(array_diff_key($earned, ['collector' => 1]));
            $metrics = dfBadgeMetrics($pdo, $userId, $role, $others);
            $added = false;
            foreach (dfBadgesFor($role) as $d) {
                if (isset($earned[$d['slug']])) continue;
                if (($metrics[$d['metric']] ?? 0) < $d['goal']) continue;

                $ins = $pdo->prepare('INSERT IGNORE INTO user_badges (user_id, badge_slug) VALUES (?, ?)');
                $ins->execute([$userId, $d['slug']]);
                $earned[$d['slug']] = date('Y-m-d H:i:s');
                if ($ins->rowCount() === 1) {
                    $newly[] = $d;
                    $tier = dfTiers()[$d['tier']]['label'];
                    $pdo->prepare('INSERT INTO notifications (user_id, notification_type, title, message) VALUES (?, ?, ?, ?)')
                        ->execute([$userId, 'badge_earned', 'New badge: ' . $d['name'], $tier . ' badge. ' . $d['desc']]);
                }
                $added = true;
            }
            if (!$added) break;
        }
    } catch (Throwable $e) {
        // never break a page over a badge
    }
    return $newly;
}

/**
 * Throttled check used by the navigation on every page (at most once every 45 seconds).
 * New badges are queued in the session so the next page can congratulate the user.
 */
function dfRunBadgeCheck(PDO $pdo, int $userId, string $role, bool $force = false): void {
    if (!$force && (time() - (int) ($_SESSION['df_badge_at'] ?? 0)) < 45) return;
    $_SESSION['df_badge_at'] = time();
    $newly = dfEvaluateBadges($pdo, $userId, $role);
    if ($newly) {
        $queue = $_SESSION['df_new_badges'] ?? [];
        foreach ($newly as $d) $queue[] = $d['slug'];
        $_SESSION['df_new_badges'] = array_values(array_unique($queue));
    }
}

/** Badges earned since the last page, as definitions. Clears the queue. */
function dfPopNewBadges(): array {
    $slugs = $_SESSION['df_new_badges'] ?? [];
    unset($_SESSION['df_new_badges']);
    $out = [];
    foreach ($slugs as $slug) { $d = dfBadgeBySlug((string) $slug); if ($d) $out[] = $d; }
    return $out;
}

/* ===================================================================
 * Rendering
 * =================================================================== */

/** The round medal. Locked badges are drawn grey. $size = '' | 'sm' | 'lg'. */
function dfBadgeMedal(array $d, bool $earned = true, string $size = ''): string {
    $tier = dfTiers()[$d['tier']]['label'] ?? '';
    return '<span class="bdg bdg-' . dfEsc($d['tier']) . ($size !== '' ? ' bdg-' . dfEsc($size) : '') . ($earned ? '' : ' is-locked') . '" role="img" aria-label="'
        . dfEsc($d['name'] . ', ' . $tier . ($earned ? '' : ', locked')) . '">'
        . dfIcon($d['icon'], 22) . '</span>';
}

/** A row of small medals for the hover card / profile: hardest first, "+N" for the rest. */
function dfBadgeStrip(array $earned, int $max = 5): string {
    if (!$earned) return '';
    $shown = array_slice($earned, 0, $max);
    $html = '<ul class="bdg-strip" aria-label="Badges">';
    foreach ($shown as $d) {
        $tier = dfTiers()[$d['tier']]['label'];
        $html .= '<li title="' . dfEsc($d['name'] . ' (' . $tier . ') - ' . $d['desc']) . '">' . dfBadgeMedal($d, true, 'sm') . '</li>';
    }
    $rest = count($earned) - count($shown);
    if ($rest > 0) $html .= '<li class="bdg-more">+' . $rest . '</li>';
    return $html . '</ul>';
}

/* ===================================================================
 * Display preferences (which badges a member chooses to show)
 *
 *  Profile  "auto"   -> hardest badges first (the original behaviour)
 *           "custom" -> only the badges the member ticked (max DF_BADGE_PROFILE_MAX)
 *  Comments one badge shown next to the member's name, or none (default)
 *
 * Preferences only ever HIDE or CHOOSE among badges the member has really earned.
 * Every read re-checks user_badges, so if a badge is ever revoked by moderation
 * it disappears from profiles and comments automatically.
 * =================================================================== */

const DF_BADGE_PROFILE_MAX = 6;

/** Creates user_badge_prefs if it is missing (once per session). */
function dfBadgePrefsReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_badge_prefs_table'])) return $ready = true;
    if (!dfBadgeTablesReady($pdo)) return false;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS user_badge_prefs (
            user_id INT PRIMARY KEY,
            profile_custom TINYINT(1) NOT NULL DEFAULT 0,
            profile_slugs VARCHAR(400) NOT NULL DEFAULT '',
            comment_slug VARCHAR(50) NULL,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
        )");
        $_SESSION['df_badge_prefs_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

function dfDefaultBadgePrefs(): array {
    return ['custom' => false, 'profile' => [], 'comment' => null];
}

/** A member's saved preferences (defaults when they never changed anything). */
function dfBadgePrefs(PDO $pdo, int $userId): array {
    $prefs = dfDefaultBadgePrefs();
    if (!dfBadgePrefsReady($pdo)) return $prefs;
    try {
        $st = $pdo->prepare('SELECT profile_custom, profile_slugs, comment_slug FROM user_badge_prefs WHERE user_id = ? LIMIT 1');
        $st->execute([$userId]);
        $row = $st->fetch(PDO::FETCH_ASSOC);
        if ($row) {
            $prefs['custom'] = (int) $row['profile_custom'] === 1;
            $prefs['profile'] = array_values(array_filter(explode(',', (string) $row['profile_slugs']), 'strlen'));
            $prefs['comment'] = ($row['comment_slug'] ?? '') !== '' ? (string) $row['comment_slug'] : null;
        }
    } catch (Throwable $e) {
        // fall back to defaults
    }
    return $prefs;
}

/**
 * Validates and stores preferences. Only badges the member has earned (and that exist
 * in the catalog for their role) are kept. Returns the cleaned prefs, or null on failure.
 */
function dfSaveBadgePrefs(PDO $pdo, int $userId, string $role, bool $custom, array $profileSlugs, ?string $commentSlug): ?array {
    if (!dfBadgePrefsReady($pdo)) return null;

    $earned = dfEarnedMap($pdo, $userId);
    $allowed = [];
    foreach (dfBadgesFor($role) as $d) if (isset($earned[$d['slug']])) $allowed[$d['slug']] = true;

    $clean = [];
    foreach ($profileSlugs as $slug) {
        $slug = (string) $slug;
        if (isset($allowed[$slug]) && !in_array($slug, $clean, true)) $clean[] = $slug;
    }
    $clean = array_slice($clean, 0, DF_BADGE_PROFILE_MAX);

    $comment = ($commentSlug !== null && isset($allowed[$commentSlug])) ? $commentSlug : null;

    try {
        $pdo->prepare('INSERT INTO user_badge_prefs (user_id, profile_custom, profile_slugs, comment_slug) VALUES (?, ?, ?, ?)
                       ON DUPLICATE KEY UPDATE profile_custom = VALUES(profile_custom), profile_slugs = VALUES(profile_slugs), comment_slug = VALUES(comment_slug)')
            ->execute([$userId, $custom ? 1 : 0, implode(',', $clean), $comment]);
        return ['custom' => $custom, 'profile' => $clean, 'comment' => $comment];
    } catch (Throwable $e) {
        return null;
    }
}

/**
 * The badges to show on a member's profile / hover card.
 * $earnedDefs comes from dfEarnedBadges() (hardest first); order is kept.
 */
function dfProfileBadges(array $earnedDefs, array $prefs): array {
    if (empty($prefs['custom'])) return $earnedDefs;
    $pick = array_flip($prefs['profile']);
    return array_values(array_filter($earnedDefs, static function ($d) use ($pick) {
        return isset($pick[$d['slug']]);
    }));
}

/**
 * Adds 'comment_badge' (a slug, or null) to a list of comment rows in ONE query.
 * Only badges still present in user_badges are returned. Never throws.
 */
function dfAttachCommentBadges(PDO $pdo, array &$rows): void {
    $ids = [];
    foreach ($rows as $r) $ids[(int) $r['user_id']] = true;
    if (!$ids || !dfBadgePrefsReady($pdo)) return;
    try {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $pdo->prepare("SELECT bp.user_id, bp.comment_slug
                             FROM user_badge_prefs bp
                             INNER JOIN user_badges ub ON ub.user_id = bp.user_id AND ub.badge_slug = bp.comment_slug
                             WHERE bp.comment_slug IS NOT NULL AND bp.user_id IN ($in)");
        $st->execute(array_keys($ids));
        $map = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $map[(int) $r['user_id']] = (string) $r['comment_slug'];
        foreach ($rows as &$r) $r['comment_badge'] = $map[(int) $r['user_id']] ?? null;
        unset($r);
    } catch (Throwable $e) {
        // comments still render, just without badges
    }
}

/** The tiny medal shown beside a name in the comment section. */
function dfCommentBadgeChip(string $slug): string {
    $d = dfBadgeBySlug($slug);
    if (!$d) return '';
    $tier = dfTiers()[$d['tier']]['label'] ?? '';
    return '<span class="df-comment-bdg" title="' . dfEsc($d['name'] . ' (' . $tier . ')') . '">' . dfBadgeMedal($d, true, 'xs') . '</span>';
}
