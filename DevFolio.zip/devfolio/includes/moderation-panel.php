<?php
/**
 * Moderator panel: open project reports, recent decisions, active bans.
 * Used by faculty/reports.php and the Moderation tab of admin/dashboard.php (both Tailwind pages).
 * Expects $pdo. Optional $modEndpoint (default '../includes/moderation-api.php').
 */
require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';

$modEndpoint = $modEndpoint ?? '../includes/moderation-api.php';
$modOpen = dfFetchReports($pdo, 'open');
$modHandled = dfFetchReports($pdo, 'handled');
$modBans = dfActiveBans($pdo);

$modFiles = [];
$modPids = array_values(array_unique(array_filter(array_map(function ($r) { return (int) ($r['project_id'] ?? 0); }, $modOpen))));
if ($modPids) $modFiles = dfFilesFor($pdo, $modPids);

$modActionLabels = ['dismiss' => 'Dismissed', 'remove' => 'Project removed', 'warn' => 'Warning sent', 'ban' => 'User banned'];
$modPerson = function ($first, $last) { $n = trim((string) $first . ' ' . (string) $last); return $n !== '' ? $n : 'Unknown user'; };
?>
<div id="modPanel" data-endpoint="<?php echo dfEsc($modEndpoint); ?>">

    <div class="flex flex-wrap items-center justify-between gap-3 mb-5">
        <h3 class="text-2xl font-black text-slate-900">Project Reports</h3>
        <span class="text-sm font-bold bg-red-100 text-red-800 px-3 py-1.5 rounded-full"><?php echo count($modOpen); ?> open</span>
    </div>

    <?php if (empty($modOpen)): ?>
        <div class="rounded-2xl border border-dashed border-slate-300 bg-slate-50 p-10 text-center text-slate-500">
            No open reports. Nothing needs your attention right now.
        </div>
    <?php else: ?>
        <div class="space-y-4">
        <?php foreach ($modOpen as $r):
            $tags = dfTags($r['tech_stack'] ?? null);
            $photo = dfAssetUrl($r['banner_image_url'] ?? '');
            if ($photo !== '' && stripos($photo, 'placehold.co') !== false) $photo = '';
            $links = [];
            foreach ([$r['demo_link'] ?? '', $r['repository_link'] ?? ''] as $l) { $l = dfSafeLink($l); if ($l !== '' && !in_array($l, $links, true)) $links[] = $l; }
            $files = $modFiles[(int) ($r['project_id'] ?? 0)] ?? [];
        ?>
            <article class="border border-slate-200 rounded-2xl p-5 bg-white" id="report-<?php echo (int) $r['id']; ?>">
                <div class="flex flex-wrap items-start justify-between gap-3">
                    <div class="min-w-0">
                        <span class="inline-flex items-center gap-1.5 text-xs font-bold bg-red-100 text-red-800 px-2.5 py-1 rounded-full"><?php echo dfIcon('flag', 14); ?> <?php echo dfEsc($r['reason']); ?></span>
                        <h4 class="text-lg font-black text-slate-900 mt-2 break-words"><?php echo dfEsc($r['project_title']); ?></h4>
                        <p class="text-sm text-slate-600 mt-1">
                            Owner: <b><?php echo dfEsc($modPerson($r['owner_first'], $r['owner_last'])); ?></b><?php if (!empty($r['owner_email'])): ?> (<?php echo dfEsc($r['owner_email']); ?>)<?php endif; ?>
                            &middot; Reported by <?php echo dfEsc($modPerson($r['reporter_first'], $r['reporter_last'])); ?>
                            &middot; <?php echo dfEsc(dfTimeAgo($r['created_at'])); ?>
                        </p>
                        <p class="text-xs text-slate-500 mt-0.5"><?php echo (int) $r['owner_reports_total']; ?> report(s) on this user in total &middot; <?php echo (int) $r['owner_warnings']; ?> earlier warning(s)</p>
                    </div>
                    <button type="button" class="mod-act bg-red-600 hover:bg-red-700 text-white px-4 py-2.5 rounded-lg text-sm font-bold transition" data-report="<?php echo (int) $r['id']; ?>" data-title="<?php echo dfEsc($r['project_title']); ?>">Take action</button>
                </div>

                <?php if (!empty($r['details'])): ?>
                    <blockquote class="mt-3 border-l-4 border-red-300 bg-red-50 text-sm text-slate-700 px-4 py-2 rounded-r-lg break-words whitespace-pre-line"><b class="text-red-800">Reporter's note:</b> <?php echo dfEsc($r['details']); ?></blockquote>
                <?php endif; ?>

                <details class="mt-3 group">
                    <summary class="cursor-pointer text-sm font-bold text-blue-700 hover:underline select-none">View reported project</summary>
                    <div class="mt-3 rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                        <?php if (empty($r['project_id'])): ?>
                            <p>This project no longer exists (it was deleted by its owner).</p>
                        <?php else: ?>
                            <p class="mb-2"><span class="font-bold">Status:</span> <?php echo dfEsc($r['project_status'] === 'approved' ? 'Published' : ucfirst((string) $r['project_status'])); ?><?php if (!empty($r['category'])): ?> &middot; <span class="font-bold">Category:</span> <?php echo dfEsc($r['category']); ?><?php endif; ?></p>
                            <?php if ($photo !== ''): ?><img src="<?php echo dfEsc($photo); ?>" alt="Project photo" class="max-h-56 rounded-lg border border-slate-200 mb-3" onerror="this.remove()"><?php endif; ?>
                            <p class="whitespace-pre-line break-words"><?php echo dfEsc($r['description'] ?? ''); ?></p>
                            <?php if ($tags): ?><p class="mt-2 text-xs text-slate-500"><b>Technologies:</b> <?php echo dfEsc(implode(', ', $tags)); ?></p><?php endif; ?>
                            <?php if ($links || $files): ?>
                                <ul class="mt-3 space-y-1">
                                    <?php foreach ($links as $l): ?><li><a class="text-blue-700 hover:underline break-all" href="<?php echo dfEsc($l); ?>" target="_blank" rel="noopener noreferrer"><?php echo dfEsc($l); ?></a></li><?php endforeach; ?>
                                    <?php foreach ($files as $f): ?><li><a class="text-blue-700 hover:underline" href="<?php echo dfEsc(dfAssetUrl($f['file_path'])); ?>" download="<?php echo dfEsc($f['file_name']); ?>"><?php echo dfEsc($f['file_name']); ?></a> <span class="text-xs text-slate-500">(<?php echo dfEsc(dfFormatSize((int) $f['file_size'])); ?>)</span></li><?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </details>
            </article>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($modBans)): ?>
        <h4 class="text-lg font-black text-slate-900 mt-10 mb-3">Active bans</h4>
        <div class="space-y-2">
            <?php foreach ($modBans as $b): ?>
                <div class="flex flex-wrap items-center justify-between gap-3 border border-slate-200 rounded-xl px-4 py-3 bg-white">
                    <div class="min-w-0">
                        <div class="font-bold text-slate-900"><?php echo dfEsc($modPerson($b['first_name'], $b['last_name'])); ?> <span class="font-normal text-slate-500 text-sm"><?php echo dfEsc($b['email']); ?></span></div>
                        <div class="text-xs text-slate-600"><?php echo !empty($b['permanent']) ? 'Permanent ban' : 'Until ' . dfEsc(date('M j, Y g:i A', strtotime((string) $b['expires_at']))); ?><?php if (!empty($b['reason'])): ?> &middot; <?php echo dfEsc(mb_strimwidth((string) $b['reason'], 0, 120, '…')); ?><?php endif; ?></div>
                    </div>
                    <button type="button" class="mod-lift bg-slate-200 hover:bg-slate-300 text-slate-800 px-3 py-2 rounded-lg text-xs font-bold transition" data-sanction="<?php echo (int) $b['id']; ?>">Lift ban</button>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($modHandled)): ?>
        <h4 class="text-lg font-black text-slate-900 mt-10 mb-3">Recently handled</h4>
        <div class="space-y-2">
            <?php foreach ($modHandled as $h): ?>
                <div class="border border-slate-200 rounded-xl px-4 py-3 bg-white text-sm">
                    <div class="flex flex-wrap items-center justify-between gap-2">
                        <span class="font-bold text-slate-900 break-words"><?php echo dfEsc($h['project_title']); ?></span>
                        <span class="text-xs font-bold px-2 py-1 rounded-full <?php echo $h['status'] === 'dismissed' ? 'bg-slate-100 text-slate-700' : 'bg-amber-100 text-amber-800'; ?>"><?php echo dfEsc($modActionLabels[$h['action_taken']] ?? ucfirst((string) $h['status'])); ?></span>
                    </div>
                    <p class="text-xs text-slate-500 mt-0.5"><?php echo dfEsc($h['reason']); ?> &middot; by <?php echo dfEsc($modPerson($h['handler_first'], $h['handler_last'])); ?> &middot; <?php echo dfEsc(dfTimeAgo($h['handled_at'])); ?></p>
                    <?php if (!empty($h['resolution_note'])): ?><p class="text-xs text-slate-600 mt-1 break-words">Message: <?php echo dfEsc(mb_strimwidth((string) $h['resolution_note'], 0, 160, '…')); ?></p><?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <!-- Decision dialog -->
    <div id="modDialog" class="hidden fixed inset-0 z-50 bg-slate-900/70 items-start sm:items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-2xl w-full max-w-lg p-6 shadow-2xl my-auto" role="dialog" aria-modal="true" aria-labelledby="modDialogTitle">
            <div class="flex justify-between items-start gap-3 mb-4">
                <div class="min-w-0">
                    <h3 id="modDialogTitle" class="text-xl font-black text-slate-900">Take action</h3>
                    <p id="modDialogProject" class="text-sm text-slate-500 break-words"></p>
                </div>
                <button type="button" id="modClose" class="text-slate-500 hover:text-slate-800 text-2xl leading-none" aria-label="Close">&times;</button>
            </div>
            <form id="modForm" class="space-y-3">
                <input type="hidden" name="action" value="resolve_report">
                <input type="hidden" name="report_id" id="modReportId" value="">

                <fieldset class="space-y-2">
                    <legend class="text-sm font-bold text-slate-800 mb-1">What should happen?</legend>
                    <label class="flex items-start gap-3 border border-slate-200 rounded-xl p-3 cursor-pointer hover:bg-slate-50"><input type="radio" name="decision" value="dismiss" class="mt-1"><span><b class="text-slate-900">Dismiss report</b><br><span class="text-xs text-slate-500">No rule was broken. Nothing happens to the project or user.</span></span></label>
                    <label class="flex items-start gap-3 border border-slate-200 rounded-xl p-3 cursor-pointer hover:bg-slate-50"><input type="radio" name="decision" value="remove" class="mt-1"><span><b class="text-slate-900">Remove the project</b><br><span class="text-xs text-slate-500">Hidden from everyone. The owner is told why.</span></span></label>
                    <label class="flex items-start gap-3 border border-slate-200 rounded-xl p-3 cursor-pointer hover:bg-slate-50"><input type="radio" name="decision" value="warn" class="mt-1"><span><b class="text-slate-900">Give the user a warning</b><br><span class="text-xs text-slate-500">The project stays. The user gets your message.</span></span></label>
                    <label class="flex items-start gap-3 border border-slate-200 rounded-xl p-3 cursor-pointer hover:bg-slate-50"><input type="radio" name="decision" value="ban" class="mt-1"><span><b class="text-slate-900">Ban the user</b><br><span class="text-xs text-slate-500">They are signed out and cannot log in for the time you choose.</span></span></label>
                </fieldset>

                <div id="modBanOptions" class="hidden rounded-xl bg-red-50 border border-red-200 p-3 space-y-2">
                    <label for="modDuration" class="block text-sm font-bold text-red-900">Ban length</label>
                    <select id="modDuration" name="ban_duration" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm bg-white">
                        <?php foreach (DF_BAN_DURATIONS as $d => $label): ?><option value="<?php echo (int) $d; ?>"><?php echo dfEsc($label); ?></option><?php endforeach; ?>
                        <option value="permanent">Permanent (until lifted by faculty or admin)</option>
                    </select>
                    <label class="flex items-center gap-2 text-sm text-red-900"><input type="checkbox" name="also_remove" value="1"> Also remove the reported project</label>
                </div>

                <div>
                    <label for="modReason" id="modReasonLabel" class="block text-sm font-bold text-slate-800 mb-1">Message to the user</label>
                    <textarea id="modReason" name="reason" rows="4" maxlength="1000" class="w-full px-3 py-2 rounded-lg border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-red-500" placeholder="Explain why. The project owner will see this message."></textarea>
                </div>

                <div class="flex gap-3 pt-1">
                    <button type="submit" id="modSubmit" class="flex-1 bg-red-600 hover:bg-red-700 text-white font-bold py-2.5 rounded-lg transition">Submit decision</button>
                    <button type="button" id="modCancel" class="flex-1 bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold py-2.5 rounded-lg transition">Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    var panel = document.getElementById('modPanel');
    var endpoint = panel.dataset.endpoint;
    var dialog = document.getElementById('modDialog');
    var form = document.getElementById('modForm');
    var banBox = document.getElementById('modBanOptions');
    var reason = document.getElementById('modReason');
    var reasonLabel = document.getElementById('modReasonLabel');
    var lastFocus = null;

    function toast(msg, ok) {
        var el = document.createElement('div');
        el.setAttribute('role', 'status');
        el.className = 'fixed top-5 right-5 z-[60] max-w-xs text-white text-sm font-semibold px-4 py-3 rounded-xl shadow-xl ' + (ok ? 'bg-emerald-600' : 'bg-red-600');
        el.textContent = msg;
        document.body.appendChild(el);
        setTimeout(function () { el.remove(); }, 4000);
    }

    function open(id, title) {
        lastFocus = document.activeElement;
        form.reset();
        document.getElementById('modReportId').value = id;
        document.getElementById('modDialogProject').textContent = title;
        sync();
        dialog.classList.remove('hidden'); dialog.classList.add('flex');
        document.body.style.overflow = 'hidden';
        form.querySelector('input[name=decision]').focus();
    }
    function close() {
        dialog.classList.add('hidden'); dialog.classList.remove('flex');
        document.body.style.overflow = '';
        if (lastFocus) lastFocus.focus();
    }
    function sync() {
        var d = (form.querySelector('input[name=decision]:checked') || {}).value;
        banBox.classList.toggle('hidden', d !== 'ban');
        reason.required = (d === 'remove' || d === 'warn' || d === 'ban');
        reasonLabel.textContent = d === 'dismiss' ? 'Note (optional, only visible to moderators)' : 'Message to the user (required)';
    }
    form.addEventListener('change', sync);

    panel.addEventListener('click', function (e) {
        var act = e.target.closest('.mod-act');
        if (act) { open(act.dataset.report, act.dataset.title); return; }
        var lift = e.target.closest('.mod-lift');
        if (lift) {
            if (!confirm('Lift this ban? The user will be able to sign in again.')) return;
            send(new URLSearchParams({ action: 'lift_ban', sanction_id: lift.dataset.sanction }));
        }
    });
    document.getElementById('modClose').addEventListener('click', close);
    document.getElementById('modCancel').addEventListener('click', close);
    dialog.addEventListener('mousedown', function (e) { if (e.target === dialog) close(); });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !dialog.classList.contains('hidden')) close(); });

    function send(body) {
        return fetch(endpoint, { method: 'POST', body: body })
            .then(function (r) { return r.json(); })
            .then(function (d) {
                toast(d.message || (d.success ? 'Done.' : 'Something went wrong.'), !!d.success);
                if (d.success) setTimeout(function () { window.location.reload(); }, 900);
                return d;
            })
            .catch(function () { toast('Could not reach the server.', false); });
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        if (!form.querySelector('input[name=decision]:checked')) { toast('Choose what should happen first.', false); return; }
        var btn = document.getElementById('modSubmit');
        btn.disabled = true;
        send(new FormData(form)).then(function (d) { if (!d || !d.success) btn.disabled = false; });
    });
})();
</script>
