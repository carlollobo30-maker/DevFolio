<?php
/**
 * Faculty right sidebar (Quick Actions, Summary, Projects by program).
 * Page links (Home, Project Reports, Student Directory) now live in the top nav.
 * Include inside .df-layout.df-layout-fac, before the main column.
 * Expects: $pdo, $navUser and $openCount (set by faculty-nav.php), optional $facActive.
 * Every figure comes from the database.
 */
$facActive = $facActive ?? 'discover';

$sbFirst = trim((string) ($navUser['first_name'] ?? '')) ?: 'there';

$sbStudents  = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$sbShowcased = (int) $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'approved'")->fetchColumn();
$sbRemoved   = (int) $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'removed'")->fetchColumn();

$sbPrograms = $pdo->query("SELECT COALESCE(NULLIF(TRIM(program), ''), 'Other') AS program, COUNT(*) AS cnt FROM projects WHERE status = 'approved' GROUP BY 1 ORDER BY cnt DESC, program ASC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);
$sbProgramTotal = 0;
foreach ($sbPrograms as $row) { $sbProgramTotal += (int) $row['cnt']; }
?>
<aside class="df-side df-side-right" aria-label="Faculty tools">
    <section class="df-panel" aria-labelledby="facWelcome">
        <div class="df-welcome-head" style="margin-bottom:0">
            <span class="df-welcome-av"><span><?php echo htmlspecialchars($navInitials); ?></span><?php if ($navAvatar !== ''): ?><img src="<?php echo htmlspecialchars($navAvatar); ?>" alt="" onerror="this.remove()"><?php endif; ?></span>
            <div>
                <h2 id="facWelcome">Welcome back, <?php echo htmlspecialchars($sbFirst); ?></h2>
                <p>Faculty &middot; CCDI Sorsogon</p>
            </div>
        </div>
    </section>

    <section class="df-panel" aria-labelledby="facActionsTitle">
        <h3 id="facActionsTitle" class="fac-h">Quick actions</h3>
        <div class="fac-actions">
            <a class="df-btn df-btn-primary" href="reports.php"><?php echo dfIcon('flag', 16); ?> Review Project Reports</a>
            <a class="df-btn df-btn-ghost" href="student-list.php"><?php echo dfIcon('users', 16); ?> View All Students</a>
            <button type="button" class="df-btn df-btn-ghost"><?php echo dfIcon('download', 16); ?> Export Accreditation Report</button>
        </div>
    </section>

    <section class="df-panel" aria-labelledby="facSummaryTitle">
        <h3 id="facSummaryTitle" class="fac-h">Summary</h3>
        <dl class="fac-stats">
            <div class="fac-stat"><dt>Students</dt><dd><?php echo $sbStudents; ?></dd></div>
            <div class="fac-stat"><dt>Showcased</dt><dd><?php echo $sbShowcased; ?></dd></div>
            <div class="fac-stat<?php echo $openCount > 0 ? ' is-alert' : ''; ?>"><dt>Open reports</dt><dd><?php echo (int) $openCount; ?></dd></div>
            <div class="fac-stat"><dt>Removed</dt><dd><?php echo $sbRemoved; ?></dd></div>
        </dl>
    </section>

    <?php if ($sbProgramTotal > 0): ?>
    <section class="df-panel" aria-labelledby="facProgTitle">
        <h3 id="facProgTitle" class="fac-h">Projects by program</h3>
        <ul class="fac-prog">
            <?php foreach ($sbPrograms as $row): $pct = (int) round(((int) $row['cnt']) / $sbProgramTotal * 100); ?>
                <li>
                    <div class="fac-prog-row"><span><?php echo htmlspecialchars((string) $row['program']); ?></span><b><?php echo (int) $row['cnt']; ?> &middot; <?php echo $pct; ?>%</b></div>
                    <div class="df-bar" role="img" aria-label="<?php echo htmlspecialchars($row['program'] . ': ' . $pct . ' percent'); ?>"><i style="width: <?php echo $pct; ?>%"></i></div>
                </li>
            <?php endforeach; ?>
        </ul>
    </section>
    <?php endif; ?>
</aside>
