<?php
/**
 * Project collaborators ("tag people who worked on it").
 *
 * When a student posts a team project they can tag classmates and say what each one did
 * (UI/UX designer, Back-end developer, ...). Tagged students:
 *   - are shown on the feed post ("with Maria Santos and 2 others"),
 *   - are listed with their role in the Team card of the project page (each opens their profile),
 *   - have their work links (LinkedIn, GitHub, portfolio...) shown on the project page, at the top right
 *     under the creator's links and next to their name in the Team card,
 *   - get a notification, and the project appears on their own profile as "Collaborated on a project".
 * A tagged student can remove their own tag; the owner can change the team at any time.
 *
 * Stored in project_team_members (project_id, student_id -> students.id, role), which is part of
 * database/schema.sql. The table is created automatically when it is missing.
 */

require_once __DIR__ . '/ui-helpers.php';
require_once __DIR__ . '/project-helpers.php';

const DF_COLLAB_MAX = 10;        // people per project
const DF_COLLAB_ROLE_MAX = 50;   // characters (column is VARCHAR(50))

/** Roles offered as suggestions (anything else can be typed). */
function dfCollabRoleSuggestions(): array {
    return [
        'Developer', 'Front-end developer', 'Back-end developer', 'Full-stack developer', 'Mobile developer',
        'UI/UX designer', 'Graphic designer', 'Animator', '3D artist', 'Video editor', 'Sound designer',
        'Database designer', 'Tester / QA', 'Documentation', 'Researcher', 'Project manager',
    ];
}

/** Creates project_team_members if it is missing (once per session). */
function dfCollabReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_collab_table'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS project_team_members (
            id INT PRIMARY KEY AUTO_INCREMENT,
            project_id INT NOT NULL,
            student_id INT NOT NULL,
            role VARCHAR(50),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            UNIQUE KEY (project_id, student_id)
        )");
        $_SESSION['df_collab_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

/** Cleans a typed role: one line, no control characters, max 50 characters. */
function dfCleanCollabRole($raw): string {
    $role = (string) preg_replace('/[\x00-\x1F\x7F]+/u', ' ', (string) $raw);
    $role = trim((string) preg_replace('/\s+/u', ' ', $role));
    return mb_substr($role, 0, DF_COLLAB_ROLE_MAX);
}

/**
 * Students whose name (or student number) matches $q, for the "Tag collaborators" search.
 * Never returns the person searching or the ids in $excludeUserIds.
 *
 * @return array[] id (user id), name, program, initials, avatar
 */
function dfSearchStudents(PDO $pdo, string $q, int $meId, array $excludeUserIds = [], int $limit = 8): array {
    $q = trim((string) preg_replace('/\s+/u', ' ', $q));
    if (mb_strlen($q) < 2) return [];
    $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], mb_substr($q, 0, 60)) . '%';
    $exclude = array_values(array_unique(array_filter(array_map('intval', $excludeUserIds))));
    $exclude[] = $meId;
    $in = implode(',', array_fill(0, count($exclude), '?'));
    $st = $pdo->prepare(
        "SELECT u.id, u.first_name, u.last_name, u.avatar_url, s.program, s.year_level
         FROM users u INNER JOIN students s ON s.user_id = u.id
         WHERE u.role = 'student' AND u.id NOT IN ($in)
           AND (CONCAT(u.first_name, ' ', u.last_name) LIKE ? OR u.last_name LIKE ? OR s.student_id LIKE ?)
         ORDER BY (CONCAT(u.first_name, ' ', u.last_name) LIKE ?) DESC, u.first_name, u.last_name
         LIMIT " . max(1, min(20, $limit))
    );
    $prefix = str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], mb_substr($q, 0, 60)) . '%';
    $st->execute(array_merge($exclude, [$like, $like, $like, $prefix]));
    $out = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[] = dfCollabPersonJson($r);
    return $out;
}

/** The fields the picker needs for one person. */
function dfCollabPersonJson(array $r): array {
    $sub = trim(implode(' · ', array_filter([(string) ($r['program'] ?? ''), (string) ($r['year_level'] ?? '')], 'strlen')));
    return [
        'id'       => (int) ($r['id'] ?? $r['user_id'] ?? 0),
        'name'     => dfOwnerName($r),
        'sub'      => $sub,
        'initials' => dfInitials($r['first_name'] ?? '', $r['last_name'] ?? ''),
        'avatar'   => dfAssetUrl($r['avatar_url'] ?? ''),
        'role'     => (string) ($r['role'] ?? ''),
    ];
}

/**
 * Reads the "collaborators" field of a form: JSON [{"id": userId, "role": "..."}].
 * Only existing students can be tagged; the owner cannot tag themselves.
 *
 * @return array{0:?string,1:array} [error message or null, list of ['user_id','student_id','role','first_name','last_name']]
 */
function dfReadCollaborators(PDO $pdo, array $post, int $ownerUserId): array {
    $raw = trim((string) ($post['collaborators'] ?? ''));
    if ($raw === '' || $raw === '[]') return [null, []];
    $data = json_decode($raw, true);
    if (!is_array($data)) return ['The tagged collaborators could not be read. Please tag them again.', []];

    $wanted = [];   // user id => role
    foreach ($data as $item) {
        if (!is_array($item)) continue;
        $uid = (int) ($item['id'] ?? 0);
        if ($uid <= 0 || $uid === $ownerUserId || isset($wanted[$uid])) continue;
        $wanted[$uid] = dfCleanCollabRole($item['role'] ?? '');
    }
    if (!$wanted) return [null, []];
    if (count($wanted) > DF_COLLAB_MAX) return ['You can tag up to ' . DF_COLLAB_MAX . ' collaborators on a project.', []];

    $ids = array_keys($wanted);
    $in = implode(',', array_fill(0, count($ids), '?'));
    $st = $pdo->prepare("SELECT u.id AS user_id, s.id AS student_id, u.first_name, u.last_name
                         FROM users u INNER JOIN students s ON s.user_id = u.id
                         WHERE u.role = 'student' AND u.id IN ($in)");
    $st->execute($ids);
    $found = [];
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $found[(int) $r['user_id']] = $r;

    $list = [];
    foreach ($wanted as $uid => $role) {
        if (!isset($found[$uid])) return ['One of the people you tagged could not be found. Remove them and try again.', []];
        $list[] = [
            'user_id'    => $uid,
            'student_id' => (int) $found[$uid]['student_id'],
            'role'       => $role,
            'first_name' => $found[$uid]['first_name'],
            'last_name'  => $found[$uid]['last_name'],
        ];
    }
    return [null, $list];
}

/**
 * Replaces the team of a project with $list (from dfReadCollaborators).
 *
 * @return ?array user ids that were newly tagged (to notify), or null when it could not be saved
 */
function dfSaveCollaborators(PDO $pdo, int $projectId, array $list): ?array {
    if (!dfCollabReady($pdo)) return null;
    try {
        $cur = $pdo->prepare('SELECT tm.student_id, s.user_id FROM project_team_members tm INNER JOIN students s ON s.id = tm.student_id WHERE tm.project_id = ?');
        $cur->execute([$projectId]);
        $before = [];
        foreach ($cur->fetchAll(PDO::FETCH_ASSOC) as $r) $before[(int) $r['student_id']] = (int) $r['user_id'];

        $keep = [];
        foreach ($list as $c) $keep[(int) $c['student_id']] = true;

        $pdo->beginTransaction();
        $del = $pdo->prepare('DELETE FROM project_team_members WHERE project_id = ? AND student_id = ?');
        foreach ($before as $sid => $uid) if (!isset($keep[$sid])) $del->execute([$projectId, $sid]);
        $ins = $pdo->prepare('INSERT INTO project_team_members (project_id, student_id, role) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE role = VALUES(role)');
        foreach ($list as $c) $ins->execute([$projectId, (int) $c['student_id'], $c['role'] !== '' ? $c['role'] : null]);
        $pdo->commit();

        $added = [];
        foreach ($list as $c) if (!isset($before[(int) $c['student_id']])) $added[] = (int) $c['user_id'];
        return $added;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        return null;
    }
}

/** A tagged student removes their own tag. Returns true when a tag was removed. */
function dfRemoveMyTag(PDO $pdo, int $projectId, int $userId): bool {
    if (!dfCollabReady($pdo)) return false;
    $st = $pdo->prepare('DELETE tm FROM project_team_members tm INNER JOIN students s ON s.id = tm.student_id WHERE tm.project_id = ? AND s.user_id = ?');
    $st->execute([$projectId, $userId]);
    return $st->rowCount() > 0;
}

/**
 * Collaborators of several projects at once (tag order).
 *
 * @return array<int,array[]> project id => rows with user_id, first_name, last_name, avatar_url, program, year_level, role
 */
function dfCollaboratorsFor(PDO $pdo, array $projectIds): array {
    $ids = array_values(array_unique(array_filter(array_map('intval', $projectIds))));
    if (!$ids || !dfCollabReady($pdo)) return [];
    try {
        $in = implode(',', array_fill(0, count($ids), '?'));
        $st = $pdo->prepare(
            "SELECT tm.project_id, tm.role, u.id AS user_id, u.first_name, u.last_name, u.avatar_url, s.program, s.year_level
             FROM project_team_members tm
             INNER JOIN students s ON s.id = tm.student_id
             INNER JOIN users u ON u.id = s.user_id
             WHERE tm.project_id IN ($in)
             ORDER BY tm.id ASC"
        );
        $st->execute($ids);
        $out = [];
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) $out[(int) $r['project_id']][] = $r;
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

/** Adds 'collaborators' to feed / profile rows (one query for the whole page). Never throws. */
function dfAttachCollaborators(PDO $pdo, array &$rows): void {
    $ids = [];
    foreach ($rows as $r) $ids[] = (int) $r['id'];
    $map = dfCollaboratorsFor($pdo, $ids);
    foreach ($rows as &$r) $r['collaborators'] = $map[(int) $r['id']] ?? [];
    unset($r);
}

/** Tells newly tagged students about the project. */
function dfNotifyTagged(PDO $pdo, array $userIds, int $ownerUserId, int $projectId, string $projectTitle, array $list): void {
    if (!$userIds) return;
    try {
        $who = $pdo->prepare('SELECT first_name, last_name FROM users WHERE id = ? LIMIT 1');
        $who->execute([$ownerUserId]);
        $ownerName = dfOwnerName($who->fetch(PDO::FETCH_ASSOC) ?: []);
        $roles = [];
        foreach ($list as $c) $roles[(int) $c['user_id']] = (string) $c['role'];
        $ins = $pdo->prepare('INSERT INTO notifications (user_id, notification_type, title, message, related_project_id) VALUES (?, ?, ?, ?, ?)');
        foreach (array_unique(array_map('intval', $userIds)) as $uid) {
            if ($uid <= 0 || $uid === $ownerUserId) continue;
            $role = $roles[$uid] ?? '';
            $msg = $ownerName . ' tagged you' . ($role !== '' ? ' as ' . $role : ' as a collaborator') . ' on "' . $projectTitle . '". It now shows on your profile.';
            $ins->execute([$uid, 'project_tag', 'You were tagged in a project', $msg, $projectId]);
        }
    } catch (Throwable $e) {
        // tagging already worked; the notification is a bonus
    }
}

/* ===================================================================
 * Display
 * =================================================================== */

/** Small round avatar for collaborator lists. */
function dfCollabAvatar(array $c, string $class = 'df-collab-av'): string {
    $avatar = dfAssetUrl($c['avatar_url'] ?? '');
    return '<span class="' . $class . '" aria-hidden="true"><span>' . dfEsc(dfInitials($c['first_name'] ?? '', $c['last_name'] ?? '')) . '</span>'
        . ($avatar !== '' ? '<img src="' . dfEsc($avatar) . '" alt="" loading="lazy" onerror="this.remove()">' : '') . '</span>';
}

/**
 * "with Maria Santos and 2 others" line (feed posts, profile posts, project header).
 * Each name opens that person's profile; "N others" jumps to the Team card of the project.
 */
function dfRenderCollabLine(array $collabs, string $projectUrl, string $prefix = 'with'): string {
    if (!$collabs) return '';
    $n = count($collabs);
    $names = [];
    $showNames = $n <= 3 ? $n : 2;
    foreach (array_slice($collabs, 0, $showNames) as $c) {
        $uid = (int) $c['user_id'];
        $name = dfOwnerName($c);
        $role = trim((string) ($c['role'] ?? ''));
        $names[] = '<a class="df-collab-name df-profile-link" href="user.php?id=' . $uid . '" data-profile="' . $uid . '"'
            . ' title="' . dfEsc($name . ($role !== '' ? ' — ' . $role : '')) . '"'
            . ' aria-label="' . dfEsc('View profile of ' . $name . ($role !== '' ? ', ' . $role : '')) . '">' . dfEsc($name) . '</a>';
    }
    $rest = $n - $showNames;
    if ($rest > 0) {
        $names[] = '<a class="df-collab-more" href="' . dfEsc($projectUrl) . '#team">' . $rest . ' ' . ($rest === 1 ? 'other' : 'others') . '</a>';
    }
    $last = array_pop($names);
    $text = $names ? implode(', ', $names) . ' and ' . $last : $last;

    $avs = '';
    foreach (array_slice($collabs, 0, 3) as $c) $avs .= dfCollabAvatar($c);
    return '<p class="df-collab">'
        . '<span class="df-collab-avs">' . $avs . '</span>'
        . '<span class="df-collab-text">' . dfIcon('users', 14) . ' <span>' . dfEsc($prefix) . ' ' . $text . '</span></span>'
        . '</p>';
}

/**
 * The Team card on the project page: the creator first, then everyone tagged with their role.
 * Each person shows their work links (LinkedIn, GitHub, portfolio...) as small icons when they added any.
 * Owners get "Edit team"; a tagged viewer gets "Remove my tag" (and a nudge to add links if they have none).
 *
 * $linksByUser: [userId => links] from dfLinksForUsers() / dfFetchLinks() (profile-links.php).
 */
function dfRenderTeamCard(array $p, array $collabs, int $meId, bool $canEdit, array $linksByUser = []): string {
    $ownerId = (int) $p['owner_user_id'];
    $owner = ['user_id' => $ownerId, 'first_name' => $p['first_name'] ?? '', 'last_name' => $p['last_name'] ?? '', 'avatar_url' => $p['avatar_url'] ?? '', 'role' => '', 'program' => $p['student_program'] ?? ''];
    $isTagged = false;
    foreach ($collabs as $c) if ((int) $c['user_id'] === $meId) $isTagged = true;
    $hasIcons = function_exists('dfRenderLinkIcons');

    $row = static function (array $c, bool $isCreator) use ($meId, $linksByUser, $hasIcons): string {
        $uid = (int) $c['user_id'];
        $name = dfOwnerName($c);
        $role = trim((string) ($c['role'] ?? ''));
        $sub = $isCreator ? 'Project owner' : ($role !== '' ? $role : 'Collaborator');
        $links = $linksByUser[$uid] ?? [];
        $icons = ($hasIcons && $links) ? dfRenderLinkIcons($links, $uid, $name, 3) : '';
        return '<li class="pjx-team-row' . ($icons !== '' ? ' has-links' : '') . '">'
            . '<a class="pjx-team-person df-profile-link" href="user.php?id=' . $uid . '" data-profile="' . $uid . '" aria-label="' . dfEsc('View profile of ' . $name . ', ' . $sub) . '">'
            . dfCollabAvatar($c, 'pjx-team-av')
            . '<span class="pjx-team-text"><b>' . dfEsc($name) . ($uid === $meId ? ' <em class="pjx-team-you">You</em>' : '') . '</b>'
            . '<span class="pjx-team-role' . ($isCreator ? ' is-creator' : '') . '">' . dfEsc($sub) . '</span></span>'
            . dfIcon('chevron', 16)
            . '</a>'
            . ($icons !== '' ? '<div class="pjx-team-links">' . $icons . '</div>' : '')
            . '</li>';
    };

    $html = '<section class="pjx-card pjx-team" id="team" aria-labelledby="pjTeam">'
        . '<div class="pjx-team-head"><h2 id="pjTeam" class="pjx-h pjx-h-icon">' . dfIcon('users', 16) . ' Team <span class="pjx-team-count">' . (count($collabs) + 1) . '</span></h2>';
    if ($canEdit) {
        $html .= '<button type="button" class="pjx-team-edit" data-team-edit>' . dfIcon('compose', 14) . ' <span>' . ($collabs ? 'Edit team' : 'Tag collaborators') . '</span></button>';
    }
    $html .= '</div><ul class="pjx-team-list">' . $row($owner, true);
    foreach ($collabs as $c) $html .= $row($c, false);
    $html .= '</ul>';
    if (!$collabs) {
        $html .= '<p class="pjx-fine">' . ($canEdit ? 'Built this with classmates? Tag them so they get credit for their part.' : 'A solo project by ' . dfEsc(dfOwnerName($p)) . '.') . '</p>';
    }
    if ($isTagged && $hasIcons && empty($linksByUser[$meId])) {
        $html .= '<a class="pjx-team-addlinks" href="profile.php#links">' . dfIcon('plus', 14) . ' Add your LinkedIn, GitHub or portfolio so it shows on this project</a>';
    }
    if ($isTagged) {
        $html .= '<button type="button" class="pjx-team-leave" data-team-leave>' . dfIcon('close', 14) . ' Remove my tag</button>';
    }
    return $html . '</section>';
}

/**
 * The "Tag collaborators" picker (the feed's "Showcase a project" dialog and the project page Team editor).
 * Behaviour lives in js/df-collab-picker.js.
 */
function dfCollabPickerHtml(string $id = 'collab', array $initial = []): string {
    $roles = '';
    foreach (dfCollabRoleSuggestions() as $r) $roles .= '<option value="' . dfEsc($r) . '">';
    $init = [];
    foreach ($initial as $c) $init[] = dfCollabPersonJson($c);
    return '<div class="dfcp" id="' . dfEsc($id) . '" data-collab-picker data-max="' . (int) DF_COLLAB_MAX . '" data-role-max="' . (int) DF_COLLAB_ROLE_MAX . '">'
        . '<label class="dfcp-title" for="' . dfEsc($id) . 'Search">Collaborators <span class="dfcp-opt">(optional, up to ' . (int) DF_COLLAB_MAX . ')</span></label>'
        . '<p class="dfcp-help">Worked on this with classmates? Tag them and say what they did. Their profiles are shown on the project and it appears on their profile too.</p>'
        . '<div class="dfcp-search">'
        . dfIcon('search', 16)
        . '<input type="text" id="' . dfEsc($id) . 'Search" class="df-light dfcp-input" placeholder="Search students by name" autocomplete="off"'
        . ' role="combobox" aria-autocomplete="list" aria-expanded="false" aria-controls="' . dfEsc($id) . 'Results">'
        . '<ul class="dfcp-results" id="' . dfEsc($id) . 'Results" role="listbox" aria-label="Matching students" hidden></ul>'
        . '</div>'
        . '<ul class="dfcp-list" aria-label="Tagged collaborators"></ul>'
        . '<datalist id="' . dfEsc($id) . 'Roles">' . $roles . '</datalist>'
        . '<p class="dfcp-msg" role="status" aria-live="polite"></p>'
        . '<script type="application/json" data-collab-initial>' . json_encode($init, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) . '</script>'
        . '</div>';
}
