<?php
/**
 * Profile timeline (Facebook-style profile): cover photo, news feed of the member's own
 * projects + projects they shared to their profile, and Following / Followers lists.
 * Used by student/my-profile.php (own profile) and student/user.php (everyone else's).
 *
 * Plagiarism protection: a shared project is always shown inside an "original work" frame
 * with the ORIGINAL creator's photo, name and link, and cannot be edited by the sharer.
 *
 * Needs ui-helpers.php, project-helpers.php, profile-helpers.php, follow-helpers.php loaded.
 */

require_once __DIR__ . '/my-projects.php';

const DF_COVER_MAX_BYTES = 8 * 1024 * 1024;
const DF_COVER_DIR_URL = '../assets/uploads/covers/';
const DF_SHARE_CAPTION_MAX = 300;
const DF_PEOPLE_LIMIT = 60;
const DF_TIMELINE_LIMIT = 30;

/* ===================================================================
 * Database readiness (created automatically on first use, like the follow table)
 * =================================================================== */

/** Adds users.cover_url if this database does not have it yet (once per session). */
function dfCoverReady(PDO $pdo): bool {
    static $ready = null;
    if ($ready !== null) return $ready;
    if (!empty($_SESSION['df_cover_col'])) return $ready = true;
    try {
        $chk = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'cover_url'");
        if ((int) $chk->fetchColumn() === 0) {
            $pdo->exec('ALTER TABLE users ADD COLUMN cover_url VARCHAR(255) NULL');
        }
        $_SESSION['df_cover_col'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return $ready = false;
    }
}

/** Creates profile_shared_projects if it is missing (once per session). */
function dfShareTableReady(PDO $pdo): bool {
    static $ready = false;
    if ($ready) return true;
    if (!empty($_SESSION['df_share_table'])) return $ready = true;
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS profile_shared_projects (
            id INT PRIMARY KEY AUTO_INCREMENT,
            user_id INT NOT NULL,
            project_id INT NOT NULL,
            caption VARCHAR(" . DF_SHARE_CAPTION_MAX . ") NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_profile_share (user_id, project_id),
            INDEX idx_profile_share_user (user_id, created_at),
            FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
            FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE
        )");
        $_SESSION['df_share_table'] = 1;
        return $ready = true;
    } catch (Throwable $e) {
        return false;
    }
}

/* ===================================================================
 * Cover photo
 * =================================================================== */

/** Stored cover photo URL of a user ('' when none). */
function dfProfileCover(PDO $pdo, int $userId): string {
    if ($userId <= 0 || !dfCoverReady($pdo)) return '';
    try {
        $st = $pdo->prepare('SELECT cover_url FROM users WHERE id = ? LIMIT 1');
        $st->execute([$userId]);
        return dfAssetUrl((string) $st->fetchColumn());
    } catch (Throwable $e) {
        return '';
    }
}

/**
 * Validates and stores an uploaded cover photo (type is read from the file itself).
 *
 * @return array{0:?string,1:?string} [error message or null, stored url or null]
 */
function dfStoreCoverImage(array $file, int $userId): array {
    if (($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) return ['Please choose an image.', null];
    if ($file['error'] !== UPLOAD_ERR_OK) return ['The cover photo could not be uploaded (max 8 MB).', null];
    if ((int) $file['size'] > DF_COVER_MAX_BYTES) return ['The cover photo is larger than 8 MB.', null];

    $info = @getimagesize($file['tmp_name']);
    $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
    if (!$info || !isset($types[$info[2]])) return ['Only JPG, PNG, and WEBP images are allowed.', null];

    $dir = __DIR__ . '/../assets/uploads/covers/';
    if (!is_dir($dir) && !mkdir($dir, 0777, true) && !is_dir($dir)) return ['Cover photo upload failed.', null];

    $name = 'cover_' . $userId . '_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $types[$info[2]];
    if (!move_uploaded_file($file['tmp_name'], $dir . $name)) return ['Cover photo upload failed.', null];
    return [null, DF_COVER_DIR_URL . $name];
}

/** Deletes a stored cover photo, but only if it really lives in the covers folder. */
function dfDeleteCoverImage(?string $url): void {
    $url = (string) $url;
    if (strpos($url, DF_COVER_DIR_URL) !== 0) return;
    $file = __DIR__ . '/../assets/uploads/covers/' . basename($url);
    if (is_file($file)) @unlink($file);
}

/* ===================================================================
 * Feed data
 * =================================================================== */

/** How many projects this user has shared to their profile. */
function dfSharedCount(PDO $pdo, int $userId): int {
    if ($userId <= 0 || !dfShareTableReady($pdo)) return 0;
    try {
        $st = $pdo->prepare("SELECT COUNT(*) FROM profile_shared_projects sp INNER JOIN projects p ON p.id = sp.project_id WHERE sp.user_id = ? AND p.status = 'approved'");
        $st->execute([$userId]);
        return (int) $st->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}

/**
 * The news feed of a profile: own approved projects and projects shared to the profile,
 * newest first. Each item: ['type' => 'own'|'shared', 'ts' => int, 'p' => project row].
 */
function dfFetchTimeline(PDO $pdo, int $profileUserId, int $viewerId): array {
    $items = [];

    $ss = $pdo->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
    $ss->execute([$profileUserId]);
    $sid = (int) $ss->fetchColumn();

    if ($sid > 0) {
        $st = $pdo->prepare(dfProjectSelectSql() . " WHERE p.student_id = :sid AND p.status = 'approved' ORDER BY p.created_at DESC, p.id DESC LIMIT " . DF_TIMELINE_LIMIT);
        $st->execute([':me' => $viewerId, ':sid' => $sid]);
        $own = $st->fetchAll(PDO::FETCH_ASSOC);
        dfAttachPhotoCounts($pdo, $own);
        dfAttachCollaborators($pdo, $own);
        foreach ($own as $p) {
            $items[] = ['type' => 'own', 'ts' => (int) strtotime((string) $p['created_at']), 'p' => $p];
        }
    }

    if (dfShareTableReady($pdo)) {
        $sql = str_replace(
            'SELECT p.*,',
            'SELECT p.*, sp.id AS share_id, sp.caption AS share_caption, sp.created_at AS shared_at,',
            dfProjectSelectSql()
        ) . " INNER JOIN profile_shared_projects sp ON sp.project_id = p.id
              WHERE sp.user_id = :uid AND p.status = 'approved'
              ORDER BY sp.created_at DESC, sp.id DESC LIMIT " . DF_TIMELINE_LIMIT;
        try {
            $st = $pdo->prepare($sql);
            $st->execute([':me' => $viewerId, ':uid' => $profileUserId]);
            $shared = $st->fetchAll(PDO::FETCH_ASSOC);
            dfAttachPhotoCounts($pdo, $shared);
            dfAttachCollaborators($pdo, $shared);
            foreach ($shared as $p) {
                $items[] = ['type' => 'shared', 'ts' => (int) strtotime((string) $p['shared_at']), 'p' => $p];
            }
        } catch (Throwable $e) {
            // sharing is optional; the feed still shows the member's own projects
        }
    }

    // Team projects this member was tagged on by the owner ("Collaborated on a project")
    if ($sid > 0 && dfCollabReady($pdo)) {
        $sql = str_replace('SELECT p.*,', 'SELECT p.*, tm.role AS tag_role,', dfProjectSelectSql())
            . " INNER JOIN project_team_members tm ON tm.project_id = p.id
                WHERE tm.student_id = :sid AND p.status = 'approved'
                ORDER BY p.created_at DESC, p.id DESC LIMIT " . DF_TIMELINE_LIMIT;
        try {
            $st = $pdo->prepare($sql);
            $st->execute([':me' => $viewerId, ':sid' => $sid]);
            $tagged = $st->fetchAll(PDO::FETCH_ASSOC);
            dfAttachPhotoCounts($pdo, $tagged);
            dfAttachCollaborators($pdo, $tagged);
            foreach ($tagged as $p) {
                $items[] = ['type' => 'tagged', 'ts' => (int) strtotime((string) $p['created_at']), 'p' => $p];
            }
        } catch (Throwable $e) {
            // tags are optional; the rest of the feed still shows
        }
    }

    usort($items, static function ($a, $b) { return $b['ts'] <=> $a['ts']; });
    return $items;
}

/**
 * People a user follows ('following') or who follow them ('followers'), newest first.
 *
 * @return array[] rows with id, first_name, last_name, avatar_url, program, profession
 */
function dfFetchPeople(PDO $pdo, int $userId, string $direction): array {
    if ($userId <= 0 || !dfFollowTableReady($pdo)) return [];
    $join = $direction === 'followers' ? 'f.follower_id' : 'f.following_id';
    $where = $direction === 'followers' ? 'f.following_id' : 'f.follower_id';
    $prof = dfProfessionReady($pdo) ? 's.profession' : "'' AS profession";
    try {
        $st = $pdo->prepare(
            "SELECT u.id, u.first_name, u.last_name, u.avatar_url, s.program, $prof
             FROM user_follows f
             INNER JOIN users u ON u.id = $join
             LEFT JOIN students s ON s.user_id = u.id
             WHERE $where = ? ORDER BY f.created_at DESC LIMIT " . DF_PEOPLE_LIMIT
        );
        $st->execute([$userId]);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return [];
    }
}

/** user ids the viewer follows (one query, used to paint the Follow buttons). */
function dfViewerFollowingIds(PDO $pdo, int $viewerId): array {
    if ($viewerId <= 0 || !dfFollowTableReady($pdo)) return [];
    try {
        $st = $pdo->prepare('SELECT following_id FROM user_follows WHERE follower_id = ?');
        $st->execute([$viewerId]);
        return array_map('intval', $st->fetchAll(PDO::FETCH_COLUMN));
    } catch (Throwable $e) {
        return [];
    }
}

/* ===================================================================
 * Rendering
 * =================================================================== */

/** Small square tile (friends-list style): photo + name. */
function dfRenderPeopleTiles(array $people, int $max = 9): string {
    $html = '<ul class="pf-tiles">';
    foreach (array_slice($people, 0, $max) as $u) {
        $name = dfOwnerName($u);
        $html .= '<li><a class="pf-tile df-profile-link" href="' . dfEsc(dfProfileUrl((int) $u['id'])) . '" data-profile="' . (int) $u['id'] . '" aria-label="' . dfEsc('View profile of ' . $name) . '">'
            . dfAvatarHtml($u) . '<span>' . dfEsc($name) . '</span></a></li>';
    }
    return $html . '</ul>';
}

/** Full list of people with a Follow button when the viewer can follow them. */
function dfRenderPeopleList(array $people, int $viewerId, bool $viewerIsStudent, array $viewerFollowing, string $emptyText): string {
    if (!$people) return '<p class="upx-muted">' . dfEsc($emptyText) . '</p>';
    $html = '<ul class="pf-people">';
    foreach ($people as $u) {
        $uid = (int) $u['id'];
        $name = dfOwnerName($u);
        $sub = trim((string) ($u['profession'] ?? ''));
        if ($sub === '') $sub = trim((string) ($u['program'] ?? ''));
        $html .= '<li class="pf-person">'
            . '<a class="pf-person-main df-profile-link" href="' . dfEsc(dfProfileUrl($uid)) . '" data-profile="' . $uid . '">'
            . dfAvatarHtml($u)
            . '<span class="pf-person-text"><strong>' . dfEsc($name) . '</strong>' . ($sub !== '' ? '<small>' . dfEsc($sub) . '</small>' : '') . '</span></a>';
        if ($viewerIsStudent && $uid !== $viewerId) {
            $html .= dfFollowButton($uid, in_array($uid, $viewerFollowing, true));
        }
        $html .= '</li>';
    }
    return $html . '</ul>';
}

/** Footer shared by every post: appreciate / comment / share on the project + comment thread. */
function dfRenderPostFooter(array $p, string $url): string {
    ob_start(); ?>
    <footer class="df-post-foot">
        <div class="df-foot-actions">
            <?php echo dfLikeButton($p); ?>
            <?php echo dfCommentButton($p); ?>
            <?php echo dfShareButton($p); ?>
        </div>
        <a class="df-post-open" href="<?php echo dfEsc($url); ?>">View project</a>
    </footer>
    <section class="df-comments" id="comments-<?php echo (int) $p['id']; ?>" data-comments="<?php echo (int) $p['id']; ?>" aria-label="Comments" hidden></section>
    <?php
    return ob_get_clean();
}

/**
 * The "..." menu of a post: open the project, report it (other people's projects),
 * or take a shared project off the owner's profile.
 */
function dfRenderPostMenu(array $p, string $url, int $shareId, bool $isOwner, bool $tagged = false): string {
    $title = (string) ($p['title'] ?? 'this project');
    ob_start(); ?>
    <details class="pf-menu" data-pf-menu>
        <summary class="pf-menu-btn" aria-label="<?php echo dfEsc('More options for ' . $title); ?>"><?php echo dfIcon('dots', 18); ?></summary>
        <div class="pf-menu-list">
            <a class="pf-menu-item" href="<?php echo dfEsc($url); ?>"><?php echo dfIcon('external', 15); ?> View project</a>
            <?php echo dfReportButton($p); ?>
            <?php if ($isOwner && $shareId > 0): ?>
                <button type="button" class="pf-menu-item is-danger pf-remove" data-unshare="<?php echo $shareId; ?>" aria-label="<?php echo dfEsc('Remove ' . $title . ' from your profile'); ?>"><?php echo dfIcon('trash', 15); ?> Remove from my profile</button>
            <?php endif; ?>
            <?php if ($isOwner && $tagged): ?>
                <button type="button" class="pf-menu-item is-danger pf-remove" data-untag="<?php echo (int) $p['id']; ?>" aria-label="<?php echo dfEsc('Remove your tag from ' . $title); ?>"><?php echo dfIcon('close', 15); ?> Remove my tag</button>
            <?php endif; ?>
        </div>
    </details>
    <?php
    return ob_get_clean();
}

/**
 * The project box inside a post: optional photo, kind + category, title, technologies.
 * $shared adds the ORIGINAL creator's credit on top so shared work is never passed off as the sharer's.
 */
function dfRenderProjectBox(array $p, string $url, bool $shared, string $type = '', int $profileUserId = 0): string {
    $tagged = $type === 'tagged';
    if ($tagged) $shared = true;   // a team project is shown inside the owner's credit frame too
    $title = $p['title'] ?? 'Untitled Project';
    $tags = dfTags($p['tech_stack'] ?? null);
    $cat = trim((string) ($p['category'] ?? ''));
    $image = dfAssetUrl($p['banner_image_url'] ?? '');
    if ($image !== '' && stripos($image, 'placehold.co') !== false) $image = '';
    $desc = '';
    if ($shared) {
        $desc = trim((string) ($p['description'] ?? ''));
        if ($desc === '') $desc = trim((string) ($p['abstract'] ?? ''));
    }
    $creator = ['first_name' => $p['first_name'] ?? '', 'last_name' => $p['last_name'] ?? '', 'avatar_url' => $p['avatar_url'] ?? ''];
    $creatorId = (int) ($p['owner_user_id'] ?? 0);

    ob_start(); ?>
    <div class="pf-box">
        <?php if ($shared): ?>
            <div class="pf-credit">
                <a class="df-creator df-profile-link" href="<?php echo dfEsc(dfProfileUrl($creatorId)); ?>" data-profile="<?php echo $creatorId; ?>" aria-label="<?php echo dfEsc('Original creator: ' . dfOwnerName($creator)); ?>">
                    <?php echo dfAvatarHtml($creator); ?>
                    <span class="df-creator-text">
                        <span class="df-creator-name"><?php echo dfEsc(dfOwnerName($creator)); ?></span>
                        <span class="df-creator-meta"><?php echo $tagged ? 'Project owner' : 'Original creator'; ?></span>
                    </span>
                </a>
                <?php if ($tagged): ?>
                    <span class="pf-credit-tag is-team"><?php echo dfIcon('users', 13); ?> Team project</span>
                <?php else: ?>
                    <span class="pf-credit-tag"><?php echo dfIcon('shield', 13); ?> Original work</span>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ($image !== ''): ?>
            <a class="pf-box-photo" href="<?php echo dfEsc($url); ?>" aria-label="<?php echo dfEsc('View details for ' . $title); ?>">
                <img src="<?php echo dfEsc($image); ?>" alt="<?php echo dfEsc('Preview of ' . $title); ?>" loading="lazy" onerror="this.parentNode.remove()">
                <?php if ((int) ($p['photo_count'] ?? 0) > 1): ?><span class="df-photo-count" title="<?php echo (int) $p['photo_count']; ?> photos"><?php echo dfIcon('image', 14) . (int) $p['photo_count']; ?></span><?php endif; ?>
            </a>
        <?php endif; ?>
        <div class="pf-box-body">
            <span class="pf-box-kicker"><?php echo dfIcon('code', 15); ?><?php if ($cat !== ''): ?><span><?php echo dfEsc($cat); ?></span><?php endif; ?></span>
            <h3 class="pf-box-title"><a href="<?php echo dfEsc($url); ?>"><?php echo dfEsc($title); ?></a></h3>
            <?php if ($desc !== ''): ?><p class="pf-box-desc"><?php echo dfEsc($desc); ?></p><?php endif; ?>
            <?php if ($tags): ?><p class="pf-box-tags" aria-label="Technologies"><?php echo implode(' / ', array_map('dfEsc', $tags)); ?></p><?php endif; ?>
            <?php
            // Everyone else on the team ("with ..."); on a tagged post the profile owner is already named in the header
            $team = array_values(array_filter($p['collaborators'] ?? [], static function ($c) use ($tagged, $profileUserId) {
                return !($tagged && (int) $c['user_id'] === $profileUserId);
            }));
            if ($team) echo dfRenderCollabLine($team, $url, $tagged ? 'Also with' : 'with');
            ?>
            <?php echo dfProjectLinkChip($p); ?>
        </div>
    </div>
    <?php
    return ob_get_clean();
}

/**
 * One post of the profile feed.
 *   $type 'own'    - the profile owner created this project ("Created a project")
 *   $type 'shared' - the profile owner shared someone's project ("Shared a project"); the original
 *                    creator is credited inside the box and the sharer cannot edit the project.
 */
function dfRenderProfilePost(array $p, array $profile, bool $isOwner, string $type): string {
    $tagged = $type === 'tagged';
    $shared = $type === 'shared';
    $url = 'project.php?id=' . (int) $p['id'];
    $title = $p['title'] ?? 'Untitled Project';
    $who = ($shared || $tagged) ? $profile : ['first_name' => $p['first_name'] ?? '', 'last_name' => $p['last_name'] ?? '', 'avatar_url' => $p['avatar_url'] ?? '', 'id' => (int) ($p['owner_user_id'] ?? 0)];
    $whoId = (int) ($who['id'] ?? 0);
    $when = dfTimeAgo($shared ? ($p['shared_at'] ?? null) : ($p['created_at'] ?? null));
    $shareId = $shared ? (int) ($p['share_id'] ?? 0) : 0;

    $tagRole = trim((string) ($p['tag_role'] ?? ''));
    if ($shared) {
        $caption = trim((string) ($p['share_caption'] ?? ''));
    } elseif ($tagged) {
        $caption = '';   // the owner's description is the owner's words; the box below shows the project
    } else {
        $caption = trim((string) ($p['description'] ?? ''));
        if ($caption === '') $caption = trim((string) ($p['abstract'] ?? ''));
    }

    ob_start(); ?>
    <article class="df-card df-post pf-post<?php echo $shared ? ' is-shared' : ($tagged ? ' is-shared is-tagged' : ''); ?>"<?php echo $tagged ? ' data-tag-post="' . (int) $p['id'] . '"' : ''; ?><?php echo $shared ? ' data-share-post="' . $shareId . '"' : ''; ?>>
        <header class="df-post-head">
            <a class="df-creator df-profile-link" href="<?php echo dfEsc(dfProfileUrl($whoId)); ?>" data-profile="<?php echo $whoId; ?>" aria-label="<?php echo dfEsc('View profile of ' . dfOwnerName($who)); ?>">
                <?php echo dfAvatarHtml($who); ?>
                <span class="df-creator-text">
                    <span class="df-creator-name"><?php echo dfEsc(dfOwnerName($who)); ?></span>
                    <span class="df-creator-meta"><?php echo $shared ? 'Shared a project' : ($tagged ? 'Collaborated on a project' . ($tagRole !== '' ? ' as <b class="pf-tag-role">' . dfEsc($tagRole) . '</b>' : '') : 'Created a project'); ?><?php echo $when !== '' ? ' &middot; ' . dfEsc($when) : ''; ?></span>
                </span>
            </a>
            <?php echo dfRenderPostMenu($p, $url, $shareId, $isOwner, $tagged); ?>
        </header>

        <?php if ($caption !== ''): ?>
            <div class="pf-post-text">
                <p class="pf-caption" data-pf-caption><?php echo dfEsc($caption); ?></p>
                <button type="button" class="pf-seemore" data-pf-seemore aria-expanded="false" hidden>See more</button>
            </div>
        <?php endif; ?>

        <?php echo dfRenderProjectBox($p, $url, $shared, $type, (int) ($profile['id'] ?? 0)); ?>

        <?php echo dfRenderPostFooter($p, $url); ?>
    </article>
    <?php
    return ob_get_clean();
}

/** The full news feed (HTML). */
function dfRenderTimeline(array $items, array $profile, bool $isOwner): string {
    if (!$items) {
        $msg = $isOwner
            ? 'Nothing here yet. Showcase a project, or share one you like from the Discover feed, and it will show up on your profile.'
            : 'No projects have been showcased or shared yet.';
        return '<div class="pf-empty">' . dfIcon('folder', 28) . '<h3>No posts yet</h3><p>' . dfEsc($msg) . '</p>'
            . ($isOwner ? '<a class="df-btn df-btn-primary" href="dashboard.php">Go to Discover</a>' : '') . '</div>';
    }
    $html = '';
    foreach ($items as $it) {
        $html .= dfRenderProfilePost($it['p'], $profile, $isOwner, in_array($it['type'], ['shared', 'tagged'], true) ? $it['type'] : 'own');
    }
    return $html;
}

/** "Label / value" rows for the About details (everything the member filled in on Account settings). */
function dfRenderFacts(array $rows): string {
    $html = '<dl class="upx-facts pf-facts">';
    foreach ($rows as $r) {
        if ($r[1] === '') continue;
        $html .= '<div><dt>' . dfEsc($r[0]) . '</dt><dd>' . (isset($r[2]) ? $r[1] : dfEsc($r[1])) . '</dd></div>';
    }
    return $html . '</dl>';
}

/** "1 follower" / "2 followers": the number is live-updated by JS, the word follows it (see df-profile.js). */
function dfCountWord(int $n, string $singular, string $plural): string {
    return $n === 1 ? $singular : $plural;
}

/**
 * Whole profile body: cover, header, tabs and panels.
 *
 * $o = [
 *   'isOwner' => bool, 'viewerId' => int, 'viewerRole' => 'student'|'faculty',
 *   'canSeePrivate' => bool (faculty), 'canFollow' => bool, 'isFollowing' => bool,
 * ]
 */
function dfRenderProfileView(PDO $pdo, array $pf, array $o): string {
    $uid = (int) $pf['id'];
    $isOwner = !empty($o['isOwner']);
    $viewerId = (int) ($o['viewerId'] ?? 0);
    $viewerIsStudent = ($o['viewerRole'] ?? '') === 'student';
    $canSeePrivate = !empty($o['canSeePrivate']);

    $cover = dfProfileCover($pdo, $uid);
    $name = dfOwnerName($pf);
    $items = dfFetchTimeline($pdo, $uid, $viewerId);
    $following = dfFetchPeople($pdo, $uid, 'following');
    $followers = dfFetchPeople($pdo, $uid, 'followers');
    $viewerFollowing = $viewerIsStudent ? dfViewerFollowingIds($pdo, $viewerId) : [];
    $sharedCount = dfSharedCount($pdo, $uid);

    $phone = '';
    if ($isOwner) {
        $ph = $pdo->prepare('SELECT phone FROM users WHERE id = ? LIMIT 1');
        $ph->execute([$uid]);
        $phone = trim((string) $ph->fetchColumn());
    }
    $showEmail = ($isOwner || $canSeePrivate) && $pf['email'] !== '';
    $joined = date('F j, Y', strtotime((string) $pf['created_at']) ?: time());
    $joinedShort = date('F Y', strtotime((string) $pf['created_at']) ?: time());
    $headline = implode(' · ', array_filter([$pf['profession'], dfProfileSubtitle($pf)], static function ($v) { return trim((string) $v) !== ''; }));

    ob_start(); ?>
    <section class="pf-hero" aria-labelledby="pfName">
        <div class="pf-cover<?php echo $cover === '' ? ' is-default' : ''; ?>" id="pfCover"<?php echo $cover !== '' ? ' style="background-image:url(\'' . dfEsc($cover) . '\')"' : ''; ?>>
            <?php if ($isOwner): ?>
                <div class="pf-cover-tools">
                    <button type="button" class="pf-cover-btn" id="pfCoverEdit" aria-label="Edit cover photo"><?php echo dfIcon('camera', 16); ?> <span id="pfCoverEditLabel">Edit cover</span></button>
                    <button type="button" class="pf-cover-btn is-quiet" id="pfCoverRemove"<?php echo $cover === '' ? ' hidden' : ''; ?>><?php echo dfIcon('trash', 16); ?> <span>Remove</span></button>
                </div>
                <input type="file" id="pfCoverInput" accept="image/jpeg,image/png,image/webp" hidden>
            <?php endif; ?>
        </div>

        <div class="pf-head">
            <div class="pf-avatar"><?php echo dfAvatarHtml($pf); ?></div>
            <div class="pf-id">
                <div class="pf-namerow">
                    <h1 id="pfName" class="pf-name"><?php echo dfEsc($name); ?></h1>
                    <?php echo dfRoleBadge('student'); ?>
                </div>
                <p class="pf-sub"><?php echo dfEsc($headline); ?></p>
                <?php if ($pf['profession'] === '' && $isOwner): ?>
                    <p class="pf-profession is-empty">Add your profession in Edit profile so people know what you do.</p>
                <?php endif; ?>
                <p class="pf-counts">
                    <button type="button" data-pf-go="followers"><b data-follower-count="<?php echo $uid; ?>"><?php echo (int) $pf['follower_count']; ?></b> <span data-count-word="follower"><?php echo dfCountWord((int) $pf['follower_count'], 'follower', 'followers'); ?></span></button>
                    <button type="button" data-pf-go="following"><b data-following-count><?php echo (int) $pf['following_count']; ?></b> following</button>
                    <button type="button" data-pf-go="posts"><b><?php echo (int) $pf['project_count']; ?></b> <?php echo dfCountWord((int) $pf['project_count'], 'project', 'projects'); ?></button>
                </p>
                <?php if (!empty($pf['links'])): ?>
                    <?php echo dfRenderLinkPills($pf['links'], 'profile', 'Working profiles of ' . $name); ?>
                <?php elseif ($isOwner): ?>
                    <p class="pf-olinks-empty"><a href="profile.php#links"><?php echo dfIcon('plus', 14); ?> Add your LinkedIn, GitHub or portfolio</a></p>
                <?php endif; ?>
            </div>
            <div class="pf-actions">
                <?php if ($isOwner): ?>
                    <a class="df-btn df-btn-primary pf-edit" href="profile.php"><?php echo dfIcon('useredit', 16); ?> Edit profile</a>
                <?php elseif (!empty($o['canFollow'])): ?>
                    <?php echo dfFollowButton($uid, !empty($o['isFollowing'])); ?>
                <?php endif; ?>
            </div>
        </div>

        <div class="pf-tabs" role="tablist" aria-label="Profile sections">
            <button type="button" class="pf-tab" role="tab" id="tab-posts" data-pf-tab="posts" aria-selected="true" aria-controls="panel-posts">Posts</button>
            <button type="button" class="pf-tab" role="tab" id="tab-about" data-pf-tab="about" aria-selected="false" aria-controls="panel-about" tabindex="-1">About</button>
            <button type="button" class="pf-tab" role="tab" id="tab-followers" data-pf-tab="followers" aria-selected="false" aria-controls="panel-followers" tabindex="-1">Followers</button>
            <button type="button" class="pf-tab" role="tab" id="tab-following" data-pf-tab="following" aria-selected="false" aria-controls="panel-following" tabindex="-1">Following</button>
            <?php if ($isOwner): ?>
                <button type="button" class="pf-tab" role="tab" id="tab-projects" data-pf-tab="projects" aria-selected="false" aria-controls="panel-projects" tabindex="-1">My Projects</button>
            <?php endif; ?>
        </div>
    </section>

    <!-- ============ POSTS: intro / skills / certificates sidebar + news feed ============ -->
    <div class="pf-panel" role="tabpanel" id="panel-posts" data-pf-panel="posts" aria-labelledby="tab-posts">
        <div class="pf-grid">
            <aside class="pf-side" aria-label="Intro">
                <section class="upx-card">
                    <h2 class="upx-h">Intro</h2>
                    <?php if ($pf['bio'] !== ''): ?>
                        <p class="pf-bio"><?php echo nl2br(dfEsc($pf['bio'])); ?></p>
                    <?php elseif ($isOwner): ?>
                        <p class="pf-bio is-empty">You have not written a bio yet. <a href="profile.php#bio">Add one</a>.</p>
                    <?php else: ?>
                        <p class="pf-bio is-empty">This student has not written a bio yet.</p>
                    <?php endif; ?>
                    <ul class="pf-intro">
                        <li><?php echo dfIcon('cap', 16); ?> <span><?php echo dfEsc(dfProfileSubtitle($pf)); ?></span></li>
                        <li><?php echo dfIcon('calendar', 16); ?> <span>Joined <?php echo dfEsc($joinedShort); ?></span></li>
                    </ul>
                    <button type="button" class="df-more pf-more" data-pf-go="about">See all details</button>
                </section>

                <?php if ($pf['skills']): ?>
                <section class="upx-card" aria-labelledby="pfSkillsH">
                    <div class="pf-card-head">
                        <h2 id="pfSkillsH" class="upx-h">Skills</h2>
                        <?php if ($isOwner): ?><a class="pf-link" href="profile.php#skills">Manage</a><?php endif; ?>
                    </div>
                    <?php echo dfRenderSkillRows($pf['skills']); ?>
                </section>
                <?php endif; ?>

                <?php if ($pf['certificates']): ?>
                <section class="upx-card" aria-labelledby="pfCertsSideH">
                    <div class="pf-card-head">
                        <h2 id="pfCertsSideH" class="upx-h">Certificates</h2>
                        <?php if ($isOwner): ?><a class="pf-link" href="profile.php#certificates">Manage</a><?php endif; ?>
                    </div>
                    <?php echo dfRenderCertificates($pf['certificates'], false, true); ?>
                </section>
                <?php endif; ?>

                <section class="upx-card" aria-labelledby="pfFollowingH">
                    <div class="pf-card-head">
                        <h2 id="pfFollowingH" class="upx-h">Following</h2>
                        <?php if (count($following) > 0): ?><button type="button" class="pf-link" data-pf-go="following">See all</button><?php endif; ?>
                    </div>
                    <p class="pf-muted-line"><span data-following-count><?php echo (int) $pf['following_count']; ?></span> following</p>
                    <?php echo $following ? dfRenderPeopleTiles($following, 9) : '<p class="upx-muted">' . ($isOwner ? 'You are not following anyone yet. Find students on the Discover feed.' : 'Not following anyone yet.') . '</p>'; ?>
                </section>
            </aside>

            <div class="pf-feed" id="pfFeed" aria-label="Posts">
                <?php if ($isOwner): ?>
                    <a class="pf-compose" href="dashboard.php">
                        <span class="pf-compose-ico"><?php echo dfIcon('compose', 18); ?></span>
                        <span class="pf-compose-text">What have you been building?</span>
                        <b><?php echo dfIcon('plus', 16); ?> Post</b>
                    </a>
                <?php endif; ?>
                <div class="pf-feed-head">
                    <h2>Posts</h2>
                    <span><?php echo (int) $pf['project_count']; ?> created &middot; <?php echo (int) $sharedCount; ?> shared</span>
                </div>
                <?php echo dfRenderTimeline($items, $pf, $isOwner); ?>
            </div>
        </div>
    </div>

    <!-- ============ ABOUT: everything from Account settings ============ -->
    <div class="pf-panel" role="tabpanel" id="panel-about" data-pf-panel="about" aria-labelledby="tab-about" hidden>
        <div class="pf-grid pf-grid-about">
            <div class="pf-stack">
                <section class="upx-card" aria-labelledby="pfAboutH">
                    <div class="pf-card-head">
                        <h2 id="pfAboutH" class="upx-h">About</h2>
                        <?php if ($isOwner): ?><a class="pf-link" href="profile.php">Edit</a><?php endif; ?>
                    </div>
                    <?php if ($pf['bio'] !== ''): ?>
                        <p class="pf-bio"><?php echo nl2br(dfEsc($pf['bio'])); ?></p>
                    <?php else: ?>
                        <p class="pf-bio is-empty"><?php echo $isOwner ? 'No bio yet.' : 'This student has not written a bio yet.'; ?></p>
                    <?php endif; ?>
                    <?php
                    echo dfRenderFacts([
                        ['Full name', $name],
                        ['Profession', $pf['profession']],
                        ['Program', $pf['program']],
                        ['Year level', dfYearLabel($pf['year_level'])],
                        ['Email', $showEmail ? '<a href="mailto:' . dfEsc($pf['email']) . '">' . dfEsc($pf['email']) . '</a>' : '', true],
                        ['Phone', $phone],
                        ['Student ID', ($isOwner || $canSeePrivate) ? $pf['student_code'] : ''],
                        ['Member since', $joined],
                    ]);
                    ?>
                </section>

                <section class="upx-card" aria-labelledby="pfLinksH">
                    <div class="pf-card-head">
                        <h2 id="pfLinksH" class="upx-h">Working profiles &amp; links</h2>
                        <?php if ($isOwner): ?><a class="pf-link" href="profile.php#links">Manage</a><?php endif; ?>
                    </div>
                    <?php echo !empty($pf['links']) ? dfRenderLinkRows($pf['links']) : '<p class="upx-muted">' . ($isOwner ? 'No links yet. Add your LinkedIn, GitHub or personal portfolio so people can find your work.' : 'No links added yet.') . '</p>'; ?>
                </section>

                <section class="upx-card" aria-labelledby="pfCertsH">
                    <div class="pf-card-head">
                        <h2 id="pfCertsH" class="upx-h">Certificates</h2>
                        <?php if ($isOwner): ?><a class="pf-link" href="profile.php#certificates">Manage</a><?php endif; ?>
                    </div>
                    <?php echo $pf['certificates'] ? dfRenderCertificates($pf['certificates'], false) : '<p class="upx-muted">' . ($isOwner ? 'No certificates yet.' : 'No certificates added yet.') . '</p>'; ?>
                </section>
            </div>

            <aside class="pf-side">
                <section class="upx-card" aria-labelledby="pfSkillsAllH">
                    <div class="pf-card-head">
                        <h2 id="pfSkillsAllH" class="upx-h">Skills</h2>
                        <?php if ($isOwner): ?><a class="pf-link" href="profile.php#skills">Manage</a><?php endif; ?>
                    </div>
                    <?php echo $pf['skills'] ? dfRenderSkillRows($pf['skills']) : '<p class="upx-muted">' . ($isOwner ? 'No skills yet.' : 'No skills listed yet.') . '</p>'; ?>
                </section>

                <section class="upx-card" aria-labelledby="pfBadgesH">
                    <h2 id="pfBadgesH" class="upx-h">Badges</h2>
                    <?php if (empty($pf['badges'])): ?>
                        <p class="upx-muted">No badges earned yet.</p>
                    <?php elseif (empty($pf['badges_shown'])): ?>
                        <p class="upx-muted">Badges are hidden on this profile.</p>
                    <?php else: ?>
                        <ul class="upx-badges">
                            <?php foreach ($pf['badges_shown'] as $bd): $tl = dfTiers()[$bd['tier']]['label']; ?>
                                <li><?php echo dfBadgeMedal($bd, true); ?><span><strong><?php echo dfEsc($bd['name']); ?></strong><small><?php echo dfEsc($tl); ?></small></span></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                    <?php if ((int) $pf['streak_best'] > 0): ?>
                        <p class="upx-muted upx-best">Current streak: <?php echo (int) $pf['streak']; ?> &middot; Best: <?php echo (int) $pf['streak_best']; ?> <?php echo (int) $pf['streak_best'] === 1 ? 'day' : 'days'; ?></p>
                    <?php endif; ?>
                </section>

                <section class="upx-card" aria-labelledby="pfNumbersH">
                    <h2 id="pfNumbersH" class="upx-h">By the numbers</h2>
                    <dl class="pf-numbers">
                        <div><dt>Projects</dt><dd><?php echo (int) $pf['project_count']; ?></dd></div>
                        <div><dt>Shared</dt><dd><?php echo (int) $sharedCount; ?></dd></div>
                        <div><dt>Appreciations</dt><dd><?php echo (int) $pf['like_total']; ?></dd></div>
                        <div><dt>Followers</dt><dd data-follower-count="<?php echo $uid; ?>"><?php echo (int) $pf['follower_count']; ?></dd></div>
                    </dl>
                </section>
            </aside>
        </div>
    </div>

    <!-- ============ FOLLOWERS / FOLLOWING (friends-list style) ============ -->
    <div class="pf-panel" role="tabpanel" id="panel-followers" data-pf-panel="followers" aria-labelledby="tab-followers" hidden>
        <section class="upx-card">
            <h2 class="upx-h">Followers</h2>
            <?php echo dfRenderPeopleList($followers, $viewerId, $viewerIsStudent, $viewerFollowing, $isOwner ? 'No followers yet. Post a project and people will start following you.' : 'No followers yet.'); ?>
            <?php if ((int) $pf['follower_count'] > DF_PEOPLE_LIMIT): ?><p class="upx-muted pf-limit">Showing the <?php echo DF_PEOPLE_LIMIT; ?> most recent.</p><?php endif; ?>
        </section>
    </div>

    <div class="pf-panel" role="tabpanel" id="panel-following" data-pf-panel="following" aria-labelledby="tab-following" hidden>
        <section class="upx-card">
            <h2 class="upx-h">Following</h2>
            <?php echo dfRenderPeopleList($following, $viewerId, $viewerIsStudent, $viewerFollowing, $isOwner ? 'You are not following anyone yet. Find students on the Discover feed.' : 'Not following anyone yet.'); ?>
            <?php if ((int) $pf['following_count'] > DF_PEOPLE_LIMIT): ?><p class="upx-muted pf-limit">Showing the <?php echo DF_PEOPLE_LIMIT; ?> most recent.</p><?php endif; ?>
        </section>
    </div>

    <?php if ($isOwner): ?>
    <!-- ============ MY PROJECTS (My Projects tab): edit and delete your uploads ============ -->
    <div class="pf-panel" role="tabpanel" id="panel-projects" data-pf-panel="projects" aria-labelledby="tab-projects" hidden>
        <?php echo dfRenderMyProjectsPanel($pdo, $uid); ?>
    </div>
    <?php endif; ?>
    <?php
    return ob_get_clean();
}
