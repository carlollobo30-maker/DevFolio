<?php
/**
 * Faculty view of the Badges & streak page.
 * Loads the shared page so every relative link stays inside faculty/.
 */
require __DIR__ . '/../student/badges.php';
