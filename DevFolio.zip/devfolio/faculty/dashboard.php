<?php
/**
 * Faculty Dashboard (Discover feed + faculty tools on the right)
 * DEVFOLIO CCDI Sorsogon
 *
 * Same browsing experience as the student dashboard (search, sort, infinite scroll,
 * appreciate, comment, share) plus a right sidebar with Quick Actions, a live Summary
 * and Projects by program.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/feed-filters.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'faculty') {
    header('Location: ../login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

$meId = (int) $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    // ---------- Feed: search / sort / paginate ----------
    if ($action === 'get_feed') {
        $offset = max(0, (int) ($_POST['offset'] ?? 0));
        $limit = 6;
        $q = trim((string) ($_POST['q'] ?? ''));
        $sort = $_POST['sort'] ?? 'latest';

        $where = "WHERE p.status = 'approved'";
        $filter = [];
        if ($q !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $where .= " AND (p.title LIKE :q1 OR p.description LIKE :q2 OR p.category LIKE :q3
                        OR CONCAT(u.first_name, ' ', u.last_name) LIKE :q4 OR CAST(p.tech_stack AS CHAR) LIKE :q5)";
            $filter = [':q1' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like, ':q5' => $like];
        }

        $where .= dfFeedFilterSql($_POST, $filter);   // Tags + release date

        $orderBy = 'p.created_at DESC, p.id DESC';
        if ($sort === 'oldest') $orderBy = 'p.created_at ASC, p.id ASC';
        if ($sort === 'appreciated') $orderBy = 'like_count DESC, p.created_at DESC, p.id DESC';

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM projects p INNER JOIN students s ON s.id = p.student_id INNER JOIN users u ON u.id = s.user_id $where");
        $countStmt->execute($filter);
        $total = (int) $countStmt->fetchColumn();

        $feedStmt = $pdo->prepare(dfProjectSelectSql() . " $where ORDER BY $orderBy LIMIT :lim OFFSET :off");
        foreach ($filter as $k => $v) $feedStmt->bindValue($k, $v);
        $feedStmt->bindValue(':me', $meId, PDO::PARAM_INT);
        $feedStmt->bindValue(':lim', $limit + 1, PDO::PARAM_INT);
        $feedStmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $feedStmt->execute();
        $rows = $feedStmt->fetchAll(PDO::FETCH_ASSOC);

        $hasMore = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);

        dfAttachPhotoCounts($pdo, $rows);
        dfAttachCollaborators($pdo, $rows);   // tagged team members on each post
        $html = '';
        foreach ($rows as $row) $html .= dfRenderCard($row);

        echo json_encode(['success' => true, 'html' => $html, 'count' => count($rows), 'total' => $total, 'has_more' => $hasMore, 'next_offset' => $offset + count($rows)]);
        exit;
    }

    // ---------- Appreciation (heart) toggle ----------
    if ($action === 'toggle_like') {
        $pid = (int) ($_POST['project_id'] ?? 0);
        $exists = $pdo->prepare("SELECT id FROM projects WHERE id = ? AND status = 'approved' LIMIT 1");
        $exists->execute([$pid]);
        if (!$exists->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Project not found.']);
            exit;
        }
        $has = $pdo->prepare('SELECT id FROM project_likes WHERE project_id = ? AND user_id = ? LIMIT 1');
        $has->execute([$pid, $meId]);
        if ($has->fetch()) {
            $pdo->prepare('DELETE FROM project_likes WHERE project_id = ? AND user_id = ?')->execute([$pid, $meId]);
            $liked = false;
        } else {
            $pdo->prepare('INSERT IGNORE INTO project_likes (project_id, user_id) VALUES (?, ?)')->execute([$pid, $meId]);
            $liked = true;
        }
        $cnt = $pdo->prepare('SELECT COUNT(*) FROM project_likes WHERE project_id = ?');
        $cnt->execute([$pid]);
        echo json_encode(['success' => true, 'liked' => $liked, 'count' => (int) $cnt->fetchColumn()]);
        exit;
    }

    echo json_encode(['success' => false, 'message' => 'Unknown action.']);
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover - DEVFOLIO Faculty</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $facActive = 'discover'; include __DIR__ . '/../includes/faculty-nav.php'; ?>

<main id="main" class="df-page">
    <section class="df-intro" aria-labelledby="pageTitle">
        <div>
            <p class="df-eyebrow">CCDI Faculty</p>
            <h1 id="pageTitle" class="df-h1">See what your students are building.</h1>
            <p class="fac-lede">Browse every showcased project, then use the top menu to review reports or open the student directory.</p>
        </div>
    </section>

    <div class="df-layout df-layout-fac">
        <!-- Gallery -->
        <section aria-labelledby="galleryTitle">
            <div class="df-toolbar" role="search">
                <div class="df-search">
                    <?php echo dfIcon('search', 18); ?>
                    <label for="feedSearch" class="df-sr">Search projects</label>
                    <input id="feedSearch" class="df-input" type="search" placeholder="Search projects, technologies or creators" autocomplete="off">
                </div>
                <?php echo dfFeedToolbarExtras(); ?>
                <div>
                    <label for="feedSort" class="df-sr">Sort projects</label>
                    <select id="feedSort" class="df-select">
                        <option value="latest">Latest projects</option>
                        <option value="appreciated">Most appreciated</option>
                        <option value="oldest">Oldest first</option>
                    </select>
                </div>
            </div>
            <?php echo dfFeedFilterPanels($pdo); ?>

            <div class="df-section-head">
                <h2 id="galleryTitle">Community projects</h2>
                <span class="df-count" id="feedCount" aria-live="polite"></span>
            </div>

            <div id="feed" class="df-grid"></div>

            <div id="feedSkeleton" class="df-grid" hidden aria-hidden="true">
                <div class="df-skel"><i style="height:44px;width:44px;border-radius:50%;margin:16px 16px 12px"></i><i style="height:12px;margin:0 16px 8px"></i><i style="height:12px;width:70%;margin:0 16px 16px"></i><i style="aspect-ratio:16/10"></i></div>
            </div>

            <div id="feedEnd" class="df-end" hidden>You're all caught up</div>
            <div id="feedSentinel" style="height:2px"></div>
        </section>

        <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
    </div>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>

<div id="dfToastHost" role="status" aria-live="polite"></div>
<?php include __DIR__ . '/../includes/social-ui.php'; ?>
<script src="../js/df-feed-filters.js"></script>
<script src="../js/df-social.js"></script>
<script src="../js/df-profile-card.js"></script>

<script>
(function () {
    // ---------- Toast ----------
    function toast(message, type) {
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        document.getElementById('dfToastHost').appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    function post(body) {
        return fetch(window.location.href, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body
        });
    }

    // ---------- Feed: search, sort, infinite scroll ----------
    var feedEl = document.getElementById('feed'), skel = document.getElementById('feedSkeleton');
    var endEl = document.getElementById('feedEnd'), countEl = document.getElementById('feedCount');
    var searchEl = document.getElementById('feedSearch'), sortEl = document.getElementById('feedSort');
    var state = { offset: 0, loading: false, done: false, token: 0 };

    function emptyState(q) {
        var wrap = document.createElement('div'); wrap.className = 'df-empty';
        var h = document.createElement('h3'), p = document.createElement('p');
        if (q) { h.textContent = 'No projects match your search or filters'; p.textContent = 'Try a different keyword, tag or date range.'; }
        else { h.textContent = 'No projects yet'; p.textContent = 'Student projects will appear here as soon as they are showcased.'; }
        wrap.appendChild(h); wrap.appendChild(p);
        if (q) {
            var clr = document.createElement('button'); clr.type = 'button'; clr.className = 'df-btn df-btn-primary';
            clr.textContent = 'Clear search and filters';
            clr.addEventListener('click', function () { searchEl.value = ''; if (window.DFFilters) DFFilters.reset(true); loadFeed(true); });
            wrap.appendChild(clr);
        }
        feedEl.appendChild(wrap);
    }

    async function loadFeed(reset) {
        if (reset) {
            state.token++; state.offset = 0; state.done = false; state.loading = false;
            feedEl.innerHTML = ''; endEl.hidden = true;
        }
        if (state.loading || state.done) return;
        state.loading = true;
        var token = state.token;
        skel.hidden = false;
        var q = searchEl.value.trim();
        try {
            var body = new URLSearchParams(Object.assign({ action: 'get_feed', offset: state.offset, q: q, sort: sortEl.value }, window.DFFilters ? DFFilters.params() : {}));
            var res = await post(body.toString());
            var data = await res.json();
            if (token !== state.token) return;
            if (!data.success) throw new Error('feed');
            feedEl.insertAdjacentHTML('beforeend', data.html);
            initCaptions(feedEl);
            state.offset = data.next_offset;
            countEl.textContent = data.total + (data.total === 1 ? ' project' : ' projects');
            if (!data.has_more) {
                state.done = true;
                if (data.total === 0) emptyState(q || (window.DFFilters && DFFilters.active())); else endEl.hidden = false;
            }
        } catch (err) {
            if (token === state.token) toast('Unable to load projects. Please try again.', 'err');
        } finally {
            if (token === state.token) { state.loading = false; skel.hidden = true; }
        }
    }

    var debounce;
    searchEl.addEventListener('input', function () { clearTimeout(debounce); debounce = setTimeout(function () { loadFeed(true); }, 300); });
    sortEl.addEventListener('change', function () { loadFeed(true); });
    if (window.DFFilters) DFFilters.onChange(function () { loadFeed(true); });
    new IntersectionObserver(function (en) { if (en[0].isIntersecting) loadFeed(); }, { rootMargin: '600px 0px' })
        .observe(document.getElementById('feedSentinel'));

    // ---------- Caption "See more" ----------
    function initCaptions(root) {
        (root || document).querySelectorAll('[data-caption]').forEach(function (cap) {
            var btn = cap.parentNode.querySelector('[data-seemore]');
            if (!btn || cap.dataset.ready) return;
            cap.dataset.ready = '1';
            if (cap.scrollHeight > cap.clientHeight + 1) btn.hidden = false;
        });
    }
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-seemore]');
        if (!btn) return;
        var cap = btn.parentNode.querySelector('[data-caption]');
        var open = cap.classList.toggle('is-open');
        btn.textContent = open ? 'See less' : 'See more';
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    window.addEventListener('resize', function () {
        document.querySelectorAll('[data-caption]:not(.is-open)').forEach(function (cap) {
            var btn = cap.parentNode.querySelector('[data-seemore]');
            if (btn) btn.hidden = !(cap.scrollHeight > cap.clientHeight + 1);
        });
    });

    // ---------- Appreciate (heart) ----------
    document.addEventListener('click', async function (e) {
        var like = e.target.closest('[data-like]');
        if (!like) return;
        var id = like.dataset.like;
        try {
            var r = await post(new URLSearchParams({ action: 'toggle_like', project_id: id }).toString());
            var d = await r.json();
            if (!d.success) { toast(d.message || 'Could not update.', 'err'); return; }
            document.querySelectorAll('[data-like="' + id + '"]').forEach(function (b) {
                b.setAttribute('aria-pressed', d.liked ? 'true' : 'false');
                b.querySelector('span').textContent = d.count > 0 ? d.count : '';
            });
        } catch (err) { toast('Could not update.', 'err'); }
    });

    loadFeed(true);
})();
</script>
</body>
</html>
