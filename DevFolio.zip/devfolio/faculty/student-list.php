<?php
/**
 * Faculty - Student Directory
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'faculty') {
    header('Location: ../login.php');
    exit;
}
require_once __DIR__ . '/../includes/project-helpers.php';

// ---- Filters (GET) ----
$dirPrograms = ['BSCS', 'BSIT', 'BSACT', 'BSIS'];
$dirYears = ['1st' => '1st Year', '2nd' => '2nd Year', '3rd' => '3rd Year', '4th' => '4th Year'];
$fProgram = in_array($_GET['program'] ?? '', $dirPrograms, true) ? $_GET['program'] : '';
$fYear = isset($dirYears[$_GET['year'] ?? '']) ? $_GET['year'] : '';
$fSearch = mb_substr(trim((string) ($_GET['q'] ?? '')), 0, 60);

// Every student account is listed, even one whose student record has not been filled in yet.
$where = ["u.role = 'student'"];
$args = [];
if ($fProgram !== '') { $where[] = 's.program = ?'; $args[] = $fProgram; }
if ($fYear !== '') { $where[] = 's.year_level = ?'; $args[] = $fYear; }
if ($fSearch !== '') {
    $like = '%' . addcslashes($fSearch, '%_\\') . '%';
    $where[] = "(CONCAT(u.first_name, ' ', u.last_name) LIKE ? OR s.student_id LIKE ?)";
    array_push($args, $like, $like);
}
$dirStmt = $pdo->prepare(
    "SELECT u.id AS user_id, u.first_name, u.last_name, u.avatar_url,
            s.student_id AS student_code, s.program, s.year_level,
            (SELECT COUNT(*) FROM projects p WHERE p.student_id = s.id AND p.status = 'approved') AS project_count
     FROM users u
     LEFT JOIN students s ON s.user_id = u.id
     WHERE " . implode(' AND ', $where) . "
     ORDER BY u.first_name ASC, u.last_name ASC
     LIMIT 200"
);
$dirStmt->execute($args);
$dirStudents = $dirStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Directory - DEVFOLIO Faculty</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $facActive = 'students'; include __DIR__ . '/../includes/faculty-nav.php'; ?>

<main id="main" class="df-page">
    <div class="df-layout df-layout-fac">
        <section aria-labelledby="dirTitle">
            <h1 id="dirTitle" class="text-3xl font-bold text-white mb-6">CCDI Student Directory</h1>

            <!-- Filters -->
            <form method="get" action="student-list.php" class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200 mb-8">
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                        <label for="dirProgram" class="block text-sm font-bold text-slate-700 mb-2">Program</label>
                        <select id="dirProgram" name="program" onchange="this.form.submit()" class="w-full px-4 py-2 rounded-lg border border-slate-300 text-slate-900">
                            <option value="">All Programs</option>
                            <?php foreach ($dirPrograms as $prog): ?>
                                <option value="<?php echo dfEsc($prog); ?>"<?php echo $fProgram === $prog ? ' selected' : ''; ?>><?php echo dfEsc($prog); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="dirYear" class="block text-sm font-bold text-slate-700 mb-2">Year Level</label>
                        <select id="dirYear" name="year" onchange="this.form.submit()" class="w-full px-4 py-2 rounded-lg border border-slate-300 text-slate-900">
                            <option value="">All Levels</option>
                            <?php foreach ($dirYears as $val => $label): ?>
                                <option value="<?php echo dfEsc($val); ?>"<?php echo $fYear === $val ? ' selected' : ''; ?>><?php echo dfEsc($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label for="dirSearch" class="block text-sm font-bold text-slate-700 mb-2">Search</label>
                        <input id="dirSearch" type="search" name="q" value="<?php echo dfEsc($fSearch); ?>" placeholder="Search student name or ID, then press Enter" class="w-full px-4 py-2 rounded-lg border border-slate-300 text-slate-900">
                    </div>
                </div>
                <?php if ($fProgram !== '' || $fYear !== '' || $fSearch !== ''): ?>
                    <p class="mt-4 text-sm text-slate-600"><a href="student-list.php" class="font-bold text-amber-600 hover:underline">Clear filters</a></p>
                <?php endif; ?>
            </form>

            <p class="text-sm text-slate-300 mb-4" aria-live="polite"><?php echo count($dirStudents); ?> <?php echo count($dirStudents) === 1 ? 'student' : 'students'; ?></p>

            <!-- Student Grid -->
            <?php if (!$dirStudents): ?>
                <div class="bg-white rounded-2xl p-8 border border-slate-200 text-center">
                    <h3 class="text-lg font-bold text-slate-900">No students found</h3>
                    <p class="text-sm text-slate-600 mt-1">Try a different program, year level or search.</p>
                </div>
            <?php else: ?>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <?php foreach ($dirStudents as $st):
                    $stName = dfOwnerName($st);
                    $stAvatar = dfAssetUrl($st['avatar_url'] ?? '');
                    $stYear = trim((string) ($st['year_level'] ?? ''));
                    if (preg_match('/^\d+(st|nd|rd|th)$/i', $stYear)) $stYear .= ' Year';
                    $stSub = implode(' · ', array_filter([trim((string) ($st['program'] ?? '')), $stYear], static function ($v) { return $v !== ''; }));
                    $stProjects = (int) $st['project_count'];
                ?>
                <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden hover:shadow-md transition">
                    <div class="bg-gradient-to-r from-slate-800 to-slate-900 h-24"></div>
                    <div class="px-6 py-4 text-center -mt-12 relative">
                        <?php if ($stAvatar !== ''): ?>
                            <img src="<?php echo dfEsc($stAvatar); ?>" alt="" class="w-20 h-20 rounded-full mx-auto mb-3 border-4 border-white shadow-md object-cover bg-slate-200" onerror="this.style.visibility='hidden'">
                        <?php else: ?>
                            <div class="w-20 h-20 rounded-full mx-auto mb-3 border-4 border-white shadow-md bg-slate-700 text-white flex items-center justify-center text-xl font-bold"><?php echo dfEsc(dfInitials($st['first_name'], $st['last_name'])); ?></div>
                        <?php endif; ?>
                        <h3 class="text-lg font-bold text-slate-900"><?php echo dfEsc($stName); ?></h3>
                        <p class="text-sm text-slate-600"><?php echo dfEsc($stSub !== '' ? $stSub : 'Student'); ?></p>
                        <?php if (!empty($st['student_code'])): ?><p class="text-xs text-amber-600 font-semibold mt-1"><?php echo dfEsc($st['student_code']); ?></p><?php endif; ?>
                        <p class="text-xs text-slate-500 mt-1"><?php echo $stProjects; ?> <?php echo $stProjects === 1 ? 'project' : 'projects'; ?> showcased</p>
                        <div class="mt-4 pt-4 border-t border-slate-100">
                            <a href="user.php?id=<?php echo (int) $st['user_id']; ?>" class="block w-full bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold py-2 rounded-lg text-sm transition">
                                <?php echo dfIcon('folder', 16); ?> View Portfolio
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </section>

        <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
    </div>
</main>
</body>
</html>
