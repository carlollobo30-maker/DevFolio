<?php
/**
 * Faculty view of a project page.
 * Loads the shared project page so faculty get the same experience as students,
 * while every relative link stays inside faculty/ (feed, comments, share).
 */
require __DIR__ . '/../student/project.php';
