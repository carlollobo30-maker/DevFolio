<?php
/**
 * Faculty view of a user's profile.
 * Loads the shared profile page so every relative link stays inside faculty/.
 */
require __DIR__ . '/../student/user.php';
