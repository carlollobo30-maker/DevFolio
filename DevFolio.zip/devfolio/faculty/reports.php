<?php
/**
 * Faculty: Project Reports
 * DEVFOLIO CCDI Sorsogon
 *
 * Students report projects from the feed. Faculty (and admin) review each report and choose:
 * dismiss, remove the project, warn the user, or ban the user for a set time or permanently.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'faculty') {
    header('Location: ../login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project Reports - DEVFOLIO Faculty</title>
    <!-- The moderation panel is built with Tailwind utility classes -->
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $facActive = 'reports'; include __DIR__ . '/../includes/faculty-nav.php'; ?>

<main id="main" class="df-page">
    <div class="df-layout df-layout-fac">
        <section class="fac-card" aria-label="Project reports">
            <?php $modEndpoint = '../includes/moderation-api.php'; include __DIR__ . '/../includes/moderation-panel.php'; ?>
        </section>

        <?php include __DIR__ . '/../includes/faculty-sidebar.php'; ?>
    </div>
</main>
</body>
</html>
