<?php
/**
 * Faculty endpoint for comments and shares (same logic as the student endpoint).
 * Loaded from faculty pages so the relative URL used by js/df-social.js resolves here.
 */
require __DIR__ . '/../student/project-actions.php';
