<?php
/**
 * Faculty endpoint for the profile hover card (same logic as the student endpoint).
 * Loaded from faculty pages so the relative URL used by js/df-profile-card.js resolves here.
 */
require __DIR__ . '/../student/profile-card.php';
