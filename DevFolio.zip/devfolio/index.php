<?php
header('Location: login.php');
exit;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DEVFOLIO | CCDI Sorsogon Student Showcase Platform</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/custom.css">
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        ccdi: {
                            navy: '#0A192F',
                            blue: '#0F2A4A',
                            gold: '#F59E0B',
                            goldDark: '#D97706',
                            goldLight: '#FEF3C7',
                            accent: '#1E3A8A',
                            bg: '#F8FAFC'
                        }
                    },
                    fontFamily: {
                        sans: ['Plus Jakarta Sans', 'sans-serif'],
                    }
                }
            }
        }
    </script>
</head>
<body class="bg-slate-50 text-slate-800 min-h-screen flex flex-col">

    <!-- HEADER & NAVIGATION -->
    <header class="bg-ccdi-navy text-white sticky top-0 z-40 shadow-lg border-b border-amber-500/30">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-20">
                <div class="flex items-center space-x-3">
                    <div class="w-12 h-12 bg-gradient-to-tr from-amber-500 to-amber-300 rounded-xl flex items-center justify-center text-ccdi-navy font-black text-xl shadow-md border border-amber-200">
                        <i class="fa-solid fa-graduation-cap"></i>
                    </div>
                    <div>
                        <div class="flex items-center space-x-2">
                            <span class="font-extrabold text-xl tracking-tight text-white">DEV<span class="text-amber-400">FOLIO</span></span>
                            <span class="text-[10px] bg-amber-500/20 text-amber-300 border border-amber-400/40 font-bold px-2 py-0.5 rounded-full uppercase tracking-wider">CCDI</span>
                        </div>
                        <p class="text-xs text-slate-300 font-medium">Computer Communication Development Institute - Sorsogon</p>
                    </div>
                </div>

                <nav class="hidden md:flex space-x-1 bg-slate-800/80 p-1.5 rounded-xl border border-slate-700">
                    <button onclick="switchView('showcase')" id="nav-showcase" class="nav-btn active flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold transition-all duration-200 text-white bg-ccdi-gold font-bold shadow-md">
                        <i class="fa-solid fa-globe"></i>
                        <span>Public Showcase</span>
                    </button>
                    <button onclick="switchView('student')" id="nav-student" class="nav-btn flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all duration-200">
                        <i class="fa-solid fa-user-graduate"></i>
                        <span>Student Portal</span>
                    </button>
                    <button onclick="switchView('faculty')" id="nav-faculty" class="nav-btn flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all duration-200">
                        <i class="fa-solid fa-user-shield"></i>
                        <span>Faculty Dashboard</span>
                    </button>
                    <button onclick="switchView('repository')" id="nav-repository" class="nav-btn flex items-center space-x-2 px-4 py-2 rounded-lg text-sm font-semibold text-slate-300 hover:text-white hover:bg-slate-700/60 transition-all duration-200">
                        <i class="fa-solid fa-folder-tree"></i>
                        <span>Project Repository</span>
                    </button>
                </nav>

                <div class="flex items-center space-x-3">
                    <div class="hidden sm:flex items-center space-x-2">
                        <a href="login.php" class="inline-flex items-center justify-center px-4 py-2 rounded-xl border border-slate-600 text-slate-200 hover:bg-slate-800 hover:text-white transition text-sm font-semibold">
                            <i class="fa-solid fa-right-to-bracket mr-2"></i>Sign In
                        </a>
                        <a href="register.php" class="inline-flex items-center justify-center px-4 py-2 rounded-xl bg-amber-500 text-slate-950 font-bold hover:bg-amber-600 transition text-sm shadow-md">
                            <i class="fa-solid fa-user-plus mr-2"></i>Register
                        </a>
                    </div>
                    <button onclick="openUploadModal()" class="hidden sm:flex items-center space-x-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-slate-950 font-bold px-4 py-2 rounded-lg text-sm shadow-md transition duration-150 transform active:scale-95">
                        <i class="fa-solid fa-cloud-arrow-up"></i>
                        <span>Submit Project</span>
                    </button>

                    <div class="relative flex items-center space-x-2 bg-slate-800/90 pl-3 pr-2 py-1.5 rounded-xl border border-slate-700">
                        <div class="text-right hidden sm:block">
                            <p class="text-xs font-bold text-white leading-none" id="currentUserRoleName">Jhon Mar (BSCS 4)</p>
                            <p class="text-[10px] text-amber-400 font-medium leading-tight" id="currentUserRoleTag">Student Account</p>
                        </div>
                        <img src="https://placehold.co/100x100/0f2a4a/ffffff?text=JM" alt="User Avatar" class="w-8 h-8 rounded-lg ring-2 ring-amber-400">
                    </div>
                </div>
            </div>
            
            <div class="md:hidden flex overflow-x-auto space-x-2 py-2 border-t border-slate-700/60">
                <button onclick="switchView('showcase')" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg bg-amber-500 text-slate-950 font-bold">Public Showcase</button>
                <button onclick="switchView('student')" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg text-slate-300 bg-slate-800">Student Portal</button>
                <button onclick="switchView('faculty')" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg text-slate-300 bg-slate-800">Faculty Panel</button>
                <button onclick="switchView('repository')" class="flex-shrink-0 text-xs px-3 py-1.5 rounded-lg text-slate-300 bg-slate-800">Repository</button>
            </div>
        </div>
    </header>

    <div id="toastContainer" class="fixed bottom-5 right-5 z-50 flex flex-col space-y-2 pointer-events-none"></div>

    <!-- MAIN CONTENT -->
    <main class="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8">

        <!-- VIEW 1: PUBLIC SHOWCASE -->
        <section id="view-showcase" class="view-section space-y-8">
            <div class="relative bg-gradient-to-r from-ccdi-navy via-ccdi-blue to-slate-900 rounded-3xl p-8 sm:p-10 text-white overflow-hidden shadow-2xl border border-amber-500/20">
                <div class="absolute -right-10 -bottom-10 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none"></div>
                <div class="relative z-10 max-w-3xl">
                    <div class="inline-flex items-center space-x-2 bg-amber-500/20 text-amber-300 px-3 py-1 rounded-full text-xs font-semibold mb-4 border border-amber-400/30">
                        <i class="fa-solid fa-award"></i>
                        <span>Official CCDI Academic Portfolio Showcase</span>
                    </div>
                    <h1 class="text-3xl sm:text-4xl lg:text-5xl font-black tracking-tight text-white mb-4">
                        Discover Cutting-Edge Systems Built by <span class="text-amber-400">CCDI Sorsogon</span> Talent.
                    </h1>
                    <p class="text-slate-300 text-sm sm:text-base leading-relaxed mb-6">
                        Bridging academic excellence with industry requirements. Explore defended capstone projects, full-stack software applications, research prototypes, and multimedia outputs created by Information Technology and Computer Science students.
                    </p>
                    <div class="flex flex-wrap gap-3">
                        <button onclick="switchView('repository')" class="bg-amber-500 hover:bg-amber-600 text-ccdi-navy font-bold px-5 py-2.5 rounded-xl text-sm transition shadow-lg flex items-center space-x-2">
                            <i class="fa-solid fa-magnifying-glass"></i>
                            <span>Explore All Projects</span>
                        </button>
                        <a href="login.php" class="bg-slate-800/80 hover:bg-slate-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm transition border border-slate-600 flex items-center space-x-2">
                            <i class="fa-solid fa-right-to-bracket text-amber-400"></i>
                            <span>Login to Portal</span>
                        </a>
                        <a href="register.php" class="bg-slate-800/80 hover:bg-slate-700 text-white font-semibold px-5 py-2.5 rounded-xl text-sm transition border border-slate-600 flex items-center space-x-2">
                            <i class="fa-solid fa-user-plus text-amber-400"></i>
                            <span>Create Account</span>
                        </a>
                    </div>
                </div>
            </div>

            <div class="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 space-y-4">
                <div class="flex flex-col md:flex-row gap-3 justify-between items-center">
                    <div class="relative w-full md:w-96">
                        <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-3.5 text-slate-400"></i>
                        <input type="text" id="showcaseSearchInput" onkeyup="filterShowcaseProjects()" placeholder="Search project title, stack, author, or keyword..." class="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 focus:outline-none focus:ring-2 focus:ring-amber-500 text-sm">
                    </div>

                    <div class="flex flex-wrap items-center gap-2 w-full md:w-auto">
                        <span class="text-xs font-bold text-slate-500 mr-1"><i class="fa-solid fa-filter"></i> Category:</span>
                        <button onclick="filterCategory('All')" class="cat-pill active-pill px-3 py-1.5 rounded-lg text-xs font-bold bg-ccdi-navy text-white">All</button>
                        <button onclick="filterCategory('Capstone System')" class="cat-pill px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 text-slate-600 hover:bg-slate-200">Capstones</button>
                        <button onclick="filterCategory('Web Application')" class="cat-pill px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 text-slate-600 hover:bg-slate-200">Web Apps</button>
                        <button onclick="filterCategory('Mobile App')" class="cat-pill px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 text-slate-600 hover:bg-slate-200">Mobile</button>
                        <button onclick="filterCategory('3D & Multimedia')" class="cat-pill px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 text-slate-600 hover:bg-slate-200">3D/Multimedia</button>
                    </div>
                </div>
            </div>

            <div id="featured-section">
                <div class="flex items-center justify-between mb-6">
                    <div>
                        <h2 class="text-xl font-bold text-slate-900 flex items-center gap-2">
                            <span class="w-2.5 h-6 bg-amber-500 rounded-full inline-block"></span>
                            Defended & Industry-Ready Projects
                        </h2>
                        <p class="text-xs text-slate-500 mt-0.5">Verified outputs evaluated and approved by CCDI Sorsogon Defense Panels</p>
                    </div>
                    <span class="text-xs font-semibold text-amber-700 bg-amber-100 px-3 py-1 rounded-full" id="showcaseCountBadge">Showing 4 Projects</span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="showcaseGrid">
                </div>
            </div>
        </section>

        <!-- VIEW 2: STUDENT PORTAL -->
        <section id="view-student" class="view-section hidden space-y-8">
            <div class="bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                <div class="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
                    <div class="flex items-center space-x-4">
                        <div class="relative">
                            <img src="https://placehold.co/120x120/0f2a4a/ffffff?text=JM" alt="Jhon Mar Profile" class="w-20 h-20 rounded-2xl object-cover ring-4 ring-amber-400">
                            <span class="absolute bottom-0 right-0 w-5 h-5 bg-emerald-500 border-2 border-white rounded-full"></span>
                        </div>
                        <div>
                            <div class="flex items-center space-x-2">
                                <h2 class="text-2xl font-bold text-slate-900">Jhon Mar D. Arcos</h2>
                                <span class="bg-blue-100 text-blue-800 text-xs font-bold px-2.5 py-0.5 rounded-full flex items-center gap-1">
                                    <i class="fa-solid fa-circle-check text-blue-600"></i> Verified CCDI Student
                                </span>
                            </div>
                            <p class="text-xs text-slate-600 font-medium mt-1">Bachelor of Science in Computer Science (BSCS) • 4th Year Senior</p>
                            <p class="text-xs text-slate-500 mt-0.5"><i class="fa-solid fa-id-card text-amber-500 mr-1"></i> Student ID: 2021-CCDI-0482</p>
                        </div>
                    </div>

                    <div class="flex flex-wrap gap-2 w-full md:w-auto">
                        <button onclick="openUploadModal()" class="flex-1 md:flex-initial bg-amber-500 hover:bg-amber-600 text-ccdi-navy font-bold px-4 py-2.5 rounded-xl text-sm shadow transition flex items-center justify-center space-x-2">
                            <i class="fa-solid fa-plus"></i>
                            <span>Upload New Project</span>
                        </button>
                        <button onclick="copyShareablePortfolioLink()" class="flex-1 md:flex-initial bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold px-4 py-2.5 rounded-xl text-sm transition flex items-center justify-center space-x-2 border border-slate-200">
                            <i class="fa-solid fa-share-nodes"></i>
                            <span>Share My Portfolio</span>
                        </button>
                    </div>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
                    <div class="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center text-xl">
                        <i class="fa-solid fa-folder-open"></i>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Total Submitted</p>
                        <h3 class="text-2xl font-bold text-slate-800" id="studentTotalProjectsCount">3</h3>
                    </div>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
                    <div class="w-12 h-12 bg-emerald-50 text-emerald-600 rounded-xl flex items-center justify-center text-xl">
                        <i class="fa-solid fa-circle-check"></i>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Approved & Live</p>
                        <h3 class="text-2xl font-bold text-slate-800">2</h3>
                    </div>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
                    <div class="w-12 h-12 bg-amber-50 text-amber-600 rounded-xl flex items-center justify-center text-xl">
                        <i class="fa-solid fa-clock-rotate-left"></i>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Faculty Reviewing</p>
                        <h3 class="text-2xl font-bold text-slate-800">1</h3>
                    </div>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm flex items-center space-x-4">
                    <div class="w-12 h-12 bg-purple-50 text-purple-600 rounded-xl flex items-center justify-center text-xl">
                        <i class="fa-solid fa-eye"></i>
                    </div>
                    <div>
                        <p class="text-xs text-slate-500 font-medium">Employer Views</p>
                        <h3 class="text-2xl font-bold text-slate-800">142</h3>
                    </div>
                </div>
            </div>

            <div class="space-y-4">
                <div class="flex justify-between items-center">
                    <h3 class="text-lg font-bold text-slate-900">My Uploaded Projects & Capstones</h3>
                    <button onclick="openUploadModal()" class="text-xs text-amber-700 font-bold hover:underline flex items-center gap-1">
                        <i class="fa-solid fa-plus"></i> Add New Entry
                    </button>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="studentProjectsGrid">
                </div>
            </div>
        </section>

        <!-- VIEW 3: FACULTY DASHBOARD -->
        <section id="view-faculty" class="view-section hidden space-y-8">
            <div class="bg-ccdi-navy text-white rounded-2xl p-6 shadow-md border border-amber-500/20 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <div>
                    <div class="flex items-center space-x-2">
                        <h2 class="text-2xl font-black text-white">Faculty Review & Accreditation Portal</h2>
                        <span class="bg-amber-500 text-slate-950 text-xs font-bold px-2.5 py-0.5 rounded-full">Evaluator Mode</span>
                    </div>
                    <p class="text-xs text-slate-300 mt-1">Logged in as: <strong class="text-white">Prof. E. Ramos, MSIT</strong> (CCDI Capstone Coordinator / Adviser)</p>
                </div>
                <button onclick="triggerToast('Accreditation report summary generated for CHED evaluation.', 'info')" class="bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold px-4 py-2 rounded-xl border border-slate-700 flex items-center gap-2">
                    <i class="fa-solid fa-file-pdf text-amber-400"></i> Export Accreditation Summary
                </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div class="text-xs text-slate-500 font-semibold uppercase">Total Defended Capstones</div>
                    <div class="text-3xl font-extrabold text-ccdi-navy mt-1">128</div>
                    <div class="text-[11px] text-emerald-600 mt-1 font-medium"><i class="fa-solid fa-arrow-trend-up"></i> AY 2025-2026 Cohort</div>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div class="text-xs text-slate-500 font-semibold uppercase">Showcased Digitally</div>
                    <div class="text-3xl font-extrabold text-emerald-600 mt-1">94%</div>
                    <div class="text-[11px] text-slate-500 mt-1 font-medium">Prevents project archiving loss</div>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div class="text-xs text-slate-500 font-semibold uppercase">Pending Evaluation</div>
                    <div class="text-3xl font-extrabold text-amber-600 mt-1" id="facultyPendingCount">2</div>
                    <div class="text-[11px] text-amber-700 mt-1 font-medium"><i class="fa-solid fa-clock"></i> Requires faculty review</div>
                </div>
                <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-sm">
                    <div class="text-xs text-slate-500 font-semibold uppercase">Employer Inquiries</div>
                    <div class="text-3xl font-extrabold text-purple-600 mt-1">45</div>
                    <div class="text-[11px] text-slate-500 mt-1 font-medium">Local & Bicol tech industry</div>
                </div>
            </div>

            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="p-5 border-b border-slate-100 flex justify-between items-center">
                    <div>
                        <h3 class="text-base font-bold text-slate-900">Student Submissions Pending Review</h3>
                        <p class="text-xs text-slate-500">Evaluate capstones before publishing to the public showcase</p>
                    </div>
                    <span class="bg-amber-100 text-amber-800 text-xs font-bold px-3 py-1 rounded-full">Faculty Action Needed</span>
                </div>

                <div class="overflow-x-auto">
                    <table class="w-full text-left text-xs">
                        <thead class="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase">
                            <tr>
                                <th class="p-4">Project Title</th>
                                <th class="p-4">Authors & Program</th>
                                <th class="p-4">Category</th>
                                <th class="p-4">Submission Date</th>
                                <th class="p-4">Status</th>
                                <th class="p-4 text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100" id="facultyReviewTable">
                        </tbody>
                    </table>
                </div>
            </div>
        </section>

        <!-- VIEW 4: REPOSITORY -->
        <section id="view-repository" class="view-section hidden space-y-6">
            <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm">
                <h2 class="text-xl font-bold text-slate-900 mb-1">CCDI Institutional Project Repository</h2>
                <p class="text-xs text-slate-500 mb-6">Complete archive of student outputs, thesis systems, and multimedia projects across school years.</p>

                <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-600 mb-1">Keyword Search</label>
                        <input type="text" id="repoSearch" onkeyup="filterRepository()" placeholder="Search title or tech..." class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-600 mb-1">Course Program</label>
                        <select id="repoCourseFilter" onchange="filterRepository()" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="ALL">All Programs</option>
                            <option value="BSCS">BSCS (Computer Science)</option>
                            <option value="BSIT">BSIT (Information Tech)</option>
                            <option value="ACT">ACT / Associate</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-600 mb-1">Project Type</label>
                        <select id="repoTypeFilter" onchange="filterRepository()" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="ALL">All Categories</option>
                            <option value="Capstone System">Capstone System</option>
                            <option value="Web Application">Web Application</option>
                            <option value="Mobile App">Mobile App</option>
                            <option value="3D & Multimedia">3D & Multimedia</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-600 mb-1">School Year</label>
                        <select id="repoYearFilter" onchange="filterRepository()" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="ALL">All Academic Years</option>
                            <option value="2025-2026">AY 2025 - 2026</option>
                            <option value="2024-2025">AY 2024 - 2025</option>
                            <option value="2023-2024">AY 2023 - 2024</option>
                        </select>
                    </div>
                </div>
            </div>

            <div class="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
                <div class="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center text-xs font-bold text-slate-600">
                    <span id="repoResultsCount">Showing all archived projects</span>
                    <i class="fa-solid fa-database text-amber-500"></i>
                </div>
                <div class="divide-y divide-slate-100" id="repositoryList">
                </div>
            </div>
        </section>

    </main>

    <!-- MODALS -->
    <div id="projectModal" class="fixed inset-0 z-50 hidden bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-3xl max-w-3xl w-full overflow-hidden shadow-2xl border border-slate-100 my-8 animate-fade-in">
            <div class="relative bg-ccdi-navy text-white p-6 sm:p-8">
                <button onclick="closeModal('projectModal')" class="absolute top-4 right-4 w-9 h-9 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white transition">
                    <i class="fa-solid fa-xmark"></i>
                </button>
                <div class="inline-block bg-amber-500 text-ccdi-navy text-xs font-bold px-3 py-1 rounded-full mb-3" id="modalCategory">Capstone System</div>
                <h2 class="text-2xl sm:text-3xl font-black text-white" id="modalTitle">Project Title</h2>
                <p class="text-xs text-amber-300 font-semibold mt-1" id="modalCourseCode">CS 412 - Final Capstone Project • AY 2025-2026</p>
            </div>

            <div class="p-6 sm:p-8 space-y-6 max-h-[70vh] overflow-y-auto">
                <div class="rounded-2xl overflow-hidden bg-slate-100 border border-slate-200 max-h-72">
                    <img id="modalImage" src="" alt="Project Banner" class="w-full h-full object-cover">
                </div>

                <div>
                    <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Project Abstract & Overview</h4>
                    <p class="text-sm text-slate-700 leading-relaxed" id="modalAbstract">Detailed abstract content goes here...</p>
                </div>

                <div>
                    <h4 class="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Technologies Used</h4>
                    <div class="flex flex-wrap gap-2" id="modalTechStack"></div>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div>
                        <h4 class="text-xs font-bold text-slate-400 uppercase">Student Authors</h4>
                        <p class="text-xs font-bold text-slate-800 mt-1" id="modalAuthors">Jhon Mar, Maria Santos, Alex Perez</p>
                        <p class="text-[11px] text-slate-500">CCDI Sorsogon Senior Batch</p>
                    </div>
                    <div>
                        <h4 class="text-xs font-bold text-slate-400 uppercase">Faculty Panel Adviser</h4>
                        <p class="text-xs font-bold text-slate-800 mt-1" id="modalAdviser">Prof. E. Ramos, MSIT</p>
                        <p class="text-[11px] text-emerald-600 font-semibold"><i class="fa-solid fa-circle-check"></i> Defended & Approved</p>
                    </div>
                </div>

                <div class="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-3">
                    <a id="modalDemoLink" href="#" target="_blank" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-5 py-2.5 rounded-xl text-sm transition inline-flex items-center space-x-2">
                        <i class="fa-solid fa-arrow-up-right-from-square"></i>
                        <span>Launch Live System Demo</span>
                    </a>
                    <button onclick="requestEmployerContact()" class="bg-ccdi-navy hover:bg-slate-800 text-white font-semibold px-5 py-2.5 rounded-xl text-sm transition inline-flex items-center space-x-2">
                        <i class="fa-solid fa-envelope"></i>
                        <span>Contact Student / Hire Request</span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <div id="uploadModal" class="fixed inset-0 z-50 hidden bg-slate-950/70 backdrop-blur-sm flex items-center justify-center p-4 overflow-y-auto">
        <div class="bg-white rounded-3xl max-w-2xl w-full overflow-hidden shadow-2xl border border-slate-100 my-8">
            <div class="bg-ccdi-navy text-white p-6 flex justify-between items-center border-b border-amber-500/30">
                <div>
                    <h3 class="text-xl font-bold text-white">Submit New CCDI Project</h3>
                    <p class="text-xs text-slate-300">Publish your capstone, app, or creative output to DEVFOLIO</p>
                </div>
                <button onclick="closeModal('uploadModal')" class="w-8 h-8 bg-white/10 hover:bg-white/20 rounded-full flex items-center justify-center text-white">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <form id="projectUploadForm" onsubmit="handleProjectSubmit(event)" class="p-6 space-y-4 max-h-[75vh] overflow-y-auto">
                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Project Title *</label>
                    <input type="text" id="formTitle" required placeholder="e.g. Sorsogon Coastal Threat Detection System" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Category *</label>
                        <select id="formCategory" required class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none bg-white">
                            <option value="Capstone System">Capstone System</option>
                            <option value="Web Application">Web Application</option>
                            <option value="Mobile App">Mobile App</option>
                            <option value="3D & Multimedia">3D & Multimedia</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Course / Subject Code *</label>
                        <input type="text" id="formCourseCode" required placeholder="e.g. CS 412 - Capstone 2" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Project Abstract / Summary *</label>
                    <textarea id="formAbstract" required rows="3" placeholder="Brief explanation of the project scope, problem solved, and technical features..." class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none"></textarea>
                </div>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Tech Stack (Comma Separated) *</label>
                        <input type="text" id="formTechStack" required placeholder="e.g. React, PHP, MySQL, Tailwind" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-slate-700 mb-1">Demo / Repository Link</label>
                        <input type="url" id="formDemoLink" placeholder="https://github.com/or-demo-link" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold text-slate-700 mb-1">Project Banner / Preview Image URL</label>
                    <input type="url" id="formImage" placeholder="https://placehold.co/600x400/0f2a4a/ffffff?text=Project+Preview" class="w-full p-2.5 rounded-xl border border-slate-200 text-xs focus:ring-2 focus:ring-amber-500 outline-none">
                    <p class="text-[10px] text-slate-400 mt-0.5">Leave empty for a auto-generated CCDI preview placeholder.</p>
                </div>

                <div class="pt-4 border-t border-slate-100 flex justify-end space-x-2">
                    <button type="button" onclick="closeModal('uploadModal')" class="px-4 py-2 text-xs font-bold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition">Cancel</button>
                    <button type="submit" class="px-5 py-2 text-xs font-bold text-ccdi-navy bg-amber-500 hover:bg-amber-600 rounded-xl shadow transition">Submit for Faculty Review</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script src="js/main.js"></script>
    <script src="js/public-showcase.js"></script>
    <script src="js/student-dash.js"></script>
    <script src="js/faculty-dash.js"></script>
    <script src="js/repository.js"></script>

    <script>
        window.onload = function() {
            renderShowcaseProjects();
            renderStudentProjects();
            renderFacultyTable();
            renderRepository();
        };
    </script>
</body>
</html>
