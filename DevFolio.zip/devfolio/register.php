<?php
/**
 * DEVFOLIO Student Registration Page
 * CCDI Sorsogon Student Showcase Platform
 */

session_start();
require_once __DIR__ . '/includes/db_connect.php';

$errors = [];
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $firstName = trim($_POST['firstname'] ?? '');
    $lastName = trim($_POST['lastname'] ?? '');
    $studentId = trim($_POST['student_id'] ?? '');
    $program = trim($_POST['program'] ?? '');
    $yearLevel = trim($_POST['year_level'] ?? '');
    $adviser = trim($_POST['adviser'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $agreeTerms = isset($_POST['agree_terms']);

    if (empty($firstName) || empty($lastName) || empty($studentId) || empty($program) || empty($yearLevel) || empty($email) || empty($password) || empty($confirmPassword)) {
        $errors[] = 'Please fill in all required fields.';
    }

    if (!$agreeTerms) {
        $errors[] = 'You must agree to the terms and privacy policy.';
    }

    if ($password !== $confirmPassword) {
        $errors[] = 'Passwords do not match.';
    }

    if (strlen($password) < 8) {
        $errors[] = 'Password must be at least 8 characters long.';
    }

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if (preg_match('/^(?=.*[A-Z])(?=.*\d).{8,}$/', $password) !== 1) {
        $errors[] = 'Password must be at least 8 characters and include at least one uppercase letter and one number.';
    }

    if (empty($errors)) {
        $checkStmt = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
        $checkStmt->execute([$email]);

        if ($checkStmt->fetch()) {
            $errors[] = 'This email is already registered.';
        }

        $studentCheckStmt = $pdo->prepare('SELECT id FROM students WHERE student_id = ? LIMIT 1');
        $studentCheckStmt->execute([$studentId]);

        if ($studentCheckStmt->fetch()) {
            $errors[] = 'This student ID is already registered.';
        }
    }

    if (empty($errors)) {
        $userStmt = $pdo->prepare(
            'INSERT INTO users (email, password_hash, first_name, last_name, role, phone, is_verified) VALUES (?, SHA2(?, 256), ?, ?, ?, ?, TRUE)'
        );

        $userStmt->execute([
            $email,
            $password,
            $firstName,
            $lastName,
            'student',
            $phone
        ]);

        $userId = $pdo->lastInsertId();

        $studentStmt = $pdo->prepare(
            'INSERT INTO students (user_id, student_id, program, year_level, adviser_id, enrollment_status) VALUES (?, ?, ?, ?, NULL, "active")'
        );

        $studentStmt->execute([$userId, $studentId, $program, $yearLevel]);

        header('Location: login.php?registered=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - DEVFOLIO CCDI</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/ccdi-theme.css">
</head>
<body class="auth-page">
    <div class="auth-layout" style="flex-direction:column; gap:16px;">
        <div class="auth-brand auth-center" style="max-width:none;">
            <h1 style="font-size:2.25rem;">DEVFOLIO</h1>
        </div>
        <div class="auth-card wide">
            <div class="mb-4">
                <h2 class="text-2xl font-bold" style="color:#050505;">Create a new account</h2>
                <p class="text-sm" style="color:#65676b;">Student registration &middot; it's quick and easy.</p>
            </div>
            <hr class="auth-divider" style="margin-top:0;">
            <div>
                <?php if (!empty($errors)): ?>
                    <div class="mb-5 p-3 bg-red-100 border border-red-300 text-red-700 rounded-xl text-sm">
                        <ul class="list-disc list-inside space-y-1">
                            <?php foreach ($errors as $error): ?>
                                <li><?php echo htmlspecialchars($error); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="POST" action="register.php" class="space-y-5">
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">First Name *</label>
                            <input type="text" name="firstname" required placeholder="enter first name" value="<?php echo htmlspecialchars($_POST['firstname'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Last Name *</label>
                            <input type="text" name="lastname" required placeholder="Enter last name" value="<?php echo htmlspecialchars($_POST['lastname'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Student ID *</label>
                            <input type="text" name="student_id" required placeholder="YEAR-CCDI-XX-XXX" value="<?php echo htmlspecialchars($_POST['student_id'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Program / Course *</label>
                            <select name="program" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm bg-white">
                                <option value="">Select Program</option>
                                <option value="BSCS" <?php echo (($_POST['program'] ?? '') === 'BSCS') ? 'selected' : ''; ?>>BSCS - Bachelor of Science in Computer Science</option>
                                <option value="BSIT" <?php echo (($_POST['program'] ?? '') === 'BSIT') ? 'selected' : ''; ?>>BSIT - Bachelor of Science in Information Technology</option>
                                <option value="BSACT" <?php echo (($_POST['program'] ?? '') === 'BSACT') ? 'selected' : ''; ?>>BSACT - Bachelor of Science in Associate in Computer Technology</option>
                                <option value="BSIS" <?php echo (($_POST['program'] ?? '') === 'BSIS') ? 'selected' : ''; ?>>BSIS - Bachelor of Science in Information System</option>
                            </select>
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Year Level *</label>
                            <select name="year_level" required class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm bg-white">
                                <option value="">Select Year</option>
                                <option value="1st" <?php echo (($_POST['year_level'] ?? '') === '1st') ? 'selected' : ''; ?>>1st Year</option>
                                <option value="2nd" <?php echo (($_POST['year_level'] ?? '') === '2nd') ? 'selected' : ''; ?>>2nd Year</option>
                                <option value="3rd" <?php echo (($_POST['year_level'] ?? '') === '3rd') ? 'selected' : ''; ?>>3rd Year</option>
                                <option value="4th" <?php echo (($_POST['year_level'] ?? '') === '4th') ? 'selected' : ''; ?>>4th Year</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Faculty Adviser</label>
                            <input type="text" name="adviser" placeholder="ProF/instructor" value="<?php echo htmlspecialchars($_POST['adviser'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Email Address *</label>
                            <input type="email" name="email" required placeholder="Enter email address" value="<?php echo htmlspecialchars($_POST['email'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Phone Number</label>
                            <input type="tel" name="phone" placeholder="Enter phone number" value="<?php echo htmlspecialchars($_POST['phone'] ?? ''); ?>"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                    </div>

                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Password *</label>
                            <input type="password" name="password" required placeholder="••••••••"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                            <p class="text-[11px] text-slate-500 mt-1">Minimum 8 characters with uppercase and numbers</p>
                        </div>
                        <div>
                            <label class="block text-sm font-bold text-slate-700 mb-1">Confirm Password *</label>
                            <input type="password" name="confirm_password" required placeholder="••••••••"
                                   class="w-full px-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-sky-500 transition text-sm">
                        </div>
                    </div>

                    <div class="bg-blue-50 border border-blue-200 rounded-xl p-4">
                        <label class="flex items-start space-x-3 cursor-pointer">
                            <input type="checkbox" name="agree_terms" required class="w-5 h-5 rounded mt-0.5">
                            <span class="text-sm text-slate-700">
                                I agree to the <a href="#" class="text-sky-600 hover:text-sky-700 font-semibold">Terms of Service</a> and <a href="#" class="text-sky-600 hover:text-sky-700 font-semibold">Privacy Policy</a> of DEVFOLIO CCDI
                            </span>
                        </label>
                    </div>

                    <div class="flex items-center justify-between gap-3 pt-2">
                        <a href="login.php" class="text-sm font-semibold" style="color:#2563eb; text-decoration:none;">Already have an account?</a>
                        <button type="submit" class="auth-btn green">Sign Up</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
