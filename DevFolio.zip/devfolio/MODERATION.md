# Posting and Moderation

There is **no approval step**. Students post directly and the project is on the feed immediately.
Community reports keep the showcase safe.

## Students
- **Post Project** (Discover page or My Projects) publishes right away.
- Every project (except your own) shows a small red flag with **Report**.
  Reasons: sexual harassment, harassment or bullying, hate speech or discrimination, violence or threats,
  nudity or sexual content, plagiarism or copied work, spam or scam, or **Others, Specify** (type the reason).
  You can add optional details. One open report per project per student, max 10 reports per day.
- Notices from moderators (warnings, removed projects, bans) arrive in the notification bell.

## Faculty and admin
- Faculty: **Project Reports** tab (red badge = open reports). Admin: **Moderation** tab. Same panel, same logic
  (`includes/moderation-panel.php`, `includes/moderation-api.php`).
- Open **View reported project** to see the full project, then **Take action**:
  1. **Dismiss report**: no violation.
  2. **Remove the project**: hidden from everyone; the owner is told why (reason required).
  3. **Give the user a warning**: message sent to the user; the project stays.
  4. **Ban the user**: 1, 3, 7, 14, 30 or 90 days, or **Permanent**. Optional "also remove the reported project".
     A banned user is signed out on their next click and cannot log in; the login screen shows how long and why.
- **Active bans** are listed under the reports with a **Lift ban** button. Timed bans end by themselves.
- Removing a project also closes other open reports on that same project.

## Technical notes
- New tables (auto-created on first page load, also in `database/schema.sql`): `project_reports`, `user_sanctions`.
- `projects.status` gained `removed`. On first load, old `pending` projects are published and old `rejected`
  projects become `removed` (their old reason is still shown to the owner).
- Owners cannot edit a removed project (so it cannot be re-published); they can still delete it.
- Report rows keep a copy of the project title, so the record survives if the owner deletes the project.
