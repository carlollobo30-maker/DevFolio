<?php
session_start();
require_once __DIR__ . '/includes/db_connect.php';

if (isset($_SESSION['user_id'])) {
    if ($_SESSION['role'] === 'admin') {
        header('Location: admin/dashboard.php');
    } elseif ($_SESSION['role'] === 'faculty') {
        header('Location: faculty/dashboard.php');
    } else {
        header('Location: student/dashboard.php');
    }
    exit;
}

$error = '';
$success = '';

if (isset($_GET['banned'])) {
    $error = 'Your account has been banned by a moderator. Sign in to see how long and why.';
}

if (isset($_GET['registered']) && $_GET['registered'] === '1') {
    $success = 'Registration successful! Please log in to continue.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        $dfBanOnLogin = ($user && $user['password_hash'] === hash('sha256', $password)) ? dfActiveBan($pdo, (int) $user['id']) : null;

        if ($dfBanOnLogin) {
            $error = dfBanMessage($dfBanOnLogin);
        } elseif ($user && $user['password_hash'] === hash('sha256', $password)) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['first_name'] = $user['first_name'];
            $_SESSION['last_name'] = $user['last_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['email'] = $user['email'];

            if ($user['role'] === 'admin') {
                header('Location: admin/dashboard.php');
            } elseif ($user['role'] === 'faculty') {
                header('Location: faculty/dashboard.php');
            } else {
                header('Location: student/dashboard.php');
            }
            exit;
        } else {
            $error = 'Mali ang email o password mo, ka-CCDI!';
        }
    } else {
        $error = 'Paki-fill up ang lahat ng fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - DEVFOLIO (CCDI Sorsogon)</title>
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body { height: 100%; }
        body {
            font-family: 'Segoe UI', Helvetica, Arial, sans-serif;
            background: #0a192f;
            color: #ffffff;
        }

        .split { display: flex; min-height: 100vh; }

        /* ---------- LEFT 50%: static dark blue panel ---------- */
        .hero {
            position: relative;
            width: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #0a192f;
            background-image:
                radial-gradient(circle at 50% 38%, rgba(37, 99, 235, 0.35) 0%, rgba(15, 42, 74, 0.6) 35%, rgba(7, 20, 38, 0) 70%),
                linear-gradient(rgba(255, 255, 255, 0.04) 1px, transparent 1px),
                linear-gradient(90deg, rgba(255, 255, 255, 0.04) 1px, transparent 1px);
            background-size: auto, 44px 44px, 44px 44px;
            border-right: 1px solid rgba(255, 255, 255, 0.08);
        }
        .hero-content {
            position: relative;
            z-index: 1;
            text-align: center;
            padding: 32px;
        }
        .hero-content img {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255, 255, 255, 0.85);
            margin-bottom: 14px;
        }
        .hero-content h2 { font-size: 2.25rem; font-weight: 800; letter-spacing: 0.06em; }
        .hero-content p { margin-top: 6px; font-size: 1rem; color: #cbd5e1; }

        /* ---------- RIGHT 50%: login ---------- */
        .panel {
            width: 50%;
            background: #0a192f;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 40px 32px;
        }
        .panel-inner { width: 100%; max-width: 400px; }
        .panel h1 { font-size: 2rem; font-weight: 800; line-height: 1.2; color: #ffffff; }
        .panel .sub { margin-top: 8px; margin-bottom: 28px; color: #94a3b8; font-size: 0.95rem; }

        label { display: block; font-size: 0.85rem; font-weight: 600; color: #cbd5e1; margin-bottom: 6px; }
        input[type="email"], input[type="password"] {
            width: 100%;
            padding: 13px 14px;
            margin-bottom: 18px;
            font-size: 1rem;
            color: #0a192f;
            background: #ffffff;
            border: 2px solid transparent;
            border-radius: 8px;
            outline: none;
        }
        input::placeholder { color: #94a3b8; }
        input:focus { border-color: #60a5fa; }

        .btn {
            display: block;
            width: 100%;
            padding: 13px;
            font-size: 1rem;
            font-weight: 700;
            text-align: center;
            text-decoration: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background 0.15s ease, color 0.15s ease;
        }
        .btn-primary { background: #ffffff; color: #0a192f; border: 2px solid #ffffff; }
        .btn-primary:hover { background: #e2e8f0; border-color: #e2e8f0; }
        .btn-outline { background: transparent; color: #ffffff; border: 2px solid #ffffff; }
        .btn-outline:hover { background: rgba(255, 255, 255, 0.1); }

        .divider { display: flex; align-items: center; gap: 12px; margin: 22px 0; color: #64748b; font-size: 0.8rem; }
        .divider::before, .divider::after { content: ""; flex: 1; height: 1px; background: #1e3a5f; }

        .alert { padding: 11px 14px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 18px; }
        .alert.error { background: #fee2e2; color: #991b1b; }
        .alert.ok { background: #dcfce7; color: #166534; }

        /* ---------- Mobile: stack, animation on top ---------- */
        @media (max-width: 820px) {
            .split { flex-direction: column; }
            .hero { width: 100%; height: 240px; border-right: 0; }
            .hero-content { padding: 16px; }
            .hero-content img { width: 60px; height: 60px; margin-bottom: 8px; }
            .hero-content h2 { font-size: 1.6rem; }
            .hero-content p { font-size: 0.85rem; }
            .panel { width: 100%; padding: 32px 20px 48px; }
        }
    </style>
</head>
<body>
    <div class="split">
        <section class="hero">

            <div class="hero-content">
                <img src="assets/img/Logologin.jpg" alt="CCDI logo">
                <h2>DEVFOLIO</h2>
                <p>CCDI Sorsogon Student Showcase Platform</p>
            </div>
        </section>

        <section class="panel">
            <div class="panel-inner">
                <h1>Welcome to Devfolio!</h1>
                <p class="sub">Log in to showcase and manage your projects.</p>

                <?php if (!empty($success)): ?>
                    <div class="alert ok"><?php echo $success; ?></div>
                <?php endif; ?>

                <?php if (!empty($error)): ?>
                    <div class="alert error"><?php echo $error; ?></div>
                <?php endif; ?>

                <form action="login.php" method="POST">
                    <label for="email">Email Address</label>
                    <input type="email" id="email" name="email" required placeholder="Enter your email">

                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" required placeholder="Enter your password">

                    <button type="submit" class="btn btn-primary">Log In</button>
                </form>

                <div class="divider">or</div>

                <a href="register.php" class="btn btn-outline">Create student account</a>
            </div>
        </section>
    </div>
</body>
</html>
