<?php
/**
 * Student notification endpoint (JSON).
 * POST action=mark_read  -> marks all of the signed-in student's notifications as read.
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    http_response_code(403);
    echo json_encode(['success' => false]);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'mark_read') {
    $st = $pdo->prepare('UPDATE notifications SET is_read = TRUE WHERE user_id = ? AND is_read = FALSE');
    $st->execute([$_SESSION['user_id']]);
    echo json_encode(['success' => true]);
    exit;
}

echo json_encode(['success' => false]);
