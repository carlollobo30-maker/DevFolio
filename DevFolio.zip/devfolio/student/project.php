<?php
/**
 * Project page (full view, opens in its own browser tab from the feed)
 * DEVFOLIO CCDI Sorsogon
 *
 * Visible to signed-in students and faculty when the project is approved
 * (faculty open it through faculty/project.php, which loads this file).
 * The owner can also open their own project if a moderator removed it (a notice is shown).
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/project-form.php';   // README helpers
require_once __DIR__ . '/../includes/profile-links.php';  // creator's + collaborators' LinkedIn / portfolio links

$dfRole = $_SESSION['role'] ?? '';
if (!isset($_SESSION['user_id']) || !in_array($dfRole, ['student', 'faculty'], true)) {
    header('Location: ../login.php');
    exit;
}

$meId = (int) $_SESSION['user_id'];
$projectId = (int) ($_GET['id'] ?? $_POST['project_id'] ?? 0);

// Each role browses from its own folder (student/ or faculty/) so every relative link
// (back to the feed, comments, share) stays inside that role. faculty/project.php loads this file.
$dfInFacultyDir = basename(dirname((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''))) === 'faculty';
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $dfRole === 'faculty' && !$dfInFacultyDir) {
    header('Location: ../faculty/project.php?id=' . $projectId);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] === 'GET' && $dfRole === 'student' && $dfInFacultyDir) {
    header('Location: ../student/project.php?id=' . $projectId);
    exit;
}
$isFaculty = $dfRole === 'faculty';

// ---------- Appreciation (heart) toggle ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'toggle_like') {
    header('Content-Type: application/json');
    $exists = $pdo->prepare("SELECT id FROM projects WHERE id = ? AND status = 'approved' LIMIT 1");
    $exists->execute([$projectId]);
    if (!$exists->fetch()) {
        echo json_encode(['success' => false, 'message' => 'Project not found.']);
        exit;
    }
    $has = $pdo->prepare('SELECT id FROM project_likes WHERE project_id = ? AND user_id = ? LIMIT 1');
    $has->execute([$projectId, $meId]);
    if ($has->fetch()) {
        $pdo->prepare('DELETE FROM project_likes WHERE project_id = ? AND user_id = ?')->execute([$projectId, $meId]);
        $liked = false;
    } else {
        $pdo->prepare('INSERT IGNORE INTO project_likes (project_id, user_id) VALUES (?, ?)')->execute([$projectId, $meId]);
        $liked = true;
    }
    $cnt = $pdo->prepare('SELECT COUNT(*) FROM project_likes WHERE project_id = ?');
    $cnt->execute([$projectId]);
    echo json_encode(['success' => true, 'liked' => $liked, 'count' => (int) $cnt->fetchColumn()]);
    exit;
}

// ---------- Load the project ----------
$st = $pdo->prepare(dfProjectSelectSql() . " WHERE p.id = :pid AND (p.status = 'approved' OR (p.status = 'removed' AND u.id = :owner)) LIMIT 1");
$st->bindValue(':me', $meId, PDO::PARAM_INT);
$st->bindValue(':pid', $projectId, PDO::PARAM_INT);
$st->bindValue(':owner', $meId, PDO::PARAM_INT);
$st->execute();
$p = $st->fetch(PDO::FETCH_ASSOC);

$notFound = !$p;
if ($notFound) http_response_code(404);

$files = [];
$readmeText = '';
$links = [];
$tags = [];
$desc = '';
if (!$notFound) {
    $files = dfFilesFor($pdo, [(int) $p['id']])[(int) $p['id']] ?? [];
    $readmeText = dfLoadReadme($pdo, (int) $p['id']);
    $tags = dfTags($p['tech_stack'] ?? null);
    $desc = trim((string) ($p['description'] ?? ''));
    if ($desc === '') $desc = trim((string) ($p['abstract'] ?? ''));
    foreach ([$p['demo_link'] ?? '', $p['repository_link'] ?? ''] as $rawLink) {
        $safe = dfSafeLink($rawLink);
        if ($safe !== '' && !in_array($safe, $links, true)) $links[] = $safe;
    }
}
$isApproved = !$notFound && $p['status'] === 'approved';
$isOwner = !$notFound && (int) $p['owner_user_id'] === $meId;

// Why a moderator removed it (shown to the owner only)
$removalNote = '';
if (!$notFound && !$isApproved) {
    $rn = $pdo->prepare("SELECT resolution_note FROM project_reports WHERE project_id = ? AND action_taken IN ('remove', 'ban') AND resolution_note IS NOT NULL ORDER BY handled_at DESC, id DESC LIMIT 1");
    $rn->execute([(int) $p['id']]);
    $removalNote = (string) ($rn->fetchColumn() ?: ($p['rejection_reason'] ?? ''));
}

// Short tagline = first sentence of the description (max ~160 characters)
$tagline = '';
if (!$notFound && $desc !== '') {
    $first = preg_split('/(?<=[.!?])\s+/', $desc, 2)[0] ?? $desc;
    $tagline = mb_strlen($first) > 160 ? rtrim(mb_substr($first, 0, 157)) . '…' : $first;
}

// Real project photo, if one was uploaded (placeholder images don't count)
$photo = '';
if (!$notFound) {
    $photo = dfAssetUrl($p['banner_image_url'] ?? '');
    if ($photo !== '' && stripos($photo, 'placehold.co') !== false) $photo = '';
}
// Every photo of the project, cover first (the old single cover counts as one photo)
$photos = [];
if (!$notFound) {
    foreach (dfPhotosFor($pdo, [$p])[(int) $p['id']] ?? [] as $ph) {
        $u = dfAssetUrl($ph['path']);
        if ($u !== '') $photos[] = $u;
    }
    if ($photos) $photo = $photos[0];
}
// The creator's working profiles (LinkedIn, GitHub, portfolio...), shown at the top right
$ownerLinks = $notFound ? [] : dfFetchLinks($pdo, (int) $p['owner_user_id']);
$ownerFirst = $notFound ? '' : trim((string) ($p['first_name'] ?? ''));
// Classmates tagged as collaborators, with what each one did (shown in the header and the Team card)
$collabs = $notFound ? [] : (dfCollaboratorsFor($pdo, [(int) $p['id']])[(int) $p['id']] ?? []);
$canEditTeam = $isOwner && $isApproved && !$isFaculty;
// Work links of everyone on the team (creator + tagged collaborators), loaded together
$teamLinks = $notFound ? [] : dfLinksForUsers($pdo, array_map(static function ($c) { return (int) $c['user_id']; }, $collabs));
if (!$notFound) $teamLinks[(int) $p['owner_user_id']] = $ownerLinks;
// Tagged collaborators who added links: shown at the top right under the creator's links
$crew = array_values(array_filter($collabs, static function ($c) use ($teamLinks) { return !empty($teamLinks[(int) $c['user_id']]); }));
$crewMax = 4;
$pageTitle = $notFound ? 'Project not found' : (string) $p['title'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo dfEsc($pageTitle); ?> - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $navActive = 'discover'; $facActive = 'discover'; include __DIR__ . '/../includes/' . ($isFaculty ? 'faculty-nav.php' : 'student-nav.php'); ?>

<main id="main" class="df-page pjx">
    <p class="df-back-row">
        <a class="df-back" href="dashboard.php"><?php echo dfIcon('code', 16); ?> Back to all projects</a>
    </p>

<?php if ($notFound): ?>
    <div class="df-empty">
        <h3>This project is not available</h3>
        <p>It may have been removed by a moderator or deleted by its owner.</p>
        <a class="df-btn df-btn-primary" href="dashboard.php">Browse projects</a>
    </div>
<?php else: ?>

    <?php if (!$isApproved): ?>
        <div class="df-status-note" role="status">
            <strong>This project was removed by a moderator.</strong> Only you can see this page.
            <?php if ($removalNote !== ''): ?><p><b>Message from moderators:</b> <?php echo nl2br(dfEsc($removalNote)); ?></p><?php endif; ?>
        </div>
    <?php endif; ?>

    <header class="pjx-head">
        <div class="pjx-head-top">
            <div class="pjx-head-text">
                <?php if (!empty($p['category'])): ?><span class="pjx-tag"><?php echo dfEsc($p['category']); ?></span><?php endif; ?>
                <h1 id="pjTitle" class="pjx-title"><?php echo dfEsc($p['title']); ?></h1>
                <?php if ($tagline !== ''): ?><p class="pjx-tagline"><?php echo dfEsc($tagline); ?></p><?php endif; ?>
            </div>
            <div class="pjx-head-side">
                <a class="pjx-explore" href="dashboard.php"><?php echo dfIcon('search', 16); ?> Explore projects</a>
                <?php if ($ownerLinks): ?>
                    <div class="pjx-owner">
                        <p class="pjx-owner-label">
                            <?php echo dfIcon('user', 13); ?>
                            <span>More from <a href="user.php?id=<?php echo (int) $p['owner_user_id']; ?>" class="df-profile-link" data-profile="<?php echo (int) $p['owner_user_id']; ?>"><?php echo dfEsc($ownerFirst !== '' ? $ownerFirst : dfOwnerName($p)); ?></a></span>
                        </p>
                        <?php echo dfRenderLinkPills($ownerLinks, 'project', 'Working profiles of ' . dfOwnerName($p)); ?>
                    </div>
                <?php elseif ($isOwner && !$isFaculty): ?>
                    <a class="pjx-owner-add" href="profile.php#links"><?php echo dfIcon('plus', 14); ?> Add your LinkedIn or portfolio here</a>
                <?php endif; ?>
                <?php if ($crew): ?>
                    <!-- Tagged collaborators' work links (LinkedIn, GitHub, portfolio...) -->
                    <div class="pjx-crew">
                        <p class="pjx-owner-label"><?php echo dfIcon('users', 13); ?><span>Collaborators</span></p>
                        <ul class="pjx-crew-list" aria-label="Work links of the collaborators">
                            <?php foreach (array_slice($crew, 0, $crewMax) as $c): $cid = (int) $c['user_id']; $cname = dfOwnerName($c); $crole = trim((string) ($c['role'] ?? '')); ?>
                                <li class="pjx-crew-row">
                                    <span class="pjx-crew-text">
                                        <a class="pjx-crew-name df-profile-link" href="user.php?id=<?php echo $cid; ?>" data-profile="<?php echo $cid; ?>"><?php echo dfEsc($cname); ?></a>
                                        <span class="pjx-crew-role"><?php echo dfEsc($crole !== '' ? $crole : 'Collaborator'); ?></span>
                                    </span>
                                    <?php echo dfRenderLinkIcons($teamLinks[$cid], $cid, $cname, 3); ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                        <?php if (count($crew) > $crewMax): ?>
                            <a class="pjx-crew-more" href="#team">See all <?php echo count($crew); ?> in Team</a>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="pjx-creator-row">
            <a class="df-creator pjx-creator df-profile-link" href="user.php?id=<?php echo (int) $p['owner_user_id']; ?>" data-profile="<?php echo (int) $p['owner_user_id']; ?>" aria-label="<?php echo dfEsc('View profile of ' . dfOwnerName($p)); ?>">
                <?php echo dfAvatarHtml($p); ?>
                <span class="df-creator-text">
                    <span class="df-creator-name"><?php echo dfEsc(dfOwnerName($p)); ?></span>
                    <span class="df-creator-meta">Student creator &middot; CCDI community</span>
                </span>
            </a>
            <div class="pjx-creator-end">
                <?php if ($isApproved) { echo dfReportButton($p); echo dfLikeButton($p); echo dfCommentButton($p); echo dfShareButton($p); } ?>
                <span class="pjx-label">Project showcase</span>
            </div>
        </div>
        <?php if ($collabs): ?>
            <div class="pjx-collab"><?php echo dfRenderCollabLine($collabs, 'project.php?id=' . (int) $p['id'], 'Made with'); ?></div>
        <?php endif; ?>
    </header>

    <div class="pjx-grid">
        <div class="pjx-main">
            <figure class="pjx-hero">
                <div class="pjx-hero-top">
                    <span>Project preview</span>
                    <span><?php echo $photo !== '' ? (count($photos) > 1 ? 'Screenshots' : 'Screenshot') : 'Concept cover'; ?></span>
                </div>
                <?php if (count($photos) > 1): ?>
                    <div class="pjx-gal" data-gallery aria-roledescription="carousel" aria-label="<?php echo dfEsc($p['title'] . ' photos'); ?>">
                        <div class="pjx-gal-stage">
                            <img class="pjx-shot" data-gallery-main src="<?php echo dfEsc($photos[0]); ?>" alt="<?php echo dfEsc('Photo 1 of ' . count($photos) . ': ' . $p['title']); ?>">
                            <button type="button" class="pjx-gal-nav is-prev" data-gallery-prev aria-label="Previous photo"><?php echo dfIcon('chevron', 22); ?></button>
                            <button type="button" class="pjx-gal-nav is-next" data-gallery-next aria-label="Next photo"><?php echo dfIcon('chevron', 22); ?></button>
                            <span class="pjx-gal-count" data-gallery-count aria-live="polite">1 / <?php echo count($photos); ?></span>
                        </div>
                        <ul class="pjx-gal-thumbs" aria-label="Choose a photo">
                            <?php foreach ($photos as $i => $src): ?>
                                <li><button type="button" class="pjx-gal-thumb<?php echo $i === 0 ? ' is-on' : ''; ?>" data-gallery-thumb data-src="<?php echo dfEsc($src); ?>" aria-label="<?php echo dfEsc('Show photo ' . ($i + 1)); ?>" aria-pressed="<?php echo $i === 0 ? 'true' : 'false'; ?>"><img src="<?php echo dfEsc($src); ?>" alt="" loading="lazy"></button></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php elseif ($photo !== ''): ?>
                    <img class="pjx-shot" src="<?php echo dfEsc($photo); ?>" alt="<?php echo dfEsc('Preview of ' . $p['title']); ?>" onerror="this.remove()">
                <?php else: ?>
                    <div class="pjx-cover">
                        <p class="pjx-cover-kicker">Show your work</p>
                        <p class="pjx-cover-title"><?php echo dfEsc($p['title']); ?></p>
                        <div class="pjx-mock" aria-hidden="true">
                            <div class="pjx-mock-bar"><i></i><i></i><i></i><span>Project workspace</span></div>
                            <div class="pjx-mock-body">
                                <div class="pjx-mock-side"><b class="on"></b><b></b><b></b><b></b></div>
                                <div class="pjx-mock-main">
                                    <b class="w1"></b><b class="w2"></b>
                                    <div class="pjx-mock-cards"><i class="hl"></i><i></i><i></i></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <figcaption class="pjx-hero-cap">Illustrative cover</figcaption>
                <?php endif; ?>
            </figure>

            <?php if ($desc !== ''): ?>
            <section class="pjx-card" aria-labelledby="pjAbout">
                <h2 id="pjAbout" class="pjx-h">About this project</h2>
                <p class="pjx-text"><?php echo dfEsc($desc); ?></p>
            </section>
            <?php endif; ?>

            <?php if ($tags): ?>
            <section class="pjx-card" aria-labelledby="pjBuilt">
                <h2 id="pjBuilt" class="pjx-h">Built with</h2>
                <ul class="pjx-tags"><?php foreach ($tags as $t): ?><li><?php echo dfIcon('code', 14); ?> <?php echo dfEsc($t); ?></li><?php endforeach; ?></ul>
            </section>
            <?php endif; ?>

            <?php $pid = (int) $p['id']; $cmtCount = (int) $p['comment_count']; $canEditReadme = $isOwner && $isApproved && !$isFaculty; ?>
            <section class="pjx-card pjx-tabs" id="discussion" aria-label="Comments and README">
                <div class="pjx-tablist" role="tablist" aria-label="Comments or MD file">
                    <?php if ($isApproved): ?>
                    <button type="button" class="pjx-tab" role="tab" id="tabComments" aria-selected="true" aria-controls="comments" data-tab="comments">
                        <?php echo dfIcon('comment', 16); ?> Comments <span class="pjx-tab-count" data-comment-count="<?php echo $pid; ?>"><?php echo $cmtCount > 0 ? $cmtCount : ''; ?></span>
                    </button>
                    <?php endif; ?>
                    <button type="button" class="pjx-tab" role="tab" id="tabReadme" aria-selected="<?php echo $isApproved ? 'false' : 'true'; ?>" aria-controls="readme" data-tab="readme"<?php echo $isApproved ? ' tabindex="-1"' : ''; ?>>
                        <?php echo dfIcon('file', 16); ?> MD File
                    </button>
                </div>

                <?php if ($isApproved): ?>
                <div class="pjx-panel" id="comments" role="tabpanel" aria-labelledby="tabComments" data-panel="comments">
                    <div class="df-comments" id="comments-<?php echo $pid; ?>" data-comments="<?php echo $pid; ?>" data-autoload></div>
                </div>
                <?php endif; ?>

                <div class="pjx-panel" id="readme" role="tabpanel" aria-labelledby="tabReadme" data-panel="readme"<?php echo $isApproved ? ' hidden' : ''; ?>>
                    <div class="pjx-readme-bar">
                        <span class="pjx-readme-name"><?php echo dfIcon('file', 16); ?> README.md</span>
                        <?php if ($canEditReadme): ?>
                        <button type="button" class="pjx-readme-edit" data-readme-edit><?php echo dfIcon('compose', 15); ?> <span>Edit</span></button>
                        <?php endif; ?>
                    </div>

                    <div class="md-body" data-readme-view></div>

                    <div class="pjx-readme-empty" data-readme-empty hidden>
                        <p class="pjx-readme-empty-title">No README yet</p>
                        <?php if ($canEditReadme): ?>
                            <p>Explain your project in Markdown: what it does, how it works, screenshots. Write it here or upload a .md file.</p>
                            <button type="button" class="df-btn df-btn-primary" data-readme-edit><?php echo dfIcon('compose', 16); ?> Add a README</button>
                        <?php else: ?>
                            <p>The creator has not added a README to this project.</p>
                        <?php endif; ?>
                    </div>

                    <?php if ($canEditReadme): ?>
                    <div class="pjx-readme-editor" data-readme-editor hidden>
                        <div class="pjx-ed-tabs" role="tablist" aria-label="Editor view">
                            <button type="button" class="pjx-ed-tab" role="tab" id="edTabWrite" aria-selected="true" aria-controls="edWrite" data-ed-mode="write">Write</button>
                            <button type="button" class="pjx-ed-tab" role="tab" id="edTabPreview" aria-selected="false" aria-controls="edPreview" data-ed-mode="preview" tabindex="-1">Preview</button>
                        </div>
                        <div id="edWrite" role="tabpanel" aria-labelledby="edTabWrite">
                            <label class="df-sr" for="readmeText">README.md text</label>
                            <textarea id="readmeText" class="pjx-ed-text" spellcheck="false" placeholder="# My project&#10;&#10;What it does, how it works, screenshots..."></textarea>
                        </div>
                        <div id="edPreview" class="pjx-ed-preview md-body" role="tabpanel" aria-labelledby="edTabPreview" data-ed-preview hidden></div>
                        <p class="pjx-ed-help">Markdown: # headings, **bold**, lists, tables, code blocks, links and images. Photos need a full https:// link.</p>
                        <div class="pjx-ed-foot">
                            <input type="file" accept=".md,text/markdown" data-readme-file hidden>
                            <button type="button" class="pjx-ghost" data-readme-pick><?php echo dfIcon('file', 15); ?> Upload .md file</button>
                            <span class="pjx-ed-count" data-readme-count aria-live="polite"></span>
                            <span class="pjx-ed-spacer"></span>
                            <button type="button" class="pjx-ghost" data-readme-cancel>Cancel</button>
                            <button type="button" class="df-btn df-btn-primary" data-readme-save>Save README</button>
                        </div>
                    </div>
                    <?php endif; ?>

                    <script type="application/json" id="readmeData"><?php echo json_encode(['body' => $readmeText, 'projectId' => $pid, 'canEdit' => $canEditReadme], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE); ?></script>
                </div>
            </section>
        </div>

        <aside class="pjx-side" aria-label="Project details">
            <?php echo dfRenderTeamCard($p, $collabs, $meId, $canEditTeam, $teamLinks); ?>

            <section class="pjx-card">
                <h2 class="pjx-h">Project details</h2>
                <dl class="pjx-facts">
                    <?php if (!empty($p['category'])): ?><div><dt>Category</dt><dd><?php echo dfEsc($p['category']); ?></dd></div><?php endif; ?>
                    <div><dt>Created by</dt><dd><?php echo dfEsc(dfOwnerName($p)); ?></dd></div>
                    <?php if (!empty($p['student_program'])): ?><div><dt>Program</dt><dd><?php echo dfEsc($p['student_program']); ?></dd></div><?php endif; ?>
                    <?php if (!empty($p['academic_year'])): ?><div><dt>Academic year</dt><dd><?php echo dfEsc($p['academic_year']); ?></dd></div><?php endif; ?>
                    <div><dt>Posted</dt><dd><?php echo dfEsc(date('F j, Y', strtotime((string) $p['created_at']))); ?></dd></div>
                </dl>
            </section>

            <section class="pjx-card">
                <h2 class="pjx-h pjx-h-icon"><?php echo dfIcon('file', 16); ?> Project resources</h2>
                <?php if ($links || !empty($files)): ?>
                    <div class="pjx-res">
                        <?php foreach ($links as $linkUrl): $meta = dfLinkMeta($linkUrl); ?>
                            <a class="pjx-res-row" href="<?php echo dfEsc($linkUrl); ?>" target="_blank" rel="noopener noreferrer">
                                <?php echo dfIcon($meta[1], 18); ?>
                                <span class="pjx-res-text"><b><?php echo dfEsc($meta[0]); ?></b><span><?php echo dfEsc(parse_url($linkUrl, PHP_URL_HOST) ?: $linkUrl); ?></span></span>
                                <?php echo dfIcon('external', 14); ?>
                            </a>
                        <?php endforeach; ?>
                        <?php foreach ($files as $f): ?>
                            <a class="pjx-res-row" href="<?php echo dfEsc(dfAssetUrl($f['file_path'])); ?>" download="<?php echo dfEsc($f['file_name']); ?>">
                                <?php echo dfIcon('file', 18); ?>
                                <span class="pjx-res-text"><b><?php echo dfEsc($f['file_name']); ?></b><span><?php echo dfEsc(dfFormatSize((int) $f['file_size'])); ?></span></span>
                                <?php echo dfIcon('download', 14); ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p class="pjx-muted">No links shared yet.</p>
                    <?php if ($isOwner): ?><p class="pjx-fine">Describe your project in the MD File tab. It is shown here, so the project stays yours.</p><?php endif; ?>
                <?php endif; ?>
            </section>

            <section class="pjx-card pjx-closing">
                <span class="pjx-closing-icon"><?php echo dfIcon('code', 18); ?></span>
                <p class="pjx-closing-title">Student work. Real possibilities.</p>
                <p class="pjx-fine">Explore the ideas, craft, and skills behind our CCDI community.</p>
            </section>
        </aside>
    </div>
<?php endif; ?>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI community</span>
    <span>Made to be shared.</span>
</footer>

<div id="dfToastHost" role="status" aria-live="polite"></div>
<?php if ($isApproved) { include __DIR__ . '/../includes/report-modal.php'; include __DIR__ . '/../includes/social-ui.php'; } ?>
<?php if ($isApproved): ?><script src="../js/df-social.js"></script><?php endif; ?>
<script src="../js/df-profile-card.js"></script>
<script src="../js/df-gallery.js"></script>
<?php if ($canEditTeam): ?>
<!-- Edit the team (owner only) -->
<div id="teamModal" class="df-modal" hidden>
    <div class="df-dialog" role="dialog" aria-modal="true" aria-labelledby="teamTitle">
        <button type="button" class="df-x" data-team-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
        <div class="df-dialog-pad">
            <h2 id="teamTitle">Tag collaborators</h2>
            <div class="df-field"><?php echo dfCollabPickerHtml('teamCollab', $collabs); ?></div>
            <div class="df-actions">
                <button type="button" class="df-btn df-btn-primary" data-team-save>Save team</button>
                <button type="button" class="df-btn df-btn-ghost" data-team-close>Cancel</button>
            </div>
        </div>
    </div>
</div>
<script src="../js/df-collab-picker.js"></script>
<?php endif; ?>
<?php if (!$notFound): ?>
<script src="../js/df-markdown.js"></script>
<script src="../js/df-readme.js"></script>
<?php endif; ?>

<script>
(function () {
    function toast(message, type) {
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        document.getElementById('dfToastHost').appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    document.addEventListener('click', async function (e) {
        var like = e.target.closest('[data-like]');
        if (!like) return;
        try {
            var res = await fetch(window.location.href, {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
                body: new URLSearchParams({ action: 'toggle_like', project_id: like.dataset.like }).toString()
            });
            var d = await res.json();
            if (!d.success) { toast(d.message || 'Could not update.', 'err'); return; }
            like.setAttribute('aria-pressed', d.liked ? 'true' : 'false');
            like.querySelector('span').textContent = d.count > 0 ? d.count : '';
        } catch (err) { toast('Could not update.', 'err'); }
    });

    // ---------- Team: tagged collaborators ----------
    var projectId = <?php echo $notFound ? 0 : (int) $p['id']; ?>;
    function api(body) {
        return fetch('project-actions.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: new URLSearchParams(body).toString()
        }).then(function (r) { return r.json(); });
    }

    var teamModal = document.getElementById('teamModal');
    if (teamModal && window.DFCollabPicker) {
        var picker = DFCollabPicker.init(document.getElementById('teamCollab'), { endpoint: 'project-actions.php' });
        var lastFocus = null;
        function openTeam() { lastFocus = document.activeElement; teamModal.hidden = false; document.body.style.overflow = 'hidden'; picker.focus(); }
        function closeTeam() { teamModal.hidden = true; document.body.style.overflow = ''; if (lastFocus) lastFocus.focus(); }
        document.querySelectorAll('[data-team-edit]').forEach(function (b) { b.addEventListener('click', openTeam); });
        teamModal.addEventListener('click', function (e) { if (e.target === teamModal || e.target.closest('[data-team-close]')) closeTeam(); });
        document.addEventListener('keydown', function (e) { if (e.key === 'Escape' && !teamModal.hidden) closeTeam(); });
        var saveBtn = teamModal.querySelector('[data-team-save]');
        saveBtn.addEventListener('click', function () {
            saveBtn.disabled = true; saveBtn.textContent = 'Saving...';
            api({ action: 'save_collaborators', project_id: projectId, collaborators: JSON.stringify(picker.value()) }).then(function (d) {
                if (!d.success) { toast(d.message || 'Could not save the team.', 'err'); return; }
                toast(d.message || 'Team updated.', 'ok');
                setTimeout(function () { window.location.hash = 'team'; window.location.reload(); }, 600);
            }).catch(function () { toast('Could not save the team.', 'err'); })
              .finally(function () { saveBtn.disabled = false; saveBtn.textContent = 'Save team'; });
        });
    }

    document.addEventListener('click', function (e) {
        var leave = e.target.closest('[data-team-leave]');
        if (!leave) return;
        if (!window.confirm('Remove your tag from this project? It will no longer show on your profile.')) return;
        leave.disabled = true;
        api({ action: 'remove_my_tag', project_id: projectId }).then(function (d) {
            if (!d.success) { toast(d.message || 'Could not remove your tag.', 'err'); leave.disabled = false; return; }
            toast(d.message, 'ok');
            setTimeout(function () { window.location.reload(); }, 900);
        }).catch(function () { toast('Could not remove your tag.', 'err'); leave.disabled = false; });
    });
})();
</script>
</body>
</html>
