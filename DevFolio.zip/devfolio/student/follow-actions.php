<?php
/**
 * Follow endpoint (JSON). Students only.
 *
 * POST action=follow    user_id  -> follow that student
 * POST action=unfollow  user_id  -> stop following them
 * Both answer { success, following, count } where count is the student's follower total.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/follow-helpers.php';

header('Content-Type: application/json');

function dfFollowJson(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    dfFollowJson(['success' => false, 'message' => 'Only signed-in students can follow people.'], 403);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dfFollowJson(['success' => false, 'message' => 'Invalid request.'], 405);
}

$meId = (int) $_SESSION['user_id'];
$action = (string) ($_POST['action'] ?? '');
$targetId = (int) ($_POST['user_id'] ?? 0);

if (!in_array($action, ['follow', 'unfollow'], true)) {
    dfFollowJson(['success' => false, 'message' => 'Unknown action.']);
}
if ($targetId === $meId) {
    dfFollowJson(['success' => false, 'message' => 'You cannot follow yourself.']);
}
if (!dfCanBeFollowed($pdo, $targetId)) {
    dfFollowJson(['success' => false, 'message' => 'This student is not available.']);
}
if (!dfFollowTableReady($pdo)) {
    dfFollowJson(['success' => false, 'message' => 'Following is not available right now.'], 500);
}

if ($action === 'follow') {
    dfFollowUser($pdo, $meId, $targetId);
} else {
    dfUnfollowUser($pdo, $meId, $targetId);
}

dfFollowJson([
    'success'   => true,
    'following' => dfIsFollowing($pdo, $meId, $targetId),
    'count'     => dfFollowerCount($pdo, $targetId),
]);
