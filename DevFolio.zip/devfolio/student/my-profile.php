<?php
/**
 * My Profile (students) - the page behind the "Profile" tab.
 * DEVFOLIO CCDI Sorsogon
 *
 * Facebook-style profile: cover photo, details from Account settings, followers / following
 * (friends-list style) and a news feed of the member's own projects plus projects they shared.
 * Details are edited on Account settings (profile.php); the cover photo is changed right here.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/profile-helpers.php';
require_once __DIR__ . '/../includes/follow-helpers.php';
require_once __DIR__ . '/../includes/profile-edit-helpers.php';
require_once __DIR__ . '/../includes/profile-timeline.php';

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    header('Location: ../login.php');
    exit;
}

$meId = (int) $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
$stmt->execute([$meId]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $meId, 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([$meId, $newStudentId, 'BSCS', '3rd']);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['logout'])) {
    session_unset();
    session_destroy();
    header('Location: ../login.php');
    exit;
}

// ---------------- Page data ----------------
$pf = dfFetchProfile($pdo, $meId, false);
if (!$pf) { header('Location: dashboard.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Profile - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $navActive = 'myprofile'; include __DIR__ . '/../includes/student-nav.php'; ?>

<main id="main" class="df-page upx pf">
    <?php echo dfRenderProfileView($pdo, $pf, [
        'isOwner'       => true,
        'viewerId'      => $meId,
        'viewerRole'    => 'student',
        'canSeePrivate' => true,
        'canFollow'     => false,
        'isFollowing'   => false,
    ]); ?>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>

<div id="dfToastHost" role="status" aria-live="polite"></div>
<?php include __DIR__ . '/../includes/social-ui.php'; ?>
<?php include __DIR__ . '/../includes/report-modal.php'; ?>
<?php echo dfRenderMyProjectsDialogs(); ?>
<script src="../js/df-more.js"></script>
<script src="../js/df-cert-view.js"></script>
<script src="../js/df-follow.js"></script>
<script src="../js/df-social.js"></script>
<script src="../js/df-profile-card.js"></script>
<script src="../js/df-profile.js"></script>
<script src="../js/df-photo-picker.js"></script>
<script src="../js/df-my-projects.js"></script>
</body>
</html>
