<?php
/**
 * Project social actions (JSON endpoint for student and faculty pages;
 * faculty/project-actions.php loads this file).
 *
 * POST action=get_comments    project_id, before_id (optional)  -> a page of comments
 * POST action=add_comment     project_id, body                  -> posts a comment
 * POST action=delete_comment  comment_id                        -> author or project owner removes it
 * POST action=record_share    project_id, channel               -> logs a share
 * POST action=save_readme      project_id, body                  -> owner edits the README.md (empty = remove)
 * POST action=search_people    q, exclude                        -> students to tag as collaborators
 * POST action=save_collaborators project_id, collaborators (JSON) -> owner changes the team
 * POST action=remove_my_tag    project_id                        -> a tagged student removes their own tag
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/project-form.php';   // README helpers
require_once __DIR__ . '/../includes/badges.php';   // member-chosen comment badge
require_once __DIR__ . '/../includes/profile-edit-helpers.php';
require_once __DIR__ . '/../includes/profile-timeline.php';

header('Content-Type: application/json');

function dfJson(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['student', 'faculty'], true)) {
    dfJson(['success' => false, 'message' => 'Please sign in to continue.'], 403);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dfJson(['success' => false, 'message' => 'Invalid request.'], 405);
}

$meId = (int) $_SESSION['user_id'];
$action = (string) ($_POST['action'] ?? '');

/** Published project + its owner's user id, or null when it is not available. */
function dfLoadPublicProject(PDO $pdo, int $projectId): ?array {
    $st = $pdo->prepare(
        "SELECT p.id, p.title, u.id AS owner_user_id
         FROM projects p
         INNER JOIN students s ON s.id = p.student_id
         INNER JOIN users u ON u.id = s.user_id
         WHERE p.id = ? AND p.status = 'approved' LIMIT 1"
    );
    $st->execute([$projectId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    return $row ?: null;
}

// ---------------------------------------------------------------
// Load comments (newest page first; "View earlier" passes before_id)
// ---------------------------------------------------------------
if ($action === 'get_comments') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    $project = dfLoadPublicProject($pdo, $projectId);
    if (!$project) dfJson(['success' => false, 'message' => 'This project is no longer available.']);

    $page = dfFetchComments($pdo, $projectId, max(0, (int) ($_POST['before_id'] ?? 0)));
    $html = '';
    foreach ($page['rows'] as $row) $html .= dfRenderComment($row, $meId, (int) $project['owner_user_id']);

    dfJson([
        'success'  => true,
        'html'     => $html,
        'has_more' => $page['has_more'],
        'first_id' => $page['rows'] ? (int) $page['rows'][0]['id'] : 0,
        'total'    => dfCommentCount($pdo, $projectId),
    ]);
}

// ---------------------------------------------------------------
// Post a comment
// ---------------------------------------------------------------
if ($action === 'add_comment') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    $project = dfLoadPublicProject($pdo, $projectId);
    if (!$project) dfJson(['success' => false, 'message' => 'This project is no longer available.']);

    $body = dfCleanComment((string) ($_POST['body'] ?? ''));
    if ($body === '') dfJson(['success' => false, 'message' => 'Write something before posting.']);
    if (mb_strlen($body) > DF_COMMENT_MAX) {
        dfJson(['success' => false, 'message' => 'Comments can be up to ' . DF_COMMENT_MAX . ' characters.']);
    }

    // Simple flood control: 5 comments per minute per person
    $recent = $pdo->prepare('SELECT COUNT(*) FROM project_comments WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE)');
    $recent->execute([$meId]);
    if ((int) $recent->fetchColumn() >= 5) {
        dfJson(['success' => false, 'message' => 'You are commenting too fast. Please wait a moment.']);
    }

    $ins = $pdo->prepare('INSERT INTO project_comments (project_id, user_id, body) VALUES (?, ?, ?)');
    $ins->execute([$projectId, $meId, $body]);
    $commentId = (int) $pdo->lastInsertId();

    $row = $pdo->prepare(
        'SELECT c.id, c.user_id, c.body, c.created_at, u.first_name, u.last_name, u.avatar_url, u.role
         FROM project_comments c INNER JOIN users u ON u.id = c.user_id WHERE c.id = ? LIMIT 1'
    );
    $row->execute([$commentId]);
    $comment = $row->fetch(PDO::FETCH_ASSOC);
    if ($comment) { $one = [$comment]; dfAttachCommentBadges($pdo, $one); $comment = $one[0]; }

    // Tell the project owner (not when they comment on their own project)
    $ownerId = (int) $project['owner_user_id'];
    if ($comment && $ownerId !== $meId) {
        $snippet = mb_strlen($body) > 120 ? rtrim(mb_substr($body, 0, 117)) . '...' : $body;
        dfNotify(
            $pdo,
            $ownerId,
            'project_comment',
            'New comment on your project',
            dfOwnerName($comment) . ' commented on "' . $project['title'] . '": ' . $snippet,
            $projectId
        );
    }

    dfJson([
        'success' => true,
        'html'    => $comment ? dfRenderComment($comment, $meId, $ownerId) : '',
        'total'   => dfCommentCount($pdo, $projectId),
    ]);
}

// ---------------------------------------------------------------
// Delete a comment (its author, or the owner of the project)
// ---------------------------------------------------------------
if ($action === 'delete_comment') {
    $commentId = (int) ($_POST['comment_id'] ?? 0);
    $st = $pdo->prepare(
        "SELECT c.id, c.user_id, c.project_id, u.id AS owner_user_id
         FROM project_comments c
         INNER JOIN projects p ON p.id = c.project_id
         INNER JOIN students s ON s.id = p.student_id
         INNER JOIN users u ON u.id = s.user_id
         WHERE c.id = ? AND c.status = 'visible' LIMIT 1"
    );
    $st->execute([$commentId]);
    $c = $st->fetch(PDO::FETCH_ASSOC);
    if (!$c) dfJson(['success' => false, 'message' => 'That comment is already gone.']);

    if ((int) $c['user_id'] !== $meId && (int) $c['owner_user_id'] !== $meId) {
        dfJson(['success' => false, 'message' => 'You can only remove your own comments or comments on your project.'], 403);
    }

    $pdo->prepare("UPDATE project_comments SET status = 'removed', removed_by = ? WHERE id = ?")->execute([$meId, $commentId]);
    dfJson(['success' => true, 'total' => dfCommentCount($pdo, (int) $c['project_id'])]);
}

// ---------------------------------------------------------------
// Log a share (count = number of different people who shared)
// ---------------------------------------------------------------
if ($action === 'record_share') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    $channel = (string) ($_POST['channel'] ?? '');
    if (!in_array($channel, ['copy', 'native', 'facebook', 'x', 'email', 'profile'], true)) {
        dfJson(['success' => false, 'message' => 'Unknown share option.']);
    }
    if (!dfLoadPublicProject($pdo, $projectId)) {
        dfJson(['success' => false, 'message' => 'This project is no longer available.']);
    }

    // Ignore a repeat of the same share within a minute (double clicks)
    $dup = $pdo->prepare('SELECT id FROM project_shares WHERE project_id = ? AND user_id = ? AND channel = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 MINUTE) LIMIT 1');
    $dup->execute([$projectId, $meId, $channel]);
    if (!$dup->fetch()) {
        $pdo->prepare('INSERT INTO project_shares (project_id, user_id, channel) VALUES (?, ?, ?)')->execute([$projectId, $meId, $channel]);
    }

    $cnt = $pdo->prepare('SELECT COUNT(DISTINCT user_id) FROM project_shares WHERE project_id = ?');
    $cnt->execute([$projectId]);
    dfJson(['success' => true, 'count' => (int) $cnt->fetchColumn()]);
}

// ---------------------------------------------------------------
// Appreciation (heart) toggle - used by the profile feed
// ---------------------------------------------------------------
if ($action === 'toggle_like') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    if (!dfLoadPublicProject($pdo, $projectId)) dfJson(['success' => false, 'message' => 'Project not found.']);
    $has = $pdo->prepare('SELECT id FROM project_likes WHERE project_id = ? AND user_id = ? LIMIT 1');
    $has->execute([$projectId, $meId]);
    if ($has->fetch()) {
        $pdo->prepare('DELETE FROM project_likes WHERE project_id = ? AND user_id = ?')->execute([$projectId, $meId]);
        $liked = false;
    } else {
        $pdo->prepare('INSERT IGNORE INTO project_likes (project_id, user_id) VALUES (?, ?)')->execute([$projectId, $meId]);
        $liked = true;
    }
    $cnt = $pdo->prepare('SELECT COUNT(*) FROM project_likes WHERE project_id = ?');
    $cnt->execute([$projectId]);
    dfJson(['success' => true, 'liked' => $liked, 'count' => (int) $cnt->fetchColumn()]);
}

// ---------------------------------------------------------------
// Share a project to the student's own profile.
// The post always credits the original creator (photo + name) and cannot be edited,
// so shared work is never passed off as the sharer's own.
// ---------------------------------------------------------------
if ($action === 'share_to_profile') {
    if (($_SESSION['role'] ?? '') !== 'student') {
        dfJson(['success' => false, 'message' => 'Only students can share projects to a profile.'], 403);
    }
    $projectId = (int) ($_POST['project_id'] ?? 0);
    $project = dfLoadPublicProject($pdo, $projectId);
    if (!$project) dfJson(['success' => false, 'message' => 'This project is no longer available.']);
    if ((int) $project['owner_user_id'] === $meId) {
        dfJson(['success' => false, 'message' => 'This is already your project, so it is on your profile.']);
    }
    if (!dfShareTableReady($pdo)) dfJson(['success' => false, 'message' => 'Sharing to a profile is not available right now.'], 500);

    $caption = dfCleanComment((string) ($_POST['caption'] ?? ''));
    if (mb_strlen($caption) > DF_SHARE_CAPTION_MAX) {
        dfJson(['success' => false, 'message' => 'Your note can be up to ' . DF_SHARE_CAPTION_MAX . ' characters.']);
    }

    $recent = $pdo->prepare('SELECT COUNT(*) FROM profile_shared_projects WHERE user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 HOUR)');
    $recent->execute([$meId]);
    if ((int) $recent->fetchColumn() >= 10) {
        dfJson(['success' => false, 'message' => 'You are sharing too fast. Please try again in a bit.']);
    }

    $ins = $pdo->prepare('INSERT IGNORE INTO profile_shared_projects (user_id, project_id, caption) VALUES (?, ?, ?)');
    $ins->execute([$meId, $projectId, $caption !== '' ? $caption : null]);
    if ($ins->rowCount() < 1) {
        dfJson(['success' => true, 'already' => true, 'message' => 'This project is already on your profile.']);
    }

    $pdo->prepare('INSERT INTO project_shares (project_id, user_id, channel) VALUES (?, ?, ?)')->execute([$projectId, $meId, 'profile']);

    // Tell the original creator who shared their work
    try {
        $who = $pdo->prepare('SELECT first_name, last_name FROM users WHERE id = ? LIMIT 1');
        $who->execute([$meId]);
        dfNotify($pdo, (int) $project['owner_user_id'], 'project_shared', 'Your project was shared',
            dfOwnerName($who->fetch(PDO::FETCH_ASSOC) ?: []) . ' shared "' . $project['title'] . '" to their profile.', $projectId);
    } catch (Throwable $e) {
        // the share itself already worked
    }

    $cnt = $pdo->prepare('SELECT COUNT(DISTINCT user_id) FROM project_shares WHERE project_id = ?');
    $cnt->execute([$projectId]);
    dfJson(['success' => true, 'message' => 'Shared to your profile.', 'count' => (int) $cnt->fetchColumn()]);
}

// ---------------------------------------------------------------
// Remove a shared project from the student's own profile
// ---------------------------------------------------------------
if ($action === 'unshare_from_profile') {
    $shareId = (int) ($_POST['share_id'] ?? 0);
    if (!dfShareTableReady($pdo)) dfJson(['success' => false, 'message' => 'Not available right now.'], 500);
    $del = $pdo->prepare('DELETE FROM profile_shared_projects WHERE id = ? AND user_id = ?');
    $del->execute([$shareId, $meId]);
    if ($del->rowCount() < 1) dfJson(['success' => false, 'message' => 'That post is already gone.']);
    dfJson(['success' => true, 'message' => 'Removed from your profile.']);
}

// ---------------------------------------------------------------
// Edit the README.md (only the student who owns the project)
// ---------------------------------------------------------------
if ($action === 'save_readme') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    $st = $pdo->prepare(
        'SELECT p.id, p.status, u.id AS owner_user_id
         FROM projects p
         INNER JOIN students s ON s.id = p.student_id
         INNER JOIN users u ON u.id = s.user_id
         WHERE p.id = ? LIMIT 1'
    );
    $st->execute([$projectId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) dfJson(['success' => false, 'message' => 'This project is no longer available.']);
    if (($_SESSION['role'] ?? '') !== 'student' || (int) $row['owner_user_id'] !== $meId) {
        dfJson(['success' => false, 'message' => 'Only the owner of a project can edit its README.'], 403);
    }
    if ($row['status'] === 'removed') {
        dfJson(['success' => false, 'message' => 'Removed projects cannot be edited.']);
    }

    [$cleanError, $text] = dfCleanReadmeText((string) ($_POST['body'] ?? ''));
    if ($cleanError !== null) dfJson(['success' => false, 'message' => $cleanError]);
    if (!dfSaveReadme($pdo, $projectId, $text)) {
        dfJson(['success' => false, 'message' => 'Could not save the README. Please try again.']);
    }
    dfJson(['success' => true, 'body' => $text]);
}

// ---------------------------------------------------------------
// Tag collaborators: search classmates by name (students only)
// ---------------------------------------------------------------
if ($action === 'search_people') {
    if (($_SESSION['role'] ?? '') !== 'student') dfJson(['success' => false, 'message' => 'Only students can tag collaborators.'], 403);
    $exclude = array_map('intval', explode(',', (string) ($_POST['exclude'] ?? '')));
    try {
        $people = dfSearchStudents($pdo, (string) ($_POST['q'] ?? ''), $meId, $exclude);
    } catch (Throwable $e) {
        dfJson(['success' => false, 'message' => 'Search is not available right now.']);
    }
    dfJson(['success' => true, 'people' => $people]);
}

/** The owner's project row (with its title), or a JSON error. */
function dfOwnedProjectOrFail(PDO $pdo, int $projectId, int $meId): array {
    $st = $pdo->prepare(
        'SELECT p.id, p.title, p.status, u.id AS owner_user_id
         FROM projects p INNER JOIN students s ON s.id = p.student_id INNER JOIN users u ON u.id = s.user_id
         WHERE p.id = ? LIMIT 1'
    );
    $st->execute([$projectId]);
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row) dfJson(['success' => false, 'message' => 'This project is no longer available.']);
    if (($_SESSION['role'] ?? '') !== 'student' || (int) $row['owner_user_id'] !== $meId) {
        dfJson(['success' => false, 'message' => 'Only the owner of a project can change its team.'], 403);
    }
    if ($row['status'] === 'removed') dfJson(['success' => false, 'message' => 'Removed projects cannot be edited.']);
    return $row;
}

// ---------------------------------------------------------------
// Change the team of a project (owner only). Newly tagged people are notified.
// ---------------------------------------------------------------
if ($action === 'save_collaborators') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    $project = dfOwnedProjectOrFail($pdo, $projectId, $meId);
    [$error, $list] = dfReadCollaborators($pdo, $_POST, $meId);
    if ($error !== null) dfJson(['success' => false, 'message' => $error]);
    $added = dfSaveCollaborators($pdo, $projectId, $list);
    if ($added === null) dfJson(['success' => false, 'message' => 'Could not save the team. Please try again.']);
    dfNotifyTagged($pdo, $added, $meId, $projectId, (string) $project['title'], $list);
    dfJson(['success' => true, 'message' => $list ? 'Team updated.' : 'All tags removed.', 'count' => count($list)]);
}

// ---------------------------------------------------------------
// A tagged student removes their own tag from someone's project
// ---------------------------------------------------------------
if ($action === 'remove_my_tag') {
    $projectId = (int) ($_POST['project_id'] ?? 0);
    if (!dfRemoveMyTag($pdo, $projectId, $meId)) dfJson(['success' => false, 'message' => 'You are not tagged on this project.']);
    dfJson(['success' => true, 'message' => 'Your tag was removed. The project is no longer on your profile.']);
}

dfJson(['success' => false, 'message' => 'Unknown action.']);
