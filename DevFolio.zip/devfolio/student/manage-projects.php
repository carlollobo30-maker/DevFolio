<?php
/**
 * The My Projects page was removed. This file only keeps old links and bookmarks working.
 */
header('Location: dashboard.php', true, 301);
exit;
