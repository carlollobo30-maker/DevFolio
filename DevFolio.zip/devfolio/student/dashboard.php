<?php
/**
 * Student Dashboard
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/feed-filters.php';
require_once __DIR__ . '/../includes/project-form.php';
require_once __DIR__ . '/../includes/follow-helpers.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$userStmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$userStmt->execute([$_SESSION['user_id']]);
$user = $userStmt->fetch(PDO::FETCH_ASSOC);

$studentStmt = $pdo->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
$studentStmt->execute([$_SESSION['user_id']]);
$student = $studentStmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $_SESSION['user_id'], 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([
        $_SESSION['user_id'],
        $newStudentId,
        'BSCS',
        '3rd'
    ]);
    $student = $pdo->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
    $student->execute([$_SESSION['user_id']]);
    $student = $student->fetch(PDO::FETCH_ASSOC);
}

$programMap = [
    'BSCS' => 'Bachelor of Science in Computer Science',
    'BSIT' => 'Bachelor of Science in Information Technology',
    'BSACT' => 'Bachelor of Science in Associate in Computer Technology',
    'BSIS' => 'Bachelor of Science in Information System'
];

$fullName = trim((string) ($user['first_name'] ?? '') . ' ' . (string) ($user['last_name'] ?? ''));
if ($fullName === '') {
    $fullName = 'Student User';
}

$program = $student['program'] ?? 'BSCS';
$yearLevel = $student['year_level'] ?? '3rd';
$studentId = $student['student_id'] ?? 'N/A';
$degreeName = $programMap[$program] ?? ucfirst((string) $program);
$yearLabel = $yearLevel;
if (!preg_match('/(st|nd|rd|th)$/', $yearLabel)) {
    $yearLabel .= ' Year';
}

// ---------------------------------------------------------------
// Daily inspiring message (changes once per day, Asia/Manila time)
// Edit / add lines here. Order = rotation order.
// ---------------------------------------------------------------
$dailyMessages = [
    'Got a new Project? Showcase them by clicking here!',
    'Built something this week? Share it with the whole campus by clicking here!',
    'Every great developer started with one small project. Post yours by clicking here!',
    'Your code deserves an audience. Showcase your latest work by clicking here!',
    'Finished a capstone or an app? Let CCDI see it by clicking here!',
    'Someone might be inspired by what you built. Share it by clicking here!',
    'Proud of a project? Show it off by clicking here!',
    'Great ideas grow when they are shared. Showcase yours by clicking here!',
    'Got a project hiding in your folders? Bring it to light by clicking here!',
    'Progress counts, even for unfinished work. Share it by clicking here!',
    'Your next project could inspire a classmate. Post it by clicking here!',
    'Made something you are proud of? Showcase it by clicking here!',
    'Turn your hard work into a portfolio piece by clicking here!',
    'Show CCDI what you can build. Upload your project by clicking here!'
];
$dailyMessage = $dailyMessages[((int) date('z')) % count($dailyMessages)];

// ---------------------------------------------------------------
// Presentation helpers
// ---------------------------------------------------------------


// dfRenderCard() lives in includes/project-helpers.php (shared with the faculty feed)


// ---------------------------------------------------------------
// Real data for the sidebar (nothing here is sample content)
// ---------------------------------------------------------------
$meId = (int) $_SESSION['user_id'];
$skillCount = (int) $pdo->query('SELECT COUNT(*) FROM skills WHERE student_id = ' . (int) $student['id'])->fetchColumn();
$projectCount = (int) $pdo->query('SELECT COUNT(*) FROM projects WHERE student_id = ' . (int) $student['id'])->fetchColumn();

$completionSteps = [
    ['done' => !empty($user['avatar_url']), 'label' => 'Add a profile photo', 'href' => 'profile.php'],
    ['done' => !empty($user['phone']), 'label' => 'Add your phone number', 'href' => 'profile.php'],
    ['done' => trim((string) ($student['bio'] ?? '')) !== '', 'label' => 'Write a short bio', 'href' => 'profile.php#bio'],
    ['done' => $skillCount > 0, 'label' => 'Add your first skill', 'href' => 'profile.php#skills'],
    ['done' => $projectCount > 0, 'label' => 'Showcase your first project', 'href' => ''],
];
$completion = (int) round(count(array_filter($completionSteps, function ($s) { return $s['done']; })) / count($completionSteps) * 100);
$nextStep = null;
foreach ($completionSteps as $stepItem) { if (!$stepItem['done']) { $nextStep = $stepItem; break; } }

$popularSkills = $pdo->query('SELECT skill_name, COUNT(DISTINCT student_id) AS cnt FROM skills GROUP BY skill_name ORDER BY cnt DESC, skill_name ASC LIMIT 5')->fetchAll(PDO::FETCH_ASSOC);

$firstName = trim((string) ($user['first_name'] ?? '')) ?: 'there';
$userInitials = dfInitials($user['first_name'] ?? '', $user['last_name'] ?? '');
$userAvatar = dfAssetUrl($user['avatar_url'] ?? '');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'save_avatar_upload' || $action === 'save_avatar_capture') {
        $targetAvatar = '';

        if ($action === 'save_avatar_upload') {
            if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
                echo json_encode(['success' => false, 'message' => 'Please select an image to upload.']);
                exit;
            }

            $file = $_FILES['avatar'];
            $allowed = ['image/jpeg', 'image/png', 'image/jpg', 'image/webp'];
            if (!in_array($file['type'], $allowed, true)) {
                echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, and WEBP images are allowed.']);
                exit;
            }

            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $ext;
            $uploadDir = __DIR__ . '/../assets/uploads/avatars/';
            if (!is_dir($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }

            $destination = $uploadDir . $filename;
            if (!move_uploaded_file($file['tmp_name'], $destination)) {
                echo json_encode(['success' => false, 'message' => 'Image upload failed.']);
                exit;
            }

            $targetAvatar = '../assets/uploads/avatars/' . $filename;
        }

        if ($action === 'save_avatar_capture') {
            $dataUrl = $_POST['avatar_data_url'] ?? '';
            if ($dataUrl === '' || stripos($dataUrl, 'data:image/') === false) {
                echo json_encode(['success' => false, 'message' => 'No captured image was provided.']);
                exit;
            }

            if (preg_match('/^data:image\/(png|jpg|jpeg|webp);base64,/', $dataUrl, $matches)) {
                $imageData = substr($dataUrl, strpos($dataUrl, ',') + 1);
                $decoded = base64_decode($imageData);
                if ($decoded === false) {
                    echo json_encode(['success' => false, 'message' => 'Captured image could not be processed.']);
                    exit;
                }

                $ext = strtolower($matches[1]);
                $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $ext;
                $uploadDir = __DIR__ . '/../assets/uploads/avatars/';
                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $destination = $uploadDir . $filename;
                if (!file_put_contents($destination, $decoded)) {
                    echo json_encode(['success' => false, 'message' => 'Captured image could not be saved.']);
                    exit;
                }

                $targetAvatar = '../assets/uploads/avatars/' . $filename;
            } else {
                echo json_encode(['success' => false, 'message' => 'Unsupported captured image format.']);
                exit;
            }
        }

        $updateUser = $pdo->prepare('UPDATE users SET avatar_url = ?, updated_at = NOW() WHERE id = ?');
        $updateUser->execute([$targetAvatar, $_SESSION['user_id']]);

        $_SESSION['avatar_url'] = $targetAvatar;
        echo json_encode(['success' => true, 'message' => 'Profile photo saved successfully.', 'avatar_url' => $targetAvatar]);
        exit;
    }


    // ---------- Feed: search / sort / paginate ----------
    if ($action === 'get_feed') {
        $offset = max(0, (int) ($_POST['offset'] ?? 0));
        $limit = 6;
        $q = trim((string) ($_POST['q'] ?? ''));
        $sort = $_POST['sort'] ?? 'latest';

        $where = "WHERE p.status = 'approved'";
        $filter = [];
        if ($q !== '') {
            $like = '%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $q) . '%';
            $where .= " AND (p.title LIKE :q1 OR p.description LIKE :q2 OR p.category LIKE :q3
                        OR CONCAT(u.first_name, ' ', u.last_name) LIKE :q4 OR CAST(p.tech_stack AS CHAR) LIKE :q5)";
            $filter = [':q1' => $like, ':q2' => $like, ':q3' => $like, ':q4' => $like, ':q5' => $like];
        }

        $where .= dfFeedFilterSql($_POST, $filter);   // Tags + release date

        $orderBy = 'p.created_at DESC, p.id DESC';
        if ($sort === 'oldest') $orderBy = 'p.created_at ASC, p.id ASC';
        if ($sort === 'appreciated') $orderBy = 'like_count DESC, p.created_at DESC, p.id DESC';

        $countStmt = $pdo->prepare("SELECT COUNT(*) FROM projects p INNER JOIN students s ON s.id = p.student_id INNER JOIN users u ON u.id = s.user_id $where");
        $countStmt->execute($filter);
        $total = (int) $countStmt->fetchColumn();

        $feedStmt = $pdo->prepare(dfProjectSelectSql() . " $where ORDER BY $orderBy LIMIT :lim OFFSET :off");
        foreach ($filter as $k => $v) $feedStmt->bindValue($k, $v);
        $feedStmt->bindValue(':me', $meId, PDO::PARAM_INT);
        $feedStmt->bindValue(':lim', $limit + 1, PDO::PARAM_INT);
        $feedStmt->bindValue(':off', $offset, PDO::PARAM_INT);
        $feedStmt->execute();
        $rows = $feedStmt->fetchAll(PDO::FETCH_ASSOC);

        $hasMore = count($rows) > $limit;
        $rows = array_slice($rows, 0, $limit);

        dfAttachPhotoCounts($pdo, $rows);
        dfAttachCollaborators($pdo, $rows);   // "with Maria Santos and 2 others"
        $html = '';
        foreach ($rows as $row) $html .= dfRenderCard($row);

        echo json_encode(['success' => true, 'html' => $html, 'count' => count($rows), 'total' => $total, 'has_more' => $hasMore, 'next_offset' => $offset + count($rows)]);
        exit;
    }

    // ---------- Appreciation (heart) toggle ----------
    if ($action === 'toggle_like') {
        $pid = (int) ($_POST['project_id'] ?? 0);
        $exists = $pdo->prepare("SELECT id FROM projects WHERE id = ? AND status = 'approved' LIMIT 1");
        $exists->execute([$pid]);
        if (!$exists->fetch()) {
            echo json_encode(['success' => false, 'message' => 'Project not found.']);
            exit;
        }
        $has = $pdo->prepare('SELECT id FROM project_likes WHERE project_id = ? AND user_id = ? LIMIT 1');
        $has->execute([$pid, $meId]);
        if ($has->fetch()) {
            $pdo->prepare('DELETE FROM project_likes WHERE project_id = ? AND user_id = ?')->execute([$pid, $meId]);
            $liked = false;
        } else {
            $pdo->prepare('INSERT IGNORE INTO project_likes (project_id, user_id) VALUES (?, ?)')->execute([$pid, $meId]);
            $liked = true;
        }
        $cnt = $pdo->prepare('SELECT COUNT(*) FROM project_likes WHERE project_id = ?');
        $cnt->execute([$pid]);
        echo json_encode(['success' => true, 'liked' => $liked, 'count' => (int) $cnt->fetchColumn()]);
        exit;
    }

    // ---------- Add a project (photo, links, files) ----------
    if ($action === 'add_project') {
        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $category = trim($_POST['category'] ?? 'Web App');
        $categoryOther = trim(preg_replace('/\s+/', ' ', (string) ($_POST['category_other'] ?? '')));
        // One link field only (stored in demo_link; repository_link stays empty for new projects)
        $projectLink = trim($_POST['project_link'] ?? '');
        // Projects publish straight to the feed. Moderation happens through reports.
        $status = 'approved';

        // Technologies: comma-separated, up to 8 tags
        $techTags = [];
        foreach (explode(',', (string) ($_POST['tech_stack'] ?? '')) as $rawTag) {
            $tag = trim(preg_replace('/\s+/', ' ', $rawTag));
            if ($tag === '') continue;
            $tag = mb_substr($tag, 0, 30);
            if (!in_array(mb_strtolower($tag), array_map('mb_strtolower', $techTags), true)) $techTags[] = $tag;
            if (count($techTags) >= 8) break;
        }
        $techJson = $techTags ? json_encode($techTags, JSON_UNESCAPED_UNICODE) : null;

        $allowedCategories = ['Web App', 'Mobile App', 'Animation', 'Capstone', 'Multimedia'];
        if ($category === 'Others, Specify') {
            if ($categoryOther === '') {
                echo json_encode(['success' => false, 'message' => 'Please specify the category of your project.']);
                exit;
            }
            if (mb_strlen($categoryOther) > 100) {
                echo json_encode(['success' => false, 'message' => 'Category is too long (max 100 characters).']);
                exit;
            }
            $category = $categoryOther;
        } elseif (!in_array($category, $allowedCategories, true)) {
            $category = 'Web App';
        }

        if ($title === '' || $description === '') {
            echo json_encode(['success' => false, 'message' => 'Title and description are required.']);
            exit;
        }
        if (mb_strlen($title) > 255) {
            echo json_encode(['success' => false, 'message' => 'Title is too long (max 255 characters).']);
            exit;
        }
        if ($projectLink !== '' && (!preg_match('#^https?://#i', $projectLink) || mb_strlen($projectLink) > 255)) {
            echo json_encode(['success' => false, 'message' => 'Project link must be a valid link starting with http:// or https://']);
            exit;
        }

        $maxBytes = 5 * 1024 * 1024; // 5 MB per file
        $bannerPath = null;

        // --- Photos (several allowed; validated now, stored once the project row exists) ---
        [$photoError, $newPhotos] = dfReadPhotoUploads($_FILES);
        if ($photoError !== null) {
            echo json_encode(['success' => false, 'message' => $photoError]);
            exit;
        }

        // --- README.md (the only file a project can carry; read as text and shown on the project page) ---
        // The text written in the form's README editor wins; a plain .md upload still works as a fallback.
        [$readmeError, $readmeText] = dfReadReadmeText($_POST);
        if ($readmeError === null && $readmeText === null) [$readmeError, $readmeText] = dfReadReadmeUpload($_FILES);
        if ($readmeError !== null) {
            echo json_encode(['success' => false, 'message' => $readmeError]);
            exit;
        }

        // --- Tagged collaborators (team projects): checked now, saved once the project row exists ---
        [$collabError, $collabs] = dfReadCollaborators($pdo, $_POST, (int) $_SESSION['user_id']);
        if ($collabError !== null) {
            echo json_encode(['success' => false, 'message' => $collabError]);
            exit;
        }

        $insert = $pdo->prepare(
            'INSERT INTO projects (student_id, title, description, abstract, category, program, academic_year, course_code, status, banner_image_url, demo_link, repository_link, tech_stack, published_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $insert->execute([
            $student['id'],
            $title,
            $description,
            $description,
            $category,
            $student['program'] ?? 'BSCS',
            date('Y') . '-' . (date('Y') + 1),
            'CCDI-PROJ',
            $status,
            $bannerPath,
            $projectLink,
            '',
            $techJson,
            date('Y-m-d H:i:s')
        ]);
        $newProjectId = (int) $pdo->lastInsertId();
        $photoProblem = $newPhotos ? dfApplyProjectPhotos($pdo, $newProjectId, (int) $student['id'], $newPhotos, [], (string) ($_POST['photo_order'] ?? '')) : null;
        if ($status === 'approved') dfNotifyFollowersOfProject($pdo, (int) $_SESSION['user_id'], $newProjectId, $title);   // tell the people who follow this student

        $readmeProblem = ($readmeText !== null && !dfSaveReadme($pdo, $newProjectId, $readmeText)) ? 'its README could not be saved' : null;

        $collabProblem = null;
        if ($collabs) {
            $tagged = dfSaveCollaborators($pdo, $newProjectId, $collabs);
            if ($tagged === null) $collabProblem = 'the people you tagged could not be saved (you can tag them on the project page)';
            else dfNotifyTagged($pdo, $tagged, (int) $_SESSION['user_id'], $newProjectId, $title, $collabs);
        }

        $problems = [];
        if ($photoProblem !== null) $problems[] = 'its photos could not be saved: ' . $photoProblem;
        if ($readmeProblem !== null) $problems[] = $readmeProblem;
        if ($collabProblem !== null) $problems[] = $collabProblem;
        echo json_encode(['success' => true, 'message' => $problems ? 'Project posted, but ' . implode(' and ', $problems) . '.' : 'Project posted! It is now on the feed.']);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    if (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Discover - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $navActive = 'discover'; include __DIR__ . '/../includes/student-nav.php'; ?>

<main id="main" class="df-page">
    <!-- Intro -->
    <section class="df-intro" aria-labelledby="pageTitle">
        <div>
            <p class="df-eyebrow">The CCDI Creative Community</p>
            <h1 id="pageTitle" class="df-h1">Big ideas. Built by you.</h1>
            <button type="button" class="df-lede open-add-project"><?php echo htmlspecialchars($dailyMessage); ?></button>
        </div>
        <button type="button" id="addProjectBtn" class="df-btn df-btn-primary open-add-project"><?php echo dfIcon('plus', 18); ?> Add Project</button>
    </section>

    <div class="df-layout">
        <!-- Gallery -->
        <section aria-labelledby="galleryTitle">
            <div class="df-toolbar" role="search">
                <div class="df-search">
                    <?php echo dfIcon('search', 18); ?>
                    <label for="feedSearch" class="df-sr">Search projects</label>
                    <input id="feedSearch" class="df-input" type="search" placeholder="Search projects, technologies or creators" autocomplete="off">
                </div>
                <?php echo dfFeedToolbarExtras(); ?>
                <div>
                    <label for="feedSort" class="df-sr">Sort projects</label>
                    <select id="feedSort" class="df-select">
                        <option value="latest">Latest projects</option>
                        <option value="appreciated">Most appreciated</option>
                        <option value="oldest">Oldest first</option>
                    </select>
                </div>
            </div>
            <?php echo dfFeedFilterPanels($pdo); ?>

            <div class="df-section-head">
                <h2 id="galleryTitle">Community projects</h2>
                <span class="df-count" id="feedCount" aria-live="polite"></span>
            </div>

            <div id="feed" class="df-grid"></div>

            <div id="feedSkeleton" class="df-grid" hidden aria-hidden="true">
                <div class="df-skel"><i style="height:44px;width:44px;border-radius:50%;margin:16px 16px 12px"></i><i style="height:12px;margin:0 16px 8px"></i><i style="height:12px;width:70%;margin:0 16px 16px"></i><i style="aspect-ratio:16/10"></i></div>
            </div>

            <div id="feedEnd" class="df-end" hidden>You're all caught up</div>
            <div id="feedSentinel" style="height:2px"></div>
        </section>

        <!-- Sidebar (all figures come from the database) -->
        <aside class="df-side" aria-label="Community">
            <section class="df-panel" aria-labelledby="welcomeTitle">
                <div class="df-welcome-head">
                    <span class="df-welcome-av"><span><?php echo htmlspecialchars($userInitials); ?></span><?php if ($userAvatar !== ''): ?><img src="<?php echo htmlspecialchars($userAvatar); ?>" alt="" onerror="this.remove()"><?php endif; ?></span>
                    <div>
                        <h2 id="welcomeTitle">Welcome back, <?php echo htmlspecialchars($firstName); ?></h2>
                        <p><?php echo htmlspecialchars($program); ?> · <?php echo htmlspecialchars($yearLabel); ?></p>
                    </div>
                </div>
                <div class="df-progress-row"><span id="pcLabel">Profile completeness</span><b><?php echo $completion; ?>%</b></div>
                <div class="df-bar" role="progressbar" aria-labelledby="pcLabel" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo $completion; ?>"><i style="width: <?php echo $completion; ?>%"></i></div>
                <p class="df-next">
                    <?php if ($nextStep === null): ?>
                        Your profile is complete.
                    <?php elseif ($nextStep['href'] === ''): ?>
                        Next: <button type="button" class="open-add-project"><?php echo htmlspecialchars($nextStep['label']); ?></button>
                    <?php else: ?>
                        Next: <a href="<?php echo htmlspecialchars($nextStep['href']); ?>"><?php echo htmlspecialchars($nextStep['label']); ?></a>
                    <?php endif; ?>
                </p>
            </section>

            <section class="df-panel is-tip" aria-labelledby="tipTitle">
                <span class="df-tip-icon"><?php echo dfIcon('sparkles', 20); ?></span>
                <h3 id="tipTitle">Make your work stand out</h3>
                <p>A great cover and a clear story make all the difference. Show the problem, your process, and what you built.</p>
            </section>

            <?php if (!empty($popularSkills)): ?>
            <section class="df-panel df-pop" aria-labelledby="popTitle">
                <h3 id="popTitle">Popular skills in the community</h3>
                <ul>
                    <?php foreach ($popularSkills as $sk): ?>
                        <li><?php echo htmlspecialchars($sk['skill_name']); ?><span><?php echo (int) $sk['cnt']; ?> <?php echo ((int) $sk['cnt']) === 1 ? 'student' : 'students'; ?></span></li>
                    <?php endforeach; ?>
                </ul>
            </section>
            <?php endif; ?>
        </aside>
    </div>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>

<button type="button" id="dfFab" class="df-btn df-btn-primary open-add-project" aria-label="Add Project" tabindex="-1"><?php echo dfIcon('plus', 18); ?> Add Project</button>
<div id="dfToastHost" role="status" aria-live="polite"></div>
<?php include __DIR__ . '/../includes/report-modal.php'; ?>
<?php include __DIR__ . '/../includes/social-ui.php'; ?>
<script src="../js/df-feed-filters.js"></script>
<script src="../js/df-photo-picker.js"></script>
<script src="../js/df-markdown.js"></script>
<script src="../js/df-readme-composer.js"></script>
<script src="../js/df-collab-picker.js"></script>
<script src="../js/df-social.js"></script>
<script src="../js/df-profile-card.js"></script>

<!-- Add project -->
<div id="addModal" class="df-modal" hidden>
    <div class="df-dialog is-wide" role="dialog" aria-modal="true" aria-labelledby="addTitle">
        <button type="button" class="df-x" data-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
        <div class="df-dialog-pad">
            <h2 id="addTitle">Showcase a project</h2>
            <form id="projectForm" enctype="multipart/form-data">
                <input type="hidden" name="action" value="add_project">
                <div class="df-field">
                    <label for="fTitle">Project title <span class="req" aria-hidden="true">*</span></label>
                    <input id="fTitle" name="title" type="text" required maxlength="255" class="df-light">
                </div>
                <div class="df-field">
                    <label for="fCategory">Category</label>
                    <select id="fCategory" name="category" class="df-light">
                        <option>Web App</option><option>Mobile App</option><option>Animation</option><option>Capstone</option><option>Multimedia</option><option>Others, Specify</option>
                    </select>
                    <input id="fCategoryOther" name="category_other" type="text" maxlength="100" class="df-light df-other" placeholder="Type your project's category" aria-label="Specify the category" hidden style="margin-top:8px">
                </div>
                <div class="df-field">
                    <label for="fDesc">Description <span class="req" aria-hidden="true">*</span></label>
                    <textarea id="fDesc" name="description" rows="4" required class="df-light" placeholder="What problem does it solve? How did you build it?"></textarea>
                </div>
                <div class="df-field">
                    <label for="fTech">Technologies</label>
                    <input id="fTech" name="tech_stack" type="text" class="df-light" placeholder="React, Tailwind, Firebase">
                    <small>Separate with commas (up to 8).</small>
                </div>
                <div class="df-field">
                    <?php echo dfPhotoPickerHtml(); ?>
                </div>
                <div class="df-field">
                    <?php echo dfCollabPickerHtml('addCollab'); ?>
                </div>
                <div class="df-field">
                    <label for="fLink">Project link</label>
                    <input id="fLink" name="project_link" type="url" class="df-light" placeholder="https://... (live demo or repository)">
                </div>
                <div class="df-field">
                    <span class="rdc-label" id="rdcLabel">README.md <span class="rdc-opt">(optional, .md only)</span></span>
                    <div class="rdc" id="readmeComposer" aria-labelledby="rdcLabel">
                        <div class="pjx-ed-tabs" role="tablist" aria-label="README editor view">
                            <button type="button" class="pjx-ed-tab" role="tab" id="rdcTabWrite" aria-selected="true" aria-controls="rdcWrite" data-rdc-mode="write">Write</button>
                            <button type="button" class="pjx-ed-tab" role="tab" id="rdcTabPreview" aria-selected="false" aria-controls="rdcPreview" data-rdc-mode="preview" tabindex="-1">Preview</button>
                        </div>
                        <div id="rdcWrite" role="tabpanel" aria-labelledby="rdcTabWrite">
                            <label class="df-sr" for="readmeText">README.md text</label>
                            <textarea id="readmeText" name="readme_text" class="pjx-ed-text rdc-text" spellcheck="false" placeholder="# My project&#10;&#10;What it does, how it works, screenshots..."></textarea>
                        </div>
                        <div id="rdcPreview" class="pjx-ed-preview rdc-preview md-body" role="tabpanel" aria-labelledby="rdcTabPreview" hidden></div>
                        <p class="pjx-ed-help">Write Markdown here or load a .md file, then check it in Preview. Photos need a full https:// link. You can still edit it on your project page later.</p>
                        <div class="pjx-ed-foot">
                            <input type="file" id="rdcFile" accept=".md,text/markdown" hidden>
                            <button type="button" class="rdc-btn" id="rdcPick"><?php echo dfIcon('file', 15); ?> Load .md file</button>
                            <button type="button" class="rdc-btn" id="rdcTemplate">Use template</button>
                            <button type="button" class="rdc-btn" id="rdcClear">Clear</button>
                            <span class="pjx-ed-spacer"></span>
                            <span class="pjx-ed-count" id="rdcCount" aria-live="polite"></span>
                        </div>
                    </div>
                </div>
                <div class="df-actions">
                    <button type="submit" id="submitProject" class="df-btn df-btn-primary">Post Project</button>
                    <button type="button" class="df-btn df-btn-ghost" data-close>Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
(function () {
    // ---------- Toast ----------
    function toast(message, type) {
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        document.getElementById('dfToastHost').appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    function post(body) {
        return fetch(window.location.href, {
            method: 'POST',
            headers: body instanceof FormData ? undefined : { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: body
        });
    }

    // ---------- Accessible modals ----------
    var openModal = null, lastFocus = null;
    var focusable = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled]),[tabindex]:not([tabindex="-1"])';

    function showModal(modal) {
        lastFocus = document.activeElement;
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        openModal = modal;
        var first = modal.querySelector('input:not([type=hidden]),textarea,.df-x');
        (first || modal.querySelector('.df-x')).focus();
    }
    function hideModal() {
        if (!openModal) return;
        openModal.hidden = true;
        openModal = null;
        document.body.style.overflow = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
    }
    document.addEventListener('keydown', function (e) {
        if (!openModal) return;
        if (e.key === 'Escape') { hideModal(); return; }
        if (e.key === 'Tab') {
            var items = Array.prototype.filter.call(openModal.querySelectorAll(focusable), function (n) { return n.offsetParent !== null; });
            if (!items.length) return;
            var first = items[0], last = items[items.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    });
    document.querySelectorAll('.df-modal').forEach(function (m) {
        m.addEventListener('mousedown', function (e) { if (e.target === m) hideModal(); });
        m.addEventListener('click', function (e) { if (e.target.closest('[data-close]')) hideModal(); });
    });

    // ---------- Add project ----------
    var addModal = document.getElementById('addModal');
    var form = document.getElementById('projectForm');
    var photoPicker = DFPhotoPicker.init();
    var readmeComposer = DFReadmeComposer.init({ toast: toast });
    var collabPicker = DFCollabPicker.init(document.getElementById('addCollab'), { endpoint: 'project-actions.php' });

    document.querySelectorAll('.open-add-project').forEach(function (b) {
        b.addEventListener('click', function () { showModal(addModal); });
    });
    // "Others, Specify" reveals a text box right under the category list
    var catSelect = document.getElementById('fCategory'), catOther = document.getElementById('fCategoryOther');
    function syncCategory() {
        var other = catSelect.value === 'Others, Specify';
        catOther.hidden = !other;
        catOther.required = other;
        if (!other) catOther.value = '';
    }
    catSelect.addEventListener('change', function () { syncCategory(); if (!catOther.hidden) catOther.focus(); });
    syncCategory();

    form.addEventListener('submit', async function (e) {
        e.preventDefault();
        if (readmeComposer.isTooLarge()) { toast('The README is too large (max 256 KB).', 'err'); readmeComposer.focus(); return; }
        var btn = document.getElementById('submitProject');
        btn.disabled = true; btn.textContent = 'Sending...';
        try {
            var fd = new FormData(form);
            photoPicker.appendTo(fd);
            collabPicker.appendTo(fd);
            var res = await post(fd);
            var text = await res.text(), data;
            try { data = JSON.parse(text); } catch (err) { throw new Error('The upload was too large for the server. Try smaller files.'); }
            if (data.success) {
                toast(data.message || 'Project posted!', 'ok');
                form.reset(); photoPicker.reset(); readmeComposer.reset(); collabPicker.reset(); syncCategory();
                hideModal();
                searchEl.value = ''; sortEl.value = 'latest'; if (window.DFFilters) DFFilters.reset(true);
                window.scrollTo({ top: 0, behavior: 'smooth' });
                loadFeed(true);
            } else {
                toast(data.message || 'Unable to save project.', 'err');
            }
        } catch (err) {
            toast(err.message || 'Unable to save project.', 'err');
        } finally {
            btn.disabled = false; btn.textContent = 'Post Project';
        }
    });

    // ---------- Floating Add Project (shows once the header button scrolls away) ----------
    var fab = document.getElementById('dfFab');
    new IntersectionObserver(function (entries) {
        var away = !entries[0].isIntersecting;
        fab.classList.toggle('show', away);
        fab.tabIndex = away ? 0 : -1;
    }, { rootMargin: '-72px 0px 0px 0px' }).observe(document.getElementById('addProjectBtn'));

    // ---------- Feed: search, sort, infinite scroll ----------
    var feedEl = document.getElementById('feed'), skel = document.getElementById('feedSkeleton');
    var endEl = document.getElementById('feedEnd'), countEl = document.getElementById('feedCount');
    var searchEl = document.getElementById('feedSearch'), sortEl = document.getElementById('feedSort');
    var state = { offset: 0, loading: false, done: false, token: 0 };

    function emptyState(q) {
        var wrap = document.createElement('div'); wrap.className = 'df-empty';
        var h = document.createElement('h3'), p = document.createElement('p');
        if (q) { h.textContent = 'No projects match your search or filters'; p.textContent = 'Try a different keyword, tag or date range.'; }
        else { h.textContent = 'No projects yet'; p.textContent = 'Be the first to showcase a project to the CCDI community.'; }
        wrap.appendChild(h); wrap.appendChild(p);
        if (q) {
            var clr = document.createElement('button'); clr.type = 'button'; clr.className = 'df-btn df-btn-primary';
            clr.textContent = 'Clear search and filters';
            clr.addEventListener('click', function () { searchEl.value = ''; if (window.DFFilters) DFFilters.reset(true); loadFeed(true); });
            wrap.appendChild(clr);
        }
        if (!q) {
            var b = document.createElement('button'); b.type = 'button'; b.className = 'df-btn df-btn-primary';
            b.textContent = 'Add Project'; b.addEventListener('click', function () { showModal(addModal); });
            wrap.appendChild(b);
        }
        feedEl.appendChild(wrap);
    }

    async function loadFeed(reset) {
        if (reset) {
            state.token++; state.offset = 0; state.done = false; state.loading = false;
            feedEl.innerHTML = ''; endEl.hidden = true;
        }
        if (state.loading || state.done) return;
        state.loading = true;
        var token = state.token;
        skel.hidden = false;
        var q = searchEl.value.trim();
        try {
            var body = new URLSearchParams(Object.assign({ action: 'get_feed', offset: state.offset, q: q, sort: sortEl.value }, window.DFFilters ? DFFilters.params() : {}));
            var res = await post(body.toString());
            var data = await res.json();
            if (token !== state.token) return;
            if (!data.success) throw new Error('feed');
            feedEl.insertAdjacentHTML('beforeend', data.html);
            initCaptions(feedEl);
            state.offset = data.next_offset;
            countEl.textContent = data.total + (data.total === 1 ? ' project' : ' projects');
            if (!data.has_more) {
                state.done = true;
                if (data.total === 0) emptyState(q || (window.DFFilters && DFFilters.active())); else endEl.hidden = false;
            }
        } catch (err) {
            if (token === state.token) toast('Unable to load projects. Please try again.', 'err');
        } finally {
            if (token === state.token) { state.loading = false; skel.hidden = true; }
        }
    }

    var debounce;
    searchEl.addEventListener('input', function () { clearTimeout(debounce); debounce = setTimeout(function () { loadFeed(true); }, 300); });
    sortEl.addEventListener('change', function () { loadFeed(true); });
    if (window.DFFilters) DFFilters.onChange(function () { loadFeed(true); });
    new IntersectionObserver(function (en) { if (en[0].isIntersecting) loadFeed(); }, { rootMargin: '600px 0px' })
        .observe(document.getElementById('feedSentinel'));

    // ---------- Caption "See more" (Facebook style) ----------
    function initCaptions(root) {
        (root || document).querySelectorAll('[data-caption]').forEach(function (cap) {
            var btn = cap.parentNode.querySelector('[data-seemore]');
            if (!btn || cap.dataset.ready) return;
            cap.dataset.ready = '1';
            if (cap.scrollHeight > cap.clientHeight + 1) btn.hidden = false;
        });
    }
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-seemore]');
        if (!btn) return;
        var cap = btn.parentNode.querySelector('[data-caption]');
        var open = cap.classList.toggle('is-open');
        btn.textContent = open ? 'See less' : 'See more';
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    window.addEventListener('resize', function () {
        document.querySelectorAll('[data-caption]:not(.is-open)').forEach(function (cap) {
            var btn = cap.parentNode.querySelector('[data-seemore]');
            if (btn) btn.hidden = !(cap.scrollHeight > cap.clientHeight + 1);
        });
    });

    // ---------- Appreciate (heart) ----------
    document.addEventListener('click', async function (e) {
        var like = e.target.closest('[data-like]');
        if (like) {
            var id = like.dataset.like;
            try {
                var r = await post(new URLSearchParams({ action: 'toggle_like', project_id: id }).toString());
                var d = await r.json();
                if (!d.success) { toast(d.message || 'Could not update.', 'err'); return; }
                document.querySelectorAll('[data-like="' + id + '"]').forEach(function (b) {
                    b.setAttribute('aria-pressed', d.liked ? 'true' : 'false');
                    b.querySelector('span').textContent = d.count > 0 ? d.count : '';
                });
            } catch (err) { toast('Could not update.', 'err'); }
        }
    });

    loadFeed(true);
})();
</script>
</body>
</html>
