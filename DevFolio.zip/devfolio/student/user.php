<?php
/**
 * User profile page (read-only, shared by students and faculty).
 * DEVFOLIO CCDI Sorsogon
 *
 * Opened by clicking a name or avatar in the feed, comments or a project page.
 * Faculty open it through faculty/user.php, which loads this file.
 * A student opening their own profile goes to my-profile.php (the editable Profile page).
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/profile-helpers.php';
require_once __DIR__ . '/../includes/follow-helpers.php';
require_once __DIR__ . '/../includes/profile-edit-helpers.php';
require_once __DIR__ . '/../includes/profile-timeline.php';

$dfRole = $_SESSION['role'] ?? '';
if (!isset($_SESSION['user_id']) || !in_array($dfRole, ['student', 'faculty'], true)) {
    header('Location: ../login.php');
    exit;
}

$meId = (int) $_SESSION['user_id'];
$profileId = (int) ($_GET['id'] ?? 0);

// Each role browses from its own folder so relative links stay inside it.
$dfInFacultyDir = basename(dirname((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''))) === 'faculty';
if ($dfRole === 'faculty' && !$dfInFacultyDir) {
    header('Location: ../faculty/user.php?id=' . $profileId);
    exit;
}
if ($dfRole === 'student' && $dfInFacultyDir) {
    header('Location: ../student/user.php?id=' . $profileId);
    exit;
}
$isFaculty = $dfRole === 'faculty';

// Own profile -> the editable Profile page
if ($dfRole === 'student' && $profileId === $meId) {
    header('Location: my-profile.php');
    exit;
}

$pf = dfFetchProfile($pdo, $profileId, true);
$isStudentProfile = $pf && $pf['role'] === 'student';
$canSeePrivate = $isFaculty; // email + student ID are for faculty/admin eyes only
// Students can follow other students (only students post projects). Faculty just see the count.
$canFollow = $pf && $isStudentProfile && $dfRole === 'student' && (int) $pf['id'] !== $meId;
$isFollowing = $canFollow ? dfIsFollowing($pdo, $meId, (int) $pf['id']) : false;
$pageTitle = $pf ? dfOwnerName($pf) : 'Profile not found';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo dfEsc($pageTitle); ?> - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $navActive = 'discover'; $facActive = 'discover'; include __DIR__ . '/../includes/' . ($isFaculty ? 'faculty-nav.php' : 'student-nav.php'); ?>

<main id="main" class="df-page upx<?php echo $isStudentProfile ? ' pf' : ''; ?>">
    <p class="df-back-row">
        <a class="df-back" id="upBack" href="dashboard.php"><?php echo dfIcon('back', 16); ?> Back</a>
    </p>

<?php if (!$pf): ?>
    <div class="df-empty">
        <h3>This profile is not available</h3>
        <p>The account may have been removed.</p>
        <a class="df-btn df-btn-primary" href="dashboard.php">Browse projects</a>
    </div>
<?php elseif ($isStudentProfile): ?>

    <?php echo dfRenderProfileView($pdo, $pf, [
        'isOwner'       => false,
        'viewerId'      => $meId,
        'viewerRole'    => $dfRole,
        'canSeePrivate' => $canSeePrivate,
        'canFollow'     => $canFollow,
        'isFollowing'   => $isFollowing,
    ]); ?>

<?php else: ?>

    <section class="upx-hero" aria-labelledby="upName">
        <div class="upx-avwrap"><?php echo dfAvatarHtml($pf); ?></div>
        <div class="upx-info">
            <div class="upx-namerow">
                <h1 id="upName" class="upx-name"><?php echo dfEsc(dfOwnerName($pf)); ?></h1>
                <?php echo dfRoleBadge($pf['role']); ?>
            </div>
            <?php if ($pf['profession'] !== ''): ?><p class="upx-profession"><?php echo dfEsc($pf['profession']); ?></p><?php endif; ?>
            <p class="upx-sub"><?php echo dfEsc(dfProfileSubtitle($pf)); ?></p>

            <ul class="upx-contact">
                <?php if ($canSeePrivate && $pf['email'] !== ''): ?>
                    <li><?php echo dfIcon('mail', 15); ?> <a href="mailto:<?php echo dfEsc($pf['email']); ?>"><?php echo dfEsc($pf['email']); ?></a></li>
                <?php endif; ?>
                <?php if ($pf['portfolio_link'] !== ''): ?>
                    <li><?php echo dfIcon('link', 15); ?> <a href="<?php echo dfEsc($pf['portfolio_link']); ?>" target="_blank" rel="noopener noreferrer">Portfolio</a></li>
                <?php endif; ?>
                <?php if ($canSeePrivate && $pf['student_code'] !== ''): ?>
                    <li><?php echo dfIcon('user', 15); ?> ID <?php echo dfEsc($pf['student_code']); ?></li>
                <?php endif; ?>
            </ul>

            <?php if ($pf['bio'] !== ''): ?>
                <p class="upx-bio"><?php echo nl2br(dfEsc($pf['bio'])); ?></p>
            <?php elseif ($isStudentProfile): ?>
                <p class="upx-bio is-empty">This student has not written a bio yet.</p>
            <?php endif; ?>

            <?php if ($canFollow): ?>
                <div class="upx-follow"><?php echo dfFollowButton((int) $pf['id'], $isFollowing); ?></div>
            <?php endif; ?>
        </div>

        <?php
            $stats = [];
            if ($isStudentProfile) {
                $stats[] = ['Projects', (int) $pf['project_count']];
                $stats[] = ['Appreciations', (int) $pf['like_total']];
                $stats[] = ['Followers', (int) $pf['follower_count'], '', (int) $pf['id']];
            }
            $stats[] = ['Streak', (int) $pf['streak'], 'flame'];
            $stats[] = ['Badges', count($pf['badges'])];
        ?>
        <dl class="upx-stats" style="--n: <?php echo count($stats); ?>">
            <?php foreach ($stats as $st): ?>
                <div><dt><?php echo dfEsc($st[0]); ?></dt><dd><?php if (!empty($st[2])) echo '<span class="upx-flame">' . dfIcon($st[2], 18) . '</span>'; echo !empty($st[3]) ? '<span data-follower-count="' . (int) $st[3] . '">' . (int) $st[1] . '</span>' : $st[1]; ?></dd></div>
            <?php endforeach; ?>
        </dl>
    </section>

    <div class="upx-grid">
        <div class="upx-main">
        <section class="upx-card" aria-labelledby="upProjects">
            <h2 id="upProjects" class="upx-h">Showcased projects</h2>
            <?php if (!$isStudentProfile): ?>
                <p class="upx-muted">Faculty members review and guide student work. They do not post projects.</p>
            <?php elseif (empty($pf['projects'])): ?>
                <p class="upx-muted">No projects have been showcased yet.</p>
            <?php else: ?>
                <div class="upx-projects">
                    <?php foreach ($pf['projects'] as $pj): $pjUrl = 'project.php?id=' . (int) $pj['id']; $likes = (int) $pj['like_count']; ?>
                        <article class="upx-project">
                            <a class="df-preview <?php echo dfEsc(dfTint($pj['category'] ?? '')); ?>" href="<?php echo dfEsc($pjUrl); ?>" aria-label="<?php echo dfEsc('View ' . $pj['title']); ?>">
                                <?php echo dfPreviewInner($pj); ?>
                            </a>
                            <h3><a href="<?php echo dfEsc($pjUrl); ?>"><?php echo dfEsc($pj['title']); ?></a></h3>
                            <p><?php echo dfEsc(trim(($pj['category'] ?? '') . ($likes > 0 ? ' · ' . $likes . ($likes === 1 ? ' appreciation' : ' appreciations') : ''), ' ·')); ?></p>
                        </article>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>

        <?php if ($isStudentProfile): ?>
        <section class="upx-card" aria-labelledby="upCerts">
            <h2 id="upCerts" class="upx-h">Certificates</h2>
            <?php if (empty($pf['certificates'])): ?>
                <p class="upx-muted">No certificates added yet.</p>
            <?php else: ?>
                <?php echo dfRenderCertificates($pf['certificates'], false); ?>
            <?php endif; ?>
        </section>
        <?php endif; ?>
        </div>

        <aside class="upx-side" aria-label="About">
            <section class="upx-card" aria-labelledby="upBadges">
                <h2 id="upBadges" class="upx-h">Badges</h2>
                <?php if (empty($pf['badges'])): ?>
                    <p class="upx-muted">No badges earned yet.</p>
                <?php elseif (empty($pf['badges_shown'])): ?>
                    <p class="upx-muted">This member has chosen not to display their badges.</p>
                <?php else: ?>
                    <ul class="upx-badges">
                        <?php foreach ($pf['badges_shown'] as $bd): $tl = dfTiers()[$bd['tier']]['label']; ?>
                            <li>
                                <?php echo dfBadgeMedal($bd, true); ?>
                                <span><strong><?php echo dfEsc($bd['name']); ?></strong><small><?php echo dfEsc($tl); ?></small></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                    <?php if (count($pf['badges_shown']) < count($pf['badges'])): ?>
                        <p class="upx-muted upx-best">Showing <?php echo count($pf['badges_shown']); ?> of <?php echo count($pf['badges']); ?> earned badges.</p>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if ((int) $pf['streak_best'] > 0): ?>
                    <p class="upx-muted upx-best">Best streak: <?php echo (int) $pf['streak_best']; ?> <?php echo (int) $pf['streak_best'] === 1 ? 'day' : 'days'; ?></p>
                <?php endif; ?>
            </section>

            <?php if ($isStudentProfile): ?>
            <section class="upx-card" aria-labelledby="upSkills">
                <h2 id="upSkills" class="upx-h">Skills</h2>
                <?php if (empty($pf['skills'])): ?>
                    <p class="upx-muted">No skills listed yet.</p>
                <?php else: ?>
                    <?php echo dfRenderSkillChips($pf['skills'], false); ?>
                <?php endif; ?>
            </section>
            <?php else: ?>
            <section class="upx-card" aria-labelledby="upAbout">
                <h2 id="upAbout" class="upx-h">About</h2>
                <dl class="upx-facts">
                    <div><dt>Department</dt><dd><?php echo dfEsc($pf['department'] !== '' ? $pf['department'] : 'CCDI Sorsogon'); ?></dd></div>
                    <?php if ($pf['specialization'] !== ''): ?><div><dt>Specialization</dt><dd><?php echo dfEsc($pf['specialization']); ?></dd></div><?php endif; ?>
                </dl>
            </section>
            <?php endif; ?>

            <section class="upx-card" aria-labelledby="upMember">
                <h2 id="upMember" class="upx-h">Member since</h2>
                <p class="upx-muted"><?php echo dfEsc(date('F j, Y', strtotime((string) $pf['created_at']) ?: time())); ?></p>
            </section>
        </aside>
    </div>

<?php endif; ?>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>
<script>
    // "Back" returns to where the person came from (feed, comments, a project) when that was this site.
    (function () {
        var back = document.getElementById('upBack');
        if (!back || !document.referrer || history.length < 2) return;
        try { if (new URL(document.referrer).origin !== location.origin) return; } catch (e) { return; }
        back.addEventListener('click', function (e) { e.preventDefault(); history.back(); });
    })();
</script>
<script src="../js/df-more.js"></script>
<?php if ($pf && $isStudentProfile): ?>
<div id="dfToastHost" role="status" aria-live="polite"></div>
<?php include __DIR__ . '/../includes/social-ui.php'; ?>
<?php if ($dfRole === 'student') { include __DIR__ . '/../includes/report-modal.php'; } ?>
<script src="../js/df-cert-view.js"></script>
<?php if ($dfRole === 'student'): ?><script src="../js/df-follow.js"></script><?php endif; ?>
<script src="../js/df-social.js"></script>
<script src="../js/df-profile-card.js"></script>
<script src="../js/df-profile.js"></script>
<?php endif; ?>
</body>
</html>
