<?php
/**
 * Edit or delete the signed-in student's own projects (JSON endpoint).
 *
 * POST action=update_project  project_id, title, category, category_other, description,
 *                             tech_stack, project_link, photos[], photo_order, remove_photos[]
 * POST action=delete_project  project_id
 *
 * Only the owner can do either. A project a moderator removed cannot be edited (so it cannot
 * be re-published) but its owner can still delete it.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/project-form.php';

header('Content-Type: application/json');

function dfOut(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    dfOut(['success' => false, 'message' => 'Please sign in as a student.'], 403);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    dfOut(['success' => false, 'message' => 'Invalid request.'], 405);
}

$meId = (int) $_SESSION['user_id'];
$action = (string) ($_POST['action'] ?? '');
$projectId = (int) ($_POST['project_id'] ?? 0);

$st = $pdo->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
$st->execute([$meId]);
$studentId = (int) $st->fetchColumn();
if ($studentId === 0) dfOut(['success' => false, 'message' => 'Student profile not found.'], 403);

// The project must belong to this student
$ps = $pdo->prepare('SELECT * FROM projects WHERE id = ? AND student_id = ? LIMIT 1');
$ps->execute([$projectId, $studentId]);
$project = $ps->fetch(PDO::FETCH_ASSOC);
if (!$project) dfOut(['success' => false, 'message' => 'That project was not found in your account.']);

// ---------------------------------------------------------------
if ($action === 'update_project') {
    if ($project['status'] === 'removed') {
        dfOut(['success' => false, 'message' => 'This project was removed by a moderator, so it cannot be edited.']);
    }

    $f = dfReadProjectFields($_POST);
    if (isset($f['error'])) dfOut(['success' => false, 'message' => $f['error']]);

    [$photoError, $pending] = dfReadPhotoUploads($_FILES);
    if ($photoError !== null) dfOut(['success' => false, 'message' => $photoError]);

    $removeIds = array_values(array_filter(array_map('intval', (array) ($_POST['remove_photos'] ?? [])), function ($n) { return $n > 0; }));
    $order = (string) ($_POST['photo_order'] ?? '');

    // Photos first, so a limit problem leaves everything untouched
    $photoProblem = null;
    if ($pending || $removeIds || $order !== '') {
        $photoProblem = dfApplyProjectPhotos($pdo, $projectId, $studentId, $pending, $removeIds, $order);
        if ($photoProblem !== null) dfOut(['success' => false, 'message' => $photoProblem]);
    }

    $up = $pdo->prepare(
        'UPDATE projects SET title = ?, description = ?, abstract = ?, category = ?, demo_link = ?, tech_stack = ?, updated_at = NOW()
         WHERE id = ? AND student_id = ? AND status <> \'removed\''
    );
    $up->execute([$f['title'], $f['description'], $f['description'], $f['category'], $f['link'], $f['tech'], $projectId, $studentId]);

    dfOut(['success' => true, 'message' => 'Changes saved.']);
}

// ---------------------------------------------------------------
if ($action === 'delete_project') {
    try {
        // Collect files first; the rows disappear with the project (comments, hearts, photos, README, team)
        $extra = [];
        try {
            $fs = $pdo->prepare('SELECT file_path FROM project_files WHERE project_id = ?');
            $fs->execute([$projectId]);
            $extra = $fs->fetchAll(PDO::FETCH_COLUMN);
        } catch (Throwable $e) {
            // table may not exist in older databases
        }

        $paths = [];
        if (dfPhotosReady($pdo)) {
            $pp = $pdo->prepare('SELECT file_path FROM project_photos WHERE project_id = ?');
            $pp->execute([$projectId]);
            $paths = $pp->fetchAll(PDO::FETCH_COLUMN);
        }
        $paths[] = (string) ($project['banner_image_url'] ?? '');

        $del = $pdo->prepare('DELETE FROM projects WHERE id = ? AND student_id = ?');
        $del->execute([$projectId, $studentId]);
        if ($del->rowCount() < 1) dfOut(['success' => false, 'message' => 'The project could not be deleted.']);

        foreach (array_unique(array_merge($paths, $extra)) as $path) dfDeleteUploadedFile((string) $path);
    } catch (Throwable $e) {
        dfOut(['success' => false, 'message' => 'The project could not be deleted. Please try again.']);
    }
    dfOut(['success' => true, 'message' => 'Project deleted.']);
}

dfOut(['success' => false, 'message' => 'Unknown action.']);
