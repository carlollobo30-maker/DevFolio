<?php
/**
 * The Skills page now lives on Account settings (skills, certificates, bio and profession).
 * This file only keeps old links and bookmarks working.
 */
header('Location: profile.php#skills', true, 301);
exit;
