<?php
/**
 * Student Account settings
 * DEVFOLIO CCDI Sorsogon
 *
 * Layout: cover photo + profile photo header (both editable here), a section menu on the left,
 * and cards for personal info, about you, working links, skills and certificates.
 * Personal info + profile photo are saved by this file; everything else (cover photo included)
 * goes through profile-actions.php.
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/follow-helpers.php';
require_once __DIR__ . '/../includes/profile-helpers.php';
require_once __DIR__ . '/../includes/profile-edit-helpers.php';
require_once __DIR__ . '/../includes/profile-timeline.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'student') {
    header('Location: ../login.php');
    exit;
}

$stmt = $pdo->prepare('SELECT * FROM users WHERE id = ? LIMIT 1');
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$studentStmt = $pdo->prepare('SELECT * FROM students WHERE user_id = ? LIMIT 1');
$studentStmt->execute([$_SESSION['user_id']]);
$student = $studentStmt->fetch(PDO::FETCH_ASSOC);

if (!$student) {
    $newStudentId = 'STU-' . date('Y') . '-' . str_pad((string) $_SESSION['user_id'], 4, '0', STR_PAD_LEFT);
    $insertStudent = $pdo->prepare('INSERT INTO students (user_id, student_id, program, year_level, enrollment_status) VALUES (?, ?, ?, ?, "active")');
    $insertStudent->execute([
        $_SESSION['user_id'],
        $newStudentId,
        'BSCS',
        '3rd'
    ]);
    $student = $pdo->query('SELECT * FROM students WHERE user_id = ' . (int) $_SESSION['user_id'] . ' LIMIT 1')->fetch(PDO::FETCH_ASSOC);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    header('Content-Type: application/json');
    $action = $_POST['action'];

    if ($action === 'save_profile') {
        $firstName = trim($_POST['first_name'] ?? '');
        $lastName = trim($_POST['last_name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        $phone = trim($_POST['phone'] ?? '');

        if ($firstName === '' || $lastName === '' || $email === '') {
            echo json_encode(['success' => false, 'message' => 'First name, last name, and email are required.']);
            exit;
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            echo json_encode(['success' => false, 'message' => 'Please enter a valid email address.']);
            exit;
        }

        $userCheck = $pdo->prepare('SELECT id FROM users WHERE email = ? AND id != ? LIMIT 1');
        $userCheck->execute([$email, $_SESSION['user_id']]);
        if ($userCheck->fetch()) {
            echo json_encode(['success' => false, 'message' => 'This email is already used by another account.']);
            exit;
        }

        // The profile photo is saved by upload_avatar, so it is left untouched here.
        $updateUser = $pdo->prepare('UPDATE users SET first_name = ?, last_name = ?, email = ?, phone = ?, updated_at = NOW() WHERE id = ?');
        $updateUser->execute([$firstName, $lastName, $email, $phone, $_SESSION['user_id']]);

        $_SESSION['first_name'] = $firstName;
        $_SESSION['last_name'] = $lastName;
        $_SESSION['email'] = $email;

        echo json_encode(['success' => true, 'message' => 'Profile saved successfully.']);
        exit;
    }

    if ($action === 'upload_avatar') {
        if (!isset($_FILES['avatar']) || $_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            echo json_encode(['success' => false, 'message' => 'Please choose an image.']);
            exit;
        }

        $file = $_FILES['avatar'];
        $info = @getimagesize($file['tmp_name']);
        $types = [IMAGETYPE_JPEG => 'jpg', IMAGETYPE_PNG => 'png', IMAGETYPE_WEBP => 'webp'];
        if (!$info || !isset($types[$info[2]])) {
            echo json_encode(['success' => false, 'message' => 'Only JPG, PNG, or WEBP images are allowed.']);
            exit;
        }

        $filename = 'avatar_' . $_SESSION['user_id'] . '_' . time() . '.' . $types[$info[2]];
        $uploadDir = __DIR__ . '/../assets/uploads/avatars/';

        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }

        $destination = $uploadDir . $filename;
        if (!move_uploaded_file($file['tmp_name'], $destination)) {
            echo json_encode(['success' => false, 'message' => 'Avatar upload failed.']);
            exit;
        }

        $avatarUrl = '../assets/uploads/avatars/' . $filename;
        $updateUser = $pdo->prepare('UPDATE users SET avatar_url = ?, updated_at = NOW() WHERE id = ?');
        $updateUser->execute([$avatarUrl, $_SESSION['user_id']]);

        echo json_encode(['success' => true, 'message' => 'Profile photo updated.', 'avatar_url' => $avatarUrl]);
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    if (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }
}

$meId = (int) $_SESSION['user_id'];
$profileFirst = (string) ($user['first_name'] ?? '');
$profileLast = (string) ($user['last_name'] ?? '');
$profileEmail = (string) ($user['email'] ?? '');
$profilePhone = (string) ($user['phone'] ?? '');
$rawAvatar = trim((string) ($user['avatar_url'] ?? ''));
$hasAvatar = $rawAvatar !== '' && stripos($rawAvatar, 'placehold.co') === false;
$profileAvatar = $hasAvatar ? dfAssetUrl($rawAvatar) : '';
$initials = dfInitials($profileFirst, $profileLast);

// About you / skills / certificates / links (edited here, saved through profile-actions.php)
$sid = (int) $student['id'];
$pf = dfFetchProfile($pdo, $meId, false);
$lists = dfProfileLists($pdo, $sid);
$skillCount = (int) $lists['skill_count'];
$certCount = (int) $lists['cert_count'];
$linkLists = dfLinkLists($pdo, $meId);
$cover = dfProfileCover($pdo, $meId);

$fullName = trim($profileFirst . ' ' . $profileLast);
$headline = implode(' · ', array_filter([$pf['profession'] ?? '', dfProfileSubtitle($pf)], static function ($v) { return trim((string) $v) !== ''; }));

// "Profile strength" checklist (each item jumps to the place where it is filled in)
$strength = [
    ['key' => 'photo', 'label' => 'Profile photo', 'done' => $hasAvatar, 'href' => '#accHero'],
    ['key' => 'cover', 'label' => 'Cover photo', 'done' => $cover !== '', 'href' => '#accHero'],
    ['key' => 'profession', 'label' => 'Profession / title', 'done' => trim((string) ($pf['profession'] ?? '')) !== '', 'href' => '#bio'],
    ['key' => 'bio', 'label' => 'Short bio', 'done' => trim((string) ($pf['bio'] ?? '')) !== '', 'href' => '#bio'],
    ['key' => 'links', 'label' => 'A working link', 'done' => (int) $linkLists['link_count'] > 0, 'href' => '#links'],
    ['key' => 'skills', 'label' => 'At least one skill', 'done' => $skillCount > 0, 'href' => '#skills'],
];
$doneCount = count(array_filter($strength, static function ($s) { return $s['done']; }));
$strengthPct = (int) round($doneCount / count($strength) * 100);

$sections = [
    ['personal', 'user', 'Personal info'],
    ['bio', 'compose', 'About you'],
    ['links', 'link', 'Working links'],
    ['skills', 'zap', 'Skills'],
    ['certificates', 'award', 'Certificates'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account settings - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $navActive = 'profile'; include __DIR__ . '/../includes/student-nav.php'; ?>

<main id="main" class="df-page acc mp">
    <header class="acc-top">
        <div>
            <p class="acc-eyebrow"><?php echo dfIcon('useredit', 14); ?> Account settings</p>
            <h1 class="acc-title">Make your profile yours</h1>
            <p class="acc-lede">Everything here shows on your public profile and on the projects you post.</p>
        </div>
        <a class="acc-view" href="my-profile.php"><?php echo dfIcon('eye', 16); ?> View my profile</a>
    </header>

    <!-- Cover photo + profile photo -->
    <section class="acc-hero" id="accHero" aria-label="Cover and profile photo">
        <div class="acc-cover<?php echo $cover === '' ? ' is-default' : ''; ?>" id="accCover"<?php echo $cover !== '' ? ' style="background-image:url(\'' . dfEsc($cover) . '\')"' : ''; ?>>
            <div class="acc-cover-drop" aria-hidden="true"><?php echo dfIcon('upload', 22); ?><span>Drop the photo to use it as your cover</span></div>
            <div class="acc-cover-busy" aria-hidden="true"><span class="acc-spin"></span><span>Uploading cover...</span></div>
            <div class="acc-cover-tools">
                <button type="button" class="acc-cover-btn" id="accCoverEdit"><?php echo dfIcon('camera', 16); ?> <span id="accCoverEditLabel"><?php echo $cover === '' ? 'Add cover photo' : 'Change cover'; ?></span></button>
                <button type="button" class="acc-cover-btn is-danger" id="accCoverRemove" aria-label="Remove cover photo"<?php echo $cover === '' ? ' hidden' : ''; ?>><?php echo dfIcon('trash', 16); ?></button>
            </div>
            <input type="file" id="accCoverInput" accept="image/jpeg,image/png,image/webp" hidden>
        </div>

        <div class="acc-hero-body">
            <div class="acc-avatar-wrap">
                <button type="button" id="avatarTrigger" class="acc-avatar" aria-haspopup="menu" aria-expanded="false" aria-controls="photoActions" aria-label="Change profile photo">
                    <span class="acc-avatar-initials"><?php echo dfEsc($initials); ?></span>
                    <img id="profileAvatarLarge" src="<?php echo dfEsc($profileAvatar); ?>" alt=""<?php echo $hasAvatar ? '' : ' hidden'; ?>>
                    <span class="acc-avatar-cam"><?php echo dfIcon('camera', 15); ?></span>
                </button>
                <div id="photoActions" class="acc-menu" role="menu" hidden>
                    <button type="button" id="uploadPhotoBtn" role="menuitem"><?php echo dfIcon('upload', 16); ?> Upload a photo</button>
                    <button type="button" id="capturePhotoBtn" role="menuitem"><?php echo dfIcon('camera', 16); ?> Take a photo</button>
                </div>
                <input type="file" id="captureInput" accept="image/*" capture="user" hidden>
                <input type="file" id="uploadInput" accept="image/jpeg,image/png,image/webp" hidden>
            </div>

            <div class="acc-id">
                <h2 class="acc-name" data-live-name><?php echo dfEsc($fullName); ?></h2>
                <p class="acc-sub" data-subtitle="<?php echo dfEsc(dfProfileSubtitle($pf)); ?>"><?php echo dfEsc($headline !== '' ? $headline : 'Student'); ?></p>
                <p class="acc-hint"><?php echo dfIcon('image', 14); ?> Cover: JPG, PNG or WEBP up to 8 MB, wide photos (about 1500 × 500) look best.</p>
            </div>

            <dl class="acc-stats" aria-label="Your audience">
                <div><dt>Followers</dt><dd data-follower-count="<?php echo $meId; ?>"><?php echo (int) $pf['follower_count']; ?></dd></div>
                <div><dt>Following</dt><dd><?php echo (int) $pf['following_count']; ?></dd></div>
                <div><dt>Projects</dt><dd><?php echo (int) $pf['project_count']; ?></dd></div>
            </dl>
        </div>
    </section>

    <div class="acc-grid">
        <aside class="acc-side">
            <nav class="acc-nav" aria-label="Settings sections">
                <?php foreach ($sections as $i => [$id, $icon, $label]): ?>
                    <a href="#<?php echo $id; ?>" data-acc-nav="<?php echo $id; ?>"<?php echo $i === 0 ? ' class="is-active" aria-current="true"' : ''; ?>><?php echo dfIcon($icon, 16); ?><span><?php echo dfEsc($label); ?></span></a>
                <?php endforeach; ?>
            </nav>

            <section class="acc-strength" aria-labelledby="accStrengthH">
                <div class="acc-strength-top">
                    <h2 id="accStrengthH">Profile strength</h2>
                    <b data-strength-pct><?php echo $strengthPct; ?>%</b>
                </div>
                <div class="acc-meter" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo $strengthPct; ?>" aria-labelledby="accStrengthH"><span data-strength-bar style="width:<?php echo $strengthPct; ?>%"></span></div>
                <ul class="acc-checks">
                    <?php foreach ($strength as $s): ?>
                        <li class="<?php echo $s['done'] ? 'is-done' : ''; ?>" data-strength="<?php echo $s['key']; ?>">
                            <a href="<?php echo $s['href']; ?>"><span class="acc-check"><?php echo dfIcon('check', 12); ?></span><?php echo dfEsc($s['label']); ?></a>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </section>
        </aside>

        <div class="acc-main">
            <section class="acc-card" id="personal" aria-labelledby="accPersonalH">
                <header class="acc-card-head">
                    <span class="acc-ico"><?php echo dfIcon('user', 18); ?></span>
                    <div>
                        <h2 id="accPersonalH">Personal info</h2>
                        <p>Your name shows on every project. Email and phone stay private to you and faculty.</p>
                    </div>
                </header>
                <form id="profileForm" method="POST" novalidate>
                    <div class="acc-fields">
                        <div class="df-field">
                            <label for="firstName">First name <span class="req">*</span></label>
                            <input id="firstName" class="df-light" type="text" autocomplete="given-name" value="<?php echo dfEsc($profileFirst); ?>" required>
                        </div>
                        <div class="df-field">
                            <label for="lastName">Last name <span class="req">*</span></label>
                            <input id="lastName" class="df-light" type="text" autocomplete="family-name" value="<?php echo dfEsc($profileLast); ?>" required>
                        </div>
                        <div class="df-field acc-icon-field">
                            <label for="email">Email <span class="req">*</span></label>
                            <span class="acc-in-ico"><?php echo dfIcon('mail', 16); ?></span>
                            <input id="email" class="df-light" type="email" autocomplete="email" value="<?php echo dfEsc($profileEmail); ?>" required>
                        </div>
                        <div class="df-field acc-icon-field">
                            <label for="phone">Phone number</label>
                            <span class="acc-in-ico"><?php echo dfIcon('phone', 16); ?></span>
                            <input id="phone" class="df-light" type="tel" autocomplete="tel" value="<?php echo dfEsc($profilePhone); ?>" placeholder="+63 9XX XXX XXXX">
                        </div>
                    </div>
                    <div class="acc-actions">
                        <span class="acc-dirty" id="accDirty" hidden>Unsaved changes</span>
                        <button type="button" id="cancelProfileBtn" class="df-btn df-btn-ghost">Discard</button>
                        <button type="submit" class="df-btn df-btn-primary"><?php echo dfIcon('check', 16); ?> Save changes</button>
                    </div>
                </form>
            </section>

            <section class="acc-card upx-card" id="bio" aria-labelledby="mpAboutH">
                <header class="acc-card-head">
                    <span class="acc-ico"><?php echo dfIcon('compose', 18); ?></span>
                    <div>
                        <h2 id="mpAboutH" class="upx-h">About you</h2>
                        <p>A title and a few lines help mentors and recruiters understand what you do.</p>
                    </div>
                </header>
                <form id="aboutForm" autocomplete="off">
                    <div class="df-field">
                        <label for="mpProfession">Profession / title</label>
                        <input id="mpProfession" class="df-light" type="text" maxlength="<?php echo DF_PROFESSION_MAX; ?>" value="<?php echo dfEsc($pf['profession']); ?>" placeholder="e.g. Full-stack developer, UI/UX designer">
                    </div>
                    <div class="df-field">
                        <label for="mpBio">Bio</label>
                        <textarea id="mpBio" class="df-light" rows="5" maxlength="<?php echo DF_BIO_MAX; ?>" placeholder="Tell people who you are and what you build..."><?php echo dfEsc($pf['bio']); ?></textarea>
                        <small class="acc-counter"><span id="mpBioCount"><?php echo mb_strlen($pf['bio']); ?></span> / <?php echo DF_BIO_MAX; ?></small>
                    </div>
                    <div class="acc-actions">
                        <button type="submit" class="df-btn df-btn-primary"><?php echo dfIcon('check', 16); ?> Save about you</button>
                    </div>
                </form>
            </section>

            <section class="acc-card upx-card" id="links" aria-labelledby="mpLinksH">
                <header class="acc-card-head">
                    <span class="acc-ico"><?php echo dfIcon('link', 18); ?></span>
                    <div>
                        <h2 id="mpLinksH" class="upx-h">Working profiles &amp; links</h2>
                        <p>Shown on your profile and at the top right of every project you post.</p>
                    </div>
                    <span class="acc-pill"><span data-link-count><?php echo (int) $linkLists['link_count']; ?></span> / <?php echo DF_LINK_LIMIT; ?></span>
                </header>
                <div id="linksBox"><?php echo $linkLists['links_html']; ?></div>
                <form id="linkForm" class="mp-link-add" autocomplete="off" novalidate>
                    <div class="df-field mp-link-type">
                        <label for="mpLinkKind">Type</label>
                        <select id="mpLinkKind" class="df-light">
                            <option value="auto" selected>Detect from link</option>
                            <?php foreach (dfLinkTypes() as $key => $t): ?>
                                <option value="<?php echo dfEsc($key); ?>"><?php echo dfEsc($key === 'other' ? 'Other' : $t[0]); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="df-field mp-link-url">
                        <label for="mpLinkUrl">Link <span class="req">*</span></label>
                        <input id="mpLinkUrl" class="df-light" type="url" inputmode="url" maxlength="<?php echo DF_LINK_URL_MAX; ?>" placeholder="https://www.linkedin.com/in/your-name" required>
                    </div>
                    <div class="df-field mp-link-label">
                        <label for="mpLinkLabel">Name <span class="mp-opt">(optional)</span></label>
                        <input id="mpLinkLabel" class="df-light" type="text" maxlength="<?php echo DF_LINK_LABEL_MAX; ?>" placeholder="e.g. My portfolio">
                    </div>
                    <button type="submit" class="df-btn df-btn-primary mp-link-btn"><?php echo dfIcon('plus', 16); ?> Add link</button>
                </form>
                <p class="mp-hint mp-hint-sm">Up to <?php echo DF_LINK_LIMIT; ?> links. Only web addresses starting with http:// or https:// are accepted.</p>
            </section>

            <section class="acc-card upx-card" id="skills" aria-labelledby="mpSkillsH">
                <header class="acc-card-head">
                    <span class="acc-ico"><?php echo dfIcon('zap', 18); ?></span>
                    <div>
                        <h2 id="mpSkillsH" class="upx-h">Skills</h2>
                        <p>List what you are good at and how confident you are with it.</p>
                    </div>
                    <span class="acc-pill"><span data-skill-count><?php echo $skillCount; ?></span> listed</span>
                </header>
                <div id="skillsBox"><?php echo $lists['skills_html']; ?></div>
                <form id="skillForm" class="mp-skill-add" autocomplete="off">
                    <label class="mp-sr" for="mpSkill">Skill name</label>
                    <input id="mpSkill" class="df-light" type="text" maxlength="<?php echo DF_SKILL_MAX_LEN; ?>" placeholder="Add a skill, e.g. PHP, Figma, Networking" required>
                    <label class="mp-sr" for="mpLevel">Level</label>
                    <select id="mpLevel" class="df-light">
                        <option value="beginner">Beginner</option>
                        <option value="intermediate" selected>Intermediate</option>
                        <option value="advanced">Advanced</option>
                        <option value="expert">Expert</option>
                    </select>
                    <button type="submit" class="df-btn df-btn-primary"><?php echo dfIcon('plus', 16); ?> Add</button>
                </form>
            </section>

            <section class="acc-card upx-card" id="certificates" aria-labelledby="mpCertsH">
                <header class="acc-card-head">
                    <span class="acc-ico"><?php echo dfIcon('award', 18); ?></span>
                    <div>
                        <h2 id="mpCertsH" class="upx-h">Certificates</h2>
                        <p>Trainings, seminars and courses you completed.</p>
                    </div>
                    <button type="button" class="df-btn df-btn-primary acc-head-btn" data-cert-open><?php echo dfIcon('plus', 16); ?> Add certificate</button>
                </header>
                <div id="certsBox"><?php echo $lists['certs_html']; ?></div>
            </section>
        </div>
    </div>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>

<div id="dfToastHost" role="status" aria-live="polite"></div>

<div id="certModal" class="df-modal" hidden>
    <div class="df-dialog acc-dialog" role="dialog" aria-modal="true" aria-labelledby="certTitleH">
        <button type="button" class="df-x" data-cert-close aria-label="Close"><?php echo dfIcon('close', 18); ?></button>
        <div class="df-dialog-pad">
            <h2 id="certTitleH">Add a certificate</h2>
            <form id="certForm" autocomplete="off">
                <div class="df-field">
                    <label for="certTitle">Certificate title <span class="req">*</span></label>
                    <input id="certTitle" class="df-light" type="text" maxlength="<?php echo DF_CERT_TEXT_MAX; ?>" required>
                </div>
                <div class="df-field">
                    <label for="certIssuer">Issued by <span class="req">*</span></label>
                    <input id="certIssuer" class="df-light" type="text" maxlength="<?php echo DF_CERT_TEXT_MAX; ?>" placeholder="e.g. CCDI Sorsogon, Coursera, Cisco" required>
                </div>
                <div class="df-field">
                    <label for="certImage">Photo or scan of the certificate</label>
                    <input id="certImage" type="file" accept="image/jpeg,image/png,image/webp">
                    <small>JPG, PNG or WEBP, up to 5 MB. Without an image, only the title shows.</small>
                </div>
                <div class="mp-modal-actions">
                    <button type="submit" class="df-btn df-btn-primary">Save certificate</button>
                    <button type="button" class="df-btn df-btn-ghost" data-cert-close>Cancel</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    window.DF_ACCOUNT = <?php echo json_encode([
        'firstName' => $profileFirst,
        'lastName'  => $profileLast,
        'email'     => $profileEmail,
        'phone'     => $profilePhone,
    ], JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;
</script>
<script src="../js/df-more.js?v=<?php echo (int) @filemtime(__DIR__ . '/../js/df-more.js'); ?>"></script>
<script src="../js/df-cert-view.js?v=<?php echo (int) @filemtime(__DIR__ . '/../js/df-cert-view.js'); ?>"></script>
<script src="../js/df-my-profile.js?v=<?php echo (int) @filemtime(__DIR__ . '/../js/df-my-profile.js'); ?>"></script>
<script src="../js/df-account.js?v=<?php echo (int) @filemtime(__DIR__ . '/../js/df-account.js'); ?>"></script>
</body>
</html>
