<?php
/**
 * Profile actions (students) - saves what the owner edits on Account settings (profile.php):
 * profession, bio, skills and certificates.
 * DEVFOLIO CCDI Sorsogon
 *
 * POST action=save_about          profession, bio
 * POST action=add_skill           skill, level
 * POST action=delete_skill        skill_id
 * POST action=add_certificate     title, detail, certificate_image (optional file)
 * POST action=delete_certificate  certificate_id
 * POST action=add_link            kind (linkedin|github|...|auto), url, label (optional)
 * POST action=delete_link         link_id ("legacy" clears the old students.portfolio_link)
 * Every action answers JSON; skill/certificate actions also return fresh list HTML.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/profile-helpers.php';
require_once __DIR__ . '/../includes/profile-edit-helpers.php';
require_once __DIR__ . '/../includes/profile-timeline.php';
require_once __DIR__ . '/../includes/profile-links.php';

header('Content-Type: application/json');

function dfProfileJson(array $payload, int $status = 200): void {
    http_response_code($status);
    echo json_encode($payload);
    exit;
}

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    dfProfileJson(['success' => false, 'message' => 'Please log in again.'], 401);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['action'])) {
    dfProfileJson(['success' => false, 'message' => 'Unknown action.'], 405);
}

$meId = (int) $_SESSION['user_id'];
$action = (string) $_POST['action'];

$stmt = $pdo->prepare('SELECT id FROM students WHERE user_id = ? LIMIT 1');
$stmt->execute([$meId]);
$student = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$student) {
    dfProfileJson(['success' => false, 'message' => 'Student record not found.'], 404);
}
$sid = (int) $student['id'];

// ---------------- Profession + bio ----------------
if ($action === 'save_about') {
    $bio = dfCleanComment((string) ($_POST['bio'] ?? ''));
    $profession = trim((string) preg_replace('/\s+/', ' ', (string) ($_POST['profession'] ?? '')));
    if (mb_strlen($bio) > DF_BIO_MAX) dfProfileJson(['success' => false, 'message' => 'Your bio can be up to ' . DF_BIO_MAX . ' characters.']);
    if (mb_strlen($profession) > DF_PROFESSION_MAX) dfProfileJson(['success' => false, 'message' => 'Your profession can be up to ' . DF_PROFESSION_MAX . ' characters.']);

    if (dfProfessionReady($pdo)) {
        $pdo->prepare('UPDATE students SET bio = ?, profession = ? WHERE id = ?')->execute([$bio, $profession !== '' ? $profession : null, $sid]);
    } else {
        $pdo->prepare('UPDATE students SET bio = ? WHERE id = ?')->execute([$bio, $sid]);
    }
    dfProfileJson(['success' => true, 'message' => 'Profile updated.', 'profession' => $profession, 'bio' => $bio]);
}

// ---------------- Cover photo ----------------
if ($action === 'upload_cover') {
    if (!dfCoverReady($pdo)) dfProfileJson(['success' => false, 'message' => 'Cover photos are not available right now.'], 500);
    [$err, $url] = dfStoreCoverImage($_FILES['cover'] ?? ['error' => UPLOAD_ERR_NO_FILE], $meId);
    if ($err !== null) dfProfileJson(['success' => false, 'message' => $err]);

    $old = $pdo->prepare('SELECT cover_url FROM users WHERE id = ? LIMIT 1');
    $old->execute([$meId]);
    $oldUrl = (string) $old->fetchColumn();
    $pdo->prepare('UPDATE users SET cover_url = ?, updated_at = NOW() WHERE id = ?')->execute([$url, $meId]);
    dfDeleteCoverImage($oldUrl);
    dfProfileJson(['success' => true, 'message' => 'Cover photo updated.', 'cover_url' => dfAssetUrl($url)]);
}

if ($action === 'remove_cover') {
    if (!dfCoverReady($pdo)) dfProfileJson(['success' => true, 'message' => 'Cover photo removed.']);
    $old = $pdo->prepare('SELECT cover_url FROM users WHERE id = ? LIMIT 1');
    $old->execute([$meId]);
    $oldUrl = (string) $old->fetchColumn();
    $pdo->prepare('UPDATE users SET cover_url = NULL, updated_at = NOW() WHERE id = ?')->execute([$meId]);
    dfDeleteCoverImage($oldUrl);
    dfProfileJson(['success' => true, 'message' => 'Cover photo removed.']);
}

// ---------------- Skills ----------------
if ($action === 'add_skill') {
    $skill = trim((string) preg_replace('/\s+/', ' ', (string) ($_POST['skill'] ?? '')));
    $level = (string) ($_POST['level'] ?? 'intermediate');
    if (!in_array($level, ['beginner', 'intermediate', 'advanced', 'expert'], true)) $level = 'intermediate';
    if ($skill === '') dfProfileJson(['success' => false, 'message' => 'Skill name is required.']);
    if (mb_strlen($skill) > DF_SKILL_MAX_LEN) dfProfileJson(['success' => false, 'message' => 'A skill can be up to ' . DF_SKILL_MAX_LEN . ' characters.']);

    $count = $pdo->prepare('SELECT COUNT(*) FROM skills WHERE student_id = ?');
    $count->execute([$sid]);
    if ((int) $count->fetchColumn() >= DF_SKILL_LIMIT) dfProfileJson(['success' => false, 'message' => 'You can list up to ' . DF_SKILL_LIMIT . ' skills.']);

    $check = $pdo->prepare('SELECT id FROM skills WHERE student_id = ? AND skill_name = ? LIMIT 1');
    $check->execute([$sid, $skill]);
    if ($check->fetch()) dfProfileJson(['success' => false, 'message' => 'You already listed that skill.']);

    $pdo->prepare('INSERT INTO skills (student_id, skill_name, proficiency_level, verified) VALUES (?, ?, ?, FALSE)')->execute([$sid, $skill, $level]);
    dfProfileJson(['success' => true, 'message' => 'Skill added.'] + dfProfileLists($pdo, $sid));
}

if ($action === 'delete_skill') {
    $pdo->prepare('DELETE FROM skills WHERE id = ? AND student_id = ?')->execute([(int) ($_POST['skill_id'] ?? 0), $sid]);
    dfProfileJson(['success' => true, 'message' => 'Skill removed.'] + dfProfileLists($pdo, $sid));
}

// ---------------- Working profiles & links (LinkedIn, GitHub, portfolio, ...) ----------------
if ($action === 'add_link') {
    if (!dfLinksReady($pdo)) dfProfileJson(['success' => false, 'message' => 'Links are not available right now.'], 500);
    $url = dfNormalizeLinkUrl((string) ($_POST['url'] ?? ''));
    if ($url === '') dfProfileJson(['success' => false, 'message' => 'Please enter a full web address, e.g. https://www.linkedin.com/in/your-name']);

    $kind = (string) ($_POST['kind'] ?? 'auto');
    if (!isset(dfLinkTypes()[$kind])) $kind = dfDetectLinkKind($url);
    $label = trim((string) preg_replace('/\s+/', ' ', (string) ($_POST['label'] ?? '')));
    if (mb_strlen($label) > DF_LINK_LABEL_MAX) dfProfileJson(['success' => false, 'message' => 'A link name can be up to ' . DF_LINK_LABEL_MAX . ' characters.']);

    if (dfLinkCount($pdo, $meId) >= DF_LINK_LIMIT) dfProfileJson(['success' => false, 'message' => 'You can add up to ' . DF_LINK_LIMIT . ' links.']);
    foreach (dfFetchLinks($pdo, $meId) as $existing) {
        if (strcasecmp(rtrim($existing['url'], '/'), rtrim($url, '/')) === 0) dfProfileJson(['success' => false, 'message' => 'You already added that link.']);
    }

    $next = $pdo->prepare('SELECT COALESCE(MAX(sort_order), -1) + 1 FROM profile_links WHERE user_id = ?');
    $next->execute([$meId]);
    $pdo->prepare('INSERT INTO profile_links (user_id, kind, label, url, sort_order) VALUES (?, ?, ?, ?, ?)')
        ->execute([$meId, $kind, $label !== '' ? $label : null, $url, (int) $next->fetchColumn()]);
    dfProfileJson(['success' => true, 'message' => 'Link added.'] + dfLinkLists($pdo, $meId));
}

if ($action === 'delete_link') {
    $key = (string) ($_POST['link_id'] ?? '');
    if ($key === 'legacy') {
        // the old single "portfolio link" from before this feature
        $pdo->prepare('UPDATE students SET portfolio_link = NULL WHERE id = ?')->execute([$sid]);
    } elseif (dfLinksReady($pdo)) {
        $pdo->prepare('DELETE FROM profile_links WHERE id = ? AND user_id = ?')->execute([(int) $key, $meId]);
    }
    dfProfileJson(['success' => true, 'message' => 'Link removed.'] + dfLinkLists($pdo, $meId));
}

// ---------------- Certificates ----------------
if ($action === 'add_certificate') {
    $title = trim((string) preg_replace('/\s+/', ' ', (string) ($_POST['title'] ?? '')));
    $detail = trim((string) preg_replace('/\s+/', ' ', (string) ($_POST['detail'] ?? '')));
    if ($title === '' || $detail === '') dfProfileJson(['success' => false, 'message' => 'Certificate title and issuer are required.']);
    if (mb_strlen($title) > DF_CERT_TEXT_MAX || mb_strlen($detail) > DF_CERT_TEXT_MAX) {
        dfProfileJson(['success' => false, 'message' => 'Title and issuer can be up to ' . DF_CERT_TEXT_MAX . ' characters each.']);
    }

    $count = $pdo->prepare('SELECT COUNT(*) FROM certificates WHERE student_id = ?');
    $count->execute([$sid]);
    if ((int) $count->fetchColumn() >= DF_CERT_LIMIT) dfProfileJson(['success' => false, 'message' => 'You can add up to ' . DF_CERT_LIMIT . ' certificates.']);

    [$imageError, $imageUrl] = dfStoreCertificateImage($_FILES['certificate_image'] ?? ['error' => UPLOAD_ERR_NO_FILE], $meId);
    if ($imageError !== null) dfProfileJson(['success' => false, 'message' => $imageError]);

    $pdo->prepare('INSERT INTO certificates (student_id, certificate_name, issuing_organization, certificate_image_url) VALUES (?, ?, ?, ?)')
        ->execute([$sid, $title, $detail, $imageUrl]);
    dfProfileJson(['success' => true, 'message' => 'Certificate added.'] + dfProfileLists($pdo, $sid));
}

if ($action === 'delete_certificate') {
    $certId = (int) ($_POST['certificate_id'] ?? 0);
    $own = $pdo->prepare('SELECT certificate_image_url FROM certificates WHERE id = ? AND student_id = ? LIMIT 1');
    $own->execute([$certId, $sid]);
    $row = $own->fetch(PDO::FETCH_ASSOC);
    if ($row) {
        $pdo->prepare('DELETE FROM certificates WHERE id = ? AND student_id = ?')->execute([$certId, $sid]);
        dfDeleteCertificateImage($row['certificate_image_url'] ?? '');
    }
    dfProfileJson(['success' => true, 'message' => 'Certificate removed.'] + dfProfileLists($pdo, $sid));
}

dfProfileJson(['success' => false, 'message' => 'Unknown action.']);
