<?php
/**
 * Hover-card endpoint (JSON). faculty/profile-card.php loads this file.
 *
 * GET ?id=USER_ID -> { success, html }   small profile preview for js/df-profile-card.js
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/profile-helpers.php';

header('Content-Type: application/json');
header('Cache-Control: private, max-age=60');

if (!isset($_SESSION['user_id']) || !in_array($_SESSION['role'] ?? '', ['student', 'faculty'], true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Please sign in to continue.']);
    exit;
}

$pf = dfFetchProfile($pdo, (int) ($_GET['id'] ?? 0));
if (!$pf) {
    http_response_code(404);
    echo json_encode(['success' => false, 'message' => 'Profile not found.']);
    exit;
}

echo json_encode(['success' => true, 'html' => dfRenderProfileCard($pf)]);
