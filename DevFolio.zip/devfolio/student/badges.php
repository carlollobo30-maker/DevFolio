<?php
/**
 * Badges & streak (shared by students and faculty; faculty/badges.php loads this file).
 * DEVFOLIO CCDI Sorsogon
 *
 * Shows the signed-in user's streak, their role, and every badge they can earn,
 * grouped by difficulty, with progress toward the ones still locked.
 */
session_start();
date_default_timezone_set('Asia/Manila');
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';
require_once __DIR__ . '/../includes/project-helpers.php';
require_once __DIR__ . '/../includes/badges.php';

$dfRole = $_SESSION['role'] ?? '';
if (!isset($_SESSION['user_id']) || !in_array($dfRole, ['student', 'faculty'], true)) {
    header('Location: ../login.php');
    exit;
}

$meId = (int) $_SESSION['user_id'];

// Each role browses from its own folder so relative links stay inside it.
$dfInFacultyDir = basename(dirname((string) ($_SERVER['SCRIPT_FILENAME'] ?? ''))) === 'faculty';
if ($dfRole === 'faculty' && !$dfInFacultyDir) { header('Location: ../faculty/badges.php'); exit; }
if ($dfRole === 'student' && $dfInFacultyDir)  { header('Location: ../student/badges.php'); exit; }
$isFaculty = $dfRole === 'faculty';

// Save which badges this member shows (profile + comments), then come back to the page.
if (empty($_SESSION['df_csrf'])) $_SESSION['df_csrf'] = bin2hex(random_bytes(16));
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_badge_display') {
    $flash = ['ok' => false, 'msg' => 'Your session expired. Please try again.'];
    if (hash_equals((string) $_SESSION['df_csrf'], (string) ($_POST['csrf'] ?? ''))) {
        $picked = isset($_POST['profile_badges']) && is_array($_POST['profile_badges']) ? $_POST['profile_badges'] : [];
        $custom = ($_POST['profile_mode'] ?? 'auto') === 'custom';
        $comment = trim((string) ($_POST['comment_badge'] ?? ''));
        $saved = dfSaveBadgePrefs($pdo, $meId, $dfRole, $custom, $picked, $comment !== '' ? $comment : null);
        $flash = $saved
            ? ['ok' => true, 'msg' => count($picked) > DF_BADGE_PROFILE_MAX
                ? 'Saved. Only the first ' . DF_BADGE_PROFILE_MAX . ' profile badges were kept.'
                : 'Your badge display settings are saved.']
            : ['ok' => false, 'msg' => 'Could not save your settings. Please try again.'];
    }
    $_SESSION['df_badge_flash'] = $flash;
    header('Location: badges.php#display');
    exit;
}
$displayFlash = $_SESSION['df_badge_flash'] ?? null;
unset($_SESSION['df_badge_flash']);

// Count today's visit, then award anything newly earned BEFORE the nav pops the "unlocked" toasts.
dfTouchStreak($pdo, $meId);
dfRunBadgeCheck($pdo, $meId, $dfRole, true);

$streak  = dfStreakInfo($pdo, $meId, true);
$earned  = dfEarnedMap($pdo, $meId);
$defs    = dfBadgesFor($dfRole);
$metrics = dfBadgeMetrics($pdo, $meId, $dfRole, count(array_diff_key($earned, ['collector' => 1])));
$tiers   = dfTiers();
$earnedDefs = dfEarnedBadges($pdo, $meId);   // hardest first
$prefs      = dfBadgePrefs($pdo, $meId);
$prefCustom = !empty($prefs['custom']);

$byTier = [];
$points = 0;
$earnedCount = 0;
foreach ($defs as $d) {
    $byTier[$d['tier']][] = $d;
    if (isset($earned[$d['slug']])) { $points += $tiers[$d['tier']]['points']; $earnedCount++; }
}
$totalCount = count($defs);

// Nearest locked badge, for the "next up" hint
$next = null; $nextRatio = -1;
foreach ($defs as $d) {
    if (isset($earned[$d['slug']])) continue;
    $ratio = min(1, ($metrics[$d['metric']] ?? 0) / max(1, $d['goal']));
    if ($ratio > $nextRatio) { $nextRatio = $ratio; $next = $d; }
}

$streakNow = (int) $streak['current'];
$streakNote = $streakNow >= 2
    ? 'Come back tomorrow to keep it going.'
    : 'Open DevFolio every day to build your streak.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Badges &amp; streak - DEVFOLIO</title>
    <link rel="stylesheet" href="../assets/css/devfolio-ui.css?v=<?php echo (int) @filemtime(__DIR__ . '/../assets/css/devfolio-ui.css'); ?>">
</head>
<body>
<?php $navActive = 'badges'; $facActive = 'badges'; include __DIR__ . '/../includes/' . ($isFaculty ? 'faculty-nav.php' : 'student-nav.php'); ?>

<main id="main" class="df-page bgx">
    <section class="df-intro" aria-labelledby="pageTitle">
        <div>
            <p class="df-eyebrow">Your progress</p>
            <h1 id="pageTitle" class="df-h1">Badges &amp; streak</h1>
            <p class="fac-lede">Earn badges by taking part in the community. Harder badges are worth more points.</p>
        </div>
    </section>

    <div class="bgx-top">
        <!-- Streak -->
        <section class="bgx-card bgx-streak" aria-labelledby="bgStreak">
            <h2 id="bgStreak" class="bgx-h">Daily streak</h2>
            <div class="bgx-streak-main">
                <span class="bgx-flame<?php echo $streakNow > 0 ? ' is-lit' : ''; ?>"><?php echo dfIcon('flame', 44); ?></span>
                <div>
                    <p class="bgx-streak-num"><b><?php echo $streakNow; ?></b> <span><?php echo $streakNow === 1 ? 'day' : 'days'; ?></span></p>
                    <p class="bgx-muted">Best streak: <strong><?php echo (int) $streak['longest']; ?></strong> <?php echo (int) $streak['longest'] === 1 ? 'day' : 'days'; ?></p>
                </div>
            </div>
            <?php if (!empty($streak['week'])): ?>
            <ol class="bgx-week" aria-label="Your last 7 days">
                <?php foreach ($streak['week'] as $day): ?>
                    <li class="<?php echo $day['active'] ? 'is-on' : ''; ?><?php echo $day['today'] ? ' is-today' : ''; ?>">
                        <span class="bgx-dot" aria-hidden="true"><?php echo $day['active'] ? dfIcon('check', 14) : ''; ?></span>
                        <small><?php echo dfEsc(mb_substr($day['label'], 0, 3)); ?></small>
                        <span class="df-sr"><?php echo dfEsc($day['label'] . ($day['active'] ? ': active' : ': not active')); ?></span>
                    </li>
                <?php endforeach; ?>
            </ol>
            <?php endif; ?>
            <p class="bgx-muted"><?php echo dfEsc($streakNote); ?> A streak counts every day you open DevFolio (Philippine time).</p>
        </section>

        <!-- Summary -->
        <section class="bgx-card" aria-labelledby="bgSummary">
            <div class="bgx-sum-head">
                <h2 id="bgSummary" class="bgx-h">Your badges</h2>
                <?php echo dfRoleBadge($dfRole); ?>
            </div>
            <p class="bgx-big"><b><?php echo $earnedCount; ?></b> <span>of <?php echo $totalCount; ?> earned &middot; <?php echo $points; ?> points</span></p>
            <ul class="bgx-tierbars">
                <?php foreach ($tiers as $key => $t): $list = $byTier[$key] ?? []; if (!$list) continue;
                    $have = 0; foreach ($list as $d) if (isset($earned[$d['slug']])) $have++;
                    $pct = (int) round($have / count($list) * 100); ?>
                    <li>
                        <span class="bgx-tiername bgx-tn-<?php echo $key; ?>"><?php echo dfEsc($t['label']); ?></span>
                        <span class="bgx-bar" role="img" aria-label="<?php echo dfEsc($t['label'] . ': ' . $have . ' of ' . count($list)); ?>"><i class="bgx-fill-<?php echo $key; ?>" style="width: <?php echo $pct; ?>%"></i></span>
                        <b><?php echo $have; ?>/<?php echo count($list); ?></b>
                    </li>
                <?php endforeach; ?>
            </ul>
            <?php if ($next): $nv = (int) min($metrics[$next['metric']] ?? 0, $next['goal']); ?>
                <p class="bgx-next">Next up: <strong><?php echo dfEsc($next['name']); ?></strong>
                    <?php if ($next['metric'] !== 'profile'): ?>(<?php echo $nv; ?> / <?php echo (int) $next['goal']; ?>)<?php endif; ?></p>
            <?php else: ?>
                <p class="bgx-next">You have earned every badge. Well done!</p>
            <?php endif; ?>
        </section>

        <!-- Roles -->
        <section class="bgx-card" aria-labelledby="bgRoles">
            <h2 id="bgRoles" class="bgx-h">Roles</h2>
            <ul class="bgx-roles">
                <li><?php echo dfRoleBadge('admin'); ?><span>Runs the platform and manages accounts.</span></li>
                <li><?php echo dfRoleBadge('faculty'); ?><span>Reviews reports and guides student work.</span></li>
                <li><?php echo dfRoleBadge('student'); ?><span>Showcases projects and builds a portfolio.</span></li>
            </ul>
        </section>
    </div>

    <!-- Display settings -->
    <section class="bgx-card bdgset" id="display" aria-labelledby="bgDisplay">
        <h2 id="bgDisplay" class="bgx-h">Show off your badges</h2>
        <p class="bgx-muted bdgset-lede">Pick which earned badges other people see. Locked badges can never be shown, and you can change this any time.</p>

        <?php if ($displayFlash): ?>
            <p class="bdgset-flash <?php echo $displayFlash['ok'] ? 'is-ok' : 'is-err'; ?>" role="status"><?php echo dfEsc($displayFlash['msg']); ?></p>
        <?php endif; ?>

        <?php if (!$earnedDefs): ?>
            <p class="bgx-muted">Earn your first badge and you will be able to choose how it is displayed here.</p>
        <?php else: ?>
        <form method="post" action="badges.php#display" id="bdgForm" data-max="<?php echo (int) DF_BADGE_PROFILE_MAX; ?>">
            <input type="hidden" name="action" value="save_badge_display">
            <input type="hidden" name="csrf" value="<?php echo dfEsc($_SESSION['df_csrf']); ?>">

            <fieldset class="bdgset-group">
                <legend>On your profile</legend>
                <label class="bdgset-radio"><input type="radio" name="profile_mode" value="auto"<?php echo $prefCustom ? '' : ' checked'; ?>> <span>Automatic <small>Your hardest badges first.</small></span></label>
                <label class="bdgset-radio"><input type="radio" name="profile_mode" value="custom"<?php echo $prefCustom ? ' checked' : ''; ?>> <span>Let me choose <small>Up to <?php echo (int) DF_BADGE_PROFILE_MAX; ?> badges. Choosing none hides them all.</small></span></label>

                <ul class="bdgset-pick<?php echo $prefCustom ? '' : ' is-off'; ?>" id="bdgPick" aria-label="Badges to show on your profile">
                    <?php foreach ($earnedDefs as $d): $on = in_array($d['slug'], $prefs['profile'], true); ?>
                        <li>
                            <label class="bdgset-opt">
                                <input type="checkbox" name="profile_badges[]" value="<?php echo dfEsc($d['slug']); ?>"<?php echo $on ? ' checked' : ''; ?><?php echo $prefCustom ? '' : ' disabled'; ?>>
                                <?php echo dfBadgeMedal($d, true); ?>
                                <span><strong><?php echo dfEsc($d['name']); ?></strong><small><?php echo dfEsc($tiers[$d['tier']]['label']); ?></small></span>
                            </label>
                        </li>
                    <?php endforeach; ?>
                </ul>
                <p class="bgx-muted" id="bdgCount" aria-live="polite"></p>
            </fieldset>

            <fieldset class="bdgset-group">
                <legend>Next to your name in comments</legend>
                <ul class="bdgset-pick bdgset-pick-single" id="bdgCommentPick">
                    <li>
                        <label class="bdgset-opt">
                            <input type="radio" name="comment_badge" value=""<?php echo $prefs['comment'] === null ? ' checked' : ''; ?>>
                            <span class="bdgset-none">&ndash;</span>
                            <span><strong>No badge</strong><small>Default</small></span>
                        </label>
                    </li>
                    <?php foreach ($earnedDefs as $d): ?>
                        <li>
                            <label class="bdgset-opt">
                                <input type="radio" name="comment_badge" value="<?php echo dfEsc($d['slug']); ?>"<?php echo $prefs['comment'] === $d['slug'] ? ' checked' : ''; ?>>
                                <?php echo dfBadgeMedal($d, true); ?>
                                <span><strong><?php echo dfEsc($d['name']); ?></strong><small><?php echo dfEsc($tiers[$d['tier']]['label']); ?></small></span>
                            </label>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </fieldset>

            <div class="bdgset-preview" aria-label="Preview">
                <div><span class="bdgset-pv-h">Profile</span><ul class="bdg-strip" id="pvProfile"></ul></div>
                <div><span class="bdgset-pv-h">Comment</span><p class="bdgset-pv-comment"><strong>Your name</strong> <span id="pvComment"></span></p></div>
            </div>

            <button type="submit" class="df-btn df-btn-primary">Save display settings</button>
        </form>
        <script>
        (function () {
            var form = document.getElementById('bdgForm');
            if (!form) return;
            var max = parseInt(form.getAttribute('data-max'), 10) || 6;
            var pick = document.getElementById('bdgPick');
            var boxes = [].slice.call(pick.querySelectorAll('input[type=checkbox]'));
            var modes = form.querySelectorAll('input[name=profile_mode]');
            var count = document.getElementById('bdgCount');
            var pvProfile = document.getElementById('pvProfile');
            var pvComment = document.getElementById('pvComment');

            function custom() { return form.querySelector('input[name=profile_mode]:checked').value === 'custom'; }
            function medalOf(input) { var m = input.parentNode.querySelector('.bdg'); return m ? m.cloneNode(true) : null; }

            function refresh() {
                var isCustom = custom();
                var checked = boxes.filter(function (b) { return b.checked; });
                pick.classList.toggle('is-off', !isCustom);
                boxes.forEach(function (b) { b.disabled = !isCustom || (!b.checked && checked.length >= max); });
                count.textContent = isCustom ? checked.length + ' of ' + max + ' selected' : '';

                // profile preview (same order the profile uses: the order of this list)
                pvProfile.innerHTML = '';
                var shown = isCustom ? checked : boxes.slice(0, max);
                shown.forEach(function (b) {
                    var li = document.createElement('li'), m = medalOf(b);
                    if (m) { m.classList.add('bdg-sm'); li.appendChild(m); pvProfile.appendChild(li); }
                });
                if (!isCustom && boxes.length > max) {
                    var more = document.createElement('li'); more.className = 'bdg-more'; more.textContent = '+' + (boxes.length - max); pvProfile.appendChild(more);
                }
                if (!pvProfile.children.length) { var none = document.createElement('li'); none.className = 'bdgset-none-txt'; none.textContent = 'No badges shown'; pvProfile.appendChild(none); }

                // comment preview
                pvComment.innerHTML = '';
                var c = form.querySelector('input[name=comment_badge]:checked');
                if (c && c.value) {
                    var m2 = medalOf(c);
                    if (m2) { m2.classList.add('bdg-xs'); pvComment.appendChild(m2); }
                }
            }
            form.addEventListener('change', refresh);
            refresh();
        })();
        </script>
        <?php endif; ?>
    </section>

    <?php foreach ($tiers as $key => $t): $list = $byTier[$key] ?? []; if (!$list) continue;
        $have = 0; foreach ($list as $d) if (isset($earned[$d['slug']])) $have++; ?>
        <section class="bgx-tier" aria-labelledby="tier-<?php echo $key; ?>">
            <header class="bgx-tier-head">
                <h2 id="tier-<?php echo $key; ?>" class="bgx-tiername bgx-tn-<?php echo $key; ?>"><?php echo dfEsc($t['label']); ?></h2>
                <p><?php echo dfEsc($t['tag']); ?> &middot; <?php echo (int) $t['points']; ?> pts each</p>
                <span class="df-count"><?php echo $have; ?> / <?php echo count($list); ?> earned</span>
            </header>
            <ul class="bgx-grid">
                <?php foreach ($list as $d):
                    $isOn = isset($earned[$d['slug']]);
                    $val = (int) min($metrics[$d['metric']] ?? 0, $d['goal']);
                    $pct = (int) round($val / max(1, $d['goal']) * 100);
                    $unit = dfMetricUnit($d['metric']); ?>
                    <li class="bgx-badge <?php echo $isOn ? 'is-earned' : 'is-locked'; ?>">
                        <?php echo dfBadgeMedal($d, $isOn, 'lg'); ?>
                        <div class="bgx-badge-text">
                            <h3><?php echo dfEsc($d['name']); ?></h3>
                            <p><?php echo dfEsc($d['desc']); ?></p>
                            <?php if ($isOn): ?>
                                <span class="bgx-earned"><?php echo dfIcon('check', 14); ?> Earned <?php echo dfEsc(date('M j, Y', strtotime((string) $earned[$d['slug']]) ?: time())); ?></span>
                            <?php elseif ($d['metric'] === 'profile'): ?>
                                <span class="bgx-progress-text">Not yet earned</span>
                            <?php else: ?>
                                <span class="bgx-bar" role="img" aria-label="<?php echo dfEsc($val . ' of ' . $d['goal']); ?>"><i class="bgx-fill-<?php echo dfEsc($d['tier']); ?>" style="width: <?php echo $pct; ?>%"></i></span>
                                <span class="bgx-progress-text"><?php echo $val; ?> / <?php echo (int) $d['goal']; ?><?php echo $unit !== '' ? ' ' . dfEsc($unit) : ''; ?></span>
                            <?php endif; ?>
                        </div>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endforeach; ?>
</main>

<footer class="df-footer">
    <span>devfolio / CCDI Sorsogon Campus</span>
    <span>Made to be shared.</span>
</footer>
</body>
</html>
