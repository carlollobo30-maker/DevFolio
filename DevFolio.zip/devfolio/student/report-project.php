<?php
/**
 * Report a project (JSON endpoint).
 * POST project_id, reason (key from DF_REPORT_REASONS or "other"), reason_other, details
 * Reports go to the faculty/admin moderation queue.
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user_id']) || ($_SESSION['role'] ?? '') !== 'student') {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'Please sign in as a student to report a project.']);
    exit;
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Invalid request.']);
    exit;
}

$me = (int) $_SESSION['user_id'];
$projectId = (int) ($_POST['project_id'] ?? 0);
$reasonKey = (string) ($_POST['reason'] ?? '');
$details = trim((string) ($_POST['details'] ?? ''));

$st = $pdo->prepare(
    "SELECT p.id, p.title, u.id AS owner_user_id
     FROM projects p
     INNER JOIN students s ON s.id = p.student_id
     INNER JOIN users u ON u.id = s.user_id
     WHERE p.id = ? AND p.status = 'approved' LIMIT 1"
);
$st->execute([$projectId]);
$project = $st->fetch(PDO::FETCH_ASSOC);
if (!$project) {
    echo json_encode(['success' => false, 'message' => 'This project is no longer available.']);
    exit;
}
if ((int) $project['owner_user_id'] === $me) {
    echo json_encode(['success' => false, 'message' => 'You cannot report your own project.']);
    exit;
}

if ($reasonKey === 'other') {
    $other = trim(preg_replace('/\s+/', ' ', (string) ($_POST['reason_other'] ?? '')));
    if (mb_strlen($other) < 3) {
        echo json_encode(['success' => false, 'message' => 'Please tell us what the problem is.']);
        exit;
    }
    $reasonLabel = 'Others: ' . mb_substr($other, 0, 120);
} elseif (isset(DF_REPORT_REASONS[$reasonKey])) {
    $reasonLabel = DF_REPORT_REASONS[$reasonKey];
} else {
    echo json_encode(['success' => false, 'message' => 'Please choose a reason for your report.']);
    exit;
}
if (mb_strlen($details) > 500) {
    echo json_encode(['success' => false, 'message' => 'Extra details are too long (max 500 characters).']);
    exit;
}

$dup = $pdo->prepare("SELECT id FROM project_reports WHERE project_id = ? AND reporter_user_id = ? AND status = 'open' LIMIT 1");
$dup->execute([$projectId, $me]);
if ($dup->fetch()) {
    echo json_encode(['success' => false, 'message' => 'You already reported this project. A moderator will review it soon.']);
    exit;
}

$recent = $pdo->prepare('SELECT COUNT(*) FROM project_reports WHERE reporter_user_id = ? AND created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)');
$recent->execute([$me]);
if ((int) $recent->fetchColumn() >= 10) {
    echo json_encode(['success' => false, 'message' => 'You have sent many reports today. Please try again tomorrow.']);
    exit;
}

$ins = $pdo->prepare(
    'INSERT INTO project_reports (project_id, project_title, reported_user_id, reporter_user_id, reason, details) VALUES (?, ?, ?, ?, ?, ?)'
);
$ins->execute([$projectId, $project['title'], (int) $project['owner_user_id'], $me, $reasonLabel, $details !== '' ? $details : null]);

echo json_encode(['success' => true, 'message' => 'Report sent. Faculty and admin will review it. Thank you for helping keep DEVFOLIO safe.']);
