/**
 * "My Projects" section on the student's own profile (student/my-profile.php).
 *
 *  [data-proj-edit="ID"]    opens the edit dialog filled with the project
 *  [data-proj-delete="ID"]  opens the delete confirmation
 *  #mpData                  JSON with every project's editable fields
 *  Needs js/df-photo-picker.js (photos) loaded first.
 */
(function () {
    'use strict';

    var API = 'project-manage.php';
    var dataEl = document.getElementById('mpData');
    var editModal = document.getElementById('mpEditModal');
    var delModal = document.getElementById('mpDeleteModal');
    if (!editModal || !delModal) return;

    var projects = {};
    try { projects = dataEl ? JSON.parse(dataEl.textContent) : {}; } catch (e) { projects = {}; }

    var picker = window.DFPhotoPicker ? window.DFPhotoPicker.init() : null;
    var form = document.getElementById('mpEditForm');
    var catSelect = document.getElementById('mpCategory');
    var catOther = document.getElementById('mpCategoryOther');
    var openModal = null, lastFocus = null, deleteId = 0;
    var focusable = 'a[href],button:not([disabled]),input:not([disabled]):not([type=hidden]),select:not([disabled]),textarea:not([disabled])';

    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3400);
        setTimeout(function () { el.remove(); }, 3900);
    }

    function send(body) {
        return fetch(API, { method: 'POST', credentials: 'same-origin', body: body })
            .then(function (res) { return res.text(); })
            .then(function (text) {
                var data;
                try { data = JSON.parse(text); }
                catch (e) { throw new Error('The upload was too large for the server. Try smaller photos.'); }
                if (data && data.banned) { window.location.href = '../login.php?banned=1'; }
                return data;
            });
    }

    // After a change, reload and land back on this section
    function reloadHere() {
        window.location.hash = 'projects';
        setTimeout(function () { window.location.reload(); }, 700);
    }

    // ---------- Modals ----------
    function show(modal, focusEl) {
        lastFocus = document.activeElement;
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        openModal = modal;
        (focusEl || modal.querySelector('.df-x')).focus();
    }
    function hide() {
        if (!openModal) return;
        openModal.hidden = true;
        openModal = null;
        document.body.style.overflow = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
    }
    [editModal, delModal].forEach(function (m) {
        m.addEventListener('mousedown', function (e) { if (e.target === m) hide(); });
        m.addEventListener('click', function (e) { if (e.target.closest('[data-mp-close]')) hide(); });
    });
    document.addEventListener('keydown', function (e) {
        if (!openModal) return;
        if (e.key === 'Escape') { hide(); return; }
        if (e.key !== 'Tab') return;
        var items = Array.prototype.filter.call(openModal.querySelectorAll(focusable), function (n) { return n.offsetParent !== null; });
        if (!items.length) return;
        var first = items[0], last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    });

    // ---------- "Others, Specify" ----------
    function syncCategory() {
        var other = catSelect.value === 'Others, Specify';
        catOther.hidden = !other;
        catOther.required = other;
    }
    catSelect.addEventListener('change', function () { syncCategory(); if (!catOther.hidden) catOther.focus(); });

    // ---------- Edit ----------
    function openEdit(id) {
        var p = projects[id];
        if (!p) { toast('Could not load this project. Please refresh the page.', 'err'); return; }
        form.reset();
        document.getElementById('mpId').value = p.id;
        document.getElementById('mpTitle').value = p.title;
        catSelect.value = p.category;
        catOther.value = p.categoryOther || '';
        syncCategory();
        document.getElementById('mpDesc').value = p.description;
        document.getElementById('mpTech').value = p.tech;
        document.getElementById('mpLink').value = p.link;
        if (picker) { picker.reset(); picker.setExisting(p.photos || []); }
        show(editModal, document.getElementById('mpTitle'));
    }

    form.addEventListener('submit', function (e) {
        e.preventDefault();
        var btn = document.getElementById('mpSave');
        var fd = new FormData(form);
        if (picker) picker.appendTo(fd);
        btn.disabled = true; btn.textContent = 'Saving...';
        send(fd).then(function (data) {
            if (data.success) {
                toast(data.message || 'Changes saved.', 'ok');
                hide();
                reloadHere();
            } else {
                toast(data.message || 'Could not save your changes.', 'err');
            }
        }).catch(function (err) {
            toast(err.message || 'Could not save your changes.', 'err');
        }).then(function () {
            btn.disabled = false; btn.textContent = 'Save changes';
        });
    });

    // ---------- Delete ----------
    function openDelete(id, title) {
        deleteId = id;
        document.getElementById('mpDelName').textContent = title || '';
        show(delModal, document.getElementById('mpDelConfirm'));
    }

    document.getElementById('mpDelConfirm').addEventListener('click', function () {
        var btn = this;
        btn.disabled = true; btn.textContent = 'Deleting...';
        var fd = new FormData();
        fd.append('action', 'delete_project');
        fd.append('project_id', deleteId);
        send(fd).then(function (data) {
            if (data.success) {
                toast(data.message || 'Project deleted.', 'ok');
                hide();
                var row = document.querySelector('[data-project-row="' + deleteId + '"]');
                if (row) row.remove();
                reloadHere();   // refreshes the counts and the Posts feed too
            } else {
                toast(data.message || 'The project could not be deleted.', 'err');
            }
        }).catch(function (err) {
            toast(err.message || 'The project could not be deleted.', 'err');
        }).then(function () {
            btn.disabled = false; btn.textContent = 'Delete project';
        });
    });

    document.addEventListener('click', function (e) {
        var ed = e.target.closest('[data-proj-edit]');
        if (ed) { openEdit(ed.dataset.projEdit); return; }
        var del = e.target.closest('[data-proj-delete]');
        if (del) openDelete(del.dataset.projDelete, del.dataset.title);
    });
})();
