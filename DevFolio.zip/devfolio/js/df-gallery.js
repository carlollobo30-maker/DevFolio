/**
 * Photo gallery on the project page: arrows, thumbnails, keyboard (left/right) and swipe.
 * Markup: [data-gallery] with [data-gallery-main], [data-gallery-prev/next], [data-gallery-count], [data-gallery-thumb data-src].
 */
(function () {
    'use strict';
    document.querySelectorAll('[data-gallery]').forEach(function (g) {
        var main = g.querySelector('[data-gallery-main]');
        var thumbs = [].slice.call(g.querySelectorAll('[data-gallery-thumb]'));
        var count = g.querySelector('[data-gallery-count]');
        if (!main || thumbs.length < 2) return;
        var at = 0;

        function show(i) {
            at = (i + thumbs.length) % thumbs.length;
            main.src = thumbs[at].getAttribute('data-src');
            main.alt = 'Photo ' + (at + 1) + ' of ' + thumbs.length;
            if (count) count.textContent = (at + 1) + ' / ' + thumbs.length;
            thumbs.forEach(function (t, k) {
                t.classList.toggle('is-on', k === at);
                t.setAttribute('aria-pressed', k === at ? 'true' : 'false');
            });
            // keep the chosen thumbnail in view in the strip
            var on = thumbs[at];
            if (on.scrollIntoView) on.scrollIntoView({ block: 'nearest', inline: 'nearest' });
        }

        g.querySelector('[data-gallery-prev]').addEventListener('click', function () { show(at - 1); });
        g.querySelector('[data-gallery-next]').addEventListener('click', function () { show(at + 1); });
        thumbs.forEach(function (t, i) { t.addEventListener('click', function () { show(i); }); });

        g.setAttribute('tabindex', '0');
        g.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowLeft') { e.preventDefault(); show(at - 1); }
            if (e.key === 'ArrowRight') { e.preventDefault(); show(at + 1); }
        });

        var x0 = null;
        g.addEventListener('touchstart', function (e) { x0 = e.touches[0].clientX; }, { passive: true });
        g.addEventListener('touchend', function (e) {
            if (x0 === null) return;
            var dx = e.changedTouches[0].clientX - x0;
            if (Math.abs(dx) > 40) show(at + (dx < 0 ? 1 : -1));
            x0 = null;
        }, { passive: true });
    });
})();
