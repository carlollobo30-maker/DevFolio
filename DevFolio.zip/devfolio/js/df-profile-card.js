/**
 * DEVFOLIO profile hover card.
 *
 * Any link with data-profile="USER_ID" (avatar or name) gets a small preview when the
 * pointer rests on it, or when it receives keyboard focus. Clicking the link still opens
 * the full profile page (user.php). Works with student/profile-card.php and its faculty wrapper.
 */
(function () {
    'use strict';

    var ENDPOINT = 'profile-card.php';
    var SHOW_DELAY = 280;   // ms the pointer must rest before the card opens
    var HIDE_DELAY = 220;   // grace period so the pointer can travel onto the card
    var GAP = 8;

    // Touch screens have no hover: a tap simply opens the profile.
    var canHover = !(window.matchMedia && window.matchMedia('(hover: none)').matches);

    var cache = {};         // id -> Promise<html|null>
    var pop = null;
    var activeTrigger = null;
    var showTimer = null;
    var hideTimer = null;
    var token = 0;

    function ensurePop() {
        if (pop) return pop;
        pop = document.createElement('div');
        pop.className = 'pcard';
        pop.id = 'dfProfileCard';
        pop.setAttribute('role', 'dialog');
        pop.setAttribute('aria-label', 'Profile preview');
        pop.hidden = true;
        pop.addEventListener('mouseenter', cancelHide);
        pop.addEventListener('mouseleave', scheduleHide);
        document.body.appendChild(pop);
        return pop;
    }

    function cancelHide() { clearTimeout(hideTimer); }
    function cancelShow() { clearTimeout(showTimer); }

    function scheduleHide() {
        cancelShow();
        clearTimeout(hideTimer);
        hideTimer = setTimeout(hide, HIDE_DELAY);
    }

    function hide() {
        token++;
        cancelShow();
        cancelHide();
        if (pop) pop.hidden = true;
        if (activeTrigger) activeTrigger.removeAttribute('aria-describedby');
        activeTrigger = null;
    }

    function load(id) {
        if (!cache[id]) {
            cache[id] = fetch(ENDPOINT + '?id=' + encodeURIComponent(id), { credentials: 'same-origin' })
                .then(function (res) { return res.json(); })
                .then(function (data) { return data && data.success ? data.html : null; })
                .catch(function () { return null; });
            // Do not remember failures, so a later hover can retry.
            cache[id].then(function (html) { if (html === null) delete cache[id]; });
        }
        return cache[id];
    }

    function position(trigger) {
        var el = ensurePop();
        var r = trigger.getBoundingClientRect();
        var w = el.offsetWidth, h = el.offsetHeight;
        var vw = document.documentElement.clientWidth, vh = document.documentElement.clientHeight;

        var left = Math.min(Math.max(8, r.left), Math.max(8, vw - w - 8));
        var below = r.bottom + GAP;
        var top = (below + h <= vh - 8 || r.top - GAP - h < 8) ? below : r.top - GAP - h;
        top = Math.max(8, Math.min(top, vh - h - 8));

        el.style.left = left + 'px';
        el.style.top = top + 'px';
    }

    function open(trigger) {
        var id = trigger.getAttribute('data-profile');
        if (!id) return;
        var myToken = ++token;
        var el = ensurePop();

        activeTrigger = trigger;
        trigger.setAttribute('aria-describedby', el.id);
        el.innerHTML = '<p class="pcard-loading">Loading profile…</p>';
        el.hidden = false;
        position(trigger);

        load(id).then(function (html) {
            if (myToken !== token) return;          // pointer already moved on
            if (html === null) { hide(); return; }
            el.innerHTML = html;
            position(trigger);
        });
    }

    function triggerFrom(target) {
        return target && target.closest ? target.closest('[data-profile]') : null;
    }

    // ---------- Pointer ----------
    document.addEventListener('mouseover', function (e) {
        if (!canHover) return;
        var t = triggerFrom(e.target);
        if (!t) return;
        cancelHide();
        if (t === activeTrigger && pop && !pop.hidden) return;
        cancelShow();
        showTimer = setTimeout(function () { open(t); }, SHOW_DELAY);
    });

    document.addEventListener('mouseout', function (e) {
        if (!canHover) return;
        var t = triggerFrom(e.target);
        if (!t) return;
        // Still inside the same link (moving between its children)? Keep it open.
        if (e.relatedTarget && t.contains(e.relatedTarget)) return;
        scheduleHide();
    });

    // ---------- Keyboard ----------
    document.addEventListener('focusin', function (e) {
        var t = triggerFrom(e.target);
        if (!t) return;
        cancelHide(); cancelShow();
        open(t);
    });
    document.addEventListener('focusout', function (e) {
        if (triggerFrom(e.target) && !(pop && pop.contains(e.relatedTarget))) scheduleHide();
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape' && pop && !pop.hidden) hide();
    });

    // ---------- Dismiss on scroll / resize / navigation ----------
    window.addEventListener('scroll', function () { if (pop && !pop.hidden) hide(); }, { passive: true });
    window.addEventListener('resize', function () { if (pop && !pop.hidden) hide(); });
    document.addEventListener('click', function (e) {
        if (triggerFrom(e.target)) hide();
    });
})();
