/**
 * DEVFOLIO Faculty Dashboard Module
 * CCDI Sorsogon Student Showcase Platform
 * 
 * Functionality: Project Review, Approval, Monitoring
 */

// ==================== FACULTY TABLE RENDERING ====================

/**
 * Render faculty review queue table
 */
function renderFacultyTable() {
    const table = document.getElementById('facultyReviewTable');
    
    // Filter projects that need review or are pending
    const reviewProjects = projectsData.filter(p => p.status === 'Pending' || true);
    
    table.innerHTML = reviewProjects.map(p => `
        <tr class="hover:bg-slate-50">
            <td class="p-4 font-bold text-slate-900">${p.title}</td>
            <td class="p-4">
                ${p.authors} 
                <br>
                <span class="text-[10px] text-slate-400 font-semibold">${p.program}</span>
            </td>
            <td class="p-4">
                <span class="bg-slate-100 px-2 py-0.5 rounded font-medium text-[11px]">${p.category}</span>
            </td>
            <td class="p-4 text-slate-500 text-sm">${p.year}</td>
            <td class="p-4">
                <span class="px-2.5 py-1 rounded-full text-[10px] font-bold ${p.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                    ${p.status}
                </span>
            </td>
            <td class="p-4 text-center">
                ${p.status === 'Pending' ? `
                    <button onclick="approveProject(${p.id})" class="bg-emerald-600 hover:bg-emerald-700 text-white text-[11px] font-bold px-3 py-1 rounded-lg shadow transition">
                        Approve & Publish
                    </button>
                ` : `
                    <span class="text-[11px] text-slate-400 italic">Published</span>
                `}
            </td>
        </tr>
    `).join('');

    // Update pending count
    const pendingCount = projectsData.filter(p => p.status === 'Pending').length;
    const badge = document.getElementById('facultyPendingCount');
    if(badge) badge.innerText = pendingCount;
}

// ==================== FACULTY ACTIONS ====================

/**
 * Approve and publish a project
 * @param {number} id - The project ID to approve
 */
function approveProject(id) {
    const project = projectsData.find(item => item.id === id);
    if(project) {
        project.status = 'Approved';
        
        // Update all views
        renderShowcaseProjects();
        renderStudentProjects();
        renderFacultyTable();
        renderRepository();
        
        // Show success notification
        triggerToast(`"${project.title}" has been approved and published to the public showcase!`, 'success');
    }
}

/**
 * Reject a project submission
 * @param {number} id - The project ID to reject
 */
function rejectProject(id) {
    const project = projectsData.find(item => item.id === id);
    if(project) {
        project.status = 'Rejected';
        renderFacultyTable();
        triggerToast(`Project rejected. Student will be notified.`, 'info');
    }
}

/**
 * Request revision from student
 * @param {number} id - The project ID
 */
function requestRevision(id) {
    const project = projectsData.find(item => item.id === id);
    if(project) {
        project.status = 'Revision Needed';
        renderFacultyTable();
        triggerToast(`Revision request sent to ${project.authors}`, 'info');
    }
}

/**
 * Handle employer contact request
 */
function requestEmployerContact() {
    closeModal('projectModal');
    triggerToast('Contact request sent! The student author will receive an email notification.', 'success');
}

// ==================== FACULTY REPORTS ====================

/**
 * Export faculty accreditation summary
 */
function exportAccreditationSummary() {
    const totalProjects = projectsData.length;
    const approvedProjects = projectsData.filter(p => p.status === 'Approved').length;
    const programs = {};
    
    projectsData.forEach(p => {
        if(!programs[p.program]) {
            programs[p.program] = 0;
        }
        programs[p.program]++;
    });

    const summary = `
CCDI DEVFOLIO ACCREDITATION SUMMARY
Generated: ${new Date().toLocaleDateString()}

Total Projects: ${totalProjects}
Approved & Published: ${approvedProjects}
Publication Rate: ${((approvedProjects/totalProjects)*100).toFixed(2)}%

Projects by Program:
${Object.entries(programs).map(([prog, count]) => `  ${prog}: ${count} projects`).join('\n')}

Categories Distribution:
${Object.entries(projectsData.reduce((acc, p) => {
    acc[p.category] = (acc[p.category] || 0) + 1;
    return acc;
}, {})).map(([cat, count]) => `  ${cat}: ${count} projects`).join('\n')}
    `;

    console.log(summary);
    triggerToast('Accreditation report generated successfully!', 'success');
}

// ==================== INITIALIZATION ====================

/**
 * Initialize faculty dashboard
 */
function initializeFacultyDashboard() {
    renderFacultyTable();
}
