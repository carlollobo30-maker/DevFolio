/**
 * Photo picker for project forms (several photos, reorder, remove, choose the cover).
 * Markup comes from dfPhotoPickerHtml() in includes/project-form.php.
 *
 *   var picker = DFPhotoPicker.init();      // finds #photoPicker on the page
 *   picker.setExisting([{id, url}, ...]);   // edit mode: photos already saved, in order
 *   picker.appendTo(formData);              // adds photos[], photo_order and remove_photos[]
 *   picker.reset();                         // empty it (new project)
 *   picker.count();
 *
 * The first photo is the cover. Nothing is uploaded until the form is submitted.
 */
(function () {
    'use strict';

    var MAX_BYTES = 5 * 1024 * 1024;
    var TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text) n.textContent = text;
        return n;
    }

    function init() {
        var root = document.getElementById('photoPicker');
        if (!root) return null;
        var max = parseInt(root.getAttribute('data-max'), 10) || 10;
        var grid = document.getElementById('photoGrid');
        var input = document.getElementById('photoInput');
        var addBtn = document.getElementById('photoAdd');
        var msg = document.getElementById('photoMsg');

        var items = [];     // { id?: number, file?: File, url: string }
        var removed = [];   // ids of saved photos to delete on save

        function say(text) { msg.textContent = text || ''; }

        function iconBtn(label, text, onClick, disabled) {
            var b = el('button', 'dfpp-btn', text);
            b.type = 'button';
            b.setAttribute('aria-label', label);
            b.title = label;
            b.disabled = !!disabled;
            b.addEventListener('click', onClick);
            return b;
        }

        function move(from, to) {
            if (to < 0 || to >= items.length) return;
            var it = items.splice(from, 1)[0];
            items.splice(to, 0, it);
            render();
            // keep keyboard focus on the photo that moved
            var moved = grid.children[to] && grid.children[to].querySelector('.dfpp-btn:not([disabled])');
            if (moved) moved.focus();
        }

        function remove(i) {
            var it = items.splice(i, 1)[0];
            if (it.id) removed.push(it.id);
            else if (it.url) URL.revokeObjectURL(it.url);
            say('');
            render();
        }

        function render() {
            grid.innerHTML = '';
            items.forEach(function (it, i) {
                var li = el('li', 'dfpp-item' + (i === 0 ? ' is-cover' : ''));
                var img = el('img');
                img.src = it.url;
                img.alt = 'Photo ' + (i + 1) + (i === 0 ? ' (cover)' : '');
                li.appendChild(img);
                if (i === 0) li.appendChild(el('span', 'dfpp-cover', 'Cover'));

                var bar = el('div', 'dfpp-bar');
                bar.appendChild(iconBtn('Move photo ' + (i + 1) + ' earlier', '\u2190', function () { move(i, i - 1); }, i === 0));
                bar.appendChild(iconBtn('Move photo ' + (i + 1) + ' later', '\u2192', function () { move(i, i + 1); }, i === items.length - 1));
                if (i > 0) bar.appendChild(iconBtn('Make photo ' + (i + 1) + ' the cover', 'Cover', function () { move(i, 0); }));
                bar.appendChild(iconBtn('Remove photo ' + (i + 1), '\u00d7', function () { remove(i); }));
                li.appendChild(bar);
                grid.appendChild(li);
            });
            var full = items.length >= max;
            addBtn.disabled = full;
            addBtn.querySelector('span').textContent = items.length ? 'Add more photos (' + items.length + '/' + max + ')' : 'Add photos';
        }

        function addFiles(fileList) {
            var problems = [];
            [].slice.call(fileList).forEach(function (f) {
                if (items.length >= max) { problems.push('Only ' + max + ' photos fit in one project.'); return; }
                if (TYPES.indexOf(f.type) === -1) { problems.push('"' + f.name + '" is not a JPG, PNG, WEBP or GIF image.'); return; }
                if (f.size > MAX_BYTES) { problems.push('"' + f.name + '" is larger than 5 MB.'); return; }
                items.push({ file: f, url: URL.createObjectURL(f) });
            });
            // the same message is not repeated when several files hit the same limit
            say(problems.filter(function (p, i, a) { return a.indexOf(p) === i; }).join(' '));
            render();
        }

        addBtn.addEventListener('click', function () { input.click(); });
        input.addEventListener('change', function () { addFiles(input.files); input.value = ''; });

        // drag files onto the picker
        ['dragenter', 'dragover'].forEach(function (ev) {
            root.addEventListener(ev, function (e) { if (e.dataTransfer && [].indexOf.call(e.dataTransfer.types || [], 'Files') !== -1) { e.preventDefault(); root.classList.add('is-drop'); } });
        });
        ['dragleave', 'drop'].forEach(function (ev) {
            root.addEventListener(ev, function () { root.classList.remove('is-drop'); });
        });
        root.addEventListener('drop', function (e) {
            if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) { e.preventDefault(); addFiles(e.dataTransfer.files); }
        });

        function reset() {
            items.forEach(function (it) { if (!it.id && it.url) URL.revokeObjectURL(it.url); });
            items = []; removed = []; say(''); render();
        }

        render();
        return {
            count: function () { return items.length; },
            reset: reset,
            setExisting: function (list) {
                reset();
                (list || []).forEach(function (p) { items.push({ id: p.id || 0, url: p.url, legacy: !p.id }); });
                render();
            },
            appendTo: function (fd) {
                var tokens = [], k = 0;
                items.forEach(function (it) {
                    if (it.file) { fd.append('photos[]', it.file, it.file.name); tokens.push('n' + (k++)); }
                    else if (it.id) tokens.push('e' + it.id);
                    // an old single cover has no id yet; the server turns it into the first row and keeps it
                });
                fd.append('photo_order', tokens.join(','));
                removed.forEach(function (id) { fd.append('remove_photos[]', id); });
            }
        };
    }

    window.DFPhotoPicker = { init: init };
})();
