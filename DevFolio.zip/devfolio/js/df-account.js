/**
 * DEVFOLIO Account settings page (student/profile.php):
 *  - cover photo: change (button or drag & drop), instant preview, remove   -> profile-actions.php
 *  - profile photo: upload or take a photo                                   -> profile.php
 *  - personal info: save / discard with an "unsaved changes" hint            -> profile.php
 *  - section menu that follows the scroll, and the live "Profile strength" checklist
 * The About / links / skills / certificates cards are handled by df-my-profile.js.
 */
(function () {
    'use strict';

    var PROFILE_API = 'profile-actions.php';
    var SELF = window.location.pathname;
    var COVER_MAX = 8 * 1024 * 1024;
    var IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
    var initial = window.DF_ACCOUNT || {};

    function $(id) { return document.getElementById(id); }

    function toast(message, type) {
        var host = $('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    function send(url, body) {
        var opts = { method: 'POST', credentials: 'same-origin' };
        if (body instanceof FormData) {
            opts.body = body;
        } else {
            opts.headers = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' };
            opts.body = new URLSearchParams(body).toString();
        }
        return fetch(url, opts).then(function (res) {
            return res.json().catch(function () { throw new Error('Unexpected response from the server.'); });
        }).then(function (d) {
            if (d && d.banned) window.location.href = '../login.php?banned=1';
            return d || {};
        });
    }

    // ---------------- Profile strength ----------------
    function setStrength(key, done) {
        var li = document.querySelector('[data-strength="' + key + '"]');
        if (li) li.classList.toggle('is-done', !!done);
        var all = document.querySelectorAll('[data-strength]');
        var ok = document.querySelectorAll('[data-strength].is-done').length;
        var pct = all.length ? Math.round(ok / all.length * 100) : 0;
        var label = document.querySelector('[data-strength-pct]');
        var bar = document.querySelector('[data-strength-bar]');
        if (label) label.textContent = pct + '%';
        if (bar) {
            bar.style.width = pct + '%';
            if (bar.parentNode) bar.parentNode.setAttribute('aria-valuenow', pct);
        }
    }

    function watchCount(selector, key) {
        var el = document.querySelector(selector);
        if (!el || !window.MutationObserver) return;
        new MutationObserver(function () { setStrength(key, parseInt(el.textContent, 10) > 0); })
            .observe(el, { childList: true, characterData: true, subtree: true });
    }
    watchCount('[data-link-count]', 'links');
    watchCount('[data-skill-count]', 'skills');
    document.addEventListener('df:about-saved', function (e) {
        var d = e.detail || {};
        setStrength('profession', String(d.profession || '').trim() !== '');
        setStrength('bio', String(d.bio || '').trim() !== '');
        var sub = document.querySelector('.acc-sub');
        if (sub) {
            var line = [String(d.profession || '').trim(), sub.getAttribute('data-subtitle') || '']
                .filter(function (p) { return p !== ''; }).join(' · ');
            sub.textContent = line || 'Student';
        }
    });

    // ---------------- Cover photo ----------------
    var cover = $('accCover');
    var coverInput = $('accCoverInput');
    var coverEdit = $('accCoverEdit');
    var coverRemove = $('accCoverRemove');
    var coverLabel = $('accCoverEditLabel');

    function paintCover(url) {
        if (url) {
            cover.style.backgroundImage = 'url("' + String(url).replace(/"/g, '%22') + '")';
            cover.classList.remove('is-default');
            coverRemove.hidden = false;
            coverLabel.textContent = 'Change cover';
        } else {
            cover.style.backgroundImage = '';
            cover.classList.add('is-default');
            coverRemove.hidden = true;
            coverLabel.textContent = 'Add cover photo';
        }
        setStrength('cover', !!url);
    }

    function uploadCover(file) {
        if (!file) return;
        if (IMAGE_TYPES.indexOf(file.type) === -1) { toast('Only JPG, PNG, and WEBP images are allowed.', 'err'); return; }
        if (file.size > COVER_MAX) { toast('The cover photo is larger than 8 MB.', 'err'); return; }

        var before = cover.style.backgroundImage;
        var wasDefault = cover.classList.contains('is-default');
        var preview = window.URL && URL.createObjectURL ? URL.createObjectURL(file) : '';
        if (preview) {
            cover.style.backgroundImage = 'url("' + preview + '")';
            cover.classList.remove('is-default');
        }
        cover.classList.add('is-busy');
        coverEdit.disabled = true;
        coverRemove.disabled = true;

        var fd = new FormData();
        fd.append('action', 'upload_cover');
        fd.append('cover', file);
        send(PROFILE_API, fd).then(function (d) {
            if (!d.success) throw new Error(d.message || 'Could not upload the cover photo.');
            paintCover(d.cover_url);
            toast(d.message || 'Cover photo updated.', 'ok');
        }).catch(function (err) {
            cover.style.backgroundImage = before;
            cover.classList.toggle('is-default', wasDefault);
            toast(err && err.message ? err.message : 'Could not upload the cover photo.', 'err');
        }).then(function () {
            cover.classList.remove('is-busy');
            coverEdit.disabled = false;
            coverRemove.disabled = false;
            if (preview) setTimeout(function () { URL.revokeObjectURL(preview); }, 4000);
        });
    }

    if (cover && coverInput && coverEdit && coverRemove) {
        coverEdit.addEventListener('click', function () { coverInput.click(); });
        coverInput.addEventListener('change', function () {
            var file = coverInput.files && coverInput.files[0];
            coverInput.value = '';
            uploadCover(file);
        });

        coverRemove.addEventListener('click', function () {
            if (!window.confirm('Remove your cover photo?')) return;
            coverRemove.disabled = true;
            send(PROFILE_API, { action: 'remove_cover' }).then(function (d) {
                if (!d.success) { toast(d.message || 'Could not remove the cover photo.', 'err'); return; }
                paintCover('');
                toast(d.message || 'Cover photo removed.', 'ok');
            }).catch(function () {
                toast('Could not remove the cover photo.', 'err');
            }).then(function () { coverRemove.disabled = false; });
        });

        // drag & drop an image straight onto the cover
        var depth = 0;
        cover.addEventListener('dragenter', function (e) {
            if (!e.dataTransfer || Array.prototype.indexOf.call(e.dataTransfer.types || [], 'Files') === -1) return;
            e.preventDefault(); depth++; cover.classList.add('is-drop');
        });
        cover.addEventListener('dragover', function (e) {
            if (cover.classList.contains('is-drop')) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }
        });
        cover.addEventListener('dragleave', function () {
            depth = Math.max(0, depth - 1);
            if (depth === 0) cover.classList.remove('is-drop');
        });
        cover.addEventListener('drop', function (e) {
            e.preventDefault(); depth = 0; cover.classList.remove('is-drop');
            uploadCover(e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0]);
        });
    }

    // ---------------- Profile photo ----------------
    var avatarBtn = $('avatarTrigger');
    var avatarImg = $('profileAvatarLarge');
    var menu = $('photoActions');
    var captureInput = $('captureInput');
    var uploadInput = $('uploadInput');

    function closeMenu() {
        if (!menu || menu.hidden) return;
        menu.hidden = true;
        avatarBtn.setAttribute('aria-expanded', 'false');
    }

    function uploadAvatar(file) {
        if (!file) return;
        if (IMAGE_TYPES.indexOf(file.type) === -1) { toast('Only JPG, PNG, or WEBP images are allowed.', 'err'); return; }
        var fd = new FormData();
        fd.append('action', 'upload_avatar');
        fd.append('avatar', file);
        avatarBtn.classList.add('is-busy');
        send(SELF, fd).then(function (d) {
            if (!d.success) { toast(d.message || 'Profile photo upload failed.', 'err'); return; }
            avatarImg.src = d.avatar_url;
            avatarImg.hidden = false;
            setStrength('photo', true);
            toast(d.message || 'Profile photo updated.', 'ok');
        }).catch(function () {
            toast('Profile photo upload failed.', 'err');
        }).then(function () { avatarBtn.classList.remove('is-busy'); });
    }

    if (avatarBtn && menu) {
        avatarBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            menu.hidden = !menu.hidden;
            avatarBtn.setAttribute('aria-expanded', menu.hidden ? 'false' : 'true');
            if (!menu.hidden) { var first = menu.querySelector('button'); if (first) first.focus(); }
        });
        document.addEventListener('click', function (e) {
            if (!menu.contains(e.target) && !avatarBtn.contains(e.target)) closeMenu();
        });
        document.addEventListener('keydown', function (e) {
            if (e.key === 'Escape' && !menu.hidden) { closeMenu(); avatarBtn.focus(); }
        });
        $('uploadPhotoBtn').addEventListener('click', function () { closeMenu(); uploadInput.click(); });
        $('capturePhotoBtn').addEventListener('click', function () { closeMenu(); captureInput.click(); });
        [captureInput, uploadInput].forEach(function (input) {
            input.addEventListener('change', function () {
                var file = input.files && input.files[0];
                input.value = '';
                uploadAvatar(file);
            });
        });
    }

    // ---------------- Personal info ----------------
    var form = $('profileForm');
    var dirtyNote = $('accDirty');
    var fields = { firstName: $('firstName'), lastName: $('lastName'), email: $('email'), phone: $('phone') };

    function isDirty() {
        return Object.keys(fields).some(function (k) { return fields[k] && fields[k].value !== String(initial[k] || ''); });
    }
    function refreshDirty() {
        if (dirtyNote) dirtyNote.hidden = !isDirty();
        var name = document.querySelector('[data-live-name]');
        if (name) name.textContent = (fields.firstName.value.trim() + ' ' + fields.lastName.value.trim()).trim() || 'Your name';
    }

    if (form) {
        Object.keys(fields).forEach(function (k) { if (fields[k]) fields[k].addEventListener('input', refreshDirty); });

        $('cancelProfileBtn').addEventListener('click', function () {
            if (!isDirty()) return;
            Object.keys(fields).forEach(function (k) { if (fields[k]) fields[k].value = String(initial[k] || ''); });
            refreshDirty();
            toast('Changes discarded.', 'ok');
        });

        form.addEventListener('submit', function (e) {
            e.preventDefault();
            var btn = form.querySelector('button[type="submit"]');
            var payload = {
                action: 'save_profile',
                first_name: fields.firstName.value.trim(),
                last_name: fields.lastName.value.trim(),
                email: fields.email.value.trim(),
                phone: fields.phone.value.trim()
            };
            if (!payload.first_name || !payload.last_name || !payload.email) {
                toast('First name, last name, and email are required.', 'err');
                return;
            }
            btn.disabled = true;
            send(SELF, payload).then(function (d) {
                if (!d.success) { toast(d.message || 'Unable to save your details.', 'err'); return; }
                initial = { firstName: payload.first_name, lastName: payload.last_name, email: payload.email, phone: payload.phone };
                Object.keys(fields).forEach(function (k) { fields[k].value = initial[k]; });
                refreshDirty();
                toast(d.message || 'Profile saved successfully.', 'ok');
            }).catch(function () {
                toast('Unable to save your details.', 'err');
            }).then(function () { btn.disabled = false; });
        });

        window.addEventListener('beforeunload', function (e) {
            if (isDirty()) { e.preventDefault(); e.returnValue = ''; }
        });
    }

    // ---------------- Section menu follows the scroll ----------------
    var navLinks = Array.prototype.slice.call(document.querySelectorAll('[data-acc-nav]'));
    function activate(id) {
        navLinks.forEach(function (a) {
            var on = a.getAttribute('data-acc-nav') === id;
            a.classList.toggle('is-active', on);
            if (on) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
        });
    }
    if (navLinks.length && 'IntersectionObserver' in window) {
        var visible = {};
        var io = new IntersectionObserver(function (entries) {
            entries.forEach(function (en) { visible[en.target.id] = en.isIntersecting; });
            for (var i = 0; i < navLinks.length; i++) {
                var id = navLinks[i].getAttribute('data-acc-nav');
                if (visible[id]) { activate(id); break; }
            }
        }, { rootMargin: '-90px 0px -55% 0px' });
        navLinks.forEach(function (a) {
            var sec = $(a.getAttribute('data-acc-nav'));
            if (sec) io.observe(sec);
            a.addEventListener('click', function () { activate(a.getAttribute('data-acc-nav')); });
        });
    }
})();
