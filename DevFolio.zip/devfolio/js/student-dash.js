/**
 * DEVFOLIO Student Dashboard Module
 * CCDI Sorsogon Student Showcase Platform
 * 
 * Functionality: Student Portfolio, Project Management, Submissions
 */

// ==================== STUDENT PROJECT RENDERING ====================

/**
 * Render student's uploaded projects
 */
function renderStudentProjects() {
    const grid = document.getElementById('studentProjectsGrid');
    const studentProjects = projectsData.filter(p => p.authors.includes("Jhon Mar"));

    // Update total projects count
    document.getElementById('studentTotalProjectsCount').innerText = studentProjects.length;

    grid.innerHTML = studentProjects.map(p => `
        <div class="bg-white rounded-2xl p-5 border border-slate-200 shadow-sm flex flex-col justify-between">
            <div>
                <div class="flex justify-between items-start mb-2">
                    <span class="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded ${p.status === 'Approved' ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'}">
                        ${p.status === 'Approved' ? '<i class="fa-solid fa-circle-check"></i> Approved & Live' : '<i class="fa-solid fa-clock"></i> In Faculty Review'}
                    </span>
                    <span class="text-xs text-slate-400 font-semibold">${p.category}</span>
                </div>
                <h4 class="text-sm font-bold text-slate-900">${p.title}</h4>
                <p class="text-xs text-slate-500 mt-1 line-clamp-2">${p.abstract}</p>
            </div>

            <div class="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                <button onclick="openProjectModal(${p.id})" class="text-xs font-semibold text-slate-700 hover:text-amber-600">
                    <i class="fa-solid fa-eye mr-1"></i> Preview
                </button>
                <button onclick="copyStudentShareLink(${p.id})" class="text-xs font-semibold text-blue-600 hover:underline">
                    <i class="fa-solid fa-link mr-1"></i> Share Link
                </button>
            </div>
        </div>
    `).join('');
}

// ==================== STUDENT ACTIONS ====================

/**
 * Handle student project submission
 * @param {Event} e - The form submission event
 */
function handleProjectSubmit(e) {
    e.preventDefault();
    
    const title = document.getElementById('formTitle').value;
    const category = document.getElementById('formCategory').value;
    const courseCode = document.getElementById('formCourseCode').value;
    const abstract = document.getElementById('formAbstract').value;
    const techStack = document.getElementById('formTechStack').value.split(',').map(s => s.trim());
    const demoLink = document.getElementById('formDemoLink').value;
    const image = document.getElementById('formImage').value || "https://placehold.co/600x400/0f2a4a/ffffff?text=CCDI+Student+Output";

    // Determine program from course code
    const program = courseCode.toUpperCase().includes('BSIT') ? 'BSIT' : 'BSCS';

    const newProject = {
        id: Date.now(),
        title,
        category,
        courseCode,
        program,
        year: '2025-2026',
        authors: 'Jhon Mar Arcos (BSCS)',
        adviser: 'Prof. E. Ramos',
        abstract,
        techStack,
        image,
        status: 'Pending',
        featured: false,
        demoLink
    };

    // Add to data store
    projectsData.unshift(newProject);
    
    // Close modal and reset form
    closeModal('uploadModal');
    document.getElementById('projectUploadForm').reset();

    // Update all relevant views
    renderStudentProjects();
    renderFacultyTable();
    renderRepository();

    // Show success notification
    triggerToast('Project submitted successfully! Pending faculty review.', 'success');
}

/**
 * Copy shareable portfolio link
 * @param {number} projectId - The project ID
 */
function copyStudentShareLink(projectId) {
    const dummyUrl = "https://devfolio.ccdi.edu.ph/student/jhon-mar-arcos/project/" + projectId;
    copyToClipboard(dummyUrl);
}

/**
 * Copy student's shareable portfolio link
 */
function copyShareablePortfolioLink() {
    const dummyUrl = "https://devfolio.ccdi.edu.ph/student/jhon-mar-arcos";
    copyToClipboard(dummyUrl);
    triggerToast('Shareable portfolio link copied to clipboard!', 'info');
}

// ==================== INITIALIZATION ====================

/**
 * Initialize student dashboard
 */
function initializeStudentDashboard() {
    renderStudentProjects();
}
