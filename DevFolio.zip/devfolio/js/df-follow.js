/**
 * DEVFOLIO follow buttons.
 *
 *  [data-follow="USER_ID"]        button: follows / unfollows that student (student/follow-actions.php)
 *  [data-follower-count="USER_ID"] any element showing that student's follower total; updated live
 */
(function () {
    'use strict';

    var ENDPOINT = 'follow-actions.php';

    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    var CHECK = '<path d="M20 6 9 17l-5-5"/>';
    var PLUS = '<path d="M5 12h14"/><path d="M12 5v14"/>';

    function paint(btn, following) {
        btn.setAttribute('aria-pressed', following ? 'true' : 'false');
        btn.classList.toggle('is-following', following);
        btn.classList.toggle('df-btn-ghost', following);
        btn.classList.toggle('df-btn-primary', !following);
        var label = btn.querySelector('.df-follow-label');
        if (label) label.textContent = following ? 'Following' : 'Follow';
        var svg = btn.querySelector('svg');
        if (svg) svg.innerHTML = following ? CHECK : PLUS;
    }

    function setCount(userId, total) {
        document.querySelectorAll('[data-follower-count="' + userId + '"]').forEach(function (el) {
            el.textContent = total;
        });
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('[data-follow]') : null;
        if (!btn || btn.disabled) return;
        var userId = btn.getAttribute('data-follow');
        var wasFollowing = btn.getAttribute('aria-pressed') === 'true';

        btn.disabled = true;
        fetch(ENDPOINT, {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: new URLSearchParams({ action: wasFollowing ? 'unfollow' : 'follow', user_id: userId }).toString()
        }).then(function (res) {
            return res.json().catch(function () { throw new Error('Unexpected response from the server.'); });
        }).then(function (data) {
            if (data && data.banned) { window.location.href = '../login.php?banned=1'; return; }
            if (!data || !data.success) { toast((data && data.message) || 'Could not update. Please try again.', 'err'); return; }
            paint(btn, !!data.following);
            setCount(userId, data.count);
            document.dispatchEvent(new CustomEvent('df:follow', { detail: { userId: userId, following: !!data.following } }));
            toast(data.following ? 'You are now following this student.' : 'You unfollowed this student.', 'ok');
        }).catch(function (err) {
            toast(err && err.message ? err.message : 'Could not update. Please try again.', 'err');
        }).then(function () {
            btn.disabled = false;
        });
    });
})();
