/**
 * Feed filters (Tags + release date) for the student and faculty dashboards.
 * Exposes window.DFFilters:
 *   params()        -> { tags, date, from, to } to send with the feed request
 *   active()        -> true when any tag or date filter is applied
 *   reset(silent)   -> clears everything (silent = do not call the change listeners)
 *   onChange(fn)    -> fn() runs after the person changes a filter
 */
(function () {
    'use strict';
    var btn = document.getElementById('tagBtn'), panel = document.getElementById('tagPanel');
    var dateSel = document.getElementById('feedDate'), custom = document.getElementById('dateCustom');
    if (!btn || !panel || !dateSel || !custom) return;

    var chips = [].slice.call(panel.querySelectorAll('[data-tag]'));
    var countEl = document.getElementById('tagBtnCount'), clearBtn = document.getElementById('tagClear');
    var fromEl = document.getElementById('dateFrom'), toEl = document.getElementById('dateTo');
    var listeners = [];

    function selectedTags() {
        return chips.filter(function (c) { return c.getAttribute('aria-pressed') === 'true'; })
                    .map(function (c) { return c.getAttribute('data-tag'); });
    }
    function dateActive() {
        return dateSel.value !== 'any' && (dateSel.value !== 'custom' || !!(fromEl.value || toEl.value));
    }
    function active() { return selectedTags().length > 0 || dateActive(); }

    function params() {
        var p = { tags: selectedTags().join(','), date: dateSel.value };
        if (dateSel.value === 'custom') { p.from = fromEl.value; p.to = toEl.value; }
        return p;
    }

    function paint() {
        var n = selectedTags().length;
        countEl.textContent = n; countEl.hidden = n === 0;
        btn.classList.toggle('is-on', n > 0);
        dateSel.classList.toggle('is-on', dateActive());
        custom.hidden = dateSel.value !== 'custom';
        clearBtn.hidden = !active();
    }
    function notify() { paint(); listeners.forEach(function (fn) { fn(); }); }

    btn.addEventListener('click', function () {
        var open = panel.hidden;
        panel.hidden = !open;
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    panel.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') { panel.hidden = true; btn.setAttribute('aria-expanded', 'false'); btn.focus(); }
    });

    chips.forEach(function (c) {
        c.addEventListener('click', function () {
            c.setAttribute('aria-pressed', c.getAttribute('aria-pressed') === 'true' ? 'false' : 'true');
            notify();
        });
    });

    dateSel.addEventListener('change', function () {
        if (dateSel.value === 'custom') fromEl.focus();
        notify();
    });
    function onDates(e) {
        // keep the range in order: if From is after To, move the one that was just not edited
        if (fromEl.value && toEl.value && fromEl.value > toEl.value) {
            if (e.target === fromEl) toEl.value = fromEl.value; else fromEl.value = toEl.value;
        }
        toEl.min = fromEl.value || '';
        notify();
    }
    fromEl.addEventListener('change', onDates);
    toEl.addEventListener('change', onDates);

    clearBtn.addEventListener('click', function () { reset(false); });

    function reset(silent) {
        chips.forEach(function (c) { c.setAttribute('aria-pressed', 'false'); });
        dateSel.value = 'any'; fromEl.value = ''; toEl.value = ''; toEl.min = '';
        paint();
        if (!silent) listeners.forEach(function (fn) { fn(); });
    }

    window.DFFilters = {
        params: params, active: active, reset: reset,
        onChange: function (fn) { listeners.push(fn); }
    };
    paint();
})();
