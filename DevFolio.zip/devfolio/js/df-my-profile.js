/**
 * DEVFOLIO Account settings: save bio + profession, add/remove skills, add/remove certificates.
 * Talks to student/profile-actions.php, which answers JSON (and fresh list HTML after each change).
 */
(function () {
    'use strict';

    var ENDPOINT = 'profile-actions.php';
    var skillsBox = document.getElementById('skillsBox');
    var certsBox = document.getElementById('certsBox');
    var modal = document.getElementById('certModal');
    var lastFocus = null;

    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    // body: URLSearchParams (plain actions) or FormData (certificate upload)
    function post(body) {
        var opts = { method: 'POST', credentials: 'same-origin', body: body instanceof FormData ? body : body.toString() };
        if (!(body instanceof FormData)) opts.headers = { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' };
        return fetch(ENDPOINT, opts).then(function (res) {
            return res.json().catch(function () { throw new Error('Unexpected response from the server.'); });
        }).then(function (data) {
            if (data && data.banned) { window.location.href = '../login.php?banned=1'; }
            return data;
        });
    }

    function applyLists(data) {
        if (typeof data.skills_html === 'string' && skillsBox) skillsBox.innerHTML = data.skills_html;
        if (typeof data.certs_html === 'string' && certsBox) certsBox.innerHTML = data.certs_html;
        if (typeof data.skill_count === 'number') {
            document.querySelectorAll('[data-skill-count]').forEach(function (el) { el.textContent = data.skill_count; });
        }
    }

    function busy(btn, on) { if (btn) btn.disabled = on; }

    function fail(err) { toast(err && err.message ? err.message : 'Something went wrong. Please try again.', 'err'); }

    // ---------- About (profession + bio) ----------
    var aboutForm = document.getElementById('aboutForm');
    var bio = document.getElementById('mpBio');
    var bioCount = document.getElementById('mpBioCount');
    if (bio && bioCount) bio.addEventListener('input', function () { bioCount.textContent = bio.value.length; });

    if (aboutForm) aboutForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var btn = aboutForm.querySelector('button[type="submit"]');
        busy(btn, true);
        post(new URLSearchParams({
            action: 'save_about',
            profession: document.getElementById('mpProfession').value,
            bio: bio.value
        })).then(function (data) {
            if (!data || !data.success) { toast((data && data.message) || 'Could not save.', 'err'); return; }
            var line = document.getElementById('mpProfessionLine');
            if (line) {
                line.textContent = data.profession || 'Add your profession in Account settings so people know what you do.';
                line.classList.toggle('is-empty', !data.profession);
            }
            document.dispatchEvent(new CustomEvent('df:about-saved', { detail: { profession: data.profession || '', bio: data.bio || '' } }));
            toast(data.message, 'ok');
        }).catch(fail).then(function () { busy(btn, false); });
    });

    // ---------- Skills ----------
    var skillForm = document.getElementById('skillForm');
    if (skillForm) skillForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var input = document.getElementById('mpSkill');
        var btn = skillForm.querySelector('button[type="submit"]');
        busy(btn, true);
        post(new URLSearchParams({ action: 'add_skill', skill: input.value, level: document.getElementById('mpLevel').value })).then(function (data) {
            if (!data || !data.success) { toast((data && data.message) || 'Could not add the skill.', 'err'); return; }
            applyLists(data);
            input.value = '';
            input.focus();
            toast(data.message, 'ok');
        }).catch(fail).then(function () { busy(btn, false); });
    });

    // ---------- Working profiles & links ----------
    var linksBox = document.getElementById('linksBox');
    var linkForm = document.getElementById('linkForm');

    function applyLinks(data) {
        if (typeof data.links_html === 'string' && linksBox) linksBox.innerHTML = data.links_html;
        if (typeof data.link_count === 'number') {
            document.querySelectorAll('[data-link-count]').forEach(function (el) { el.textContent = data.link_count; });
        }
    }

    // Same rules as dfDetectLinkKind() in includes/profile-links.php (a hint only; the server decides).
    function detectKind(value) {
        var host = '';
        try { host = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(value) ? value : 'https://' + value).hostname.toLowerCase(); } catch (err) { return ''; }
        host = host.replace(/^www\./, '');
        var map = { 'linkedin.com': 'linkedin', 'lnkd.in': 'linkedin', 'github.com': 'github', 'github.io': 'portfolio', 'gitlab.com': 'gitlab', 'behance.net': 'behance', 'dribbble.com': 'dribbble' };
        for (var d in map) { if (host === d || host.slice(-(d.length + 1)) === '.' + d) return map[d]; }
        return host.indexOf('.') > 0 ? 'website' : '';
    }

    if (linkForm) linkForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var url = document.getElementById('mpLinkUrl');
        var kind = document.getElementById('mpLinkKind');
        var label = document.getElementById('mpLinkLabel');
        if (!url.value.trim()) { toast('Paste the link to your profile first.', 'err'); url.focus(); return; }
        if (!detectKind(url.value.trim())) { toast('That does not look like a web address. Example: https://www.linkedin.com/in/your-name', 'err'); url.focus(); return; }
        var btn = linkForm.querySelector('button[type="submit"]');
        busy(btn, true);
        post(new URLSearchParams({ action: 'add_link', kind: kind.value, url: url.value.trim(), label: label.value.trim() })).then(function (data) {
            if (!data || !data.success) { toast((data && data.message) || 'Could not add the link.', 'err'); return; }
            applyLinks(data);
            url.value = '';
            label.value = '';
            kind.value = 'auto';
            url.focus();
            toast(data.message, 'ok');
        }).catch(fail).then(function () { busy(btn, false); });
    });

    document.addEventListener('click', function (e) {
        var linkDel = e.target.closest ? e.target.closest('[data-link-delete]') : null;
        if (linkDel) {
            busy(linkDel, true);
            post(new URLSearchParams({ action: 'delete_link', link_id: linkDel.getAttribute('data-link-delete') })).then(function (data) {
                if (!data || !data.success) { toast((data && data.message) || 'Could not remove the link.', 'err'); busy(linkDel, false); return; }
                applyLinks(data);
                toast(data.message, 'ok');
            }).catch(function (err) { busy(linkDel, false); fail(err); });
            return;
        }

        var del = e.target.closest ? e.target.closest('[data-skill-delete]') : null;
        if (del) {
            busy(del, true);
            post(new URLSearchParams({ action: 'delete_skill', skill_id: del.getAttribute('data-skill-delete') })).then(function (data) {
                if (!data || !data.success) { toast((data && data.message) || 'Could not remove the skill.', 'err'); busy(del, false); return; }
                applyLists(data);
                toast(data.message, 'ok');
            }).catch(function (err) { busy(del, false); fail(err); });
            return;
        }

        var cert = e.target.closest ? e.target.closest('[data-cert-delete]') : null;
        if (cert) {
            if (!window.confirm('Remove this certificate? This cannot be undone.')) return;
            busy(cert, true);
            post(new URLSearchParams({ action: 'delete_certificate', certificate_id: cert.getAttribute('data-cert-delete') })).then(function (data) {
                if (!data || !data.success) { toast((data && data.message) || 'Could not remove the certificate.', 'err'); busy(cert, false); return; }
                applyLists(data);
                toast(data.message, 'ok');
            }).catch(function (err) { busy(cert, false); fail(err); });
        }
    });

    // ---------- Certificate dialog ----------
    function openModal() {
        if (!modal) return;
        lastFocus = document.activeElement;
        document.getElementById('certForm').reset();
        modal.hidden = false;
        document.getElementById('certTitle').focus();
    }
    function closeModal() {
        if (!modal || modal.hidden) return;
        modal.hidden = true;
        if (lastFocus && lastFocus.focus) lastFocus.focus();
    }

    document.addEventListener('click', function (e) {
        if (e.target.closest && e.target.closest('[data-cert-open]')) { openModal(); return; }
        if (e.target.closest && e.target.closest('[data-cert-close]')) { closeModal(); return; }
        if (e.target === modal) closeModal();   // click on the dark backdrop
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') closeModal(); });

    var certForm = document.getElementById('certForm');
    if (certForm) certForm.addEventListener('submit', function (e) {
        e.preventDefault();
        var btn = certForm.querySelector('button[type="submit"]');
        var fd = new FormData();
        fd.append('action', 'add_certificate');
        fd.append('title', document.getElementById('certTitle').value);
        fd.append('detail', document.getElementById('certIssuer').value);
        var file = document.getElementById('certImage').files[0];
        if (file) {
            if (file.size > 5 * 1024 * 1024) { toast('The certificate image is larger than 5 MB.', 'err'); return; }
            fd.append('certificate_image', file);
        }
        busy(btn, true);
        post(fd).then(function (data) {
            if (!data || !data.success) { toast((data && data.message) || 'Could not add the certificate.', 'err'); return; }
            applyLists(data);
            closeModal();
            toast(data.message, 'ok');
        }).catch(fail).then(function () { busy(btn, false); });
    });
})();
