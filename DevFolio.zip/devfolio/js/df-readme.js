/**
 * DEVFOLIO project page: "Comments | MD File" tabs, README viewer and owner editor.
 * Needs js/df-markdown.js. The README text comes from <script id="readmeData"> (JSON).
 *
 *   window.DFProjectTabs.show('comments' | 'readme')   switch tab (used by df-social.js)
 */
(function () {
    'use strict';

    var ENDPOINT = 'project-actions.php';
    var MAX_BYTES = 262144;     // same limit as the server (256 KB)

    var dataEl = document.getElementById('readmeData');
    var tablist = document.querySelector('.pjx-tablist');
    if (!dataEl || !tablist || !window.DFMarkdown) return;

    var data = { body: '', projectId: 0, canEdit: false };
    try { data = JSON.parse(dataEl.textContent); } catch (e) { /* keep defaults */ }

    // ---------- helpers ----------
    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }
    function byteLength(str) { return new Blob([str]).size; }
    function $(sel, root) { return (root || document).querySelector(sel); }

    // ===================================================================
    // Tabs (Comments | MD File)
    // ===================================================================
    var tabs = Array.prototype.slice.call(tablist.querySelectorAll('[role="tab"]'));

    function show(name, focusTab) {
        var found = false;
        tabs.forEach(function (tab) {
            var on = tab.dataset.tab === name;
            if (on) found = true;
        });
        if (!found) return;
        tabs.forEach(function (tab) {
            var on = tab.dataset.tab === name;
            tab.setAttribute('aria-selected', on ? 'true' : 'false');
            tab.tabIndex = on ? 0 : -1;
            var panel = document.getElementById(tab.getAttribute('aria-controls'));
            if (panel) panel.hidden = !on;
            if (on && focusTab) tab.focus();
        });
    }

    tabs.forEach(function (tab, i) {
        tab.addEventListener('click', function () { show(tab.dataset.tab); });
        tab.addEventListener('keydown', function (e) {
            var next = null;
            if (e.key === 'ArrowRight') next = tabs[(i + 1) % tabs.length];
            else if (e.key === 'ArrowLeft') next = tabs[(i - 1 + tabs.length) % tabs.length];
            else if (e.key === 'Home') next = tabs[0];
            else if (e.key === 'End') next = tabs[tabs.length - 1];
            if (next) { e.preventDefault(); show(next.dataset.tab, true); }
        });
    });
    window.DFProjectTabs = { show: show };

    // a link such as project.php?id=7#readme opens that tab
    function fromHash() {
        var h = (location.hash || '').replace('#', '');
        if (h === 'readme' || h === 'comments') {
            show(h);
            var panel = document.getElementById(h);
            if (panel && !panel.hidden) panel.scrollIntoView({ block: 'start' });
        }
    }
    fromHash();
    window.addEventListener('hashchange', fromHash);

    // ===================================================================
    // README view
    // ===================================================================
    var view = $('[data-readme-view]');
    var emptyBox = $('[data-readme-empty]');
    var bar = $('.pjx-readme-bar');
    var barEdit = bar ? $('[data-readme-edit]', bar) : null;

    function renderView() {
        var has = /\S/.test(data.body || '');
        if (has) DFMarkdown.mount(view, data.body); else view.innerHTML = '';
        view.hidden = !has;
        emptyBox.hidden = has;
        if (barEdit) barEdit.hidden = !has;   // the empty state has its own "Add a README" button
    }
    renderView();

    if (!data.canEdit) return;

    // ===================================================================
    // README editor (owner)
    // ===================================================================
    var editor = $('[data-readme-editor]');
    var text = $('#readmeText');
    var previewBox = $('[data-ed-preview]');
    var writePanel = $('#edWrite');
    var edTabs = Array.prototype.slice.call(editor.querySelectorAll('[data-ed-mode]'));
    var fileInput = $('[data-readme-file]', editor);
    var countEl = $('[data-readme-count]', editor);
    var saveBtn = $('[data-readme-save]', editor);
    var original = '';
    var editing = false;

    function updateCount() {
        var n = byteLength(text.value);
        var kb = (n / 1024).toFixed(n < 10240 ? 1 : 0);
        countEl.textContent = kb + ' KB of 256 KB';
        countEl.classList.toggle('is-over', n > MAX_BYTES);
        saveBtn.disabled = n > MAX_BYTES;
    }

    function setMode(mode) {
        var preview = mode === 'preview';
        edTabs.forEach(function (t) {
            var on = t.dataset.edMode === mode;
            t.setAttribute('aria-selected', on ? 'true' : 'false');
            t.tabIndex = on ? 0 : -1;
        });
        writePanel.hidden = preview;
        previewBox.hidden = !preview;
        if (preview) {
            if (/\S/.test(text.value)) DFMarkdown.mount(previewBox, text.value);
            else previewBox.innerHTML = '<p class="md-note">Nothing to preview yet.</p>';
        }
    }
    edTabs.forEach(function (t) {
        t.addEventListener('click', function () { setMode(t.dataset.edMode); });
        t.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowRight' || e.key === 'ArrowLeft') {
                e.preventDefault();
                var other = edTabs.filter(function (x) { return x !== t; })[0];
                setMode(other.dataset.edMode);
                other.focus();
            }
        });
    });

    function openEditor() {
        editing = true;
        original = data.body || '';
        text.value = original;
        setMode('write');
        view.hidden = true;
        emptyBox.hidden = true;
        if (barEdit) barEdit.hidden = true;
        editor.hidden = false;
        updateCount();
        text.focus();
    }

    function closeEditor() {
        editing = false;
        editor.hidden = true;
        renderView();
    }

    function dirty() { return editing && text.value !== original; }

    document.addEventListener('click', function (e) {
        if (e.target.closest('[data-readme-edit]')) { show('readme'); openEditor(); }
    });

    text.addEventListener('input', updateCount);
    text.addEventListener('keydown', function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') { e.preventDefault(); save(); }
    });

    // Replace the text with a .md file from the computer (read in the browser, saved with Save)
    $('[data-readme-pick]', editor).addEventListener('click', function () { fileInput.click(); });
    fileInput.addEventListener('change', function () {
        var f = fileInput.files[0];
        fileInput.value = '';
        if (!f) return;
        if (!/\.md$/i.test(f.name)) { toast('Only a Markdown file (.md) can be used.', 'err'); return; }
        if (f.size > MAX_BYTES) { toast('That file is too large (max 256 KB).', 'err'); return; }
        if (/\S/.test(text.value) && text.value !== original && !window.confirm('Replace what you have typed with the contents of ' + f.name + '?')) return;
        var reader = new FileReader();
        reader.onload = function () {
            var value = String(reader.result || '');
            if (value.indexOf('\u0000') !== -1) { toast('That does not look like a text file.', 'err'); return; }
            text.value = value.replace(/^\uFEFF/, '');
            setMode('write');
            updateCount();
            toast('Loaded ' + f.name + '. Press Save README to publish it.', 'ok');
        };
        reader.onerror = function () { toast('Could not read that file.', 'err'); };
        reader.readAsText(f, 'UTF-8');
    });

    $('[data-readme-cancel]', editor).addEventListener('click', function () {
        if (dirty() && !window.confirm('Discard your changes to the README?')) return;
        closeEditor();
    });

    function save() {
        if (saveBtn.disabled) return;
        if (!/\S/.test(text.value) && /\S/.test(original) && !window.confirm('Saving an empty README removes it from your project. Continue?')) return;
        var label = saveBtn.textContent;
        saveBtn.disabled = true;
        saveBtn.textContent = 'Saving...';
        fetch(ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: new URLSearchParams({ action: 'save_readme', project_id: String(data.projectId), body: text.value }).toString()
        }).then(function (res) {
            return res.text().then(function (raw) {
                try { return JSON.parse(raw); } catch (err) { throw new Error('The README is too large for the server. Try a shorter one.'); }
            });
        }).then(function (d) {
            if (!d.success) { toast(d.message || 'Could not save the README.', 'err'); return; }
            data.body = d.body || '';
            toast(data.body ? 'README saved.' : 'README removed.', 'ok');
            closeEditor();
        }).catch(function (err) {
            toast(err.message || 'Could not save the README.', 'err');
        }).then(function () {
            saveBtn.textContent = label;
            updateCount();
        });
    }
    saveBtn.addEventListener('click', save);

    // do not lose unsaved edits by accident
    window.addEventListener('beforeunload', function (e) {
        if (dirty()) { e.preventDefault(); e.returnValue = ''; }
    });
})();
