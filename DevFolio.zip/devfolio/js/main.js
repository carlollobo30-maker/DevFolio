/**
 * DEVFOLIO Main Application Logic
 * CCDI Sorsogon Student Showcase Platform
 * 
 * Core functionality: Navigation, View Switching, Toast Notifications
 */

// ==================== VIEW NAVIGATION ====================

/**
 * Switch between different application views
 * @param {string} viewName - The name of the view to switch to
 */
function switchView(viewName) {
    // Hide all sections
    document.querySelectorAll('.view-section').forEach(sec => sec.classList.add('hidden'));
    
    // Show target section
    const target = document.getElementById(`view-${viewName}`);
    if(target) target.classList.remove('hidden');

    // Update Header Nav active state
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('bg-ccdi-gold', 'text-white', 'font-bold', 'shadow-md');
        btn.classList.add('text-slate-300');
    });
    
    const activeBtn = document.getElementById(`nav-${viewName}`);
    if(activeBtn) {
        activeBtn.classList.add('bg-ccdi-gold', 'text-white', 'font-bold', 'shadow-md');
        activeBtn.classList.remove('text-slate-300');
    }

    // Update user role tag display
    const roleName = document.getElementById('currentUserRoleName');
    const roleTag = document.getElementById('currentUserRoleTag');
    if(viewName === 'faculty') {
        roleName.innerText = "Prof. E. Ramos";
        roleTag.innerText = "Faculty Evaluator";
    } else {
        roleName.innerText = "Jhon Mar (BSCS 4)";
        roleTag.innerText = "Student Account";
    }
}

// ==================== MODAL OPERATIONS ====================

/**
 * Open a modal dialog
 * @param {string} modalId - The ID of the modal to open
 */
function openProjectModal(id) {
    const project = projectsData.find(p => p.id === id);
    if(!project) return;

    document.getElementById('modalTitle').innerText = project.title;
    document.getElementById('modalCategory').innerText = project.category;
    document.getElementById('modalCourseCode').innerText = `${project.courseCode} • AY ${project.year}`;
    document.getElementById('modalAbstract').innerText = project.abstract;
    document.getElementById('modalAuthors').innerText = project.authors;
    document.getElementById('modalAdviser').innerText = project.adviser;
    document.getElementById('modalImage').src = project.image;
    document.getElementById('modalDemoLink').href = project.demoLink || "#";

    const techContainer = document.getElementById('modalTechStack');
    techContainer.innerHTML = project.techStack.map(t => 
        `<span class="bg-slate-100 text-slate-800 text-xs font-semibold px-2.5 py-1 rounded-md border border-slate-200">${t}</span>`
    ).join('');

    document.getElementById('projectModal').classList.remove('hidden');
}

/**
 * Close a modal dialog
 * @param {string} modalId - The ID of the modal to close
 */
function closeModal(modalId) {
    document.getElementById(modalId).classList.add('hidden');
}

/**
 * Open the project upload modal
 */
function openUploadModal() {
    document.getElementById('uploadModal').classList.remove('hidden');
}

// ==================== TOAST NOTIFICATIONS ====================

/**
 * Display a toast notification
 * @param {string} message - The message to display
 * @param {string} type - The type of notification ('success', 'error', 'info')
 */
function triggerToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    
    const bgColor = type === 'success' ? 'bg-emerald-600' : 'bg-ccdi-navy';
    const icon = type === 'success' ? 'fa-circle-check' : 'fa-circle-info';

    toast.className = `${bgColor} text-white text-xs font-semibold px-4 py-3 rounded-xl shadow-xl flex items-center space-x-2 pointer-events-auto border border-amber-400/40 transform transition-all duration-300 translate-y-2 opacity-0`;
    toast.innerHTML = `<i class="fa-solid ${icon} text-amber-400"></i> <span>${message}</span>`;

    container.appendChild(toast);

    // Animate in
    setTimeout(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
    }, 50);

    // Animate out and remove
    setTimeout(() => {
        toast.classList.add('opacity-0', 'translate-y-2');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

// ==================== INITIALIZATION ====================

/**
 * Initialize the application on page load
 */
window.onload = function() {
    console.log('DEVFOLIO Application Initialized');
    // Additional initialization can be added here
};

// ==================== UTILITY FUNCTIONS ====================

/**
 * Copy text to clipboard
 * @param {string} text - The text to copy
 */
function copyToClipboard(text) {
    if(navigator.clipboard) {
        navigator.clipboard.writeText(text).then(() => {
            triggerToast('Copied to clipboard!', 'success');
        });
    } else {
        // Fallback for older browsers
        const textArea = document.createElement("textarea");
        textArea.value = text;
        document.body.appendChild(textArea);
        textArea.select();
        document.execCommand('copy');
        document.body.removeChild(textArea);
    }
}
