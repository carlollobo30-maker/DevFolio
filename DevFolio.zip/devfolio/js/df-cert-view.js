/**
 * DEVFOLIO "See certificate" viewer.
 *
 * Any element with data-cert-view opens the certificate in a dialog:
 *   data-cert-title   certificate title
 *   data-cert-issuer  issued by (optional)
 *   data-cert-img     image URL (optional - without it the dialog says no file was added)
 *
 * The dialog is built on first use, so every page only needs to include this file.
 * Esc, the close button, or a click outside the dialog closes it, and focus returns to the button.
 */
(function () {
    'use strict';

    var root = null;
    var lastFocus = null;

    function el(tag, cls, text) {
        var node = document.createElement(tag);
        if (cls) node.className = cls;
        if (text) node.textContent = text;
        return node;
    }

    function build() {
        if (root) return root;
        root = el('div', 'df-modal cv-modal');
        root.id = 'certViewer';
        root.hidden = true;
        root.innerHTML =
            '<div class="cv-dialog" role="dialog" aria-modal="true" aria-labelledby="cvTitle">' +
              '<button type="button" class="cv-close" data-cv-close aria-label="Close certificate">' +
                '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>' +
              '</button>' +
              '<header class="cv-head"><h2 id="cvTitle" class="cv-title"></h2><p class="cv-issuer" id="cvIssuer"></p></header>' +
              '<div class="cv-stage" id="cvStage"></div>' +
              '<footer class="cv-foot"><a class="cv-open" id="cvOpen" target="_blank" rel="noopener noreferrer">Open full size in a new tab</a></footer>' +
            '</div>';
        document.body.appendChild(root);

        root.addEventListener('click', function (e) {
            if (e.target === root || e.target.closest('[data-cv-close]')) close();
        });
        return root;
    }

    function open(trigger) {
        build();
        lastFocus = trigger;

        var title = trigger.getAttribute('data-cert-title') || 'Certificate';
        var issuer = trigger.getAttribute('data-cert-issuer') || '';
        var img = trigger.getAttribute('data-cert-img') || '';

        root.querySelector('#cvTitle').textContent = title;
        var issuerEl = root.querySelector('#cvIssuer');
        issuerEl.textContent = issuer ? 'Issued by ' + issuer : '';
        issuerEl.hidden = !issuer;

        var stage = root.querySelector('#cvStage');
        var openLink = root.querySelector('#cvOpen');
        stage.textContent = '';
        stage.classList.remove('is-empty');

        function showEmpty() {
            stage.textContent = '';
            stage.classList.add('is-empty');
            stage.appendChild(el('p', 'cv-empty', 'No image of this certificate was added.'));
            openLink.hidden = true;
        }

        if (img) {
            var pic = document.createElement('img');
            pic.className = 'cv-img';
            pic.alt = 'Certificate: ' + title;
            pic.addEventListener('error', showEmpty);
            pic.src = img;
            stage.appendChild(pic);
            openLink.href = img;
            openLink.hidden = false;
        } else {
            showEmpty();
        }

        root.hidden = false;
        document.documentElement.classList.add('cv-lock');
        root.querySelector('[data-cv-close]').focus();
    }

    function close() {
        if (!root || root.hidden) return;
        root.hidden = true;
        document.documentElement.classList.remove('cv-lock');
        var stage = root.querySelector('#cvStage');
        if (stage) stage.textContent = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
        lastFocus = null;
    }

    document.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('[data-cert-view]') : null;
        if (!btn) return;
        e.preventDefault();
        open(btn);
    });

    document.addEventListener('keydown', function (e) {
        if (!root || root.hidden) return;
        if (e.key === 'Escape') { e.preventDefault(); close(); return; }
        if (e.key === 'Tab') {
            // keep keyboard focus inside the dialog
            var f = root.querySelectorAll('a[href]:not([hidden]), button:not([disabled])');
            if (!f.length) return;
            var first = f[0], last = f[f.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    });
})();
