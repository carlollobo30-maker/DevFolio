/**
 * DEVFOLIO social features: comment threads + share dialog.
 * Works with includes/social-ui.php and student/project-actions.php.
 *
 *  [data-comment-toggle="ID"]  button: opens/closes the thread (feed) or jumps to it (project page)
 *  [data-comments="ID"]        container the thread is built into (add data-autoload to open at once)
 *  [data-share="ID"]           button: opens the share dialog
 */
(function () {
    'use strict';

    var ENDPOINT = 'project-actions.php';

    // ---------- helpers ----------
    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    function api(params) {
        return fetch(ENDPOINT, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: new URLSearchParams(params).toString()
        }).then(function (res) {
            return res.json().catch(function () { throw new Error('Unexpected response from the server.'); });
        }).then(function (data) {
            if (data && data.banned) { window.location.href = '../login.php?banned=1'; }
            return data;
        });
    }

    function setCount(selector, value) {
        document.querySelectorAll(selector).forEach(function (el) { el.textContent = value > 0 ? value : ''; });
    }
    function setCommentCount(id, total) { setCount('[data-comment-count="' + id + '"]', total); }

    // ===================================================================
    // Comment threads
    // ===================================================================
    function buildThread(box) {
        if (box.dataset.ready) return;
        box.dataset.ready = '1';
        var id = box.dataset.comments;

        var more = document.createElement('button');
        more.type = 'button';
        more.className = 'df-comments-more';
        more.textContent = 'View earlier comments';
        more.hidden = true;

        var list = document.createElement('ul');
        list.className = 'df-comment-list';
        list.setAttribute('aria-live', 'polite');

        var empty = document.createElement('p');
        empty.className = 'df-comments-empty';
        empty.textContent = 'No comments yet. Be the first to say something.';
        empty.hidden = true;

        var tpl = document.getElementById('dfComposerTpl');
        var composer = tpl ? tpl.content.firstElementChild.cloneNode(true) : null;

        box.appendChild(more);
        box.appendChild(list);
        box.appendChild(empty);
        if (composer) box.appendChild(composer);

        var state = { firstId: 0, loading: false };

        function syncEmpty() { empty.hidden = list.children.length > 0; }

        function load(older) {
            if (state.loading) return;
            state.loading = true;
            more.disabled = true;
            var params = { action: 'get_comments', project_id: id };
            if (older && state.firstId) params.before_id = state.firstId;
            api(params).then(function (d) {
                if (!d.success) { toast(d.message || 'Could not load comments.', 'err'); return; }
                if (older) {
                    list.insertAdjacentHTML('afterbegin', d.html);
                } else {
                    list.insertAdjacentHTML('beforeend', d.html);
                }
                if (d.first_id) state.firstId = d.first_id;
                more.hidden = !d.has_more;
                setCommentCount(id, d.total);
                syncEmpty();
            }).catch(function () {
                toast('Could not load comments.', 'err');
            }).then(function () {
                state.loading = false;
                more.disabled = false;
            });
        }

        more.addEventListener('click', function () { load(true); });

        if (composer) {
            var input = composer.querySelector('.df-composer-input');
            var send = composer.querySelector('.df-composer-send');
            var counter = composer.querySelector('.df-composer-count');
            var max = parseInt(input.getAttribute('maxlength'), 10) || 500;

            function sync() {
                input.style.height = 'auto';
                input.style.height = Math.min(input.scrollHeight, 160) + 'px';
                var len = input.value.length;
                send.disabled = input.value.trim() === '';
                counter.textContent = len >= max - 80 ? (max - len) + ' left' : '';
            }
            input.addEventListener('input', sync);
            // Ctrl/Cmd + Enter posts, Enter adds a new line
            input.addEventListener('keydown', function (e) {
                if (e.key === 'Enter' && (e.ctrlKey || e.metaKey) && !send.disabled) {
                    e.preventDefault();
                    composer.requestSubmit ? composer.requestSubmit() : send.click();
                }
            });

            composer.addEventListener('submit', function (e) {
                e.preventDefault();
                var body = input.value.trim();
                if (!body || send.disabled) return;
                send.disabled = true;
                api({ action: 'add_comment', project_id: id, body: body }).then(function (d) {
                    if (!d.success) { toast(d.message || 'Could not post your comment.', 'err'); send.disabled = false; return; }
                    list.insertAdjacentHTML('beforeend', d.html);
                    if (!state.firstId) {
                        var first = list.querySelector('[data-comment]');
                        state.firstId = first ? parseInt(first.dataset.comment, 10) : 0;
                    }
                    input.value = '';
                    sync();
                    setCommentCount(id, d.total);
                    syncEmpty();
                }).catch(function () {
                    toast('Could not post your comment.', 'err');
                    send.disabled = false;
                });
            });
            sync();
        }

        // Remove a comment (author, or the project owner)
        box.addEventListener('click', function (e) {
            var del = e.target.closest('[data-comment-delete]');
            if (!del) return;
            var item = del.closest('[data-comment]');
            if (!window.confirm('Delete this comment?')) return;
            del.disabled = true;
            api({ action: 'delete_comment', comment_id: del.dataset.commentDelete }).then(function (d) {
                if (!d.success) { toast(d.message || 'Could not delete the comment.', 'err'); del.disabled = false; return; }
                if (item) item.remove();
                setCommentCount(id, d.total);
                syncEmpty();
            }).catch(function () {
                toast('Could not delete the comment.', 'err');
                del.disabled = false;
            });
        });

        load(false);
    }

    // Feed: the Comment button opens/closes the thread under the post.
    // Project page: the thread is always visible, so the button just jumps to it.
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-comment-toggle]');
        if (!btn) return;
        var id = btn.dataset.commentToggle;
        var post = btn.closest('.df-post');
        var box = post
            ? post.querySelector('[data-comments="' + id + '"]')
            : document.querySelector('[data-comments="' + id + '"]');
        if (!box) return;

        if (!post) {
            // project page: the thread lives in the "Comments" tab, so open that tab first
            if (window.DFProjectTabs) window.DFProjectTabs.show('comments');
            buildThread(box);
            box.scrollIntoView({ behavior: 'smooth', block: 'center' });
            var field = box.querySelector('.df-composer-input');
            if (field) field.focus({ preventScroll: true });
            return;
        }

        var open = box.hidden;
        box.hidden = !open;
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
        if (open) {
            buildThread(box);
            var input = box.querySelector('.df-composer-input');
            if (input) input.focus({ preventScroll: true });
        }
    });

    function initThreads() {
        document.querySelectorAll('[data-comments][data-autoload]').forEach(buildThread);
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', initThreads);
    else initThreads();

    // ===================================================================
    // Share dialog
    // ===================================================================
    var modal = document.getElementById('shareModal');
    if (!modal) return;

    var urlInput = document.getElementById('shareUrl');
    var titleEl = document.getElementById('shareProject');
    var copyBtn = document.getElementById('shareCopy');
    var nativeBtn = document.getElementById('shareNative');
    var current = { id: '', title: '', url: '' };
    var lastFocus = null;
    var focusable = 'a[href],button:not([disabled]),input:not([disabled]),select:not([disabled]),textarea:not([disabled])';

    if (navigator.share) nativeBtn.hidden = false;

    var profileBox = document.getElementById('shareProfileBox');
    var profileOr = document.getElementById('shareOr');
    var profileBtn = document.getElementById('shareToProfile');
    var captionEl = document.getElementById('shareCaption');

    function openShare(id, title, owner) {
        lastFocus = document.activeElement;
        // Students can put someone else's project on their own profile (never their own project)
        var canProfile = !!profileBox && modal.dataset.role === 'student' && owner && owner !== modal.dataset.me;
        if (profileBox) {
            profileBox.hidden = !canProfile;
            profileOr.hidden = !canProfile;
            captionEl.value = '';
            profileBtn.disabled = false;
            profileBtn.querySelector('span').textContent = 'Share to profile';
        }
        current.id = id;
        current.title = title || 'a project on DEVFOLIO';
        current.url = new URL('project.php?id=' + encodeURIComponent(id), window.location.href).href;
        urlInput.value = current.url;
        titleEl.textContent = title || '';
        copyBtn.querySelector('span').textContent = 'Copy link';
        modal.hidden = false;
        document.body.style.overflow = 'hidden';
        copyBtn.focus();
    }
    function closeShare() {
        modal.hidden = true;
        document.body.style.overflow = '';
        if (lastFocus && document.contains(lastFocus)) lastFocus.focus();
    }

    function record(channel) {
        api({ action: 'record_share', project_id: current.id, channel: channel }).then(function (d) {
            if (d && d.success) setCount('[data-share-count="' + current.id + '"]', d.count);
        }).catch(function () { /* the share itself already worked; counting is best-effort */ });
    }

    function copyText(text) {
        if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
        return new Promise(function (resolve, reject) {
            urlInput.focus();
            urlInput.select();
            try { document.execCommand('copy') ? resolve() : reject(); } catch (err) { reject(err); }
        });
    }

    document.addEventListener('click', function (e) {
        var opener = e.target.closest('[data-share]');
        if (opener) { e.preventDefault(); openShare(opener.dataset.share, opener.dataset.title, opener.dataset.owner || ''); return; }
        if (e.target.closest('[data-share-close]')) closeShare();
    });
    modal.addEventListener('mousedown', function (e) { if (e.target === modal) closeShare(); });
    urlInput.addEventListener('focus', function () { urlInput.select(); });

    copyBtn.addEventListener('click', function () {
        copyText(current.url).then(function () {
            copyBtn.querySelector('span').textContent = 'Copied!';
            toast('Link copied.', 'ok');
            record('copy');
        }).catch(function () {
            urlInput.focus(); urlInput.select();
            toast('Press Ctrl+C to copy the selected link.', 'err');
        });
    });

    if (profileBtn) {
        profileBtn.addEventListener('click', function () {
            profileBtn.disabled = true;
            api({ action: 'share_to_profile', project_id: current.id, caption: captionEl.value.trim() }).then(function (d) {
                if (!d.success) { toast(d.message || 'Could not share to your profile.', 'err'); profileBtn.disabled = false; return; }
                if (typeof d.count === 'number') setCount('[data-share-count="' + current.id + '"]', d.count);
                toast(d.message || 'Shared to your profile.', 'ok');
                closeShare();
            }).catch(function () {
                toast('Could not share to your profile.', 'err');
                profileBtn.disabled = false;
            });
        });
    }

    nativeBtn.addEventListener('click', function () {
        navigator.share({ title: current.title, text: 'Check out "' + current.title + '" on DEVFOLIO', url: current.url })
            .then(function () { record('native'); })
            .catch(function () { /* cancelled */ });
    });

    modal.addEventListener('click', function (e) {
        var opt = e.target.closest('[data-share-channel]');
        if (!opt) return;
        var channel = opt.dataset.shareChannel;
        var u = encodeURIComponent(current.url);
        var text = encodeURIComponent('Check out "' + current.title + '" on DEVFOLIO');
        if (channel === 'facebook') {
            window.open('https://www.facebook.com/sharer/sharer.php?u=' + u, '_blank', 'noopener,noreferrer');
        } else if (channel === 'x') {
            window.open('https://twitter.com/intent/tweet?url=' + u + '&text=' + text, '_blank', 'noopener,noreferrer');
        } else if (channel === 'email') {
            window.location.href = 'mailto:?subject=' + encodeURIComponent(current.title) + '&body=' + text + '%0A%0A' + u;
        } else {
            return;
        }
        record(channel);
    });

    document.addEventListener('keydown', function (e) {
        if (modal.hidden) return;
        if (e.key === 'Escape') { e.stopPropagation(); closeShare(); return; }
        if (e.key === 'Tab') {
            var items = Array.prototype.filter.call(modal.querySelectorAll(focusable), function (n) { return n.offsetParent !== null; });
            if (!items.length) return;
            var first = items[0], last = items[items.length - 1];
            if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
            else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
        }
    }, true);
})();
