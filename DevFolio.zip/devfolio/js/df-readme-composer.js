/**
 * DEVFOLIO: README.md editor inside the "Showcase a project" dialog.
 * Write or load a .md file, check it in Preview, then it is posted with the project.
 * Needs js/df-markdown.js. Only Markdown (.md) text is ever accepted.
 *
 *   var composer = DFReadmeComposer.init({ toast: fn });
 *   composer.isTooLarge()  -> true when the text is over 256 KB
 *   composer.reset()       -> clears the editor (after posting)
 *   composer.focus()
 */
(function (root) {
    'use strict';

    var MAX_BYTES = 262144; // same limit as the server (256 KB)

    var TEMPLATE = [
        '# Project title',
        '',
        'One or two sentences about what this project does.',
        '',
        '## Features',
        '',
        '- Feature one',
        '- Feature two',
        '',
        '## Tech stack',
        '',
        '- HTML, CSS, JavaScript',
        '',
        '## How to use it',
        '',
        '1. Open the project link',
        '2. Describe the main steps here',
        '',
        '## Team',
        '',
        '- Your name'
    ].join('\n');

    function byteLength(str) { return new Blob([str]).size; }

    function init(opts) {
        opts = opts || {};
        var toast = opts.toast || function () {};
        var box = document.getElementById('readmeComposer');
        if (!box) return { isTooLarge: function () { return false; }, reset: function () {}, focus: function () {} };

        var text = document.getElementById('readmeText');
        var preview = document.getElementById('rdcPreview');
        var write = document.getElementById('rdcWrite');
        var count = document.getElementById('rdcCount');
        var file = document.getElementById('rdcFile');
        var tabs = Array.prototype.slice.call(box.querySelectorAll('[data-rdc-mode]'));

        function size() { return byteLength(text.value); }

        function updateCount() {
            var n = size();
            count.textContent = n ? (n / 1024).toFixed(n < 10240 ? 1 : 0) + ' KB of 256 KB' : '';
            count.classList.toggle('is-over', n > MAX_BYTES);
        }

        function setMode(mode) {
            var showPreview = mode === 'preview';
            tabs.forEach(function (t) {
                var on = t.dataset.rdcMode === mode;
                t.setAttribute('aria-selected', on ? 'true' : 'false');
                t.tabIndex = on ? 0 : -1;
            });
            write.hidden = showPreview;
            preview.hidden = !showPreview;
            if (showPreview) {
                if (/\S/.test(text.value) && root.DFMarkdown) root.DFMarkdown.mount(preview, text.value);
                else preview.innerHTML = '<p class="md-note">Nothing to preview yet.</p>';
            }
        }

        tabs.forEach(function (t) {
            t.addEventListener('click', function () { setMode(t.dataset.rdcMode); });
            t.addEventListener('keydown', function (e) {
                if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
                e.preventDefault();
                var other = tabs.filter(function (x) { return x !== t; })[0];
                setMode(other.dataset.rdcMode);
                other.focus();
            });
        });

        function confirmReplace(message) {
            return !/\S/.test(text.value) || root.confirm(message);
        }

        // Load a .md file from the computer into the editor (read in the browser, nothing is uploaded yet)
        document.getElementById('rdcPick').addEventListener('click', function () { file.click(); });
        file.addEventListener('change', function () {
            var f = file.files[0];
            file.value = '';
            if (!f) return;
            if (!/\.md$/i.test(f.name)) { toast('Only a Markdown file (.md) can be attached.', 'err'); return; }
            if (f.size > MAX_BYTES) { toast('That file is too large (max 256 KB).', 'err'); return; }
            if (!confirmReplace('Replace what you have written with the contents of ' + f.name + '?')) return;
            var reader = new FileReader();
            reader.onload = function () {
                var value = String(reader.result || '');
                if (value.indexOf('\u0000') !== -1) { toast('That does not look like a text file.', 'err'); return; }
                text.value = value.replace(/^\uFEFF/, '');
                setMode('write');
                updateCount();
                toast('Loaded ' + f.name + '. You can edit it before posting.', 'ok');
            };
            reader.onerror = function () { toast('Could not read that file.', 'err'); };
            reader.readAsText(f, 'UTF-8');
        });

        document.getElementById('rdcTemplate').addEventListener('click', function () {
            if (!confirmReplace('Replace what you have written with the README template?')) return;
            text.value = TEMPLATE;
            setMode('write');
            updateCount();
            text.focus();
        });

        document.getElementById('rdcClear').addEventListener('click', function () {
            if (/\S/.test(text.value) && !root.confirm('Clear the README text?')) return;
            text.value = '';
            setMode('write');
            updateCount();
            text.focus();
        });

        text.addEventListener('input', updateCount);

        updateCount();

        return {
            isTooLarge: function () { return size() > MAX_BYTES; },
            focus: function () { setMode('write'); text.focus(); },
            reset: function () { text.value = ''; setMode('write'); updateCount(); }
        };
    }

    root.DFReadmeComposer = { init: init };
})(window);
