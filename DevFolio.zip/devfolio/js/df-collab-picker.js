/**
 * "Tag collaborators" picker: search classmates, tag them and type what each one did.
 * Markup comes from dfCollabPickerHtml() in includes/project-collaborators.php.
 *
 *   var picker = DFCollabPicker.init(document.getElementById('collab'), { endpoint: 'project-actions.php' });
 *   picker.appendTo(formData);   // adds collaborators = [{"id": userId, "role": "..."}]
 *   picker.reset();
 */
(function () {
    'use strict';

    function el(tag, cls, text) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (text != null) n.textContent = text;
        return n;
    }

    function avatar(person, cls) {
        var av = el('span', cls || 'dfcp-av');
        av.setAttribute('aria-hidden', 'true');
        av.appendChild(el('span', '', person.initials || '?'));
        if (person.avatar) {
            var img = document.createElement('img');
            img.src = person.avatar; img.alt = ''; img.loading = 'lazy';
            img.onerror = function () { img.remove(); };
            av.appendChild(img);
        }
        return av;
    }

    function init(root, opts) {
        if (!root) return null;
        opts = opts || {};
        var endpoint = opts.endpoint || 'project-actions.php';
        var max = parseInt(root.dataset.max, 10) || 10;
        var roleMax = parseInt(root.dataset.roleMax, 10) || 50;
        var input = root.querySelector('.dfcp-input');
        var results = root.querySelector('.dfcp-results');
        var list = root.querySelector('.dfcp-list');
        var msg = root.querySelector('.dfcp-msg');
        var rolesId = root.querySelector('datalist').id;
        var people = [];     // {id, name, sub, initials, avatar, role}
        var found = [];
        var active = -1;
        var timer = null, token = 0;

        function say(text) { msg.textContent = text || ''; }

        function closeResults() {
            results.hidden = true;
            results.innerHTML = '';
            input.setAttribute('aria-expanded', 'false');
            input.removeAttribute('aria-activedescendant');
            found = []; active = -1;
        }

        function setActive(i) {
            var items = results.querySelectorAll('[role=option]');
            if (!items.length) return;
            active = (i + items.length) % items.length;
            items.forEach(function (it, k) { it.setAttribute('aria-selected', k === active ? 'true' : 'false'); });
            input.setAttribute('aria-activedescendant', items[active].id);
            items[active].scrollIntoView({ block: 'nearest' });
        }

        function showResults(rows, q) {
            results.innerHTML = '';
            found = rows; active = -1;
            if (!rows.length) {
                var none = el('li', 'dfcp-none', 'No students match "' + q + '".');
                results.appendChild(none);
            }
            rows.forEach(function (p, i) {
                var li = el('li', 'dfcp-opt-row');
                li.id = root.id + 'Opt' + i;
                li.setAttribute('role', 'option');
                li.setAttribute('aria-selected', 'false');
                li.appendChild(avatar(p));
                var t = el('span', 'dfcp-person');
                t.appendChild(el('b', '', p.name));
                if (p.sub) t.appendChild(el('small', '', p.sub));
                li.appendChild(t);
                li.addEventListener('mousedown', function (e) { e.preventDefault(); });
                li.addEventListener('click', function () { add(p); });
                results.appendChild(li);
            });
            results.hidden = false;
            input.setAttribute('aria-expanded', 'true');
        }

        function search() {
            var q = input.value.trim();
            if (q.length < 2) { closeResults(); return; }
            var my = ++token;
            var body = new URLSearchParams({ action: 'search_people', q: q, exclude: people.map(function (p) { return p.id; }).join(',') });
            fetch(endpoint, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' }, body: body.toString() })
                .then(function (r) { return r.json(); })
                .then(function (d) {
                    if (my !== token) return;
                    if (!d.success) { say(d.message || 'Search is not available right now.'); closeResults(); return; }
                    showResults(d.people || [], q);
                })
                .catch(function () { if (my === token) say('Search is not available right now.'); });
        }

        function render() {
            list.innerHTML = '';
            people.forEach(function (p) {
                var li = el('li', 'dfcp-item');
                li.appendChild(avatar(p));
                var t = el('span', 'dfcp-person');
                t.appendChild(el('b', '', p.name));
                if (p.sub) t.appendChild(el('small', '', p.sub));
                li.appendChild(t);

                var role = document.createElement('input');
                role.type = 'text';
                role.className = 'df-light dfcp-role';
                role.maxLength = roleMax;
                role.setAttribute('list', rolesId);
                role.placeholder = 'What did they do? e.g. UI/UX designer';
                role.setAttribute('aria-label', 'Role of ' + p.name);
                role.value = p.role || '';
                role.addEventListener('input', function () { p.role = role.value; });
                li.appendChild(role);

                var rm = el('button', 'dfcp-remove');
                rm.type = 'button';
                rm.setAttribute('aria-label', 'Remove ' + p.name);
                rm.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>';
                rm.addEventListener('click', function () {
                    people = people.filter(function (x) { return x.id !== p.id; });
                    render();
                    say(p.name + ' removed.');
                    input.focus();
                });
                li.appendChild(rm);
                li.dataset.id = p.id;
                list.appendChild(li);
            });
            input.disabled = people.length >= max;
            input.placeholder = people.length >= max ? 'You can tag up to ' + max + ' people' : 'Search students by name';
        }

        function add(p) {
            if (people.some(function (x) { return x.id === p.id; })) return;
            if (people.length >= max) { say('You can tag up to ' + max + ' people.'); return; }
            people.push({ id: p.id, name: p.name, sub: p.sub, initials: p.initials, avatar: p.avatar, role: p.role || '' });
            input.value = '';
            closeResults();
            render();
            say(p.name + ' tagged. Add their role.');
            var last = list.querySelector('.dfcp-item[data-id="' + p.id + '"] .dfcp-role');
            if (last) last.focus();
        }

        input.addEventListener('input', function () {
            clearTimeout(timer);
            say('');
            timer = setTimeout(search, 250);
        });
        input.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowDown' && !results.hidden) { e.preventDefault(); setActive(active + 1); }
            else if (e.key === 'ArrowUp' && !results.hidden) { e.preventDefault(); setActive(active - 1); }
            else if (e.key === 'Enter') {
                // never submit the whole form from the search box
                e.preventDefault();
                if (!results.hidden && found.length) add(found[active >= 0 ? active : 0]);
            } else if (e.key === 'Escape' && !results.hidden) { e.preventDefault(); e.stopPropagation(); closeResults(); }
        });
        input.addEventListener('blur', function () { setTimeout(closeResults, 120); });

        function set(rows) {
            people = (rows || []).map(function (p) { return { id: p.id, name: p.name, sub: p.sub, initials: p.initials, avatar: p.avatar, role: p.role || '' }; });
            render();
        }

        var initial = [];
        var initEl = root.querySelector('[data-collab-initial]');
        if (initEl) { try { initial = JSON.parse(initEl.textContent) || []; } catch (e) { initial = []; } }
        set(initial);

        return {
            value: function () { return people.map(function (p) { return { id: p.id, role: (p.role || '').trim() }; }); },
            appendTo: function (fd) { fd.set('collaborators', JSON.stringify(this.value())); },
            set: set,
            reset: function () { set([]); input.value = ''; closeResults(); say(''); },
            focus: function () { input.focus(); }
        };
    }

    window.DFCollabPicker = { init: init };
})();
