/**
 * DEVFOLIO Public Showcase Module
 * CCDI Sorsogon Student Showcase Platform
 * 
 * Functionality: Project Display, Filtering, Search
 */

// ==================== STATE MANAGEMENT ====================

// Active Category Filter for Showcase View
let activeCategory = 'All';

// Sample CCDI Capstone Data Store
let projectsData = [
    {
        id: 1,
        title: "Sorsogon Wander: Mobile Tourism & Cultural Guide",
        category: "Mobile App",
        courseCode: "BSCS 4th Year Capstone",
        program: "BSCS",
        year: "2025-2026",
        authors: "Jhon Mar Arcos, Lea Mortega",
        adviser: "Prof. E. Ramos",
        abstract: "A location-based Android application providing augmented reality directions and offline cultural heritage mapping for tourists visiting Sorsogon Province. Designed to boost local eco-tourism.",
        techStack: ["Flutter", "Dart", "Firebase", "Google Maps API"],
        image: "https://placehold.co/600x400/0f2a4a/f59e0b?text=Sorsogon+Wander+App",
        status: "Approved",
        featured: true,
        demoLink: "https://github.com/ccdi-sorsogon/wander-app"
    },
    {
        id: 2,
        title: "Devfolio: CCDI Student Showcase Platform",
        category: "Web Application",
        courseCode: "CS 412 - Software Engineering",
        program: "BSCS",
        year: "2025-2026",
        authors: "Jhon Mar Arcos",
        adviser: "Prof. E. Ramos",
        abstract: "Centralized web platform designed for CCDI Sorsogon to store, evaluate, and showcase student capstones, proposals, and creative 3D assets to local industry partners.",
        techStack: ["Tailwind CSS", "JavaScript", "PHP", "PostgreSQL"],
        image: "https://placehold.co/600x400/0a192f/ffffff?text=DEVFOLIO+Platform",
        status: "Approved",
        featured: true,
        demoLink: "#"
    },
    {
        id: 3,
        title: "Campus Threat & Incident Intelligence System",
        category: "Capstone System",
        courseCode: "IT 402 - Information Assurance",
        program: "BSIT",
        year: "2025-2026",
        authors: "Mark Anthony B., Sarah D.",
        adviser: "Engr. V. Lasala",
        abstract: "Real-time incident reporting and threat logging dashboard with automated SMS notifications for campus security and administrative response teams at CCDI.",
        techStack: ["PHP", "MySQL", "Bootstrap", "Twilio API"],
        image: "https://placehold.co/600x400/1e3a8a/ffffff?text=Incident+Intel+System",
        status: "Pending",
        featured: false,
        demoLink: "#"
    },
    {
        id: 4,
        title: "3D Digital Twin of CCDI Main Campus",
        category: "3D & Multimedia",
        courseCode: "ACT 201 - Multimedia Systems",
        program: "ACT",
        year: "2024-2025",
        authors: "Christian V., Kevin P.",
        adviser: "Prof. M. Dio",
        abstract: "Interactive 3D model simulation of the CCDI Sorsogon building layout used for virtual orientation and emergency evacuation planning.",
        techStack: ["Three.js", "Blender", "WebGL", "HTML5"],
        image: "https://placehold.co/600x400/0f2a4a/f59e0b?text=CCDI+3D+Campus+Model",
        status: "Approved",
        featured: true,
        demoLink: "#"
    }
];

// ==================== RENDER SHOWCASE GRID ====================

/**
 * Render the public showcase projects grid
 */
function renderShowcaseProjects() {
    const grid = document.getElementById('showcaseGrid');
    const searchVal = (document.getElementById('showcaseSearchInput')?.value || '').toLowerCase();

    const filtered = projectsData.filter(p => {
        const matchesCat = activeCategory === 'All' || p.category === activeCategory;
        const matchesSearch = p.title.toLowerCase().includes(searchVal) || 
                              p.abstract.toLowerCase().includes(searchVal) ||
                              p.techStack.some(t => t.toLowerCase().includes(searchVal));
        return matchesCat && matchesSearch && (p.status === 'Approved');
    });

    // Update count badge
    document.getElementById('showcaseCountBadge').innerText = `Showing ${filtered.length} Projects`;

    if(filtered.length === 0) {
        grid.innerHTML = `
            <div class="col-span-full py-12 text-center text-slate-400 bg-white rounded-2xl border border-dashed border-slate-200">
                <i class="fa-solid fa-folder-open text-3xl mb-2"></i>
                <p class="text-sm font-semibold">No approved projects match your criteria.</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = filtered.map(p => `
        <div class="bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-md transition border border-slate-200 flex flex-col h-full group">
            <div class="relative h-48 bg-slate-900 overflow-hidden">
                <img src="${p.image}" alt="${p.title}" class="w-full h-full object-cover group-hover:scale-105 transition duration-300">
                <span class="absolute top-3 left-3 bg-ccdi-navy/90 text-amber-300 text-[10px] font-extrabold uppercase px-2.5 py-1 rounded-md border border-amber-400/30">
                    ${p.category}
                </span>
                <span class="absolute top-3 right-3 bg-emerald-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                    <i class="fa-solid fa-circle-check"></i> Defended
                </span>
            </div>

            <div class="p-5 flex-1 flex flex-col justify-between space-y-4">
                <div>
                    <span class="text-[11px] font-bold text-amber-700 uppercase tracking-wide">${p.courseCode}</span>
                    <h3 class="text-base font-bold text-slate-900 group-hover:text-amber-600 transition leading-snug mt-1">${p.title}</h3>
                    <p class="text-xs text-slate-600 line-clamp-2 mt-2 leading-relaxed">${p.abstract}</p>
                </div>

                <div>
                    <!-- Tech Badges -->
                    <div class="flex flex-wrap gap-1 mb-4">
                        ${p.techStack.map(t => `<span class="bg-slate-100 text-slate-700 text-[10px] font-semibold px-2 py-0.5 rounded">${t}</span>`).join('')}
                    </div>

                    <div class="pt-3 border-t border-slate-100 flex items-center justify-between">
                        <span class="text-[11px] font-semibold text-slate-500"><i class="fa-solid fa-user-graduate text-slate-400"></i> ${p.authors}</span>
                        <button onclick="openProjectModal(${p.id})" class="text-xs font-bold text-ccdi-navy hover:text-amber-600 flex items-center gap-1">
                            Details <i class="fa-solid fa-arrow-right"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `).join('');
}

// ==================== FILTER FUNCTIONS ====================

/**
 * Filter projects by category
 * @param {string} category - The category to filter by
 */
function filterCategory(category) {
    activeCategory = category;
    
    // Update button states
    document.querySelectorAll('.cat-pill').forEach(btn => {
        btn.classList.remove('bg-ccdi-navy', 'text-white', 'font-bold');
        btn.classList.add('bg-slate-100', 'text-slate-600');
    });
    
    event.target.classList.add('bg-ccdi-navy', 'text-white', 'font-bold');
    event.target.classList.remove('bg-slate-100', 'text-slate-600');
    
    // Re-render projects
    renderShowcaseProjects();
}

/**
 * Filter showcase projects based on search input
 */
function filterShowcaseProjects() {
    renderShowcaseProjects();
}

// ==================== INITIALIZATION ====================

/**
 * Initialize public showcase view
 */
function initializeShowcase() {
    renderShowcaseProjects();
}
