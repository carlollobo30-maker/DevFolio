/**
 * DEVFOLIO profile page (student/my-profile.php and student/user.php).
 *
 *  [data-pf-tab="name"]    tab button (posts | about | following | followers | projects)
 *  [data-pf-go="name"]     any link/button that jumps to a tab
 *  #pfCoverEdit / #pfCoverRemove / #pfCoverInput   cover photo controls (owner only)
 *  [data-unshare="ID"]     removes a shared project from the owner's profile
 *  [data-untag="ID"]       removes the owner's collaborator tag from a team project
 *  [data-like="ID"]        appreciate button on the feed
 *  [data-pf-menu]          the "..." menu of a post (closes on outside click / Esc)
 *  [data-pf-caption]       post caption, clamped, with a "See more" button
 *  [data-count-word]       "follower" / "followers" word that follows its live number
 */
(function () {
    'use strict';

    var PROFILE_API = 'profile-actions.php';
    var PROJECT_API = 'project-actions.php';
    var TABS = ['posts', 'about', 'following', 'followers', 'projects'];

    function toast(message, type) {
        var host = document.getElementById('dfToastHost');
        var el = document.createElement('div');
        el.className = 'df-toast ' + (type === 'err' ? 'err' : 'ok');
        el.textContent = message;
        (host || document.body).appendChild(el);
        setTimeout(function () { el.style.opacity = '0'; }, 3200);
        setTimeout(function () { el.remove(); }, 3700);
    }

    function send(url, body) {
        var isForm = body instanceof FormData;
        return fetch(url, {
            method: 'POST',
            credentials: 'same-origin',
            headers: isForm ? undefined : { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8' },
            body: isForm ? body : new URLSearchParams(body).toString()
        }).then(function (res) {
            return res.json().catch(function () { throw new Error('Unexpected response from the server.'); });
        }).then(function (data) {
            if (data && data.banned) { window.location.href = '../login.php?banned=1'; }
            return data;
        });
    }

    // ===================================================================
    // Tabs
    // ===================================================================
    var tabBtns = Array.prototype.slice.call(document.querySelectorAll('[data-pf-tab]'));
    var panels = Array.prototype.slice.call(document.querySelectorAll('[data-pf-panel]'));

    function showTab(name, opts) {
        if (TABS.indexOf(name) === -1) name = 'posts';
        // the owner-only "projects" panel does not exist on other people's profiles
        if (!panels.some(function (p) { return p.dataset.pfPanel === name; })) name = 'posts';
        tabBtns.forEach(function (b) {
            var on = b.dataset.pfTab === name;
            b.setAttribute('aria-selected', on ? 'true' : 'false');
            b.tabIndex = on ? 0 : -1;
        });
        panels.forEach(function (p) { p.hidden = p.dataset.pfPanel !== name; });
        if (opts && opts.hash && window.history && history.replaceState) {
            history.replaceState(null, '', name === 'posts' ? location.pathname + location.search : '#' + name);
        }
        if (opts && opts.scroll) {
            var bar = document.querySelector('.pf-tabs');
            if (bar) bar.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
    }

    if (tabBtns.length) {
        document.addEventListener('click', function (e) {
            var tab = e.target.closest('[data-pf-tab]');
            if (tab) { showTab(tab.dataset.pfTab, { hash: true }); return; }
            var go = e.target.closest('[data-pf-go]');
            if (go) { showTab(go.dataset.pfGo, { hash: true, scroll: true }); }
        });

        // Arrow keys move between tabs
        var list = document.querySelector('.pf-tabs');
        if (list) {
            list.addEventListener('keydown', function (e) {
                if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft') return;
                var i = tabBtns.indexOf(document.activeElement);
                if (i < 0) return;
                var next = tabBtns[(i + (e.key === 'ArrowRight' ? 1 : tabBtns.length - 1)) % tabBtns.length];
                e.preventDefault();
                showTab(next.dataset.pfTab, { hash: true });
                next.focus();
            });
        }

        var initial = (location.hash || '').replace('#', '');
        if (TABS.indexOf(initial) > -1) showTab(initial);
        window.addEventListener('hashchange', function () {
            var h = (location.hash || '').replace('#', '');
            showTab(TABS.indexOf(h) > -1 ? h : 'posts');
        });
    }

    // ===================================================================
    // Cover photo (owner)
    // ===================================================================
    var cover = document.getElementById('pfCover');
    var coverInput = document.getElementById('pfCoverInput');
    var coverEdit = document.getElementById('pfCoverEdit');
    var coverRemove = document.getElementById('pfCoverRemove');
    var coverLabel = document.getElementById('pfCoverEditLabel');

    function paintCover(url) {
        if (url) {
            cover.style.backgroundImage = 'url("' + url.replace(/"/g, '%22') + '")';
            cover.classList.remove('is-default');
            coverRemove.hidden = false;
            coverLabel.textContent = 'Edit cover';
        } else {
            cover.style.backgroundImage = '';
            cover.classList.add('is-default');
            coverRemove.hidden = true;
            coverLabel.textContent = 'Edit cover';
        }
    }

    if (cover && coverInput && coverEdit) {
        coverEdit.addEventListener('click', function () { coverInput.click(); });

        coverInput.addEventListener('change', function () {
            var file = coverInput.files && coverInput.files[0];
            coverInput.value = '';
            if (!file) return;
            if (file.size > 8 * 1024 * 1024) { toast('The cover photo is larger than 8 MB.', 'err'); return; }
            if (!/^image\/(jpeg|png|webp)$/.test(file.type)) { toast('Only JPG, PNG, or WEBP images are allowed.', 'err'); return; }

            var fd = new FormData();
            fd.append('action', 'upload_cover');
            fd.append('cover', file);
            coverEdit.disabled = true;
            cover.classList.add('is-busy');
            send(PROFILE_API, fd).then(function (d) {
                if (!d.success) { toast(d.message || 'Cover photo upload failed.', 'err'); return; }
                paintCover(d.cover_url);
                toast(d.message || 'Cover photo updated.', 'ok');
            }).catch(function (err) {
                toast(err && err.message ? err.message : 'Cover photo upload failed.', 'err');
            }).then(function () {
                coverEdit.disabled = false;
                cover.classList.remove('is-busy');
            });
        });

        coverRemove.addEventListener('click', function () {
            if (!window.confirm('Remove your cover photo?')) return;
            coverRemove.disabled = true;
            send(PROFILE_API, { action: 'remove_cover' }).then(function (d) {
                if (!d.success) { toast(d.message || 'Could not remove the cover photo.', 'err'); return; }
                paintCover('');
                toast(d.message || 'Cover photo removed.', 'ok');
            }).catch(function () {
                toast('Could not remove the cover photo.', 'err');
            }).then(function () { coverRemove.disabled = false; });
        });
    }

    // ===================================================================
    // Appreciate (heart) on feed posts
    // ===================================================================
    document.addEventListener('click', function (e) {
        var like = e.target.closest('[data-like]');
        if (!like) return;
        var id = like.dataset.like;
        send(PROJECT_API, { action: 'toggle_like', project_id: id }).then(function (d) {
            if (!d.success) { toast(d.message || 'Could not update.', 'err'); return; }
            document.querySelectorAll('[data-like="' + id + '"]').forEach(function (b) {
                b.setAttribute('aria-pressed', d.liked ? 'true' : 'false');
                var span = b.querySelector('span');
                if (span) span.textContent = d.count > 0 ? d.count : '';
            });
        }).catch(function () { toast('Could not update.', 'err'); });
    });

    // ===================================================================
    // Remove a shared project from my profile
    // ===================================================================
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-unshare]');
        if (!btn) return;
        if (!window.confirm('Remove this shared project from your profile? The original project is not affected.')) return;
        var post = btn.closest('[data-share-post]');
        btn.disabled = true;
        send(PROJECT_API, { action: 'unshare_from_profile', share_id: btn.dataset.unshare }).then(function (d) {
            if (!d.success) { toast(d.message || 'Could not remove it.', 'err'); btn.disabled = false; return; }
            if (post) post.remove();
            toast(d.message || 'Removed from your profile.', 'ok');
            if (!document.querySelector('#pfFeed .df-post')) window.location.reload();
        }).catch(function () {
            toast('Could not remove it.', 'err');
            btn.disabled = false;
        });
    });


    // ===================================================================
    // Remove my tag from a team project (it leaves my profile; the project stays)
    // ===================================================================
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-untag]');
        if (!btn) return;
        if (!window.confirm('Remove your tag from this project? It will no longer show on your profile.')) return;
        var post = btn.closest('[data-tag-post]');
        btn.disabled = true;
        send(PROJECT_API, { action: 'remove_my_tag', project_id: btn.dataset.untag }).then(function (d) {
            if (!d.success) { toast(d.message || 'Could not remove your tag.', 'err'); btn.disabled = false; return; }
            if (post) post.remove();
            toast(d.message || 'Your tag was removed.', 'ok');
            if (!document.querySelector('#pfFeed .df-post')) window.location.reload();
        }).catch(function () {
            toast('Could not remove your tag.', 'err');
            btn.disabled = false;
        });
    });

    // ===================================================================
    // Post captions: clamp to 3 lines, "See more" / "See less"
    // ===================================================================
    function fitCaptions() {
        document.querySelectorAll('[data-pf-caption]:not(.is-open)').forEach(function (cap) {
            var btn = cap.parentNode.querySelector('[data-pf-seemore]');
            if (btn) btn.hidden = cap.scrollHeight <= cap.clientHeight + 1;
        });
    }
    document.addEventListener('click', function (e) {
        var btn = e.target.closest('[data-pf-seemore]');
        if (!btn) return;
        var cap = btn.parentNode.querySelector('[data-pf-caption]');
        if (!cap) return;
        var open = cap.classList.toggle('is-open');
        btn.textContent = open ? 'See less' : 'See more';
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
    fitCaptions();
    window.addEventListener('load', fitCaptions);
    window.addEventListener('resize', fitCaptions);
    // captions sit inside hidden tabs until opened; measure again when a tab is shown
    document.addEventListener('click', function (e) { if (e.target.closest('[data-pf-tab],[data-pf-go]')) setTimeout(fitCaptions, 0); });

    // ===================================================================
    // "..." post menu: one open at a time, closes on outside click / Esc
    // ===================================================================
    document.addEventListener('click', function (e) {
        document.querySelectorAll('[data-pf-menu][open]').forEach(function (m) {
            if (!m.contains(e.target) || e.target.closest('.pf-menu-item, .df-report')) m.removeAttribute('open');
        });
    });
    document.addEventListener('keydown', function (e) {
        if (e.key !== 'Escape') return;
        document.querySelectorAll('[data-pf-menu][open]').forEach(function (m) {
            m.removeAttribute('open');
            var s = m.querySelector('summary');
            if (s) s.focus();
        });
    });

    // ===================================================================
    // "1 follower" / "2 followers": keep the word in step with the live number
    // ===================================================================
    function fixCountWords() {
        document.querySelectorAll('[data-count-word="follower"]').forEach(function (w) {
            var b = w.parentNode.querySelector('[data-follower-count]');
            if (!b) return;
            w.textContent = (parseInt(b.textContent, 10) || 0) === 1 ? 'follower' : 'followers';
        });
    }
    document.addEventListener('df:follow', function () { setTimeout(fixCountWords, 60); });

    // ===================================================================
    // Keep "Following" counts honest when the owner unfollows / follows from the lists
    // ===================================================================
    document.addEventListener('df:follow', function (e) {
        if (!coverEdit) return; // only on your own profile does this change your own "following" total
        var delta = e.detail && e.detail.following ? 1 : -1;
        document.querySelectorAll('[data-following-count]').forEach(function (el) {
            var n = parseInt(el.textContent, 10) || 0;
            el.textContent = Math.max(0, n + delta);
        });
    });
})();
