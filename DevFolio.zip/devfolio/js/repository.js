/**
 * DEVFOLIO Project Repository Module
 * CCDI Sorsogon Student Showcase Platform
 * 
 * Functionality: Archive Search, Filtering, Historical Records
 */

// ==================== REPOSITORY RENDERING ====================

/**
 * Render the project repository list
 */
function renderRepository() {
    const list = document.getElementById('repositoryList');
    const search = (document.getElementById('repoSearch')?.value || '').toLowerCase();
    const course = document.getElementById('repoCourseFilter')?.value || 'ALL';
    const type = document.getElementById('repoTypeFilter')?.value || 'ALL';
    const year = document.getElementById('repoYearFilter')?.value || 'ALL';

    // Filter based on search and selection criteria
    const filtered = projectsData.filter(p => {
        const matchSearch = p.title.toLowerCase().includes(search) || 
                           p.techStack.some(t => t.toLowerCase().includes(search));
        const matchCourse = course === 'ALL' || p.program === course;
        const matchType = type === 'ALL' || p.category === type;
        const matchYear = year === 'ALL' || p.year === year;
        
        return matchSearch && matchCourse && matchType && matchYear;
    });

    // Update results count
    document.getElementById('repoResultsCount').innerText = `Showing ${filtered.length} Archived Output(s)`;

    if(filtered.length === 0) {
        list.innerHTML = `
            <div class="p-8 text-center text-xs text-slate-400">
                <i class="fa-solid fa-magnifying-glass text-2xl mb-2"></i>
                <p>No project records matching selected filters.</p>
            </div>
        `;
        return;
    }

    list.innerHTML = filtered.map(p => `
        <div class="p-4 hover:bg-slate-50 flex flex-col md:flex-row justify-between items-start md:items-center gap-4 border-b border-slate-100 last:border-b-0 transition">
            <div class="flex-1">
                <div class="flex items-center space-x-2 mb-1">
                    <span class="bg-slate-200 text-slate-800 text-[10px] font-bold px-2 py-0.5 rounded">${p.program}</span>
                    <span class="text-xs font-bold text-slate-800">${p.title}</span>
                </div>
                <p class="text-xs text-slate-500 mt-1">${p.abstract}</p>
                <p class="text-[10px] text-slate-400 mt-1">
                    <i class="fa-solid fa-users"></i> Authors: ${p.authors} • Adviser: ${p.adviser}
                </p>
            </div>
            <button onclick="openProjectModal(${p.id})" class="flex-shrink-0 bg-slate-100 hover:bg-amber-500 hover:text-slate-950 text-slate-700 text-xs font-bold px-3 py-1.5 rounded-lg transition border border-slate-200">
                View Archive
            </button>
        </div>
    `).join('');
}

// ==================== FILTER FUNCTIONS ====================

/**
 * Apply filters to repository
 */
function filterRepository() {
    renderRepository();
}

/**
 * Reset all repository filters
 */
function resetRepositoryFilters() {
    document.getElementById('repoSearch').value = '';
    document.getElementById('repoCourseFilter').value = 'ALL';
    document.getElementById('repoTypeFilter').value = 'ALL';
    document.getElementById('repoYearFilter').value = 'ALL';
    renderRepository();
    triggerToast('Filters reset', 'info');
}

// ==================== REPOSITORY STATISTICS ====================

/**
 * Get repository statistics
 * @returns {Object} Statistics object
 */
function getRepositoryStats() {
    return {
        total: projectsData.length,
        approved: projectsData.filter(p => p.status === 'Approved').length,
        pending: projectsData.filter(p => p.status === 'Pending').length,
        byProgram: {
            BSCS: projectsData.filter(p => p.program === 'BSCS').length,
            BSIT: projectsData.filter(p => p.program === 'BSIT').length,
            ACT: projectsData.filter(p => p.program === 'ACT').length
        },
        byCategory: {
            'Capstone System': projectsData.filter(p => p.category === 'Capstone System').length,
            'Web Application': projectsData.filter(p => p.category === 'Web Application').length,
            'Mobile App': projectsData.filter(p => p.category === 'Mobile App').length,
            '3D & Multimedia': projectsData.filter(p => p.category === '3D & Multimedia').length
        }
    };
}

// ==================== INITIALIZATION ====================

/**
 * Initialize repository view
 */
function initializeRepository() {
    renderRepository();
}
