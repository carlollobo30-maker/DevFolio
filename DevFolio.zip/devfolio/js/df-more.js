/**
 * DEVFOLIO "View more" for preview lists (skills, certificates).
 * The server renders every item and hides the ones after the preview limit:
 *
 *   [data-more-wrap]      container holding the items and the button
 *   [data-more-item]      an item that starts hidden
 *   [data-more-toggle]    the button ("View more (N)" <-> "Show less")
 */
(function () {
    'use strict';
    document.addEventListener('click', function (e) {
        var btn = e.target.closest ? e.target.closest('[data-more-toggle]') : null;
        if (!btn) return;
        var wrap = btn.closest('[data-more-wrap]');
        if (!wrap) return;
        var expanded = btn.getAttribute('aria-expanded') === 'true';
        wrap.querySelectorAll('[data-more-item]').forEach(function (el) { el.hidden = expanded; });
        btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
        btn.textContent = expanded ? btn.getAttribute('data-more-text') : 'Show less';
    });
})();
