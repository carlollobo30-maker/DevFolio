/**
 * DEVFOLIO Markdown renderer (README.md view + live preview in the editor).
 *
 * Safe by construction: the output is built only from tags this file writes itself.
 * Every piece of text is HTML-escaped, raw HTML in the README is never passed through
 * (tags are dropped; <img> and <br> are rebuilt safely), and links/images only keep
 * http(s) (and mailto / #anchor for links).
 *
 * DFMarkdown.render(text)  ->  HTML string
 * DFMarkdown.mount(el, text) -> renders into el and wires anchors + broken-image fallbacks
 *
 * Supported: headings (# and underlined), paragraphs, **bold**, *italic*, ~~strike~~,
 * `code`, fenced code blocks, blockquotes, bullet / numbered / task lists (nested),
 * tables, horizontal rules, links, images (also [![badge](img)](link)), reference links,
 * autolinks, <br>, <img>.
 */
(function (root) {
    'use strict';

    var MAX_INPUT = 300000;       // characters rendered (uploads are capped lower)
    var MAX_DEPTH = 8;            // nesting limit for lists / quotes

    // ---------- escaping + URL safety ----------
    function esc(s) {
        return String(s).replace(/[&<>"']/g, function (c) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
        });
    }

    function cleanUrl(raw) {
        return String(raw || '').replace(/[\u0000-\u001f\u007f\s]+/g, '').trim();
    }

    /** Link target: http(s), mailto or an in-page #anchor. Returns '' when not allowed. */
    function safeLinkUrl(raw) {
        var u = cleanUrl(raw);
        if (/^https?:\/\/[^\s]+$/i.test(u) || /^mailto:[^\s]+$/i.test(u) || /^#[^\s]*$/.test(u)) return u;
        return '';
    }
    /** Image source: http(s) only. */
    function safeImageUrl(raw) {
        var u = cleanUrl(raw);
        return /^https?:\/\/[^\s]+$/i.test(u) ? u : '';
    }

    function slug(text) {
        return String(text).toLowerCase()
            .replace(/!\[[^\]]*\]\([^)]*\)/g, '')
            .replace(/\[([^\]]*)\]\([^)]*\)/g, '$1')
            .replace(/<[^>]*>/g, '')
            .replace(/[^\p{L}\p{N}\s-]/gu, '')
            .trim().replace(/\s+/g, '-') || 'section';
    }

    // ---------- inline ----------
    function imgHtml(alt, url, title) {
        var src = safeImageUrl(url);
        if (!src) {
            // relative / unsupported path: show what it was meant to be, never a broken icon
            return '<span class="md-img-missing" role="img" aria-label="' + esc('Image not available: ' + alt) + '">' +
                '<span aria-hidden="true">&#9635;</span> ' + esc(alt || 'image') + '</span>';
        }
        return '<img class="md-img" src="' + esc(src) + '" alt="' + esc(alt) + '"' +
            (title ? ' title="' + esc(title) + '"' : '') +
            ' loading="lazy" referrerpolicy="no-referrer">';
    }

    function linkHtml(innerHtml, url, title) {
        var href = safeLinkUrl(url);
        if (!href) return innerHtml;     // keep the words, drop the unsafe / relative target
        if (href.charAt(0) === '#') {
            return '<a href="' + esc(href) + '" data-md-anchor="md-' + esc(slug(decodeURIComponentSafe(href.slice(1)))) + '"' +
                (title ? ' title="' + esc(title) + '"' : '') + '>' + innerHtml + '</a>';
        }
        return '<a href="' + esc(href) + '" target="_blank" rel="noopener noreferrer nofollow"' +
            (title ? ' title="' + esc(title) + '"' : '') + '>' + innerHtml + '</a>';
    }

    function decodeURIComponentSafe(s) {
        try { return decodeURIComponent(s); } catch (e) { return s; }
    }

    function parseTitle(t) {
        if (!t) return '';
        t = t.trim();
        var m = /^(?:"([^"]*)"|'([^']*)'|\(([^)]*)\))$/.exec(t);
        return m ? (m[1] || m[2] || m[3] || '') : '';
    }

    function inline(text, refs, noLinks) {
        var stash = [];
        function keep(html) { stash.push(html); return '\u0000' + (stash.length - 1) + '\u0000'; }

        var s = String(text);

        // 1. code spans
        s = s.replace(/(`+)([\s\S]*?[^`])\1(?!`)/g, function (m, ticks, code) {
            return keep('<code>' + esc(code.replace(/^ (.*) $/, '$1')) + '</code>');
        });

        // 2. a little raw HTML: <br>, <img>, comments / other tags are dropped
        s = s.replace(/<!--[\s\S]*?-->/g, '');
        s = s.replace(/<br\s*\/?>/gi, function () { return keep('<br>'); });
        s = s.replace(/<img\b([^>]*)>/gi, function (m, attrs) {
            var src = /\bsrc\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
            var alt = /\balt\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i.exec(attrs);
            return keep(imgHtml(alt ? (alt[1] || alt[2] || alt[3] || '') : '', src ? (src[1] || src[2] || src[3] || '') : '', ''));
        });
        s = s.replace(/<(https?:\/\/[^\s<>]+)>/gi, function (m, url) {
            return keep(linkHtml(esc(url), url, ''));
        });
        s = s.replace(/<\/?[a-zA-Z][^>]*>/g, '');

        // 3. backslash escapes
        s = s.replace(/\\([\\`*_{}\[\]()#+\-.!~|>])/g, function (m, ch) { return keep(esc(ch)); });

        // 4. images, then links (link text may hold an image badge)
        s = s.replace(/!\[([^\]]*)\]\(\s*((?:[^()\s]|\([^()\s]*\))+)(?:\s+("[^"]*"|'[^']*'))?\s*\)/g, function (m, alt, url, title) {
            return keep(imgHtml(alt, url, parseTitle(title)));
        });
        s = s.replace(/!\[([^\]]*)\]\[([^\]]*)\]/g, function (m, alt, ref) {
            var r = refs && refs[(ref || alt).toLowerCase()];
            return r ? keep(imgHtml(alt, r.url, r.title)) : m;
        });
        if (!noLinks) {
            // label text is formatted on its own; pieces already stashed (badge images, code) are kept as they are
            var label2html = function (label) {
                return label.split(/(\u0000\d+\u0000)/).map(function (part) {
                    var mk = /^\u0000(\d+)\u0000$/.exec(part);
                    return mk ? (stash[+mk[1]] !== undefined ? stash[+mk[1]] : '') : inline(part, refs, true);
                }).join('');
            };
            s = s.replace(/\[((?:[^\[\]]|\u0000\d+\u0000)*)\]\(\s*((?:[^()\s]|\([^()\s]*\))+)(?:\s+("[^"]*"|'[^']*'))?\s*\)/g, function (m, label, url, title) {
                return keep(linkHtml(label2html(label), url, parseTitle(title)));
            });
            s = s.replace(/\[((?:[^\[\]]|\u0000\d+\u0000)*)\]\[([^\]]*)\]/g, function (m, label, ref) {
                var r = refs && refs[(ref || label).toLowerCase()];
                return r ? keep(linkHtml(label2html(label), r.url, r.title)) : m;
            });
            s = s.replace(/\[([^\[\]\u0000]+)\](?!\()/g, function (m, label) {
                var r = refs && refs[label.toLowerCase()];
                return r ? keep(linkHtml(esc(label), r.url, r.title)) : m;
            });
        }

        // 5. escape everything that is left, then emphasis
        s = esc(s);
        s = s.replace(/\*\*\*(?=\S)([\s\S]*?\S)\*\*\*/g, '<strong><em>$1</em></strong>');
        s = s.replace(/\*\*(?=\S)([\s\S]*?\S)\*\*/g, '<strong>$1</strong>');
        s = s.replace(/(^|[^\w])__(?=\S)([\s\S]*?\S)__(?!\w)/g, '$1<strong>$2</strong>');
        s = s.replace(/\*(?=\S)([^*]*?\S)\*/g, '<em>$1</em>');
        s = s.replace(/(^|[^\w])_(?=\S)([^_]*?\S)_(?!\w)/g, '$1<em>$2</em>');
        s = s.replace(/~~(?=\S)([\s\S]*?\S)~~/g, '<del>$1</del>');

        // 6. bare links
        if (!noLinks) {
            s = s.replace(/(^|[\s(])(https?:\/\/(?:(?!&quot;|&#39;|&lt;|&gt;)[^\s<])+)/g, function (m, pre, url) {
                var trail = '';
                var t = /[.,;:!?)\]]+$/.exec(url);
                if (t) { trail = t[0]; url = url.slice(0, -trail.length); }
                var plain = url.replace(/&amp;/g, '&');
                return pre + keep(linkHtml(url, plain, '')) + trail;
            });
        }

        // 7. hard breaks, then put the stashed pieces back (they may contain stash markers)
        s = s.replace(/(?: {2,}|\\)\n/g, '<br>\n');
        var guard = 0;
        while (/\u0000\d+\u0000/.test(s) && guard++ < 10) {
            s = s.replace(/\u0000(\d+)\u0000/g, function (m, i) { return stash[+i] !== undefined ? stash[+i] : ''; });
        }
        return s;
    }

    // ---------- blocks ----------
    var reFence = /^ {0,3}(`{3,}|~{3,})\s*([\w+#.-]*)[^\n]*$/;
    var reHr = /^ {0,3}([-*_])(?:\s*\1){2,}\s*$/;
    var reAtx = /^ {0,3}(#{1,6})[ \t]+(.*?)(?:[ \t]+#+)?[ \t]*$/;
    var reQuote = /^ {0,3}>\s?/;
    var reItem = /^( *)([-*+]|\d{1,9}[.)])[ \t]+(.*)$/;
    var reTableSep = /^\s*\|?\s*:?-{1,}:?\s*(\|\s*:?-{1,}:?\s*)*\|?\s*$/;

    function splitRow(line) {
        var t = line.trim();
        if (t.charAt(0) === '|') t = t.slice(1);
        if (t.charAt(t.length - 1) === '|' && t.charAt(t.length - 2) !== '\\') t = t.slice(0, -1);
        var cells = [], cur = '';
        for (var i = 0; i < t.length; i++) {
            if (t[i] === '\\' && t[i + 1] === '|') { cur += '|'; i++; }
            else if (t[i] === '|') { cells.push(cur.trim()); cur = ''; }
            else cur += t[i];
        }
        cells.push(cur.trim());
        return cells;
    }

    function isBlockStart(line) {
        return reFence.test(line) || reAtx.test(line) || reHr.test(line) || reQuote.test(line) || reItem.test(line);
    }

    function blocks(lines, refs, depth, tight) {
        var out = [];
        var i = 0;
        var usedSlugs = blocks.slugs || (blocks.slugs = {});

        while (i < lines.length) {
            var line = lines[i];

            if (/^\s*$/.test(line)) { i++; continue; }

            // fenced code
            var f = reFence.exec(line);
            if (f) {
                var fence = f[1], lang = f[2].replace(/[^\w+#.-]/g, ''), code = [];
                i++;
                while (i < lines.length) {
                    var close = new RegExp('^ {0,3}' + fence.charAt(0) + '{' + fence.length + ',}\\s*$');
                    if (close.test(lines[i])) { i++; break; }
                    code.push(lines[i]);
                    i++;
                }
                out.push('<pre class="md-pre"><code' + (lang ? ' class="language-' + esc(lang) + '"' : '') + '>' + esc(code.join('\n')) + '</code></pre>');
                continue;
            }

            // indented code
            if (/^( {4}|\t)/.test(line) && !tightContext(tight)) {
                var ic = [];
                while (i < lines.length && (/^( {4}|\t)/.test(lines[i]) || /^\s*$/.test(lines[i]))) {
                    ic.push(lines[i].replace(/^( {4}|\t)/, ''));
                    i++;
                }
                while (ic.length && /^\s*$/.test(ic[ic.length - 1])) ic.pop();
                out.push('<pre class="md-pre"><code>' + esc(ic.join('\n')) + '</code></pre>');
                continue;
            }

            // heading
            var h = reAtx.exec(line);
            if (h) {
                var level = h[1].length;
                var base = slug(h[2]);
                var n = usedSlugs[base] = (usedSlugs[base] || 0) + 1;
                var id = 'md-' + base + (n > 1 ? '-' + (n - 1) : '');
                out.push('<h' + level + ' id="' + esc(id) + '">' + inline(h[2], refs) + '</h' + level + '>');
                i++;
                continue;
            }

            // horizontal rule
            if (reHr.test(line)) { out.push('<hr>'); i++; continue; }

            // blockquote
            if (reQuote.test(line) && depth < MAX_DEPTH) {
                var q = [];
                while (i < lines.length && (reQuote.test(lines[i]) || (/\S/.test(lines[i]) && q.length && !isBlockStart(lines[i])))) {
                    q.push(lines[i].replace(reQuote, ''));
                    i++;
                }
                out.push('<blockquote>' + blocks(q, refs, depth + 1, false) + '</blockquote>');
                continue;
            }

            // table
            if (line.indexOf('|') !== -1 && i + 1 < lines.length && reTableSep.test(lines[i + 1]) && lines[i + 1].indexOf('-') !== -1) {
                var head = splitRow(line);
                var aligns = splitRow(lines[i + 1]).map(function (c) {
                    var l = c.charAt(0) === ':', r = c.charAt(c.length - 1) === ':';
                    return l && r ? 'center' : r ? 'right' : l ? 'left' : '';
                });
                if (head.length === aligns.length) {
                    var rows = [];
                    i += 2;
                    while (i < lines.length && /\S/.test(lines[i]) && lines[i].indexOf('|') !== -1) { rows.push(splitRow(lines[i])); i++; }
                    var cell = function (tag, txt, k) {
                        return '<' + tag + (aligns[k] ? ' style="text-align:' + aligns[k] + '"' : '') + '>' + inline(txt || '', refs) + '</' + tag + '>';
                    };
                    var html = '<div class="md-table-wrap"><table><thead><tr>' + head.map(function (c, k) { return cell('th', c, k); }).join('') + '</tr></thead><tbody>';
                    rows.forEach(function (r) {
                        html += '<tr>' + aligns.map(function (a, k) { return cell('td', r[k], k); }).join('') + '</tr>';
                    });
                    out.push(html + '</tbody></table></div>');
                    continue;
                }
            }

            // list
            var li = reItem.exec(line);
            if (li && depth < MAX_DEPTH) {
                var res = list(lines, i, refs, depth);
                out.push(res.html);
                i = res.next;
                continue;
            }

            // paragraph (and setext headings)
            var para = [line];
            i++;
            while (i < lines.length && /\S/.test(lines[i]) && !isBlockStart(lines[i]) && !/^ {4}/.test(lines[i])) {
                if (/^ {0,3}(=+|-+)\s*$/.test(lines[i])) break;
                para.push(lines[i]);
                i++;
            }
            if (i < lines.length && /^ {0,3}(=+|-+)\s*$/.test(lines[i]) && para.length) {
                var lvl = lines[i].trim().charAt(0) === '=' ? 1 : 2;
                var txt = para.join(' ').trim();
                var b2 = slug(txt);
                var n2 = usedSlugs[b2] = (usedSlugs[b2] || 0) + 1;
                out.push('<h' + lvl + ' id="md-' + esc(b2) + (n2 > 1 ? '-' + (n2 - 1) : '') + '">' + inline(txt, refs) + '</h' + lvl + '>');
                i++;
                continue;
            }
            var ptxt = para.map(function (l) { return l.replace(/^\s+/, ''); }).join('\n');
            var rendered = inline(ptxt, refs);
            if (/\S/.test(rendered.replace(/<br>/g, ''))) out.push(tight ? rendered : '<p>' + rendered + '</p>');
        }
        return out.join('\n');
    }

    function tightContext(tight) { return !!tight; }

    function list(lines, start, refs, depth) {
        var first = reItem.exec(lines[start]);
        var baseIndent = first[1].length;
        var ordered = /\d/.test(first[2].charAt(0));
        var startNum = ordered ? parseInt(first[2], 10) : 1;
        var items = [];
        var i = start;
        var loose = false;

        while (i < lines.length) {
            var m = reItem.exec(lines[i]);
            if (!m || m[1].length < baseIndent || (m[1].length > baseIndent + 1 && !items.length)) break;
            if (m[1].length > baseIndent + 1) break;                       // belongs to a nested list (handled below)
            if (/\d/.test(m[2].charAt(0)) !== ordered) break;
            var contentIndent = m[1].length + m[2].length + 1;
            var body = [m[3]];
            i++;
            var sawBlank = false;
            while (i < lines.length) {
                var ln = lines[i];
                if (/^\s*$/.test(ln)) {
                    // a blank line only continues the item if the next line is indented under it
                    var j = i + 1;
                    while (j < lines.length && /^\s*$/.test(lines[j])) j++;
                    if (j < lines.length && indentOf(lines[j]) >= contentIndent) { body.push(''); sawBlank = true; i++; continue; }
                    break;
                }
                var nm = reItem.exec(ln);
                if (nm && nm[1].length <= baseIndent + 1) break;           // next sibling item
                if (indentOf(ln) >= contentIndent || !isBlockStart(ln)) {
                    body.push(ln.replace(new RegExp('^ {0,' + contentIndent + '}'), ''));
                    i++;
                    continue;
                }
                break;
            }
            if (sawBlank) loose = true;
            items.push(body);
            // a blank line between items makes the list loose
            if (i < lines.length && /^\s*$/.test(lines[i])) {
                var k = i;
                while (k < lines.length && /^\s*$/.test(lines[k])) k++;
                var nx = k < lines.length ? reItem.exec(lines[k]) : null;
                if (nx && nx[1].length <= baseIndent + 1 && /\d/.test(nx[2].charAt(0)) === ordered && nx[1].length >= baseIndent) {
                    loose = true;
                    i = k;
                } else break;
            }
        }

        var tag = ordered ? 'ol' : 'ul';
        var task = false;
        var html = items.map(function (body) {
            var text = body[0];
            var box = /^\[([ xX])\][ \t]+/.exec(text);
            var prefix = '';
            if (box) {
                task = true;
                body = body.slice();
                body[0] = text.replace(/^\[[ xX]\][ \t]+/, '');
                prefix = '<input type="checkbox" disabled' + (box[1] !== ' ' ? ' checked' : '') + ' aria-label="' + (box[1] !== ' ' ? 'Done' : 'Not done') + '"> ';
            }
            var inner = blocks(body, refs, depth + 1, !loose);
            return '<li' + (box ? ' class="md-task"' : '') + '>' + prefix + inner + '</li>';
        }).join('');
        return {
            html: '<' + tag + (ordered && startNum !== 1 ? ' start="' + startNum + '"' : '') + (task ? ' class="md-tasks"' : '') + '>' + html + '</' + tag + '>',
            next: i
        };
    }

    function indentOf(line) {
        var m = /^( *)/.exec(line);
        return m[1].length;
    }

    // ---------- public API ----------
    function render(text) {
        var src = String(text == null ? '' : text).replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').replace(/\t/g, '    ');
        var truncated = false;
        if (src.length > MAX_INPUT) { src = src.slice(0, MAX_INPUT); truncated = true; }

        // reference definitions:  [id]: https://url "title"   (not inside code fences)
        var refs = {};
        var lines = src.split('\n');
        var kept = [], inFence = false, fenceMark = '';
        lines.forEach(function (ln) {
            var fm = /^ {0,3}(`{3,}|~{3,})/.exec(ln);
            if (fm) {
                if (!inFence) { inFence = true; fenceMark = fm[1].charAt(0); }
                else if (fm[1].charAt(0) === fenceMark) inFence = false;
                kept.push(ln);
                return;
            }
            var d = !inFence && /^ {0,3}\[([^\]]+)\]:\s*<?(\S+?)>?(?:\s+("[^"]*"|'[^']*'|\([^)]*\)))?\s*$/.exec(ln);
            if (d) refs[d[1].toLowerCase()] = { url: d[2], title: parseTitle(d[3]) };
            else kept.push(ln);
        });

        // HTML comments can span lines; remove them outside code
        var joined = kept.join('\n');
        var parts = joined.split(/(^ {0,3}(?:`{3,}|~{3,})[^\n]*\n[\s\S]*?\n {0,3}(?:`{3,}|~{3,})[ \t]*$)/m);
        joined = parts.map(function (p, idx) { return idx % 2 ? p : p.replace(/<!--[\s\S]*?-->/g, ''); }).join('');

        blocks.slugs = {};
        var html = blocks(joined.split('\n'), refs, 0, false);
        if (truncated) html += '<p class="md-note">This README is very long, so only the first part is shown.</p>';
        return html;
    }

    function mount(el, text) {
        el.innerHTML = render(text);
        // images that fail to load fall back to their description
        el.querySelectorAll('img.md-img').forEach(function (img) {
            img.addEventListener('error', function () {
                var span = document.createElement('span');
                span.className = 'md-img-missing';
                span.setAttribute('role', 'img');
                span.setAttribute('aria-label', 'Image could not be loaded: ' + (img.alt || 'image'));
                span.textContent = '\u25A3 ' + (img.alt || 'image');
                if (img.parentNode) img.parentNode.replaceChild(span, img);
            }, { once: true });
        });
        // in-page links (table of contents) scroll inside the README instead of changing the URL
        if (el.__mdBound) return;
        el.__mdBound = true;
        el.addEventListener('click', function (e) {
            var a = e.target.closest ? e.target.closest('a[data-md-anchor]') : null;
            if (!a) return;
            var target = el.querySelector('#' + (window.CSS && CSS.escape ? CSS.escape(a.getAttribute('data-md-anchor')) : a.getAttribute('data-md-anchor')));
            if (target) { e.preventDefault(); target.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
        });
    }

    root.DFMarkdown = { render: render, mount: mount };
    if (typeof module !== 'undefined' && module.exports) module.exports = root.DFMarkdown;
})(typeof window !== 'undefined' ? window : (typeof globalThis !== 'undefined' ? globalThis : this));
