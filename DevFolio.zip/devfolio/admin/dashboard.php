<?php
/**
 * Admin Dashboard
 * DEVFOLIO CCDI Sorsogon
 */
session_start();
require_once __DIR__ . '/../includes/db_connect.php';
require_once __DIR__ . '/../includes/ui-helpers.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: ../login.php');
    exit;
}

$adminName = trim((string) ($_SESSION['first_name'] ?? '') . ' ' . (string) ($_SESSION['last_name'] ?? ''));
if ($adminName === '') {
    $adminName = 'Admin User';
}

$successMessage = '';
$errorMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['logout'])) {
        session_unset();
        session_destroy();
        header('Location: ../login.php');
        exit;
    }

    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'update_user_role' && !empty($_POST['user_id'])) {
            $userId = (int) $_POST['user_id'];
            $newRole = strtolower((string) ($_POST['role'] ?? 'student'));
            if (in_array($newRole, ['student', 'faculty', 'admin'], true) && $userId !== (int) $_SESSION['user_id']) {
                $stmt = $pdo->prepare('UPDATE users SET role = ?, updated_at = NOW() WHERE id = ?');
                $stmt->execute([$newRole, $userId]);
                $successMessage = 'User role updated successfully.';
            } else {
                $errorMessage = 'You cannot change your own admin role.';
            }
        }
    }
}

$totalStudents = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'student'")->fetchColumn();
$totalFaculty = (int) $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'faculty'")->fetchColumn();
$openReports = dfOpenReportCount($pdo);
$approvedProjects = (int) $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'approved'")->fetchColumn();

$allUsers = $pdo->query("SELECT u.*, s.student_id FROM users u LEFT JOIN students s ON s.user_id = u.id ORDER BY u.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
$programStats = $pdo->query("SELECT s.program, COUNT(*) as total FROM students s GROUP BY s.program ORDER BY total DESC")->fetchAll(PDO::FETCH_ASSOC);
$recentProjects = $pdo->query("SELECT p.*, s.student_id, u.first_name, u.last_name FROM projects p LEFT JOIN students s ON s.id = p.student_id LEFT JOIN users u ON u.id = s.user_id ORDER BY p.created_at DESC LIMIT 6")->fetchAll(PDO::FETCH_ASSOC);

$currentView = $_GET['view'] ?? 'dashboard';
if ($currentView === 'review-projects') $currentView = 'moderation';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - DEVFOLIO</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            color: #0f172a;
        }
        .content-shell {
            background: rgba(255, 255, 255, 0.18);
            backdrop-filter: none;
            min-height: calc(100vh - 88px);
        }
        .ccdi-header {
            background: linear-gradient(90deg, #0b234d 0%, #113a78 100%);
            border-bottom: 2px solid rgba(255,255,255,0.08);
            box-shadow: 0 8px 18px rgba(11, 35, 77, 0.18);
        }
        .ccdi-logo-wrap {
            display: flex;
            align-items: center;
            gap: 14px;
            min-width: 260px;
        }
        .ccdi-mark {
            width: 58px;
            height: 58px;
            border-radius: 50%;
            overflow: hidden;
            display: flex;
            align-items: center;
            justify-content: center;
            background: #ffffff;
            border: 4px solid rgba(255,255,255,0.18);
            box-shadow: inset 0 0 0 3px rgba(11,35,77,0.08);
        }
        .ccdi-mark img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
        }
        .ccdi-wordmark {
            font-size: clamp(2.1rem, 2vw, 3rem);
            font-weight: 900;
            letter-spacing: 0.01em;
            color: #ffffff;
            line-height: 1;
            white-space: nowrap;
        }
        .ccdi-nav {
            display: flex;
            align-items: center;
            gap: 14px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }
        .nav-link {
            padding: 0.8rem 1.2rem;
            border-radius: 12px;
            font-weight: 800;
            font-size: 1.05rem;
            color: #e2e8f0;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 46px;
            transition: all 0.2s ease;
        }
        .nav-link:hover {
            color: #fff;
            background: rgba(255,255,255,0.08);
        }
        .nav-link.active {
            background: linear-gradient(180deg, #f8c75e 0%, #f2ae1c 100%);
            color: #121826;
            box-shadow: 0 6px 18px rgba(242, 174, 28, 0.35);
        }
        .nav-link.red {
            background: linear-gradient(180deg, #ff5a5a 0%, #e53935 100%);
            color: #fff;
            border: none;
            box-shadow: 0 6px 18px rgba(229, 57, 53, 0.35);
        }
        .nav-link.red:hover {
            background: linear-gradient(180deg, #f25050 0%, #d62e2e 100%);
            color: #fff;
        }
        .section-panel {
            display: none;
        }
        .section-panel.active {
            display: block;
        }
        @media (max-width: 768px) {
            .ccdi-logo-wrap {
                width: 100%;
                justify-content: center;
            }
            .ccdi-nav {
                width: 100%;
                justify-content: center;
            }
            .ccdi-wordmark {
                font-size: 1.9rem;
            }
        }
        .page-bg-video {
            position: fixed;
            top: 50%;
            left: 50%;
            min-width: 100%;
            min-height: 100%;
            width: auto;
            height: auto;
            z-index: -1;
            transform: translate(-50%, -50%);
            object-fit: cover;
        }
    </style>
    <link rel="stylesheet" href="../assets/css/ccdi-theme.css">
</head>
<body class="bg-slate-50">
    <div class="min-h-screen">
        <nav class="ccdi-header text-white p-5 shadow-lg">
            <div class="w-full flex justify-between items-center gap-4 flex-wrap">
                <div class="ccdi-logo-wrap">
                    <div class="ccdi-mark">
                        <img src="../assets/img/ccdi_2.jpg" alt="CCDI logo">
                    </div>
                    <div class="ccdi-wordmark">DEVFOLIO</div>
                </div>

                <div class="ccdi-nav">
                    <a href="dashboard.php?view=dashboard" class="nav-link <?php echo $currentView === 'dashboard' ? 'active' : ''; ?>">Dashboard</a>
                    <a href="dashboard.php?view=users" class="nav-link <?php echo $currentView === 'users' ? 'active' : ''; ?>">Users</a>
                    <a href="dashboard.php?view=moderation" class="nav-link <?php echo $currentView === 'moderation' ? 'active' : ''; ?>">Moderation<?php if ($openReports > 0): ?> <span class="ml-2 bg-red-600 text-white text-xs font-black rounded-full px-2 py-0.5"><?php echo $openReports; ?></span><?php endif; ?></a>
                    <a href="dashboard.php?view=manage-users" class="nav-link <?php echo $currentView === 'manage-users' ? 'active' : ''; ?>">Manage Users</a>
                    <a href="dashboard.php?view=reports" class="nav-link <?php echo $currentView === 'reports' ? 'active' : ''; ?>">Reports</a>
                    <form method="POST" action="dashboard.php" class="inline">
                        <button type="submit" name="logout" value="1" class="nav-link red border-0 cursor-pointer">
                            Logout
                        </button>
                    </form>
                </div>
            </div>
        </nav>

        <div class="content-shell">
            <div class="w-full px-4 sm:px-8 py-8">
                <?php if ($successMessage !== ''): ?>
                    <div class="mb-5 rounded-xl border border-emerald-200 bg-emerald-50 text-emerald-700 px-4 py-3 text-sm font-medium">
                        <?php echo htmlspecialchars($successMessage); ?>
                    </div>
                <?php endif; ?>

                <?php if ($errorMessage !== ''): ?>
                    <div class="mb-5 rounded-xl border border-red-200 bg-red-50 text-red-700 px-4 py-3 text-sm font-medium">
                        <?php echo htmlspecialchars($errorMessage); ?>
                    </div>
                <?php endif; ?>

                <section id="dashboard" class="section-panel <?php echo $currentView === 'dashboard' ? 'active' : ''; ?> mb-8">
                    <div class="bg-white/90 rounded-2xl border border-slate-200 shadow-sm p-8">
                        <h2 class="text-3xl font-black text-slate-800 mb-3">Admin Dashboard</h2>
                        <p class="text-lg text-slate-700 font-medium">Welcome, <span class="text-slate-900 font-bold"><?php echo htmlspecialchars($adminName); ?></span></p>
                    </div>

                    <section class="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-slate-500 text-sm">Total Students</p>
                                    <h3 class="text-3xl font-bold text-slate-900"><?php echo $totalStudents; ?></h3>
                                </div>
                                <i class="fa-solid fa-user-graduate text-4xl text-blue-500 opacity-20"></i>
                            </div>
                        </div>

                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-slate-500 text-sm">Faculty Members</p>
                                    <h3 class="text-3xl font-bold text-slate-900"><?php echo $totalFaculty; ?></h3>
                                </div>
                                <i class="fa-solid fa-chalkboard-user text-4xl text-emerald-500 opacity-20"></i>
                            </div>
                        </div>

                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-slate-500 text-sm">Open Reports</p>
                                    <h3 class="text-3xl font-bold text-slate-900"><?php echo $openReports; ?></h3>
                                </div>
                                <i class="fa-solid fa-clock text-4xl text-amber-500 opacity-20"></i>
                            </div>
                        </div>

                        <div class="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-slate-500 text-sm">Published Projects</p>
                                    <h3 class="text-3xl font-bold text-slate-900"><?php echo $approvedProjects; ?></h3>
                                </div>
                                <i class="fa-solid fa-check-circle text-4xl text-violet-500 opacity-20"></i>
                            </div>
                        </div>
                    </section>

                    <section class="mt-8 bg-white rounded-2xl p-6 shadow-sm border border-slate-200">
                        <h3 class="text-2xl font-black text-slate-900 mb-5">Quick Actions</h3>
                        <div class="flex flex-wrap gap-3">
                            <a href="dashboard.php?view=review-projects" class="bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold px-6 py-3 rounded-lg transition shadow-sm text-lg">
                                <i class="fa-solid fa-list-check mr-2"></i>Review Projects
                            </a>
                            <a href="dashboard.php?view=manage-users" class="bg-blue-500 hover:bg-blue-600 text-white font-bold px-6 py-3 rounded-lg transition shadow-sm text-lg">
                                <i class="fa-solid fa-user-plus mr-2"></i>Manage Users
                            </a>
                            <a href="dashboard.php?view=reports" class="bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold px-6 py-3 rounded-lg transition shadow-sm text-lg">
                                <i class="fa-solid fa-chart-column mr-2"></i>Reports
                            </a>
                        </div>
                    </section>
                </section>

                <section id="users" class="section-panel <?php echo $currentView === 'users' ? 'active' : ''; ?> mb-8 bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                    <div class="flex items-center justify-between mb-4">
                        <h3 class="text-2xl font-black text-slate-900">Users</h3>
                        <span class="text-xs font-semibold bg-slate-100 text-slate-700 px-3 py-1 rounded-full"><?php echo count($allUsers); ?> total</span>
                    </div>

                    <div class="overflow-x-auto">
                        <table class="w-full text-sm">
                            <thead class="bg-slate-50 border-b border-slate-200">
                                <tr>
                                    <th class="px-4 py-3 text-left font-bold text-slate-700">Name</th>
                                    <th class="px-4 py-3 text-left font-bold text-slate-700">Email</th>
                                    <th class="px-4 py-3 text-left font-bold text-slate-700">Role</th>
                                    <th class="px-4 py-3 text-left font-bold text-slate-700">Student ID</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (empty($allUsers)): ?>
                                    <tr>
                                        <td colspan="4" class="px-4 py-6 text-center text-slate-500">No users found.</td>
                                    </tr>
                                <?php else: ?>
                                    <?php foreach ($allUsers as $user): ?>
                                        <?php $fullName = trim((string) ($user['first_name'] ?? '') . ' ' . (string) ($user['last_name'] ?? '')); ?>
                                        <tr class="border-b border-slate-100 hover:bg-slate-50">
                                            <td class="px-4 py-3 font-semibold text-slate-800"><?php echo htmlspecialchars($fullName !== '' ? $fullName : 'Unknown User'); ?></td>
                                            <td class="px-4 py-3 text-slate-600"><?php echo htmlspecialchars($user['email'] ?? ''); ?></td>
                                            <td class="px-4 py-3">
                                                <?php
                                                    $roleKey = $user['role'] ?? 'student';
                                                    $roleStyle = ['admin' => 'background:#fbbf24;color:#422006', 'faculty' => 'background:#dc2626;color:#fff', 'student' => 'background:#15803d;color:#fff'][$roleKey] ?? 'background:#e2e8f0;color:#0f172a';
                                                ?>
                                                <span class="inline-block rounded-full px-2.5 py-1 text-xs font-bold tracking-wide" style="<?php echo $roleStyle; ?>"><?php echo htmlspecialchars(strtoupper($roleKey)); ?></span>
                                            </td>
                                            <td class="px-4 py-3 text-slate-600"><?php echo htmlspecialchars($user['student_id'] ?? '—'); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </section>

                <section id="moderation" class="section-panel <?php echo $currentView === 'moderation' ? 'active' : ''; ?> mb-8 bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                    <?php if ($currentView === 'moderation') { $modEndpoint = '../includes/moderation-api.php'; include __DIR__ . '/../includes/moderation-panel.php'; } ?>
                </section>

                <section id="manage-users" class="section-panel <?php echo $currentView === 'manage-users' ? 'active' : ''; ?> mb-8 bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                    <h3 class="text-2xl font-black text-slate-900 mb-5">Manage Users</h3>

                    <div class="space-y-4">
                        <?php foreach ($allUsers as $user): ?>
                            <?php if ((int) $user['id'] === (int) $_SESSION['user_id']) continue; ?>
                            <?php $fullName = trim((string) ($user['first_name'] ?? '') . ' ' . (string) ($user['last_name'] ?? '')); ?>
                            <div class="border border-slate-200 rounded-xl p-4">
                                <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                                    <div>
                                        <div class="font-bold text-slate-900"><?php echo htmlspecialchars($fullName !== '' ? $fullName : 'Unknown User'); ?></div>
                                        <div class="text-sm text-slate-500"><?php echo htmlspecialchars($user['email'] ?? ''); ?></div>
                                    </div>

                                    <form method="POST" action="dashboard.php?view=manage-users" class="flex flex-wrap items-center gap-2">
                                        <input type="hidden" name="action" value="update_user_role">
                                        <input type="hidden" name="user_id" value="<?php echo (int) $user['id']; ?>">
                                        <select name="role" class="rounded-lg border border-slate-300 px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-sky-500">
                                            <option value="student" <?php echo (($user['role'] ?? '') === 'student') ? 'selected' : ''; ?>>Student</option>
                                            <option value="faculty" <?php echo (($user['role'] ?? '') === 'faculty') ? 'selected' : ''; ?>>Faculty</option>
                                            <option value="admin" <?php echo (($user['role'] ?? '') === 'admin') ? 'selected' : ''; ?>>Admin</option>
                                        </select>
                                        <button type="submit" class="bg-sky-600 hover:bg-sky-700 text-white font-bold px-4 py-2 rounded-lg text-sm">
                                            Update Role
                                        </button>
                                    </form>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </section>

                <section id="reports" class="section-panel <?php echo $currentView === 'reports' ? 'active' : ''; ?> bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
                    <h3 class="text-2xl font-black text-slate-900 mb-5">Reports</h3>

                    <div class="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div class="bg-slate-50 border border-slate-200 rounded-xl p-5">
                            <p class="text-slate-500 text-sm">Published Projects</p>
                            <h4 class="text-3xl font-bold text-slate-900 mt-2"><?php echo $approvedProjects; ?></h4>
                        </div>
                        <div class="bg-slate-50 border border-slate-200 rounded-xl p-5">
                            <p class="text-slate-500 text-sm">Open Reports</p>
                            <h4 class="text-3xl font-bold text-slate-900 mt-2"><?php echo $openReports; ?></h4>
                        </div>
                        <div class="bg-slate-50 border border-slate-200 rounded-xl p-5">
                            <p class="text-slate-500 text-sm">Total Users</p>
                            <h4 class="text-3xl font-bold text-slate-900 mt-2"><?php echo count($allUsers); ?></h4>
                        </div>
                    </div>

                    <div class="space-y-5">
                        <?php foreach ($programStats as $stat): ?>
                            <?php $percent = count($programStats) > 0 ? round((int) $stat['total'] / max(array_sum(array_column($programStats, 'total')), 1) * 100) : 0; ?>
                            <div>
                                <div class="flex justify-between text-sm font-semibold mb-2">
                                    <span class="text-slate-800 font-bold"><?php echo htmlspecialchars($stat['program'] ?? 'Unknown'); ?></span>
                                    <span class="text-slate-700"><?php echo (int) $stat['total']; ?> projects</span>
                                </div>
                                <div class="w-full bg-slate-200 rounded-full h-3">
                                    <div class="bg-blue-600 h-3 rounded-full" style="width: <?php echo $percent; ?>%"></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="mt-8">
                        <h4 class="text-lg font-black text-slate-900 mb-4">Recent Project Activity</h4>
                        <div class="space-y-3">
                            <?php foreach ($recentProjects as $project): ?>
                                <div class="flex items-center justify-between border border-slate-200 rounded-lg px-4 py-3">
                                    <div>
                                        <div class="font-bold text-slate-800"><?php echo htmlspecialchars($project['title']); ?></div>
                                        <div class="text-xs text-slate-500"><?php echo htmlspecialchars($project['first_name'] ?? 'Unknown'); ?> <?php echo htmlspecialchars($project['last_name'] ?? 'User'); ?></div>
                                    </div>
                                    <span class="inline-block text-xs font-bold px-2 py-1 rounded-full
                                        <?php echo ($project['status'] ?? '') === 'approved' ? 'bg-emerald-100 text-emerald-700' : (($project['status'] ?? '') === 'removed' ? 'bg-red-100 text-red-700' : 'bg-slate-100 text-slate-700'); ?>">
                                        <?php echo htmlspecialchars(($project['status'] ?? '') === 'approved' ? 'PUBLISHED' : strtoupper($project['status'] ?? 'DRAFT')); ?>
                                    </span>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </section>
            </div>
        </div>
    </div>

    <script>
        // Server-side navigation is in effect; no JS toggling needed.
    </script>
</body>
</html>
